# AdminDroid LDAP Explorer

- Module: LDAP Explorer
- Module ID: ldap-explorer
- Module version: 1.7.9.39
- Server (base): 2.0.0.33
- Client (base): 2.0.0.66
