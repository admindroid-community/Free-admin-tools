# Development Guide

This document consolidates how to set up, run, and iterate on the Community Tool in development across the server (Node/Express) and client (Ember with Engines).

## Overview

- Backend (Express): `server/`
  - Serves the Ember build in non‑development modes
  - Loads server modules from `server/module/<module-id>`
  - Manages app config in `server/config/appInfo.js`
- Frontend (Ember host app + Engines): `client/`
  - Engines located under `client/lib/{ad,graph-explorer,ldap-explorer,m365}`
  - Local addon workbench in `client/addon-workbench`

## Prerequisites

- Node.js 18+ and npm
- Git
- Ember CLI (optional but recommended for local dev): `npm i -g ember-cli`
- Need to install the communityTool exe for the default files.
- Windows is required to run the provided `.bat` packaging scripts; day‑to‑day dev on macOS/Linux is fine.

## Quick Start

Open two terminals:

1. Backend

```
cd server
npm install
npm start
```

2. Frontend

```
cd client
npm install
npm start
```

- Frontend runs at `http://localhost:4200`.
- Backend runs on `http://localhost:<SERVER_PORT>`, and if SERVER_PORT is not set, it defaults to `http://localhost:3000`.

Alternatively, use the helper script to configure env vars and start both services in separate terminals:

```
./scripts/dev-start.ps1
```

Options:

```
./scripts/dev-start.ps1 -BuildType development -ClientPort 4201 -ServerPort 3001
```

## Environment & Configuration (Backend)

Key settings are defined in `server/config/appInfo.js` and may be overridden by environment variables:

- `BUILD_TYPE`: `development` | `testing` | `production` (default: `development`)
- `CORS_ORIGINS`: comma‑separated list (defaults include `http://localhost:4200`)
- `SERVER_PORT`: single port value (default: `3000`)
- `SESSION_SECRET`: cookie session secret
- `APP_INSTALL_PATH`: base directory for modules, files, logs, and backups where the app is installed
- `LOG_CLEAR_INTERVAL_DAYS`: number of days before old logs are cleared

Important note for development paths:

- Place a `.env` file in the server root directory (see sample.env for reference)
- When `BUILD_TYPE=development`, paths used by the app (modules/files/logs/etc.) resolve under `APP_INSTALL_PATH` or the default `C:\\Program Files\\AdminDroid\\Community Tool`.
- For a smoother dev experience, set `APP_INSTALL_PATH` to a writable location, e.g. your repo workspace:

## Common Tasks

- Lint (client): `cd client && npm run lint` (and `npm run lint:fix`)
- Test (client): `cd client && npm run test`
- Update CORS origins: set `CORS_ORIGINS` to include your dev host(s)
- Check server is live: open `/admindroid` on the server port

## Engines and Modules in Dev

- Ember Engines live under `client/lib/<engine>`; they build into `client/dist/engines-dist/<engine>`.
- Backend modules live under `server/module/<module-id>`:
  - In development, `ModuleLoaderService` looks for `src/router.js` inside each module folder and mounts it at `/<module-id>`.
  - In packaged builds, modules are rolled up and loaded from the installed modules directory.

## Packaging & Local Install Validation (Windows)

1. Navigate to `server/core/` and run: `npx rollup -c`. This bundles the core server CJS file into the build/ directory.
2. Next, go to each module directory and bundle them similarly.
3. Copy all bundled CJS files and place them in: `<APP_INSTALL_PATH>/modules/server/<module_id>/`
4. Navigate to the client directory and run: `npm run build`. This generates the output in the dist/ folder.
5. Copy all files from dist/ and place them in: `<APP_INSTALL_PATH>/modules/client/`

Details on artifacts and versioning are in `RELEASES.md`.

## Troubleshooting

- Port already in use: set `SERVER_PORT` to free port or stop the conflicting process.
- CORS errors in the browser: add your client origin to `CORS_ORIGINS`.
- Paths not writable on Windows: set `APP_INSTALL_PATH` to a user‑writable folder for development.
- Module not mounted: verify `server/module/<id>/src/router.js` exists and exports an Express router.
- Session/cookie issues: set `SESSION_SECRET` (or `SESSION_SECRETS`) and clear cookies during debugging.

## References

- Backend notes: `server/README.md`
- Frontend notes: `client/README.md`
- Contribution guidelines: `CONTRIBUTING.md`
- Packaging and releases: `RELEASES.md`
