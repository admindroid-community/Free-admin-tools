# Security Policy

## Supported Versions

We aim to keep the latest release and the previous minor release in a supported state. Older versions may not receive security updates.

## Reporting a Vulnerability

Please do not open public issues for security vulnerabilities.

- Email: support [at] admindroid [dot] com with details (proof of concept, affected versions, environment). Replace [at] with @ and [dot] with . when sending.
- Optionally, use GitHub’s private security advisory workflow if enabled for this repository.

We will acknowledge receipt within 3–5 business days and work with you on validation, remediation, and coordinated disclosure. If a CVE is appropriate, we will handle or coordinate it.

## Safe Harbor

We support responsible, good‑faith research. Avoid any actions that could harm users or data, and do not access, modify, or exfiltrate data that does not belong to you.
