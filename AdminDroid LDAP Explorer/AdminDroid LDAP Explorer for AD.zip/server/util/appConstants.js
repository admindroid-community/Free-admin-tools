const TOOL_INFO = {
  ad: 'ad',
  m365: 'm365',
  graphExplorer: 'graph-explorer',
  ldapExplorer: 'ldap-explorer',
  baseClient: 'baseClient',
  baseServer: 'baseServer',
};

module.exports = { TOOL_INFO };
