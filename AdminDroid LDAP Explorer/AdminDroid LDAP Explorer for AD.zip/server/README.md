# Backend Development Notes

## Error Handling & Logging

The server uses a standardized error pattern to ensure consistent API responses and logs.

- Always throw errors via `sendAndLogError(loggerNamespace, message, statusCode, details)` from `server/util/errorResponse.js`.
- Do not send responses directly from services. Throw and let the global `errorHandler` middleware format the response.
- Controllers may early‑validate input and call `sendAndLogError` on validation failures.
- Choose the right logger namespace from `server/util/logger.js` (e.g., `logger.ai`, `logger.graph`, `logger.session`, `logger.ldap`, `logger.core`).
- Avoid `console.log`; use the logger.

Example (controller validation):

```js
const { sendAndLogError } = require("../util/errorResponse");
const { logger } = require("../util/logger");

if (!req.body.apiKey) {
  sendAndLogError(
    logger.apikey,
    "Missing apiKey",
    400,
    "API key is required for authentication."
  );
}
```

Example (service failure):

```js
const { sendAndLogError } = require("../util/errorResponse");
const { logger } = require("../util/logger");

if (!response.ok) {
  sendAndLogError(
    logger.core,
    "File Download error",
    500,
    "Failed to download ZIP file"
  );
}
```

Provider adapters follow a unified mapping:

- 401 → Authentication failed
- 429 → Rate limited
- 500 → Provider internal error

## AI Providers

- Providers (OpenAI, Groq, Claude, Gemini, Cohere) are centralized under `server/core/providers/`.
- Module‑specific prompts/contexts are injected by factories in each module to preserve behavior.
- Prefer shared adapters over module‑local implementations.

## Environment Variables

- `BUILD_TYPE`: `development` | `testing` | `production` (default: `development`)
- `CORS_ORIGINS`: comma‑separated list (defaults include `http://localhost:4200`)
- `SERVER_PORT`: single port value (default: `3000`)
- `SESSION_SECRET`: cookie session secret
- `APP_INSTALL_PATH`: base directory for modules, files, logs, and backups where the app is installed
- `LOG_CLEAR_INTERVAL_DAYS`: number of days before old logs are cleared
