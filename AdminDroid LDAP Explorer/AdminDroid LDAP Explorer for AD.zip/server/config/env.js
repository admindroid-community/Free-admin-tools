const fs = require("fs");
const path = require("path");

let envPath = path.join(process.cwd(), ".env");

if (
  process.env.BUILD_TYPE === "development" &&
  path.basename(process.cwd()) !== "server"
) {
  envPath = path.join(process.cwd(), "server", ".env");
}

if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, "utf-8");
  const lines = envContent.split(/\r?\n/);

  for (const line of lines) {
    if (!line || line.startsWith("#")) continue;
    const [key, ...valParts] = line.split("=");
    const value = valParts.join("=").trim();
    if (key && value && !process.env[key]) {
      process.env[key] = value;
    }
  }
}

process.env.BUILD_TYPE = process.env.BUILD_TYPE || "development";
