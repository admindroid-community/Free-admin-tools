const RootDirName = "AdminDroid\\Community Tool";
const ServerUrl = "https://license.admindroid.com"
const SessionSecret = "a3f8d7c9b2e4f1a6c5d0e9b8a7f6d4c3b1e2f3d4a5b6c7d8e9f0a1b2c3d4e5f6";
const DefaultInstallationPath = `C:\\Program Files\\${RootDirName}`;

function parseCsv(str) {
  return String(str)
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function parseCorsOrigins(str) {
  const list = parseCsv(str);
  return list.length ? list : ["http://localhost:4200", "http://localhost:4201", "http://localhost:4202"];
}

const AppInfo = process.env.BUILD_TYPE === "development" ?
  {
    appName: RootDirName,
    adminServerUrl:
      process.env.ADMIN_SERVER_URL ||
      ServerUrl,
    sessionSecret: process.env.SESSION_SECRET || SessionSecret,
    corsOrigins: process.env.CORS_ORIGINS
      ? parseCorsOrigins(process.env.CORS_ORIGINS)
      : ["http://localhost:4200", "http://localhost:4201", "http://localhost:4202"],
    defaultInstallationPath: process.env.APP_INSTALL_PATH
      ? `${process.env.APP_INSTALL_PATH}`
      : DefaultInstallationPath,
    devServerPort: Number(process.env.SERVER_PORT || 3000),
    logClearIntervalDays: Number(process.env.LOG_CLEAR_INTERVAL_DAYS || 7),
    buildType: (process.env.BUILD_TYPE || "development").toLowerCase(),
  }
  : {
    appName: RootDirName,
    adminServerUrl: ServerUrl,
    sessionSecret: SessionSecret,
    corsOrigins: "",
    defaultInstallationPath: DefaultInstallationPath,
    buildType: (process.env.BUILD_TYPE || "production").toLowerCase(),
  };

module.exports = AppInfo;
