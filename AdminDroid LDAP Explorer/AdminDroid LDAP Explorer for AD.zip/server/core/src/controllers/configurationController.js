const configurationService = require("../services/configurationService");

class ConfigurationController {

    async getConfiguration(req, res, next) {
        try {
            const result = await configurationService.getConfigurations();
            res.status(200).json(result);
        } catch (error) {
            next(error);
        }
    }

    async setConfiguration(req, res, next) {
        try {
            const { key, value } = req.body;
            const result = await configurationService.setConfigurations(key, value);
            res.status(200).json(result);
        } catch (error) {
            next(error);
        }
    }
}




module.exports = new ConfigurationController();