const apikeyController = require("../controllers/apikeyController.js");
const { validateBody } = require("../../../util/validator.js");
const { setApiKeySchema, enableKeySchema, deleteKeySchema } = require("./validationSchemas.js");
const express = require("express");

const router = express.Router();

router.post("/apikey", validateBody(setApiKeySchema), apikeyController.setApiKey);
router.patch("/apikey", validateBody(enableKeySchema), apikeyController.enableKey);
router.delete("/apikey", validateBody(deleteKeySchema), apikeyController.deleteKey);

router.get("/providers", apikeyController.getApiKey);

module.exports = router;
