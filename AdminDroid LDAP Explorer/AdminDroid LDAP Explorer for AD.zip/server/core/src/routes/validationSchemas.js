const { z } = require("zod");

const setApiKeySchema = z.object({
  provider: z.string().min(1,'provider must be at least more than 1 characters'),
  apiKey: z.string().min(1,'Apikey must be at least more than 1 characters'),
});

const enableKeySchema = z.object({
  provider: z.string().min(1),
  keyName: z.string().min(1),
});

const deleteKeySchema = enableKeySchema;

module.exports = { setApiKeySchema, enableKeySchema, deleteKeySchema };

