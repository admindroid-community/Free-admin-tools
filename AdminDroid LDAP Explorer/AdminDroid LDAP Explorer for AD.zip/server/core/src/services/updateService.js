const path = require("path");
const { sendAndLogError } = require("../../../util/errorResponse.js");
const toolsDetailsFileServices = require("../utils/toolsDetailsFileServices");
const { logger } = require("../../../util/logger");
const fileServices = require("../../../util/fileServices");

class UpdateService {

    async updateApply(moduleId, oldPath, newPath, backupPath, isBackupEnabled = false) {
        try {
            if (isBackupEnabled) {
                const backupManifestPath = path.resolve(backupPath, moduleId, "manifest.json");
                const backupFilesPath = path.resolve(backupPath, moduleId, "backup");
                var backupManifest = {};

                backupManifest["moduleId"] = moduleId;
                backupManifest["version"] = await toolsDetailsFileServices.getModuleInfo(moduleId, "version");
                backupManifest["generatedAt"] = new Date().toLocaleString();

                await fileServices.copy(oldPath, backupFilesPath);
                await fileServices.writeFile(backupManifestPath, backupManifest, false);
            }

            // await fileServices.delete(oldPath);
            await fileServices.copy(newPath, oldPath);

            logger.core.info(` ${moduleId} Updated Successfully`);
        } catch (error) {
            logger.core.error("Apply update error : " + error);
            sendAndLogError(logger.core, "Update Error!", 500, error.message || "-")
        }
    }

    async revertApply(backupDir, desDir) {
        try {
            const backupFilesDir = path.resolve(backupDir, "backup");
            if (!fileServices.checkDirExists(backupFilesDir)) {
                logger.core.error("No Backup found!");
                return { message: "No Backup found", isSuccess: false };
            }

            await fileServices.delete(desDir);
            await fileServices.copy(backupFilesDir, desDir);

            logger.core.debug(`Backup Path : ${backupFilesDir}`);
            logger.core.info("Revert applied from backup");
            return { message: "Old files restored successfully", isSuccess: true };
        } catch (error) {
            logger.core.error(`Error in reverting update : ${JSON.stringify(error)}`);
            sendAndLogError(logger.core, "Revert Failed!", 500, error.message || "-");
        }
    }
}

module.exports = new UpdateService();
