const path = require("path");
const encryptionService = require("../../../util/encryptService.js");
const fileServices = require("../../../util/fileServices.js");
const pathUtils = require("../../../util/pathUtils.js");
const { Mutex } = require("async-mutex");
class CredentialFileService {
    constructor() {
        this.credentialDir = pathUtils.getInstalledDir();
        this.credentialFilePath = path.resolve(pathUtils.getFilesDir(), "credentialFile.txt");
        this.profileFilePath = path.resolve(pathUtils.getFilesDir(), "storedProfiles.json");
        this.providersFilePath = path.resolve(pathUtils.getFilesDir(), "providers.json");
    
        this.credentialMutex = new Mutex();
        this.profileMutex = new Mutex();
        this.ensureFileInitialized();
    }

    async ensureFileInitialized() {
        const credentialData = await fileServices.readFile(this.credentialFilePath);
        if (!credentialData.length) {
            const initialData = JSON.stringify({ API_KEY: {}, API_KEY_USAGE: {} });
            const encryptedData = encryptionService.encrypt(initialData);
            await fileServices.writeFile(this.credentialFilePath, encryptedData, true);
        }
        const profileData = await fileServices.readFile(this.profileFilePath);
        if (!profileData.length) {
            const initialData = { AD: {}, MS: {} };
            await fileServices.writeFile(this.profileFilePath, initialData, false);
        }
    }

    async withCredentialLock(fn) {
        return this.credentialMutex.runExclusive(fn);
    }

    async withProfileLock(fn) {
        return this.profileMutex.runExclusive(fn);
    }

}

module.exports = CredentialFileService;
