const resolve = require('@rollup/plugin-node-resolve');
const commonjs = require('@rollup/plugin-commonjs');
const json = require('@rollup/plugin-json');
const { builtinModules } = require('module');
const path = require('path');
const { moduleNames } = require("../util/pathUtils")

module.exports = {
  input: './server.js',
  output: {
    file: `./build/${moduleNames.baseServer}.cjs`,
    format: 'cjs',
    sourcemap: false,
    inlineDynamicImports: true,
    intro: 'console.log("Initializing server...");',
  },
  external: [...builtinModules],

  plugins: [
    resolve({
      preferBuiltins: true,
      exportConditions: ['node'],
      browser: false,
    }),
    commonjs({
      include: ['../node_modules/**', './src/**', '../config/**', '../util/**', '../core/**'],
      defaultIsModuleExports: true,
      ignoreDynamicRequires: true,
      sourceMap: true,
      transformMixedEsModules: true,
      dynamicRequireTargets: [
        'node_modules/express/lib/view.js',
        'node_modules/express/lib/view/*.js',
      ],
      dynamicRequireRoot: path.resolve(__dirname, 'node_modules'),
    }),
    json(),
  ],
};
