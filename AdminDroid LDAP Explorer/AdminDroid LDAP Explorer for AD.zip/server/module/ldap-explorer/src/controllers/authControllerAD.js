// const authServiceAD = require("../../../../core/src/services/authServiceAD.js");
const ldapService = require("../services/ldapService.js");
const {
  constructBindDN,
} = require("../../../../core/src/utils/ldapDataFormat.js");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const authServiceAD = require("../services/authServiceAD.js");
const profileService = require("../services/profileService.js");
const { logger } = require("../../../../util/logger.js");
const encryptService = require("../../../../util/encryptService.js");
const usageService = require("../../../../core/src/services/usageService.js");

class AuthControllerAD {
  async login(req, res, next) {
    try {
      let {
        username,
        domainName,
        bindPassword,
        isUPN,
        storeDetails,
        isAnonymousDataStored,
      } = req.body;
      if (!username || !domainName || !bindPassword) {
        sendAndLogError(
          logger.session,
          "Missing Required Information",
          400,
          "Please provide all necessary details to proceed with login."
        );
      }

      username = username.trim();
      domainName = domainName.trim();

      let ipAddress = '';
      if (authServiceAD.isIPAddress(domainName)) {
        try {
          const retrivedDomainName = await authServiceAD.findDomainNameByIP(domainName);
          logger.testing.session.info("Retrieved domain from IP: " + retrivedDomainName);

          if (retrivedDomainName) {
            ipAddress = domainName;
            domainName = retrivedDomainName;
          }
        } catch (err) {
          logger.testing.session.error(`Could not fetch domain name from ${domainName}: ${err.message}`);
        }
      }

      verifyUsername(username);

      const isSupportLDAPS = await authServiceAD.checkSupportLdaps(getBindDomainAddress());
      logger.session.info(`isSupportLDAPS : ${isSupportLDAPS}`);

      const ldapURL = isSupportLDAPS
        ? `ldaps://${getBindDomainAddress()}:636`
        : `ldap://${getBindDomainAddress()}:389`;
      let bindDN = constructBindDN(username, domainName, isUPN);

      bindPassword = encryptService.keyBasedDecrypt(bindPassword);
      await authServiceAD.loginWithCredentials(ldapURL, bindDN, bindPassword);

      let data;
      const userBindID = `${username}-${domainName}`.toLowerCase();
      if (storeDetails) {
        const loginData = {
          ldapURL: ldapURL,
          bindDN: bindDN,
          bindPassword: bindPassword,
          domainName: domainName,
        };

        const response = await ldapService.getThumbnailPhoto(
          loginData,
          username
        );
        data = {
          username: username,
          domainName: domainName,
          ipAddress: ipAddress,
          isUPN: isUPN,
          userBindID: userBindID,
          thumbnailPhoto: response.thumbnailPhoto || null,
        };

        await profileService.saveUserProfile(data);
      }

      const userData = {
        username: username,
        domainName: domainName,
        bindDN: bindDN,
        ldapURL: ldapURL,
        userBindID: userBindID,
        bindPassword: encryptService.encrypt(bindPassword),
      };

      let oldSessionData = req.session.ad_user ?? [];
      oldSessionData.push(userData);
      req.session.ad_user = oldSessionData;

      req.session.save((err) => {
        if (err) {
          logger.session.error(`Session save error: ${err}`);
          return sendAndLogError(
            logger.session,
            "Internal server error",
            500,
            "Failed to store session"
          );
        }
        res.status(200).send({
          isSuccess: true,
          userBindID: userBindID,
          statusCode: 200,
        });
      });


      function getBindDomainAddress() {
        return authServiceAD.isIPAddress(ipAddress) ? ipAddress : domainName;
      }

      function verifyUsername() {
        if (username.includes('@')) {
          username = username.split('@')[0];
        }        
        if (username.includes("\\")) {
          username = username.split("\\")[1];
        }
      }

    } catch (error) {
      next(error);
    }
  }

  async profile(req, res, next) {
    try {
      let storedData = await profileService.getStoredProfileData();
      storedData = storedData.AD || {};
      if (req.session.ad_user) {
        res.status(200).send({
          status: 200,
          data: {
            message: "User login credential fetched successfully",
            sessionData: req.session.ad_user.map((profile) => ({
              username: profile.username,
              domainName: profile.domainName,
              bindDN: profile.bindDN,
              userBindID: profile.userBindID,
            })),
            storedData: storedData,
          },
        });
      } else {
        res.status(200).send({
          status: 200,
          data: {
            message: "Session Closed. User logged out, Please Log in again",
            sessionData: [],
            storedData: storedData,
          },
        });
      }
    } catch (error) {
      next(error);
    }
  }

  async logout(req, res, next) {
    try {
      const userBindID = req.params.userBindID;
      let oldSessionData = req.session.ad_user ?? [];
      const updatedSessionData = oldSessionData.filter(
        (profile) => profile.userBindID !== userBindID
      );
      req.session.ad_user = updatedSessionData;
      req.session.save((err) => {
        if (err) {
          logger.session.error(`Session save error: ${err}`);
          return sendAndLogError(
            logger.session,
            "Internal server error",
            500,
            "Failed to update session"
          );
        }
        res.status(200).json({
          isSuccess: true,
          userBindID: userBindID,
          statusCode: 200,
        });
      });
    } catch (error) {
      next(error);
    }
  }

  async deleteProfile(req, res, next) {
    try {
      const userBindID = req.params.userBindID;
      let oldSessionData = req.session.ad_user ?? [];
      const updatedSessionData = oldSessionData.filter(
        (profile) => profile.userBindID !== userBindID
      );
      req.session.ad_user = updatedSessionData;
      req.session.save((err) => {
        if (err) {
          logger.session.error(`Session save error: ${err}`);
          return sendAndLogError(
            logger.session,
            "Internal server error",
            500,
            "Failed to update session"
          );
        }
      });
      const response = await profileService.deleteUserProfile(userBindID);
      res.status(200).json(response);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new AuthControllerAD();
