const encryptService = require("../../../../util/encryptService.js");
const ldapService = require("../services/ldapService.js");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const { logger } = require("../../../../util/logger.js");
const { AttributeList, TabHeaders, SortOptionsConfig, FilterTypesConfig, TabConfig, FilterPresetOptions, FilterActionsAvailableConfig } = require("../services/ldapConfig.js");
const LDAPQueryGenerator = require("../services/ldapQueryGenerator.js");

class LDAPController {

  async getConfig(req, res, next) {
    try {
      res.json({ AttributeList, TabConfig, TabHeaders, SortOptionsConfig, FilterTypesConfig, FilterPresetOptions, FilterActionsAvailableConfig });
    } catch (error) {
      next(error);
    }
  }

  async executeLDAPRequest(req, res, next) {
    try {
      if (!req.session.ad_user) {
        sendAndLogError(logger.ldap, "Missing Bind DN.", 401, "Session Closed, Please Loggin again.");
      }

      const userBindID = req.params.userBindID;
      const paginationId = Number(req.query.paginationId ?? 0);
      const pageSize = Number(req.query.pageSize ?? 100);
      const sortLimit = Number(req.query.sortLimit ?? 2000);
      const selectedProfile = (req.session.ad_user ?? []).find(profile => profile.userBindID === userBindID);

      if (!selectedProfile) {
        sendAndLogError(logger.ldap, "Missing Selected Domain", 400, "Kindly select the domain you want to perform actions");
      }


      const { query, appliedFilterActions } = LDAPQueryGenerator.generate(req.body);

      const params = {
        action: query,
        paginationId: paginationId,
        pageSize: pageSize,
        sortLimit: sortLimit,
        credentials: {
          ldapURL: selectedProfile.ldapURL,
          bindDN: selectedProfile.bindDN,
          bindPassword: encryptService.decrypt(selectedProfile.bindPassword)
        },
      };
      const response = await ldapService.processLdapQuery(params, false, appliedFilterActions);
      res.json(response);
    } catch (error) {
      next(error);
    }
  }

  async getThumbnailPhoto(req, res, next) {
    try {
      const { username } = req.body;
      if (!req.session.ad_user) {
        sendAndLogError(logger.ldap, "Missing Bind DN.", 401, "Session Closed, Please Loggin again.");
      }

      const userBindID = req.params.userBindID;
      const selectedProfile = (req.session.ad_user ?? []).find(profile => profile.userBindID === userBindID);

      if (!selectedProfile) {
        sendAndLogError(logger.ldap, "Missing Selected Domain", 400, "Kindly select the domain you want to perform actions");
      }

      const data = {
        ldapURL: selectedProfile.ldapURL,
        bindDN: selectedProfile.bindDN,
        bindPassword: encryptService.decrypt(selectedProfile.bindPassword),
        domainName: selectedProfile.domainName
      };
      const response = await ldapService.getThumbnailPhoto(data, username);
      res.json(response);
    } catch (error) {
      next(error);
    }
  }

}

module.exports = new LDAPController();
