require("../../../config/polyfills.js");

const express = require("express");

const authControllerAD = require("./controllers/authControllerAD.js");
const ldapController = require("./controllers/ldapController.js");
const { logger } = require("../../../util/logger.js");

const router = express.Router();
logger.production.core.info(`ldapRouter`);
// ad-auth routes
router.post("/login", authControllerAD.login);
router.get("/profile", authControllerAD.profile);
router.delete("/profile/:userBindID", authControllerAD.deleteProfile);
router.post("/logout/:userBindID", authControllerAD.logout);

// ldap routes
router.get("/ldap/config",ldapController.getConfig);
router.post("/ldap/:userBindID", ldapController.executeLDAPRequest);
router.post("/thumbnail-photo/:userBindID", ldapController.getThumbnailPhoto);

module.exports = router;
