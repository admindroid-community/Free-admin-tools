class LDAPPaginationCookieManager {
    static cookies = new Map();
    static paginationId = 1;

    static set(paginationId, continuationCookie, entriesProcessed, maxEntryLimit) {
        const id = (paginationId <= 0 || !this.cookies.has(paginationId)) ? this.paginationId++ : paginationId;
        this.cookies.set(id, {
            cookie: continuationCookie,
            count: entriesProcessed,
            limit: maxEntryLimit
        });

        return id;
    }

    static has(paginationId) {
        return this.cookies.has(paginationId);
    }

    static get(paginationId) {
        return this.cookies.has(paginationId) ? this.cookies.get(paginationId) : null;
    }

    static delete(paginationId) {
        return this.cookies.delete(paginationId);
    }

    static clearAll() {
        this.cookies.clear();
        this.paginationId = 1;
    }
}

module.exports = LDAPPaginationCookieManager;