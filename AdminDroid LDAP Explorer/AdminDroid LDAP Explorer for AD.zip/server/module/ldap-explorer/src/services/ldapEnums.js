const ScopeTypes = Object.freeze({
    BASE: 0,
    ONE: 1,
    SUB: 2,
});

const ObjectTypes = Object.freeze({
    ALL: 0,
    USER: 1,
    GROUP: 2,
    COMPUTER: 3,
    CONTACT: 4,
    OU: 5
});

const FilterActionsAvailable = Object.freeze({
    SORT: "sort",
    FILTER: "filter",
    CUSTOMIZE_TABLE: "customizeTable"
});

const FilterTypes = Object.freeze({
    EQUALS: 0,
    NOT_EQUALS: 1,
    CONTAINS: 2,
    NOT_CONTAINS: 3,
    STARTS_WITH: 4,
    ENDS_WITH: 5,
    GREATER_THAN_OR_EQUAL: 6,
    LESS_THAN_OR_EQUAL: 7,
    EMPTY: 8,
    NON_EMPTY: 9
});

const FilterValueTypes = Object.freeze({
    STRING: 0,
    DATE_AND_TIME: 1,
    PRESET_OPTIONS: 2
});

const FilterLogicalConditionTypes = Object.freeze({
    OR: 0,
    AND: 1
});

const SortTypes = Object.freeze({
    ASCENDING: 0,
    DESCENDING: 1
});

const SortOptions = Object.freeze({
    A_TO_Z: 0,
    Z_TO_A: 1,
    LOW_TO_HIGH: 2,
    HIGH_TO_LOW: 3,
    OLD_TO_NEW: 4,
    NEW_TO_OLD: 5
});

module.exports = {
    ScopeTypes,
    ObjectTypes,
    FilterActionsAvailable,
    FilterTypes,
    FilterLogicalConditionTypes,
    FilterValueTypes,
    SortTypes,
    SortOptions
}