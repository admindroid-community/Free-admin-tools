const { logger } = require("../../../../util/logger");
const { SortTypes, ObjectTypes, FilterTypes, ScopeTypes, FilterLogicalConditionTypes, FilterValueTypes, FilterActionsAvailable } = require("./ldapEnums");
const { ObjectClassFilters, FilterPresetOptions, AttributeList, TabHeaders, ErrorMessage } = require("./ldapConfig");

class LDAPQueryGenerator {


    static appliedFilterActions = [];


    static generate(params) {

        this.appliedFilterActions = [];

        if (params?.operation !== "search") {
            return { query: params, appliedFilterActions: this.appliedFilterActions };
        }

        var query = {};

        query.operation = params.operation;
        query.dn = params.dn ?? "-"
        query.params = {};

        query.params.scope = this.prepareScope(params.scope);
        query.params.filter = this.prepareLDAPFilter(params.filter, params.objectType);
        query.params.attributes = this.appendMustIncludedAttributes(params.attributes || ["cn", "sn", "mail"], params.objectType);

        query.sortKeys = params.sortKeys;
        query.size = params.size;

        return { query: query, appliedFilterActions: this.appliedFilterActions };
    }

    static prepareScope(scope) {
        if (scope == null || !Object.values(ScopeTypes).includes(scope)) {
            return "sub";
        } else {
            switch (scope) {
                case ScopeTypes.BASE:
                    return "base";
                case ScopeTypes.ONE:
                    return "one";
                case ScopeTypes.SUB:
                    return "sub";
            }
        }
    }

    static prepareLDAPFilter(filters, objectType) {

        let filterQuery = "";

        logger.testing.ldap.debug("filters : " + JSON.stringify(filters));
        logger.testing.ldap.debug("objectType : " + objectType);
        logger.testing.ldap.debug("filterQuery : " + filterQuery);

        if (objectType == null || !Object.values(ObjectTypes).includes(objectType)) {
            filterQuery = ObjectClassFilters[ObjectTypes.ALL].filter;
        } else {
            filterQuery = ObjectClassFilters[objectType].filter;
        }

        logger.testing.ldap.debug("filterQuery : " + filterQuery);

        if (filters &&
            typeof filters === 'object' &&
            Object.keys(filters).length > 0) {

            const customFilters = this.prepareGroupedFilter(filters);
            filterQuery = `(&${filterQuery}${customFilters})`;

            logger.testing.ldap.debug("filterQuery : " + filterQuery);
            this.appliedFilterActions.push(FilterActionsAvailable.FILTER);
        }

        return this.appendExclusionFilters(filterQuery);
    }

    static prepareGroupedFilter(filters) {

        const attrUsingFileTimeFormat = ["accountexpires", "lastlogon", "lastlogoff", "lastlogontimestamp", "pwdlastset", "badpasswordtime", "lockouttime", "creationtime"];
        const attrUsingGeneralizedTimeFormat = ["whencreated", "whenchanged", "modifytimestamp", "createtimestamp"];

        if (!filters || typeof filters !== 'object') return false;

        if ('logicType' in filters) {
            if (!Object.values(FilterLogicalConditionTypes).includes(filters.logicType)) {
                return false;
            }
        }

        if (!Array.isArray(filters.condition) || filters.condition.length === 0) {
            return false;
        }

        let filterQueryList = [];

        filters.condition.forEach(filter => {

            logger.testing.ldap.debug("filter item : " + JSON.stringify(filter))
            if (filter.logicType != null && filter.condition != null) {
                filterQueryList.push(this.prepareGroupedFilter(filter) ?? "");
                return;
            };

            if (filter.filterType == null) return;
            if (
                typeof filter.filterType === "number" &&
                !Object.values(FilterTypes).includes(filter.filterType) &&
                this.isNullOrEmpty(filter.attribute) &&
                this.isNullOrEmpty(filter.value)
            ) return;


            let transformedValue = filter.value;

            if (!(filter.filterType === FilterTypes.EMPTY || filter.filterType === FilterTypes.NON_EMPTY)) {

                if ((attrUsingFileTimeFormat.includes(filter.attribute.toLowerCase()))) {
                    transformedValue = this.convertToLdapFileTime(filter.value);
                }
                if ((attrUsingGeneralizedTimeFormat.includes(filter.attribute.toLowerCase()))) {
                    logger.testing.ldap.debug("filter.value : " + filter.value);
                    transformedValue = this.convertToGeneralizedTime(filter.value);
                    logger.testing.ldap.debug("transformedValue : " + transformedValue);
                }
            }

            let filterString = '';
            const attr = filter.attribute;

            logger.testing.ldap.debug("filter : " + JSON.stringify(filter));

            logger.testing.ldap.debug("filter.valueType : " + JSON.stringify(filter.valueType));
            logger.testing.ldap.debug("(filter.valueType === FilterValueTypes.PRESET_OPTIONS) : " + JSON.stringify((filter.valueType === FilterValueTypes.PRESET_OPTIONS)));

            logger.testing.ldap.debug("attr : " + JSON.stringify(attr));
            logger.testing.ldap.debug("FilterPresetOptions[attr] : " + JSON.stringify(FilterPresetOptions[attr]));

            if (filter.valueType === FilterValueTypes.PRESET_OPTIONS) {
                if (FilterPresetOptions[attr] != null) {
                    logger.testing.ldap.debug("inside the true : ");
                    filterString = FilterPresetOptions[attr][filter.value].value;
                    logger.testing.ldap.debug("inside the true filterString : " + filterString);
                }
            } else {

                const attrLower = attr.toLowerCase();

                const isGeneralizedTime = attrUsingGeneralizedTimeFormat.includes(attrLower);
                const isFileTime = attrUsingFileTimeFormat.includes(attrLower);

                const equalFilter = () => {
                    if (isGeneralizedTime) {
                        return this.createEqualToGeneralizedTimeFilterRange(attr, filter.value);
                    }
                    if (isFileTime) {
                        return this.createEqualToLdapTimeFilterRange(attr, filter.value);
                    }
                    return `(${attr}=${transformedValue})`;
                };

                switch (filter.filterType) {

                    case FilterTypes.EQUALS:
                        filterString = equalFilter();
                        break;

                    case FilterTypes.NOT_EQUALS:
                        filterString = `(!${equalFilter()})`;
                        break;

                    case FilterTypes.CONTAINS:
                        filterString = `(${attr}=*${transformedValue}*)`;
                        break;

                    case FilterTypes.NOT_CONTAINS:
                        filterString = `(!(${attr}=*${transformedValue}*))`;
                        break;

                    case FilterTypes.STARTS_WITH:
                        filterString = `(${attr}=${transformedValue}*)`;
                        break;

                    case FilterTypes.ENDS_WITH:
                        filterString = `(${attr}=*${transformedValue})`;
                        break;

                    case FilterTypes.GREATER_THAN_OR_EQUAL:
                        filterString = `(${attr}>=${transformedValue})`;
                        break;

                    case FilterTypes.LESS_THAN_OR_EQUAL:
                        filterString = `(${attr}<=${transformedValue})`;
                        break;

                    case FilterTypes.EMPTY:
                        filterString = `(!(${attr}=*))`;
                        break;

                    case FilterTypes.NON_EMPTY:
                        filterString = `(${attr}=*)`;
                        break;
                }
            }
            filterQueryList.push(filterString);
        });

        if (filterQueryList.length === 0) return "";

        const operation = filters.logicType === FilterLogicalConditionTypes.AND ? "&" : "|";
        return `(${operation}${filterQueryList.join("")})`

    }

    static appendExclusionFilters(userFilter) {
        const exclusionFilters = [
            // '(!(cn=*system*))',
            '(!(cn=*wmipolicy*))',
            '(!(cn=*ipsec*))'
        ].join('');
        const finalFilter = `(&${userFilter}${exclusionFilters})`;
        logger.testing.ldap.debug("final filter : " + finalFilter);
        return finalFilter;
    }

    static appendMustIncludedAttributes(requestedAttributes, objectType) {

        const mustIncludedAttributes = ["distinguishedName"];

        if (!Array.isArray(requestedAttributes)) {
            requestedAttributes = typeof requestedAttributes === 'string' ? requestedAttributes.split(',').map(attr => attr.trim()) : requestedAttributes;
        }

        if (requestedAttributes?.length < TabHeaders[objectType]?.length) this.appliedFilterActions.push(FilterActionsAvailable.CUSTOMIZE_TABLE);

        const lowerCaseAttributes = requestedAttributes.map(attr => attr.toLowerCase().trim());

        mustIncludedAttributes.forEach(element => {
            if (!lowerCaseAttributes.includes(element.toLowerCase().trim())) {
                requestedAttributes.push(element.trim());
            }
        });

        return requestedAttributes;
    }

    static isNullOrEmpty(s) {
        return s == null || s.trim() === "";
    }

    static standardizeDateInput(dateString) {
        if (!dateString || typeof dateString !== 'string') {
            throw new Error('Invalid date string');
        }

        dateString = dateString.trim();

        if (!dateString.includes('T')) {
            const localDate = new Date(`${dateString}T00:00:00`);
            return localDate.toISOString().replace('.000', '');
        }

        const hasTimeZone = /Z$|[+-]\d{2}:?\d{2}$/.test(dateString);

        let date;

        if (hasTimeZone) {
            date = new Date(dateString);
        } else {
            const [datePart, timePart] = dateString.split('T');
            const [h = '00', m = '00', s = '00'] = timePart.split(':');

            const local = new Date(
                `${datePart}T${h.padStart(2, '0')}:${m.padStart(2, '0')}:${s.padStart(2, '0')}`
            );

            date = local;
        }

        if (isNaN(date.getTime())) {
            throw new Error('Invalid date format');
        }

        return date.toISOString().replace('.000', '');
    }

    static convertToLdapFileTime(dateString) {
        const standardizedDateString = this.standardizeDateInput(dateString);
        const AD_EPOCH_OFFSET_MS = 11644473600000n;
        const inputDate = new Date(standardizedDateString);
        const msSinceUnixEpoch = BigInt(inputDate.getTime());
        const msSinceADEpoch = msSinceUnixEpoch + AD_EPOCH_OFFSET_MS;
        const fileTime = msSinceADEpoch * 10000n;
        return fileTime.toString();
    }

    static convertToGeneralizedTime(dateString) {
        const standardizedDateString = this.standardizeDateInput(dateString);

        const date = new Date(standardizedDateString);

        if (isNaN(date.getTime())) {
            return null;
        }

        const pad = (num) => String(num).padStart(2, '0');

        const year = date.getUTCFullYear();
        const month = pad(date.getUTCMonth() + 1);
        const day = pad(date.getUTCDate());
        const hour = pad(date.getUTCHours());
        const minute = pad(date.getUTCMinutes());
        const second = pad(date.getUTCSeconds());

        const generalizedTime = `${year}${month}${day}${hour}${minute}${second}.0Z`;

        return generalizedTime;
    }

    static createEqualToGeneralizedTimeFilterRange(attributeName, targetDateString) {

        const startGeneralizedTimeFull = this.convertToGeneralizedTime(targetDateString);

        if (!startGeneralizedTimeFull) {
            return "Invalid date input for GeneralizedTime filter.";
        }

        const standardizedStartString = this.standardizeDateInput(targetDateString);
        const startDate = new Date(standardizedStartString);

        const pad = (num) => String(num).padStart(2, '0');

        const year = startDate.getUTCFullYear();
        const month = pad(startDate.getUTCMonth() + 1);
        const day = pad(startDate.getUTCDate());

        const endTime = `${year}${month}${day}235959.0Z`;

        return `(&(${attributeName}>=${startGeneralizedTimeFull})(${attributeName}<=${endTime}))`;
    }

    static createEqualToLdapTimeFilterRange(attributeName, targetDateString) {

        const startTimeTicks = this.convertToLdapFileTime(targetDateString);

        if (startTimeTicks === null || startTimeTicks === 'NaN') {
            return "";
        }

        const startDate = new Date(this.standardizeDateInput(targetDateString));
        const nextDayDate = new Date(startDate);
        nextDayDate.setUTCDate(startDate.getUTCDate() + 1);

        const pad = (num) => String(num).padStart(2, '0');
        const nextDayString = `${nextDayDate.getUTCFullYear()}-${pad(nextDayDate.getUTCMonth() + 1)}-${pad(nextDayDate.getUTCDate())}T00:00:00Z`;

        const nextDayMidnightTicks = this.convertToLdapFileTime(nextDayString);

        const endTimeTicks = BigInt(nextDayMidnightTicks) - BigInt(1);

        return `(&(${attributeName}>=${startTimeTicks})(${attributeName}<=${endTimeTicks.toString()}))`;
    }
}

module.exports = LDAPQueryGenerator;
