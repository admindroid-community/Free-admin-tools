// const mcpClient = require('../mcp/client.js');
const ldap = require("ldapjs");
const { formateData, decodePrimaryGroupID } = require("../../../../core/src/utils/ldapDataFormat");
const { logger } = require("../../../../util/logger");
const LDAPPaginationCookieManager = require("./ldapPaginationManager");
const { SortTypes, FilterTypes, FilterActionsAvailable } = require("./ldapEnums");
const { AttributeList, ErrorMessage } = require("./ldapConfig");
class LDAPService {

    async getThumbnailPhoto(data, username) {
        let client;

        try {
            client = await this.makeConnection(
                data.ldapURL,
                data.bindDN,
                data.bindPassword
            );

            const baseDN = `DC=${data.domainName.split('.').join(',DC=')}`;
            const opts = {
                scope: 'sub',
                filter: `(sAMAccountName=${username})`,
                attributes: ['thumbnailPhoto']
            };

            return await new Promise((resolve, reject) => {
                client.search(baseDN, opts, (err, res) => {
                    if (err) {
                        return reject(
                            this.ldapError(
                                'LDAP search failed',
                                500,
                                err.message || err
                            )
                        );
                    }

                    let resolved = false;

                    res.on('searchEntry', (entry) => {
                        if (resolved) return;
                        resolved = true;

                        const photoAttr = entry.attributes.find(
                            attr => attr.type === 'thumbnailPhoto'
                        );

                        const base64 =
                            photoAttr?.buffers?.[0]?.toString('base64') || null;

                        resolve({
                            thumbnailPhoto: base64
                                ? `data:image/png;base64,${base64}`
                                : null
                        });
                    });

                    res.on('error', (err) => {
                        reject(
                            this.ldapError(
                                'LDAP response error',
                                500,
                                err.message || err
                            )
                        );
                    });

                    res.on('end', () => {
                        if (!resolved) {
                            reject(
                                this.ldapError(
                                    'User not found or thumbnail missing',
                                    404
                                )
                            );
                        }
                    });
                });
            });

        } catch (err) {
            throw this.ldapError(
                'Failed to connect to LDAP server',
                err.statusCode || 500,
                err.details || err.message || err
            );
        } finally {
            if (client) {
                client.unbind(() => {
                    logger.ldap.info('LDAP connection closed');
                });
            }
        }
    }

    async makeConnection(ldapURL, bindDN, bindPassword) {
        return new Promise((resolve, reject) => {
            const client = ldap.createClient({
                url: ldapURL,
                timeout: 5000,
                connectTimeout: 5000,
            });

            client.once("error", (err) => {
                logger.ldap.error(`LDAP Connection Error: ${err.message}`);
                reject(err);
            });

            client.bind(bindDN, bindPassword, (err) => {
                if (err) {
                    logger.ldap.error(`Error executing binding: ${err.message}`);
                    client.destroy();
                    return reject(err);
                }

                logger.ldap.info("LDAP bind successful");
                resolve(client);
            });
        });
    }

    async processLdapQuery(params, isInternal = false, appliedFilterActions = []) {
        const { action, credentials } = params;
        if (!credentials) {
            return this.resolveMessage("Failed to connect to LDAP server : Invalid or Empty credentials. Login again and try again", false, isInternal, { bindError: true });
        }

        return new Promise(async (resolve, reject) => {
            let client;
            try {

                try {
                    client = await this.makeConnection(
                        credentials.ldapURL,
                        credentials.bindDN,
                        credentials.bindPassword
                    );

                    logger.testing.ldap.debug("client state : connected");

                } catch (err) {
                    return resolve(
                        this.resolveMessage(
                            "Failed to connect to LDAP server",
                            false,
                            isInternal,
                            { bindError: true }
                        )
                    );
                }

                if (action.operation == "add") {
                    client.add(action.dn, action.params, (err) => {
                        client.unbind();
                        if (err) {
                            logger.ldap.error(`Add error : ${err}`);
                            resolve(this.resolveMessage(`Add failed: ${err.message}`, false, isInternal));
                            return;
                        }
                        resolve(this.resolveMessage("Object added successfully", true, isInternal));
                    });

                } else if (action.operation == "search") {

                    const users = [];

                    const pageSize = (params.pageSize ?? 100) > 1000 ? 1000 : (params.pageSize ?? 100);
                    var paginationId = params.paginationId ?? 0;
                    const sortKeys = action.sortKeys ?? [];
                    var overallLimit = action.size ?? -1;
                    const controls = [];
                    var cookieBuffer = Buffer.alloc(0);
                    var pageCookieCaptured = false;
                    var entriesProcessed = 0;
                    var effectivePageSize = pageSize;
                    var currentCount = 0;
                    var validObjectsCount = 0;
                    var hasMore = true;
                    let supportsPagination = true;

                    var hasLimitedFeatures = false;
                    var limitedErrorMessage;


                    if (sortKeys && sortKeys.length > 0) {

                        let finalSortKeys = [];
                        let mandatorySortKeyNonEmptyFilterCondition = [];

                        sortKeys.forEach(key => {
                            if (
                                typeof key.type === "number" &&
                                !Object.values(SortTypes).includes(key.type) &&
                                this.isNullOrEmpty(key.attribute)
                            ) return;
                            finalSortKeys.push(
                                {
                                    "attributeType": key.attribute,
                                    "reverseOrder": key.type === SortTypes.DESCENDING
                                }
                            );
                            mandatorySortKeyNonEmptyFilterCondition.push(
                                {
                                    attribute: key.attribute,
                                    value: "-",
                                    filterType: FilterTypes.NON_EMPTY,
                                    valueType: AttributeList[key.attribute]?.filterValueType ?? 0
                                }
                            );
                        });

                        if (finalSortKeys.length > 0) {
                            const sortControl = new ldap.ServerSideSortingRequestControl({
                                value: finalSortKeys
                            });
                            controls.push(sortControl);
                            supportsPagination = false;
                        }
                    }

                    const options = action.params;

                    if (!supportsPagination) {
                        options.paged = {
                            pageSize: 500,
                            pagePause: false
                        };
                        hasMore = false;
                        overallLimit = params.sortLimit ?? 2000;
                    }

                    if (supportsPagination) {
                        const currentCookie = LDAPPaginationCookieManager.get(paginationId);

                        logger.testing.ldap.debug("cuurent cookie : " + JSON.stringify(currentCookie));

                        if (currentCookie) {
                            if (currentCookie.cookie && typeof currentCookie.cookie === 'string' && currentCookie.cookie.length > 0) {
                                cookieBuffer = Buffer.from(currentCookie.cookie, 'base64');
                            }
                            if (currentCookie.limit && currentCookie.count) {
                                entriesProcessed = currentCookie.count ?? 0;
                                if (currentCookie.limit > 0) {
                                    const remainingLimit = currentCookie.limit - entriesProcessed;
                                    effectivePageSize = Math.min(pageSize, remainingLimit);
                                }
                            }
                        }

                        if (effectivePageSize <= 0) {
                            hasMore = false;
                        }

                        const pagedControl = new ldap.PagedResultsControl({
                            value: {
                                size: effectivePageSize,
                                cookie: cookieBuffer || new Buffer.alloc(0)
                            },
                        });
                        controls.push(pagedControl);
                    }

                    // Debug Logs
                    logger.testing.ldap.debug("pageSize: " + JSON.stringify(pageSize));
                    logger.testing.ldap.debug("paginationId: " + JSON.stringify(paginationId));
                    logger.testing.ldap.debug("overallLimit: " + JSON.stringify(overallLimit));
                    logger.testing.ldap.debug("controls: " + JSON.stringify(controls));
                    logger.testing.ldap.debug("cookieBuffer: " + JSON.stringify(cookieBuffer));
                    logger.testing.ldap.debug("pageCookieCaptured: " + JSON.stringify(pageCookieCaptured));
                    logger.testing.ldap.debug("entriesProcessed: " + JSON.stringify(entriesProcessed));
                    logger.testing.ldap.debug("effectivePageSize: " + JSON.stringify(effectivePageSize));
                    logger.testing.ldap.debug("currentCount: " + JSON.stringify(currentCount));
                    logger.testing.ldap.debug("validObjectsCount: " + JSON.stringify(validObjectsCount));
                    logger.testing.ldap.debug("hasMore: " + JSON.stringify(hasMore));
                    logger.testing.ldap.debug("options: " + JSON.stringify(options));

                    client.search(
                        action.dn,
                        options,
                        controls,
                        (err, res) => {
                            if (err) {
                                client.unbind();
                                logger.ldap.error(`Search error : ${err}`);
                                resolve(this.resolveMessage(`Search failed: ${err.message}`, false, isInternal, { bindError: true }));
                                return;
                            }

                            res.on("searchEntry", (entry) => {

                                if (overallLimit > 0 && users?.length >= overallLimit) {
                                    // res.emit('end');
                                    res.removeAllListeners('searchEntry');
                                    hasMore = false;
                                    logger.testing.ldap.debug(`Max limit reached : ${overallLimit}`);
                                    logger.testing.ldap.debug(`Max limit reached and stoped on entry dn : ${entry.dn}`);
                                } else {

                                    currentCount++;
                                    const needToSkipSystemObjects = options.scope === "sub"

                                    const dn = entry.dn.toString().toLowerCase();
                                    if (needToSkipSystemObjects &&
                                        (
                                            dn.includes("cn=system") ||
                                            dn.includes("cn=wmipolicy") ||
                                            dn.includes("cn=ipsec")
                                        )
                                    ) {
                                        logger.testing.ldap.debug(`SKIPPED SYSTEM ENTRY: ${entry.dn?.toString()}`);
                                    } else {

                                        const rawAttributes = entry.attributes;
                                        const user = {};

                                        for (const attr of rawAttributes) {
                                            if (attr.type && attr.values && attr.values.length > 0) {
                                                const attrType = attr.type.toLowerCase();

                                                const skipAttrs = [
                                                    "instancetype", "primarygroupid", "dsasignature",
                                                    "dscorepropagationdata", "userparameters", "ntsecuritydescriptor", "dnsrecord"
                                                ];

                                                if (!skipAttrs.includes(attrType)) {
                                                    const formatedData = formateData(attr);
                                                    user[attr.type] = formatedData;
                                                }
                                            }
                                        }

                                        if (Object.keys(user).length > 0) {
                                            users.push(user);
                                            validObjectsCount++;
                                        }
                                        else {
                                            logger.testing.ldap.debug(`SKIPPED EMPTY ENTRY: ${entry.dn?.toString()}`);
                                        }
                                    }
                                }
                            });

                            res.on("end", async (result) => {

                                const responseControls = result?.controls || [];

                                const sssControl = responseControls.find(c => c.type === '1.2.840.113556.1.4.474');
                                const pagedControl = result.controls.find(c => c.type === '1.2.840.113556.1.4.319');

                                if (pagedControl && pagedControl.value && pagedControl.value.cookie) {
                                    const newCookieBuffer = pagedControl.value.cookie;
                                    if (supportsPagination && newCookieBuffer.length > 0) {
                                        const newCookie = newCookieBuffer.toString('base64');
                                        logger.testing.ldap.debug("newCookie end : " + newCookie);
                                        paginationId = LDAPPaginationCookieManager.set(paginationId, newCookie, (entriesProcessed + validObjectsCount), overallLimit);
                                    } else {
                                        hasMore = false;
                                    }
                                }

                                if (!supportsPagination && users?.length > 0) {
                                    const isSortSuccessful = sssControl?.value?.result === 0;

                                    if (isSortSuccessful) {
                                        logger.testing.ldap.debug('Sorting was successful.');
                                        appliedFilterActions.push(FilterActionsAvailable.SORT);
                                    } else {
                                        logger.testing.ldap.debug(
                                            sssControl
                                                ? `Sorting failed with Error Code: ${sssControl.value.result}`
                                                : 'Server did not return a sorting control (sorting was ignored).'
                                        );

                                        hasLimitedFeatures = true;
                                        limitedErrorMessage = ErrorMessage.SORT_LIMIT;
                                    }
                                }

                                if ((overallLimit > 0 && (entriesProcessed + validObjectsCount) >= overallLimit)) {
                                    hasMore = false;
                                }
                                let isSuccess = true;
                                if (!isInternal) isSuccess = users.length > 0;
                                client.unbind();
                                if (!hasMore) LDAPPaginationCookieManager.delete(paginationId);
                                logger.testing.ldap.debug("users : " + users.length)

                                try {
                                    const balanceObjectCount = pageSize - validObjectsCount;
                                    if (hasMore && balanceObjectCount > 0) {

                                        let balanceObjectsParams = params;

                                        balanceObjectsParams.pageSize = balanceObjectCount;
                                        balanceObjectsParams.paginationId = paginationId;

                                        const balanceObjects = await this.processLdapQuery(balanceObjectsParams, true, appliedFilterActions);
                                      
                                        if (balanceObjects && balanceObjects.isSuccess) {
                                            users.push(...balanceObjects.data);
                                            hasMore = balanceObjects.hasMore;
                                            validObjectsCount += balanceObjects.data.length ?? 0;
                                        }
                                    }
                                } catch (e) {
                                    logger.ldap.error("Failed internal call : " + e);
                                }

                                resolve(
                                    this.resolveMessage(
                                        isSuccess ? users : "No records found. Please try again with different criteria",
                                        isSuccess,
                                        isInternal,
                                        {
                                            supportsPagination: supportsPagination,
                                            hasMore: hasMore,
                                            paginationId: paginationId,
                                            currentCount: validObjectsCount,
                                            pageSize: pageSize,
                                            entriesProcessed: (entriesProcessed + validObjectsCount),
                                            maxEntryLimit: overallLimit,
                                            hasLimitedFeatures: hasLimitedFeatures,
                                            limitedErrorMessage: limitedErrorMessage,
                                            appliedFilterActions: appliedFilterActions
                                        }
                                    )
                                );
                            });

                            res.on("error", (error) => {
                                client.unbind();
                                logger.ldap.error(`Search error : ${error}`);
                                resolve(this.resolveMessage(`Search failed: ${error.message}`, false, isInternal, { bindError: true }));
                            });
                        }
                    );

                } else if (action.operation == "modify") {
                    const changesArray = action.changes.map((change) => {
                        const operation =
                            change.operation === "add"
                                ? "add"
                                : change.operation === "replace"
                                    ? "replace"
                                    : "delete";
                        return {
                            operation: operation,
                            modification: new ldap.Attribute(change.modification),
                        };
                    });

                    client.modify(action.dn, changesArray, (err) => {
                        client.unbind();
                        if (err) {
                            logger.ldap.error(`Modify error : ${err}`);
                            resolve(this.resolveMessage(`Update failed: ${err.message}`, false, isInternal));
                            return;
                        }
                        resolve(this.resolveMessage("Object details updated successfully", true, isInternal));
                    });

                } else if (action.operation == "delete") {
                    client.del(action.dn, (err) => {
                        client.unbind();
                        if (err) {
                            logger.ldap.error(`Delete error : ${err}`);
                            resolve(this.resolveMessage(`Delete failed: ${err.message}`, false, isInternal));
                            return;
                        }
                        resolve(this.resolveMessage("Object deleted successfully", true, isInternal));
                    });
                } else {
                    client.unbind();
                    resolve(this.resolveMessage("Invalid operation", false, isInternal));
                }

            } catch (err) {
                logger.ldap.error(`Unknowns error : ${err}`);
                if (client) {
                    client.unbind(function (unbindErr) {
                        if (unbindErr) logger.ldap.error(`Unbind error in catch: ${unbindErr}`);
                    });
                }
                return resolve(this.resolveMessage(`Something went wrong : ${err.message}`, false, isInternal, { bindError: true }));
            }
        });
    }

    resolveMessage(
        message,
        isSuccess,
        isInternal,
        {
            supportsPagination = true,
            hasMore = false,
            paginationId = -1,
            currentCount = 0,
            pageSize = 0,
            entriesProcessed = 0,
            maxEntryLimit = 0,
            hasLimitedFeatures = false,
            limitedErrorMessage = "",
            bindError = false,
            appliedFilterActions = []
        } = {}
    ) {
        const isString = typeof message === "string";

        const responseObject = {
            isSuccess,
            supportsPagination,
            hasMore,
            paginationId,
            currentCount,
            pageSize,
            entriesProcessed,
            maxEntryLimit,
            hasLimitedFeatures,
            limitedErrorMessage,
            bindError,
            appliedFilterActions
        };

        if (isInternal) {
            responseObject.type = "internal";
            responseObject.data = isString ? [] : message;
        } else {
            responseObject.type = "text";
            responseObject.text = {
                message: isString ? message : "",
                data: isString ? [] : message
            };
        }

        return responseObject;
    }

    ldapError(message, statusCode = 500, details = null) {
        const err = new Error(message);
        err.statusCode = statusCode;
        err.details = details;
        return err;
    };

}

module.exports = new LDAPService();
