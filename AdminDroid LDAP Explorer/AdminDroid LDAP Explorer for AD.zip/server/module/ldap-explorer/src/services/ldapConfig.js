const { ObjectTypes, SortOptions, SortTypes, FilterTypes, FilterValueTypes, FilterActionsAvailable } = require("./ldapEnums");

function AttrKey(attr) {
    return attr.key;
}

function createFilterPlaceholder(example) {
    return example;
}

const AttributeList = {};

function addAttribute({
    key,
    displayName,
    sortSupports = [],
    filterSupports = [FilterTypes.EMPTY, FilterTypes.NON_EMPTY],
    filterValueType = FilterValueTypes.STRING,
    placeholderExample = ""
}) {
    AttributeList[key] = {
        key,
        displayName,
        sortSupports,
        filterSupports,
        filterValueType,
        filterPlaceholder: createFilterPlaceholder(placeholderExample)
    };
}

function registerAllAttributes() {

    addAttribute({
        key: "cn",
        displayName: "Common Name",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "John Doe"
    });

    addAttribute({
        key: "name",
        displayName: "Name",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "John Doe"
    });

    addAttribute({
        key: "ou",
        displayName: "Organizational Unit",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "HQ"
    });

    addAttribute({
        key: "objectClass",
        displayName: "Object Class",
        placeholderExample: "user",
        filterSupports: [FilterTypes.EQUALS],
        filterValueType: FilterValueTypes.PRESET_OPTIONS
    });

    addAttribute({
        key: "distinguishedName",
        displayName: "Distinguished Name",
        placeholderExample: "CN=John Doe,OU=Users,DC=example,DC=com",
        filterSupports: []
    });

    addAttribute({
        key: "sAMAccountName",
        displayName: "SAM Account Name",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "jdoe"
    });

    addAttribute({
        key: "userPrincipalName",
        displayName: "User Principal Name",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "john.doe@example.com"
    });

    addAttribute({
        key: "mail",
        displayName: "Email",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "john.doe@example.com"
    });

    addAttribute({
        key: "description",
        displayName: "Description",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "This OU is for the Engineering department"
    });

    addAttribute({
        key: "displayName",
        displayName: "Display Name",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "John Doe"
    });

    addAttribute({
        key: "givenName",
        displayName: "Given Name",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "John"
    });

    addAttribute({
        key: "sn",
        displayName: "Surname",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "Doe"
    });

    addAttribute({
        key: "memberOf",
        displayName: "Member Of",
        placeholderExample: "Administrators",
        filterSupports: []
    });

    addAttribute({
        key: "telephoneNumber",
        displayName: "Telephone Number",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "+91-9876543210"
    });

    addAttribute({
        key: "mobile",
        displayName: "Mobile Number",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "+91-9876543210"
    });

    addAttribute({
        key: "title",
        displayName: "Job Title",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "Software Engineer"
    });

    addAttribute({
        key: "department",
        displayName: "Department",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "IT"
    });

    addAttribute({
        key: "manager",
        displayName: "Manager",
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "Jane Smith"
    });

    addAttribute({
        key: "pwdLastSet",
        displayName: "Password Last Set",
        sortSupports: [SortOptions.OLD_TO_NEW, SortOptions.NEW_TO_OLD],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.GREATER_THAN_OR_EQUAL, FilterTypes.LESS_THAN_OR_EQUAL
        ],
        filterValueType: FilterValueTypes.DATE_AND_TIME,
        placeholderExample: "2025-12-11 10:00"
    });

    addAttribute({
        key: "lastLogon",
        displayName: "Last Logon",
        sortSupports: [SortOptions.OLD_TO_NEW, SortOptions.NEW_TO_OLD],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.GREATER_THAN_OR_EQUAL, FilterTypes.LESS_THAN_OR_EQUAL
        ],
        filterValueType: FilterValueTypes.DATE_AND_TIME,
        placeholderExample: "2025-12-11 09:30"
    });

    addAttribute({
        key: "lastLogonTimestamp",
        displayName: "Last Logon Timestamp",
        sortSupports: [SortOptions.OLD_TO_NEW, SortOptions.NEW_TO_OLD],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.GREATER_THAN_OR_EQUAL, FilterTypes.LESS_THAN_OR_EQUAL
        ],
        filterValueType: FilterValueTypes.DATE_AND_TIME,
        placeholderExample: "2025-12-11 09:30"
    });

    addAttribute({
        key: "accountExpires",
        displayName: "Account Expires",
        sortSupports: [SortOptions.OLD_TO_NEW, SortOptions.NEW_TO_OLD],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.GREATER_THAN_OR_EQUAL, FilterTypes.LESS_THAN_OR_EQUAL
        ],
        filterValueType: FilterValueTypes.DATE_AND_TIME,
        placeholderExample: "2026-01-01 00:00"
    });

    addAttribute({
        key: "userAccountControl",
        displayName: "User Account Control",
        filterSupports: [
            FilterTypes.EQUALS
        ],
        placeholderExample: "Disabled Accounts",
        filterValueType: FilterValueTypes.PRESET_OPTIONS
    });

    addAttribute({
        key: "dNSHostName",
        displayName: "DNS Host Name",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
        ],
        placeholderExample: "server01.example.com"
    });

    addAttribute({
        key: "operatingSystem",
        displayName: "Operating System",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
        ],
        placeholderExample: "Windows 11 Pro"
    });

    addAttribute({
        key: "operatingSystemVersion",
        displayName: "Operating System Version",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
        ],
        placeholderExample: "10.0.22621"
    });

    addAttribute({
        key: "servicePrincipalName",
        displayName: "SPN (Service Principal Name)",
        placeholderExample: "HTTP/server01.example.com"
    });

    addAttribute({
        key: "whenCreated",
        displayName: "When Created",
        sortSupports: [SortOptions.OLD_TO_NEW, SortOptions.NEW_TO_OLD],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.GREATER_THAN_OR_EQUAL, FilterTypes.LESS_THAN_OR_EQUAL
        ],
        filterValueType: FilterValueTypes.DATE_AND_TIME,
        placeholderExample: "2025-12-01 12:00"
    });

    addAttribute({
        key: "whenChanged",
        displayName: "When Changed",
        sortSupports: [SortOptions.OLD_TO_NEW, SortOptions.NEW_TO_OLD],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.GREATER_THAN_OR_EQUAL, FilterTypes.LESS_THAN_OR_EQUAL
        ],
        filterValueType: FilterValueTypes.DATE_AND_TIME,
        placeholderExample: "2025-12-10 15:30"
    });

    addAttribute({
        key: "managedBy",
        displayName: "Managed By",
        placeholderExample: "Jane Smith",
    });

    addAttribute({
        key: "groupType",
        displayName: "Group Type",
        filterSupports: [
            FilterTypes.EQUALS
        ],
        placeholderExample: "Security",
        filterValueType: FilterValueTypes.PRESET_OPTIONS
    });

    addAttribute({
        key: "member",
        displayName: "Group Members",
        placeholderExample: "John Doe"
    });

    addAttribute({
        key: "objectGUID",
        displayName: "Object GUID",
        placeholderExample: "550e8400-e29b-41d4-a716-446655440000",
        filterSupports: []
    });

    addAttribute({
        key: "adminCount",
        displayName: "Admin Count",
        sortSupports: [SortOptions.LOW_TO_HIGH, SortOptions.HIGH_TO_LOW],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS,
            FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
        ],
        placeholderExample: "1"
    });

    addAttribute({
        key: "thumbnailPhoto",
        displayName: "Thumbnail Photo",
        placeholderExample: "user_photo.jpg"
    });

    addAttribute({
        key: "c",
        displayName: "Country",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "IN"
    });

    addAttribute({
        key: "logonHours",
        displayName: "Logon Hours",
        placeholderExample: "09:00-18:00"
    });

    addAttribute({
        key: "proxyAddresses",
        displayName: "Proxy Addresses",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "SMTP:john.doe@example.com"
    });

    addAttribute({
        key: "company",
        displayName: "Company",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "Example Corp"
    });

    addAttribute({
        key: "targetAddress",
        displayName: "Target Address",
        sortSupports: [SortOptions.A_TO_Z, SortOptions.Z_TO_A],
        filterSupports: [
            FilterTypes.EQUALS, FilterTypes.NOT_EQUALS, FilterTypes.CONTAINS, FilterTypes.NOT_CONTAINS, FilterTypes.EMPTY, FilterTypes.NON_EMPTY,
            FilterTypes.STARTS_WITH, FilterTypes.ENDS_WITH
        ],
        placeholderExample: "SMTP:john.doe@example.com"
    });

}

registerAllAttributes();

const TabConfig = {
    [ObjectTypes.ALL]: {
        id: ObjectTypes.ALL,
        displayName: "All",
        icon: "custom-icon-bullet-list-bold",
        isShown: true
    },
    [ObjectTypes.USER]: {
        id: ObjectTypes.USER,
        displayName: "Users",
        icon: "custom-icon-user-solid",
        isShown: true
    },
    [ObjectTypes.GROUP]: {
        id: ObjectTypes.GROUP,
        displayName: "Groups",
        icon: "custom-icon-group-solid",
        isShown: true
    },
    [ObjectTypes.COMPUTER]: {
        id: ObjectTypes.COMPUTER,
        displayName: "Computers",
        icon: "custom-icon-computer-solid",
        isShown: true
    },
    [ObjectTypes.CONTACT]: {
        id: ObjectTypes.CONTACT,
        displayName: "Contacts",
        icon: "custom-icon-contact-solid",
        isShown: true
    },
    [ObjectTypes.OU]: {
        id: ObjectTypes.OU,
        displayName: "Organizational Units",
        icon: "custom-icon-classification-3",
        isShown: true
    }
};

const TabHeaders = {
    [ObjectTypes.ALL]: [
        AttrKey(AttributeList.cn),
        AttrKey(AttributeList.objectClass),
        AttrKey(AttributeList.distinguishedName),
        AttrKey(AttributeList.sAMAccountName),
        AttrKey(AttributeList.userPrincipalName),
        AttrKey(AttributeList.mail),
        AttrKey(AttributeList.displayName),
        AttrKey(AttributeList.givenName),
        AttrKey(AttributeList.sn),
        AttrKey(AttributeList.memberOf),
        AttrKey(AttributeList.telephoneNumber),
        AttrKey(AttributeList.mobile),
        AttrKey(AttributeList.title),
        AttrKey(AttributeList.department),
        AttrKey(AttributeList.manager),
        AttrKey(AttributeList.pwdLastSet),
        AttrKey(AttributeList.lastLogon),
        AttrKey(AttributeList.lastLogonTimestamp),
        AttrKey(AttributeList.accountExpires),
        AttrKey(AttributeList.userAccountControl),
        AttrKey(AttributeList.dNSHostName),
        AttrKey(AttributeList.operatingSystem),
        AttrKey(AttributeList.operatingSystemVersion),
        AttrKey(AttributeList.servicePrincipalName),
        AttrKey(AttributeList.whenCreated),
        AttrKey(AttributeList.whenChanged),
        AttrKey(AttributeList.managedBy),
        AttrKey(AttributeList.groupType),
        AttrKey(AttributeList.member),
        AttrKey(AttributeList.objectGUID),
        AttrKey(AttributeList.adminCount),
    ],

    [ObjectTypes.USER]: [
        AttrKey(AttributeList.thumbnailPhoto),
        AttrKey(AttributeList.cn),
        AttrKey(AttributeList.distinguishedName),
        AttrKey(AttributeList.sAMAccountName),
        AttrKey(AttributeList.userPrincipalName),
        AttrKey(AttributeList.mail),
        AttrKey(AttributeList.displayName),
        AttrKey(AttributeList.givenName),
        AttrKey(AttributeList.sn),
        AttrKey(AttributeList.memberOf),
        AttrKey(AttributeList.title),
        AttrKey(AttributeList.department),
        AttrKey(AttributeList.manager),
        AttrKey(AttributeList.telephoneNumber),
        AttrKey(AttributeList.mobile),
        AttrKey(AttributeList.c),
        AttrKey(AttributeList.pwdLastSet),
        AttrKey(AttributeList.lastLogonTimestamp),
        AttrKey(AttributeList.lastLogon),
        AttrKey(AttributeList.accountExpires),
        AttrKey(AttributeList.userAccountControl),
        AttrKey(AttributeList.objectGUID),
        AttrKey(AttributeList.logonHours),
        AttrKey(AttributeList.adminCount)
    ],

    [ObjectTypes.COMPUTER]: [
        AttrKey(AttributeList.cn),
        AttrKey(AttributeList.distinguishedName),
        AttrKey(AttributeList.sAMAccountName),
        AttrKey(AttributeList.dNSHostName),
        AttrKey(AttributeList.operatingSystem),
        AttrKey(AttributeList.operatingSystemVersion),
        AttrKey(AttributeList.servicePrincipalName),
        AttrKey(AttributeList.lastLogonTimestamp),
        AttrKey(AttributeList.lastLogon),
        AttrKey(AttributeList.pwdLastSet),
        AttrKey(AttributeList.whenCreated),
        AttrKey(AttributeList.whenChanged),
        AttrKey(AttributeList.managedBy),
        AttrKey(AttributeList.userAccountControl),
        AttrKey(AttributeList.memberOf),
        AttrKey(AttributeList.objectGUID)
    ],

    [ObjectTypes.GROUP]: [
        AttrKey(AttributeList.cn),
        AttrKey(AttributeList.distinguishedName),
        AttrKey(AttributeList.sAMAccountName),
        AttrKey(AttributeList.groupType),
        AttrKey(AttributeList.member),
        AttrKey(AttributeList.memberOf),
        AttrKey(AttributeList.managedBy),
        AttrKey(AttributeList.mail),
        AttrKey(AttributeList.displayName),
        AttrKey(AttributeList.whenCreated),
        AttrKey(AttributeList.whenChanged),
        AttrKey(AttributeList.objectGUID),
        AttrKey(AttributeList.adminCount)
    ],

    [ObjectTypes.CONTACT]: [
        AttrKey(AttributeList.thumbnailPhoto),
        AttrKey(AttributeList.cn),
        AttrKey(AttributeList.distinguishedName),
        AttrKey(AttributeList.displayName),
        AttrKey(AttributeList.givenName),
        AttrKey(AttributeList.sn),
        AttrKey(AttributeList.mail),
        AttrKey(AttributeList.proxyAddresses),
        AttrKey(AttributeList.telephoneNumber),
        AttrKey(AttributeList.mobile),
        AttrKey(AttributeList.company),
        AttrKey(AttributeList.department),
        AttrKey(AttributeList.title),
        AttrKey(AttributeList.manager),
        AttrKey(AttributeList.memberOf),
        AttrKey(AttributeList.targetAddress),
        AttrKey(AttributeList.whenCreated),
        AttrKey(AttributeList.whenChanged),
        AttrKey(AttributeList.objectGUID)
    ],

    [ObjectTypes.OU]: [
        // AttrKey(AttributeList.name),
        AttrKey(AttributeList.ou),
        AttrKey(AttributeList.distinguishedName),
        AttrKey(AttributeList.description),
        AttrKey(AttributeList.managedBy),
        AttrKey(AttributeList.whenCreated),
        AttrKey(AttributeList.whenChanged)
    ]
};

const SortOptionsConfig = {
    [SortOptions.A_TO_Z]: {
        id: SortOptions.A_TO_Z,
        displayName: "Alphabetical (A → Z)",
        sortType: SortTypes.ASCENDING
    },

    [SortOptions.Z_TO_A]: {
        id: SortOptions.Z_TO_A,
        displayName: "Alphabetical (Z → A)",
        sortType: SortTypes.DESCENDING
    },

    [SortOptions.LOW_TO_HIGH]: {
        id: SortOptions.LOW_TO_HIGH,
        displayName: "Numeric (Low → High)",
        sortType: SortTypes.ASCENDING
    },

    [SortOptions.HIGH_TO_LOW]: {
        id: SortOptions.HIGH_TO_LOW,
        displayName: "Numeric (High → Low)",
        sortType: SortTypes.DESCENDING
    },

    [SortOptions.OLD_TO_NEW]: {
        id: SortOptions.OLD_TO_NEW,
        displayName: "Date (Old → New)",
        sortType: SortTypes.ASCENDING
    },

    [SortOptions.NEW_TO_OLD]: {
        id: SortOptions.NEW_TO_OLD,
        displayName: "Date (New → Old)",
        sortType: SortTypes.DESCENDING
    }
};

const FilterActionsAvailableConfig = {
    [FilterActionsAvailable.SORT]: {
        id: FilterActionsAvailable.SORT,
        name: 'Sort',
        icon: 'custom-icon-sorting-2'
    },
    [FilterActionsAvailable.FILTER]: {
        id: FilterActionsAvailable.FILTER,
        name: 'Filter',
        icon: "custom-icon-filter-medium"
    },
    [FilterActionsAvailable.CUSTOMIZE_TABLE]: {
        id: FilterActionsAvailable.CUSTOMIZE_TABLE,
        name: 'Customize Columns',
        icon: "custom-icon-filter-3"
    },
}

const FilterTypesConfig = {
    [FilterTypes.EQUALS]: {
        id: FilterTypes.EQUALS,
        displayName: "Equals (=)",
        needValue: true
    },

    [FilterTypes.NOT_EQUALS]: {
        id: FilterTypes.NOT_EQUALS,
        displayName: "Not Equals (!=)",
        needValue: true
    },

    [FilterTypes.CONTAINS]: {
        id: FilterTypes.CONTAINS,
        displayName: "Contains",
        needValue: true
    },

    [FilterTypes.NOT_CONTAINS]: {
        id: FilterTypes.NOT_CONTAINS,
        displayName: "Not Contains",
        needValue: true
    },

    [FilterTypes.STARTS_WITH]: {
        id: FilterTypes.STARTS_WITH,
        displayName: "Starts With",
        needValue: true
    },

    [FilterTypes.ENDS_WITH]: {
        id: FilterTypes.ENDS_WITH,
        displayName: "Ends With",
        needValue: true
    },

    [FilterTypes.GREATER_THAN_OR_EQUAL]: {
        id: FilterTypes.GREATER_THAN_OR_EQUAL,
        displayName: "Greater Than or Equal (>=)",
        needValue: true
    },

    [FilterTypes.LESS_THAN_OR_EQUAL]: {
        id: FilterTypes.LESS_THAN_OR_EQUAL,
        displayName: "Less Than or Equal (<=)",
        needValue: true
    },

    [FilterTypes.EMPTY]: {
        id: FilterTypes.EMPTY,
        displayName: "Empty",
        needValue: false
    },

    [FilterTypes.NON_EMPTY]: {
        id: FilterTypes.NON_EMPTY,
        displayName: "Non-empty",
        needValue: false
    }


};

const ObjectClassFilters = {
    [ObjectTypes.ALL]: {
        id: ObjectTypes.ALL,
        filter: "(objectClass=*)"
        // "(|" +
        // "(objectClass=user)" +
        // "(objectClass=group)" +
        // "(objectClass=computer)" +
        // "(objectClass=contact)" +
        // "(objectClass=organizationalUnit)" +
        // "(objectClass=container)" +
        // "(objectClass=msDS-Container)" +
        // "(objectClass=msDS-GroupManagedServiceAccount)" +
        // "(objectClass=domainDNS)" +
        // "(objectClass=sharedFolder)" +
        // "(objectClass=printQueue)" +
        // "(objectClass=volume)" +
        // ")"
    },

    [ObjectTypes.USER]: {
        id: ObjectTypes.USER,
        filter: "(&(objectCategory=person)(objectClass=user))"
    },

    [ObjectTypes.GROUP]: {
        id: ObjectTypes.GROUP,
        filter: "(objectClass=group)"
    },

    [ObjectTypes.COMPUTER]: {
        id: ObjectTypes.COMPUTER,
        filter: "(objectClass=computer)"
    },

    [ObjectTypes.CONTACT]: {
        id: ObjectTypes.CONTACT,
        filter: "(objectClass=contact)"
    },

    [ObjectTypes.OU]: {
        id: ObjectTypes.OU,
        filter: "(objectClass=organizationalUnit)"
    }
};

const FilterPresetOptions = {
    [AttrKey(AttributeList.objectClass)]: {
        0: {
            id: 0,
            value: "(&(objectCategory=person)(objectClass=user))",
            displayName: "User"
        },
        1: {
            id: 1,
            value: "(objectClass=group)",
            displayName: "Group"
        },
        2: {
            id: 2,
            value: "(objectClass=computer)",
            displayName: "Computer"
        },
        3: {
            id: 3,
            value: "(objectClass=contact)",
            displayName: "Contact"
        },
        4: {
            id: 4,
            value: "(objectClass=organizationalUnit)",
            displayName: "Organizational Unit"
        },
        5: {
            id: 5,
            value: "(objectClass=container)",
            displayName: "Container"
        },
        6: {
            id: 6,
            value: "(objectClass=domainDNS)",
            displayName: "Domain"
        },
        7: {
            id: 7,
            value: "(objectClass=groupPolicyContainer)",
            displayName: "Group Policy Object"
        },
        8: {
            id: 8,
            value: "(objectClass=sharedFolder)",
            displayName: "Shared Folder"
        },
        9: {
            id: 9,
            value: "(objectClass=printQueue)",
            displayName: "Printer"
        },
        10: {
            id: 10,
            value: "(objectClass=volume)",
            displayName: "Volume"
        },
        11: {
            id: 11,
            value: "(objectClass=foreignSecurityPrincipal)",
            displayName: "Foreign Security Principal"
        },
        12: {
            id: 12,
            value: "(objectClass=msDS-GroupManagedServiceAccount)",
            displayName: "Group Managed Service Account (gMSA)"
        },
        13: {
            id: 13,
            value: "(objectClass=msDS-ManagedServiceAccount)",
            displayName: "Managed Service Account (MSA)"
        },
        14: {
            id: 14,
            value: "(objectClass=computer)(primaryGroupID=516)",
            displayName: "Domain Controller"
        },
        15: {
            id: 15,
            value: "(objectClass=site)",
            displayName: "AD Site"
        },
        16: {
            id: 16,
            value: "(objectClass=subnet)",
            displayName: "Subnet"
        },
        17: {
            id: 17,
            value: "(objectClass=trustDomain)",
            displayName: "Trust Relationship"
        }
    },
    [AttrKey(AttributeList.groupType)]: {
        0: {
            id: 0,
            value: "(&(objectClass=group)(groupType:1.2.840.113556.1.4.803:=2147483648))",
            displayName: "Security Group (Any Scope)"
        },
        1: {
            id: 1,
            value: "(&(objectClass=group)(groupType:1.2.840.113556.1.4.803:=2)(groupType:1.2.840.113556.1.4.803:=2147483648))",
            displayName: "Security Group - Global"
        },
        2: {
            id: 2,
            value: "(&(objectClass=group)(groupType:1.2.840.113556.1.4.803:=4)(groupType:1.2.840.113556.1.4.803:=2147483648))",
            displayName: "Security Group - Domain Local"
        },
        3: {
            id: 3,
            value: "(&(objectClass=group)(groupType:1.2.840.113556.1.4.803:=8)(groupType:1.2.840.113556.1.4.803:=2147483648))",
            displayName: "Security Group - Universal"
        },
        4: {
            id: 4,
            value: "(&(objectClass=group)(!(groupType:1.2.840.113556.1.4.803:=2147483648)))",
            displayName: "Distribution Group (Any Scope)"
        },
        5: {
            id: 5,
            value: "(&(objectClass=group)(groupType:1.2.840.113556.1.4.803:=2)(!(groupType:1.2.840.113556.1.4.803:=2147483648)))",
            displayName: "Distribution Group - Global"
        },
        6: {
            id: 6,
            value: "(&(objectClass=group)(groupType:1.2.840.113556.1.4.803:=4)(!(groupType:1.2.840.113556.1.4.803:=2147483648)))",
            displayName: "Distribution Group - Domain Local"
        },
        7: {
            id: 7,
            value: "(&(objectClass=group)(groupType:1.2.840.113556.1.4.803:=8)(!(groupType:1.2.840.113556.1.4.803:=2147483648)))",
            displayName: "Distribution Group - Universal"
        }
    },
    [AttrKey(AttributeList.userAccountControl)]: {
        0: {
            id: 0,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=2)",
            displayName: "Disabled Accounts"
        },
        1: {
            id: 1,
            value: "(!(userAccountControl:1.2.840.113556.1.4.803:=2))",
            displayName: "Enabled Accounts"
        },
        2: {
            id: 2,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=16)",
            displayName: "Locked Out Accounts"
        },
        3: {
            id: 3,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=32)",
            displayName: "Password Not Required"
        },
        4: {
            id: 4,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=64)",
            displayName: "Password Cannot Change"
        },
        5: {
            id: 5,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=128)",
            displayName: "Encrypted Text Password Allowed"
        },
        6: {
            id: 6,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=512)",
            displayName: "Normal User Account"
        },
        7: {
            id: 7,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=65536)",
            displayName: "Password Never Expires"
        },
        8: {
            id: 8,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=131072)",
            displayName: "Smart Card Required"
        },
        9: {
            id: 9,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=262144)",
            displayName: "Trusted for Delegation"
        },
        10: {
            id: 10,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=524288)",
            displayName: "Account is Sensitive and Cannot Be Delegated"
        },
        11: {
            id: 11,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=1048576)",
            displayName: "Do Not Require Kerberos Preauthentication"
        },
        12: {
            id: 12,
            value: "(userAccountControl:1.2.840.113556.1.4.803:=2097152)",
            displayName: "Password Expired"
        }
    }

}

const ErrorMessage = Object.freeze({
    SORT_LIMIT: "Too many results (over 10,000). Sorting alone is not supported for large result sets. Use Filters to narrow your search"
})


module.exports = {
    AttributeList,
    TabConfig,
    TabHeaders,
    SortOptionsConfig,
    FilterActionsAvailableConfig,
    FilterTypesConfig,
    ObjectClassFilters,
    FilterPresetOptions,
    ErrorMessage
}