const ldap = require("ldapjs");
const { logger } = require("../../../../util/logger");
const { exec } = require("child_process");
const util = require("util");
const profileService = require("./profileService");
const execPromise = util.promisify(exec);
class AuthServiceAD {
  constructor() {
    this.getLoggedOnAccount();
  }

  async getLoggedOnAccount() {
    try {
      // let { stdout: username } = await execPromise("echo %USERNAME%");
      let domainName = null;
      let username = null;
      const { stdout: nltest } = await execPromise("nltest /dsgetdc:");
      const domainMatch = nltest.match(/Dom Name:\s+([^\r\n]+)/);
      if (domainMatch) {
        domainName = domainMatch[1];
      }

      let result;
      try {
        const { stdout } = await execPromise(
          'powershell -Command "(Get-WmiObject -Class Win32_ComputerSystem).UserName"'
        );
        result = stdout.trim();
      } catch {
        logger.ldap.error("Unable to determine the username");
      }

      if (!result) {
        logger.session.error("No active user detected.");
        return;
      }

      logger.testing.ldap.debug("fetched username details : " + result);

      const parts = result.split("\\");
      if (parts.length === 2) {
        username = parts[1];
      } else {
        username = parts[0];
      }


      if (!domainName && !username) {
        logger.session.error(
          "Could not be able to retrive the domain details."
        );
        return;
      }

      username = username.trim();
      domainName = domainName.trim();

      const userBindID = `${username}-${domainName}`.toLowerCase();

      const data = {
        username: username,
        domainName: domainName,
        isUPN: true,
        userBindID: userBindID,
        thumbnailPhoto: null,
      };

      await profileService.saveUserProfile(data);
      logger.session.debug(
        "Stored the current logged on device domain account"
      );
    } catch (error) {
      logger.session.error("Could not be able to retrive the domain details.");
    }
  }

  async loginWithCredentials(ldapURL, bindDN, bindPassword) {
    const client = ldap.createClient({
      url: ldapURL,
      tlsOptions: {
        rejectUnauthorized: true,
      },
      timeout: 5000,
      connectTimeout: 5000,
    });
    client.on("error", (err) => {
      logger.session.error(`LDAP Connection Error: ${err}`);
    });

    return new Promise((resolve, reject) => {
      client.bind(bindDN, bindPassword, (err) => {
        if (err) {
          logger.session.error(`LDAP BIND Error: ${err}`);
          client.unbind();
          if (err.code === "ENOTFOUND") {
            reject(new Error(`Invalid domain name`));
          }
          if (err.message === "connection timeout") {
            reject(
              new Error(`Unable to establish connection — timeout occurred`)
            );
          }
          reject(new Error(err.message));
        } else {
          client.unbind();
          resolve({ message: "Bind successfull", isSuccess: true });
        }
      });
    });
  }

  async checkSupportLdaps(domainName) {
    return new Promise((resolve, reject) => {
      const client = ldap.createClient({
        url: `ldaps://${domainName}:636`,
        tlsOptions: { rejectUnauthorized: true },
      });
      client.on("connect", () => {
        client.unbind();
        resolve(true);
      });
      client.on("error", (err) => {
        logger.session.error(`LDAPS not supported or connection error: ${err}`);
        resolve(false);
      });
    });
  }

  isIPAddress(value) {
    const ipv4Regex = /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;
    return ipv4Regex.test(value);
  }

  async findDomainNameByIP(ip) {
    const client = ldap.createClient({ url: `ldap://${ip}:389`, reconnect: false });

    return new Promise((resolve, reject) => {

      client.on('error', err => {
        client.unbind();
        reject(err);
      });

      const opts = { scope: 'base', attributes: ['defaultNamingContext'] };

      client.search('', opts, (err, res) => {
        if (err) return reject(err);

        let domainDN;

        res.on('searchEntry', entry => {
          domainDN = entry.attributes.find(a => a.type === 'defaultNamingContext')?.vals?.[0];
        });

        res.on('error', reject);
        res.on('end', () => {
          client.unbind();
          if (!domainDN) return reject(new Error('Unable to find the domain name. Kindly verify your credentials.'));
          const dnsDomain = domainDN.split(',')
            .map(p => p.replace(/^DC=/i, ''))
            .join('.');
          resolve(dnsDomain);
        });
      });
    });
  }

}

module.exports = new AuthServiceAD();
