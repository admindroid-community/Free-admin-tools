const { logger } = require("../../../../util/logger");
const { sendAndLogError } = require("../../../../util/errorResponse");
const fileServices = require("../../../../util/fileServices");
const CredentialFileService = require("../../../../core/src/services/credentialFileService");
const encryptionService = require("../../../../util/encryptService");

class ProfileService extends CredentialFileService {
  constructor() {
    super();
  }

  async saveUserProfile(inputData) {
    return this.withProfileLock(async () => {
      try {
        let data = await this.getStoredProfileDataInternal();
        const userBindID = inputData.userBindID || "";
        if (!data.AD) {
          data["AD"] = {};
        }
        data.AD[userBindID] = inputData;

        await fileServices.writeFile(this.profileFilePath, data, false);
        return { message: "Data successfully stored", isSuccess: true };
      } catch (error) {
        logger.session.debug(`Store user profile input : ${inputData}`);
        logger.session.error(
          `Error storing user profile, writing JSON to file: ${error}`
        );
        return sendAndLogError(
          logger.session,
          "Error storing user profile",
          500,
          "Failed to store user profile data."
        );
      }
    });
  }

  async deleteUserProfile(userBindID) {
    return this.withProfileLock(async () => {
      try {
        let data = await this.getStoredProfileDataInternal();
        if (!data.AD) {
          return sendAndLogError(
            logger.session,
            "Error deleting user profile",
            500,
            "Failed to remove user profile data."
          );
        }

        delete data.AD[userBindID || ""];

        await fileServices.writeFile(this.profileFilePath, data, false);
        return { message: "Data successfully removed" };
      } catch (error) {
        logger.session.debug(`Delete user profile input: ${userBindID}`);
        logger.session.error(
          `Error deleting user profile writing JSON to file: ${error}`
        );
        return sendAndLogError(
          logger.session,
          "Error deleting user profile",
          500,
          "Failed to remove user profile data."
        );
      }
    });
  }

  async getStoredProfileData() {
    return await this.withProfileLock(async () => {
      return await this.getStoredProfileDataInternal();
    });
  }

  async getStoredProfileDataInternal() {
    try {
      const data = await fileServices.readFile(this.profileFilePath);

      if (!data.length) {
        await this.ensureFileInitialized();
      }

      const jsonData = JSON.parse(data || "{}");
      return jsonData || {};
    } catch (err) {
      logger.session.error(
        `Error fetching stored profiles reading or parsing file: ${err}`
      );
      return {};
    }
  }
}

module.exports = new ProfileService();
