const attrUsingFileTimeFormat = ["accountexpires", "lastlogon", "lastlogoff", "lastlogontimestamp", "pwdlastset", "badpasswordtime", "lockouttime", "creationtime"];
const attrUsingGeneralizedTimeFormat = ["whencreated", "whenchanged", "modifytimestamp", "createtimestamp"];
const attrUsingADInterval = ["lockoutduration", "lockoutobservationwindow", "maxpwdage"];

function formateData(attr) {

    const type = attr.type.toLowerCase();
    const value = attr.values;
    const buffer = attr.buffers;

    switch (type) {
        case "objectclass":
            return getObjectClass(value);
        case "useraccountcontrol":
            return decodeUserAccountControl(value);
        case "samaccounttype":
            return decodeSAMAccountType(value);
        case "instancetype":
            return decodeInstanceType(value);
        case "minpwdage":
            return decodeMinPwdAge(value);
        case "grouptype":
            return decodeGroupTypeValue(value);
        case "auditingpolicy":
            return decodeAuditingPolicy(buffer);
        case "systemflags":
            return decodeSystemFlags(value);
        case "forcelogoff":
            return decodeForceLogoff(value);
        case "thumbnailphoto":
            return getThumbnailPhoto(buffer);
        case "ms-ds-consistencyguid":
        case "objectguid":
            return decodeGuid(buffer);
        case "objectsid":
            return decodeSid(buffer);
        default:
            if (attrUsingFileTimeFormat.includes(type)) {
                return decodeFileTime(type, value);
            }
            if (attrUsingGeneralizedTimeFormat.includes(type)) {
                return decodeGeneralizedTime(type, value);
            }
            if (attrUsingADInterval.includes(type)) {
                return adIntervalToMinutes(value);
            }
            return value;
    }
}

function getThumbnailPhoto(buffer) {
    const base64 = buffer[0].toString('base64');
    return [base64 ? `data:image/png;base64,${base64}` : null];
}

function getObjectClass(value) {
    const object = value[value.length - 1]
    return object ? [object] : ["unknown"];
}

function decodeUserAccountControl(uacValue) {
    const flags = [
        { value: 0x0001, name: 'Logon script required' },
        { value: 0x0002, name: 'Account disabled' },
        { value: 0x0008, name: 'Home directory required' },
        { value: 0x0010, name: 'Account locked out' },
        { value: 0x0020, name: 'Password not required' },
        { value: 0x0080, name: 'Store password using reversible encryption' },
        { value: 0x0100, name: 'Temporary duplicate account' },
        { value: 0x0200, name: 'Normal account' },
        { value: 0x0800, name: 'Interdomain trust account' },
        { value: 0x1000, name: 'Workstation trust account' },
        { value: 0x2000, name: 'Server trust account' },
        { value: 0x10000, name: 'Password never expires' },
        { value: 0x20000, name: 'MNS logon account' },
        { value: 0x40000, name: 'Smart card required for logon' },
        { value: 0x80000, name: 'Trusted for delegation' },
        { value: 0x100000, name: 'Not delegated' },
        { value: 0x200000, name: 'Use DES encryption only' },
        { value: 0x400000, name: 'Do not require Kerberos preauthentication' },
        { value: 0x800000, name: 'Password expired' },
        { value: 0x1000000, name: 'Trusted to authenticate for delegation' },
        { value: 0x04000000, name: 'Partial secrets account' },
    ];
    return flags
        .filter(flag => (uacValue & flag.value) === flag.value)
        .map(flag => flag.name);
}

function decodeSAMAccountType(value) {
    const types = {
        805306368: 'User Account',
        805306369: 'Computer Account',
        805306370: 'Trust Account',
        805306371: 'Security Group (Alias)',
        805306372: 'Distribution Group (Non-Security Alias)',
        805306373: 'User Account',
        805306374: 'Computer Account',
        805306375: 'Trust Account',
        805306376: 'Application Basic Group',
        805306377: 'Application Query Group',
        805306378: 'Account Type (Max)',
        268435456: 'Security Group',
        268435457: 'Distribution Group',
        536870912: 'General Group'
    };
    return [types[value] || `Unknown sAMAccountType: ${value}`];
}

function decodeInstanceType(value) {
    const flags = [
        { bit: 0x0001, name: 'Naming Context Head' },
        { bit: 0x0002, name: 'Writable Naming Context' },
        { bit: 0x0004, name: 'Naming Context Coming' },
        { bit: 0x0008, name: 'Naming Context Going' },
        { bit: 0x0010, name: 'Primary Naming Context' },
        { bit: 0x0020, name: 'Previous Naming Context' },
        { bit: 0x0040, name: 'Global Catalog' },
        { bit: 0x0200, name: 'Constructed Instance Type' },
    ];
    return flags.filter(flag => (value & flag.bit) === flag.bit)
        .map(flag => flag.name);
}

function decodeGroupTypeValue(groupTypeValue) {
    const SCOPE_FLAGS = [
        { value: 0x00000002, name: 'Global Group' },
        { value: 0x00000004, name: 'Domain Local Group' },
        { value: 0x00000008, name: 'Universal Group' },
    ];

    const SECURITY_FLAG = 0x80000000 >>> 0;
    const unsignedValue = groupTypeValue >>> 0;

    const result = [];

    if ((unsignedValue & SECURITY_FLAG) !== 0) {
        result.push("Security Group");
    } else {
        result.push("Distribution Group");
    }
    for (const flag of SCOPE_FLAGS) {
        if ((unsignedValue & flag.value) === flag.value) {
            result.push(flag.name);
        }
    }
    return result;
}

function decodeAuditingPolicy(policyBuffer) {

    //console.log("aduting policy : ", policyBuffer);

    const buf = Buffer.from(policyBuffer[0], 'binary');
    const value = buf.readUInt16LE(0);
    const flags = {
        0x0001: "Logon/Logoff",
        0x0002: "File Access",
        0x0004: "Use of User Rights",
        0x0008: "Process Tracking",
        0x0010: "Policy Change",
        0x0020: "Directory Service Access",
        0x0040: "Account Logon",
        0x0080: "Account Management"
    };

    let results = [];
    for (const [bit, name] of Object.entries(flags)) {
        if (value & bit) {
            results.push(name);
        }
    }

    return results.length > 0 ? results : ["None"];
}

function decodeSystemFlags(value) {
    const unsigned = value >>> 0;

    const flags = [
        { bit: 0x00000001, name: "Disallow Delete" },
        { bit: 0x00000002, name: "Allow Rename (Config)" },
        { bit: 0x00000004, name: "Allow Move (Config)" },
        { bit: 0x00000008, name: "Allow Limited Move (Config)" },
        { bit: 0x02000000, name: "Disallow Move (Domain)" },
        { bit: 0x04000000, name: "Disallow Rename (Domain)" },
        { bit: 0x08000000, name: "NTDS Naming Context" },
        { bit: 0x10000000, name: "NTDS Domain" },
        { bit: 0x20000000, name: "Attribute is Constructed" },
        { bit: 0x40000000, name: "Disallow Move on Delete" },
        { bit: 0x80000000, name: "Disallow Rename on Delete" }
    ];

    const setFlags = flags.filter(f => (unsigned & f.bit) !== 0).map(f => f.name);
    return setFlags;

}

function decodeMinPwdAge(value) {
    const ticks = BigInt(value);
    if (ticks === BigInt(0)) return ["No restriction"];

    return adIntervalToMinutes(value);
}

function decodeForceLogoff(value) {
    value = value[0] || "-1";
    if (value === "-9223372036854775808") {
        return ["Never (do not force logoff when logon hours expire)"];
    }
    if (value === "0") {
        return ["Force logoff immediately when logon hours expire"];
    }
    return ["Unknown"];
}

function decodeFileTime(type, timeValue) {

    if (typeof timeValue[0] !== "string" || timeValue[0] === '0') return ['-'];
    const fileTime = BigInt(timeValue);
    const EPOCH_DIFFERENCE = 116444736000000000n;
    const MS_PER_TICK = 10000n;

    if (type === "accountexpires") {
        if (fileTime === 0n || fileTime === 9223372036854775807n) {
            return ["Never Expires"];
        }
    }

    if (type === "lockouttime") {
        if (fileTime === 0n) {
            return ["Not Locked"];
        }
    }

    const unixTimeMs = (fileTime - EPOCH_DIFFERENCE) / MS_PER_TICK;
    const date = new Date(Number(unixTimeMs));
    return [date.toLocaleString()];
}

function decodeGeneralizedTime(type, timeValue) {

    timeValue = timeValue[0];
    if (typeof timeValue !== "string" || timeValue === '0') return ['-'];
    const match = timeValue.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/);
    if (!match) return null;

    const [_, year, month, day, hour, minute, second] = match;
    const date = new Date(Date.UTC(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
        parseInt(hour),
        parseInt(minute),
        parseInt(second)
    ));
    return [date.toLocaleString()];
}

function adIntervalToMinutes(value) {
    const ticks = BigInt(value[0] || 0);
    const seconds = Number(ticks / BigInt(-10000000));
    return [formatDuration(seconds)];
}

function formatDuration(seconds) {
    let remaining = seconds;

    const years = Math.floor(remaining / (365 * 24 * 3600));
    remaining %= 365 * 24 * 3600;

    const months = Math.floor(remaining / (30 * 24 * 3600));
    remaining %= 30 * 24 * 3600;

    const days = Math.floor(remaining / (24 * 3600));
    remaining %= 24 * 3600;

    const hours = Math.floor(remaining / 3600);
    remaining %= 3600;

    const minutes = Math.floor(remaining / 60);
    const secs = remaining % 60;

    const parts = [];
    if (years) parts.push(`${years} year(s)`);
    if (months) parts.push(`${months} month(s)`);
    if (days) parts.push(`${days} day(s)`);
    if (hours) parts.push(`${hours} hour(s)`);
    if (minutes) parts.push(`${minutes} minute(s)`);
    if (secs) parts.push(`${secs} second(s)`);

    return parts.length > 0 ? parts.join(" ") : "0 second(s)";
}

function decodePrimaryGroupID(objectsid, value) {
    const groups = {
        512: 'Domain Administrators',
        513: 'Domain Users',
        514: 'Domain Guests',
        515: 'Domain Computers',
        516: 'Domain Controllers',
        517: 'Certificate Publishers',
        518: 'Schema Administrators',
        519: 'Enterprise Administrators',
        520: 'Group Policy Creator Owners',
        521: 'Read-only Domain Controllers',
        522: 'Cloneable Domain Controllers'
    };
    if (groups[value]) {
        return groups[value];
    } else {
        const parts = objectsid.split("-");
        parts[parts.length - 1] = value[0].toString();
        const groupSID = parts.join("-");
        return [`Group (SID ${groupSID})`];
    }
}

function decodeGuid(buffer) {
    buffer = buffer[0];
    if (!Buffer.isBuffer(buffer) || buffer.length !== 16) {
        //console.log("Invalid GUID buffer");
        return ["Invalid GUID buffer"];
    }

    const data1 = buffer.readUInt32LE(0).toString(16).padStart(8, '0');
    const data2 = buffer.readUInt16LE(4).toString(16).padStart(4, '0');
    const data3 = buffer.readUInt16LE(6).toString(16).padStart(4, '0');

    const data4 = buffer.slice(8, 10).toString('hex');
    const data5 = buffer.slice(10, 16).toString('hex');

    return [`${data1}-${data2}-${data3}-${data4}-${data5}`];
}

function decodeSid(buffer) {
    buffer = buffer[0];
    if (!Buffer.isBuffer(buffer) || buffer.length < 8) {
        return "Invalid SID buffer";
    }

    const revision = buffer[0];
    const subAuthCount = buffer[1];
    const identifierAuthority = buffer.slice(2, 8).reduce(
        (acc, val) => (acc << 8) | val,
        0
    );

    let sid = `S-${revision}-${identifierAuthority}`;

    for (let i = 0; i < subAuthCount; i++) {
        const subAuth = buffer.readUInt32LE(8 + i * 4);
        sid += `-${subAuth}`;
    }

    return [sid];
}

function getLdapFormatedTime() {
    const date = new Date();
    function pad(n) { return n.toString().padStart(2, '0') };
    const ldapGeneralizedTime =
        date.getUTCFullYear().toString() +
        pad(date.getUTCMonth() + 1) +
        pad(date.getUTCDate()) +
        pad(date.getUTCHours()) +
        pad(date.getUTCMinutes()) +
        pad(date.getUTCSeconds()) +
        ".0Z";
    const unixTimeMs = BigInt(date.getTime());
    const fileTimeOffset = BigInt(116444736000000000);
    const ldapFileTime = (unixTimeMs * BigInt(10000)) + fileTimeOffset;
    return {
        "ldapGeneralizedTime": ldapGeneralizedTime || "-",
        "ldapFileTime": ldapFileTime || "-"
    }
}

function constructBindDN(username, domainName, isUPN) {
    if (isUPN) {
        return `${username}@${domainName}`;
    } else {
        const netBIOSDomainName = domainName.split(".")[0];
        return `${netBIOSDomainName}\\${username}`;
    }
}

module.exports = {
    getLdapFormatedTime,
    constructBindDN,
    formateData,
    decodePrimaryGroupID
}