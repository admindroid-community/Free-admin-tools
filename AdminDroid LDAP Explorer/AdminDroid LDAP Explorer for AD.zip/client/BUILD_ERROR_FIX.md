# Build Error Fix - Playwright Files

## The Error

```
Build Error (Babel) in community-base-tool/tests/playwright-fixtures/base.js
Unexpected token, expected "," (1:13)
> 1 | const { test as base } = require('@playwright/test');
```

## Root Cause

Ember's build process was trying to compile Playwright test files (which use Node.js CommonJS syntax) as browser JavaScript.

## Solution Applied

### 1. Moved Playwright Files

- **From:** `tests/playwright-*` directories
- **To:** `e2e-tests/` directory (separate from Ember's build)

### 2. Cleaned Up Old Files

```bash
# Removed old directories
rm -rf tests/playwright-fixtures
rm -rf tests/playwright-helpers
rm -rf tests/playwright-setup.js
rm -rf tests/acceptance

# Cleared build cache
rm -rf dist tmp .cache
```

### 3. Updated Configuration

- Updated `playwright.config.js` to point to `e2e-tests/`
- Updated `.eslintignore` to ignore `e2e-tests/`
- Updated all test scripts in `package.json`

## Verification Steps

Run these commands to verify the fix:

```bash
# 1. Clear any remaining cache (if error persists)
rm -rf dist tmp .cache node_modules/.cache

# 2. Start the dev server (should work without Babel errors)
npm start

# 3. In another terminal, run Ember tests (should work)
npm run test:ember

# 4. Run Playwright tests (should work)
npm run test:playwright:ui
```

## If Error Still Occurs

### Step 1: Clear Everything

```bash
# Stop the dev server (Ctrl+C)

# Clear all build artifacts
rm -rf dist tmp .cache node_modules/.cache

# Remove old playwright files from tests/
rm -rf tests/playwright-fixtures tests/playwright-helpers tests/playwright-setup.js tests/acceptance
```

### Step 2: Verify File Structure

```bash
# Should NOT exist:
ls tests/playwright-fixtures    # Should not exist
ls tests/playwright-helpers     # Should not exist
ls tests/acceptance             # Should not exist

# Should exist:
ls e2e-tests/fixtures           # Should exist ✓
ls e2e-tests/helpers            # Should exist ✓
ls e2e-tests/tests              # Should exist ✓
```

### Step 3: Restart Dev Server

```bash
npm start
```

## Why This Happened

Ember uses Babel to transpile JavaScript for the browser. When Playwright files were in `tests/`, Ember tried to include them in the build. Playwright files use Node.js syntax (`require()`), which Babel tried to transpile and failed.

## The Fix

By moving Playwright files to `e2e-tests/` (outside the `tests/` directory), they're no longer processed by Ember's build system. They run directly in Node.js via Playwright.

## Current Structure (Correct)

```
client/
├── e2e-tests/              # ✓ Playwright tests (Node.js)
│   ├── fixtures/
│   ├── helpers/
│   └── tests/
│
├── tests/                  # ✓ Ember tests (browser)
│   ├── unit/
│   ├── integration/
│   └── helpers/
│
├── dist/                   # Build output (generated)
├── tmp/                    # Build cache (generated)
└── .cache/                 # Various caches (generated)
```

## Key Takeaway

**Playwright files MUST be outside `tests/` directory** to avoid Ember trying to compile them.

---

If you still see the error after following these steps, try:

```bash
# Nuclear option - reinstall dependencies
rm -rf node_modules package-lock.json
npm install
npm start
```
