import { module, test } from 'qunit';
import { setupTest } from 'community-base-tool/tests/helpers';

module('Unit | Route | testing-addon', function (hooks) {
  setupTest(hooks);

  test('it exists', function (assert) {
    let route = this.owner.lookup('route:testing-addon');
    assert.ok(route);
  });
});
