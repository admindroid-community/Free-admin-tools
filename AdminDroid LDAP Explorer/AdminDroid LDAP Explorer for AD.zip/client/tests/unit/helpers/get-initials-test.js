import { module, test } from 'qunit';
import getInitialsHelper from 'community-base-tool/helpers/get-initials';

/**
 * Unit Test Example: Testing a Helper Function
 *
 * Unit tests should:
 * - Be fast (no DOM rendering, no async operations)
 * - Test pure logic
 * - Cover edge cases
 * - Be isolated (no external dependencies)
 */

module('Unit | Helper | get-initials', function () {
  test('it extracts initials from a full name', function (assert) {
    // Ember helpers return a function, we need to call compute() or invoke it
    let result = getInitialsHelper.compute(['John Doe']);
    assert.strictEqual(result, 'JD', 'should return "JD" for "John Doe"');
  });

  test('it extracts initials from a single name', function (assert) {
    let result = getInitialsHelper.compute(['John']);
    assert.strictEqual(result, 'J', 'should return "J" for "John"');
  });

  test('it limits initials to first two words', function (assert) {
    let result = getInitialsHelper.compute(['John Middle Doe']);
    assert.strictEqual(result, 'JM', 'should return "JM" for "John Middle Doe"');
  });

  test('it capitalizes initials', function (assert) {
    let result = getInitialsHelper.compute(['john doe']);
    assert.strictEqual(result, 'JD', 'should capitalize initials');
  });

  test('it handles empty string', function (assert) {
    let result = getInitialsHelper.compute(['']);
    assert.strictEqual(result, '', 'should return empty string for empty input');
  });

  test('it handles non-string input', function (assert) {
    let result = getInitialsHelper.compute([null]);
    assert.strictEqual(result, '', 'should return empty string for null');

    result = getInitialsHelper.compute([undefined]);
    assert.strictEqual(result, '', 'should return empty string for undefined');

    result = getInitialsHelper.compute([123]);
    assert.strictEqual(result, '', 'should return empty string for number');
  });

  test('it handles extra spaces', function (assert) {
    let result = getInitialsHelper.compute(['John  Doe']);
    assert.strictEqual(result, 'JD', 'should handle multiple spaces');
  });

  test('it handles leading/trailing spaces', function (assert) {
    let result = getInitialsHelper.compute(['  John Doe  ']);
    assert.strictEqual(result, 'JD', 'should handle leading/trailing spaces');
  });
});
