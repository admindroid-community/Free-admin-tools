/**
 * Skip tests that require data-test attributes
 *
 * Use this at the top of test files that need data-test-* attributes:
 *
 * const { skipIfNoSelectors } = require('../fixtures/skip-if-no-selectors');
 * test.describe.configure({ mode: skipIfNoSelectors() });
 */

function skipIfNoSelectors() {
  // Check if we should skip tests that need data-test attributes
  const SKIP_SELECTOR_TESTS = process.env.SKIP_SELECTOR_TESTS !== 'false';

  return SKIP_SELECTOR_TESTS ? 'skip' : 'parallel';
}

module.exports = { skipIfNoSelectors };
