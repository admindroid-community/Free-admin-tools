/**
 * Test Selectors for Playwright Tests
 *
 * Centralized selectors to make tests more maintainable.
 * Use data-test-* attributes in your components for reliable selectors.
 */

module.exports = {
  // Common selectors across all engines
  common: {
    loadingIndicator: '[data-test-loading]',
    errorMessage: '[data-test-error-message]',
    successMessage: '[data-test-success-message]',
  },

  // AD Engine selectors
  ad: {
    promptBox: '[data-test-prompt-box]',
    promptInput: '[data-test-prompt-input]',
    submitButton: '[data-test-submit-button]',
    responseBox: '[data-test-response-box]',
    responseTable: '[data-test-response-table]',
    writeConfirmation: '[data-test-write-confirmation]',
    switchConfirmation: '[data-test-switch-confirmation]',
  },

  // Graph Explorer selectors
  graphExplorer: {
    sidebar: '[data-test-sidebar]',
    apiExplorer: '[data-test-api-explorer]',
    historyExplorer: '[data-test-history-explorer]',
    sampleQueries: '[data-test-sample-queries]',
    methodSelect: '[data-test-method-select]',
    urlInput: '[data-test-url-input]',
    sendButton: '[data-test-send-button]',
    responseSection: '[data-test-response-section]',
    jsonView: '[data-test-json-view]',
    tableView: '[data-test-table-view]',
  },

  // LDAP Explorer selectors
  ldapExplorer: {
    treeView: '[data-test-tree-view]',
    objectDetails: '[data-test-object-details]',
    columnFilter: '[data-test-column-filter]',
    searchInput: '[data-test-search-input]',
    tableLoader: '[data-test-table-loader]',
  },

  // M365 Engine selectors
  m365: {
    promptBox: '[data-test-prompt-box]',
    promptInput: '[data-test-prompt-input]',
    submitButton: '[data-test-submit-button]',
    responseBox: '[data-test-response-box]',
    consentPopup: '[data-test-consent-popup]',
    initialPrompt: '[data-test-initial-prompt]',
  },

  // Navigation
  navigation: {
    engineSelector: '[data-test-engine-selector]',
    adLink: '[data-test-engine-ad]',
    graphExplorerLink: '[data-test-engine-graph-explorer]',
    ldapExplorerLink: '[data-test-engine-ldap-explorer]',
    m365Link: '[data-test-engine-m365]',
  }
};
