const { test } = require('../../fixtures/base');
const { expect } = require('@playwright/test');
const selectors = require('../../helpers/test-selectors');

/**
 * Acceptance Test: M365 Engine - Prompt Workflow
 *
 * Tests the Microsoft 365 prompt and response workflow:
 * 1. Entering prompts
 * 2. Handling consent/permissions
 * 3. Viewing responses
 * 4. Data visualization
 */

test.describe('M365 Engine - Prompt Workflow', () => {
  test.beforeEach(async ({ enginePage }) => {
    // Navigate to M365 engine
    await enginePage.goto('m365');
    await enginePage.waitForEmber();
  });

  test('should load M365 engine successfully', async ({ page }) => {
    // Verify we're on the M365 engine
    expect(page.url()).toContain('/m365');

    // Verify key components are visible
    await expect(page.locator(selectors.m365.promptBox)).toBeVisible();
    await expect(page.locator(selectors.m365.promptInput)).toBeVisible();
  });

  test('should show initial prompt suggestions', async ({ page }) => {
    const initialPrompt = page.locator(selectors.m365.initialPrompt);

    if (await initialPrompt.isVisible()) {
      // Click on a suggestion
      const suggestionButtons = page.locator('[data-test-prompt-suggestion]');
      const count = await suggestionButtons.count();

      if (count > 0) {
        console.log(`✅ Found ${count} prompt suggestions`);
        expect(count).toBeGreaterThan(0);
      }
    }
  });

  test('should accept and submit a prompt', async ({ page, waitHelpers }) => {
    const testPrompt = 'Get all Microsoft 365 users';

    // Fill in the prompt
    await page.fill(selectors.m365.promptInput, testPrompt);

    // Verify the input has the correct value
    const inputValue = await page.inputValue(selectors.m365.promptInput);
    expect(inputValue).toBe(testPrompt);

    // Submit the prompt
    await page.click(selectors.m365.submitButton);

    // Wait for loading to complete
    await waitHelpers.waitForNoLoading();

    console.log('✅ M365 prompt submitted successfully');
  });

  test('should handle consent popup for permissions', async ({ page }) => {
    // Note: This test assumes consent is needed
    const testPrompt = 'Get all users from Microsoft 365';

    await page.fill(selectors.m365.promptInput, testPrompt);
    await page.click(selectors.m365.submitButton);

    // Wait for consent popup (if needed)
    const consentPopup = page.locator(selectors.m365.consentPopup);

    try {
      await consentPopup.waitFor({ timeout: 5000 });
      console.log('✅ Consent popup appeared');

      // Accept consent
      const acceptButton = page.locator('[data-test-consent-accept]');
      if (await acceptButton.isVisible()) {
        await acceptButton.click();
        console.log('✅ Consent accepted');
      }
    } catch (error) {
      console.log('⚠️  No consent popup needed (already authorized or no auth setup)');
    }
  });

  test('should display response after query', async ({ page, waitHelpers }) => {
    const testPrompt = 'List all SharePoint sites';

    await page.fill(selectors.m365.promptInput, testPrompt);
    await page.click(selectors.m365.submitButton);

    // Wait for response
    await waitHelpers.waitForNoLoading();

    // Verify response box appears
    const responseBox = page.locator(selectors.m365.responseBox);
    await expect(responseBox).toBeVisible({ timeout: 15000 });

    console.log('✅ M365 response displayed');
  });

  test('should display response in different formats', async ({ page, waitHelpers }) => {
    // Submit a query that returns data
    const testPrompt = 'Get user count';

    await page.fill(selectors.m365.promptInput, testPrompt);
    await page.click(selectors.m365.submitButton);
    await waitHelpers.waitForNoLoading();

    // Check for tabs (table, chart, json, etc.)
    const tabButtons = page.locator('[data-test-response-tab]');
    const tabCount = await tabButtons.count();

    if (tabCount > 0) {
      console.log(`✅ Found ${tabCount} response format tabs`);

      // Click through tabs
      for (let i = 0; i < Math.min(tabCount, 3); i++) {
        await tabButtons.nth(i).click();
        await page.waitForTimeout(300);
      }

      console.log('✅ Tab switching works correctly');
    }
  });

  test('should display charts when data visualization is available', async ({ page, waitHelpers }) => {
    const testPrompt = 'Show user statistics';

    await page.fill(selectors.m365.promptInput, testPrompt);
    await page.click(selectors.m365.submitButton);
    await waitHelpers.waitForNoLoading();

    // Look for chart tab
    const chartTab = page.locator('[data-test-tab-chart]');

    if (await chartTab.isVisible()) {
      await chartTab.click();

      // Verify chart is rendered
      const chart = page.locator('[data-test-chart-canvas]');
      await expect(chart).toBeVisible({ timeout: 5000 });

      console.log('✅ Chart visualization displayed');
    }
  });

  test('should handle write operations with confirmation', async ({ page }) => {
    const writePrompt = 'Update user John Doe email';

    await page.fill(selectors.m365.promptInput, writePrompt);
    await page.click(selectors.m365.submitButton);

    // Wait for write confirmation dialog
    const writeConfirmation = page.locator('[data-test-write-confirmation]');

    try {
      await writeConfirmation.waitFor({ timeout: 5000 });
      console.log('✅ Write confirmation dialog appeared');

      // Cancel the operation
      const cancelButton = page.locator('[data-test-write-cancel]');
      if (await cancelButton.isVisible()) {
        await cancelButton.click();
        console.log('✅ Write operation cancelled');
      }
    } catch (error) {
      console.log('⚠️  Write confirmation not triggered (may need specific setup)');
    }
  });

  test('should support multiline prompts with Shift+Enter', async ({ page }) => {
    const line1 = 'Get all users where';
    const line2 = 'Department is IT';

    await page.fill(selectors.m365.promptInput, line1);
    await page.press(selectors.m365.promptInput, 'Shift+Enter');
    await page.fill(selectors.m365.promptInput, `${line1}\n${line2}`);

    const inputValue = await page.inputValue(selectors.m365.promptInput);
    expect(inputValue).toContain(line1);
    expect(inputValue).toContain(line2);

    console.log('✅ Multiline input works correctly');
  });

  test('should handle authentication requirements', async ({ page, authHelpers }) => {
    const isLoggedIn = await authHelpers.isLoggedIn();

    if (!isLoggedIn) {
      await page.fill(selectors.m365.promptInput, 'Get users');
      await page.click(selectors.m365.submitButton);

      // Should show login prompt
      console.log('⚠️  Authentication flow needs implementation');
    } else {
      console.log('✅ Already authenticated');
    }
  });

  test('should maintain prompt history', async ({ page }) => {
    const prompts = [
      'Get all users',
      'List SharePoint sites',
      'Show Teams data',
    ];

    // Submit multiple prompts
    for (const prompt of prompts) {
      await page.fill(selectors.m365.promptInput, prompt);
      await page.press(selectors.m365.promptInput, 'Enter');
      await page.waitForTimeout(1000);
    }

    // Try to access history (if feature exists)
    // Use arrow up key to navigate history
    await page.focus(selectors.m365.promptInput);
    await page.keyboard.press('ArrowUp');

    const inputValue = await page.inputValue(selectors.m365.promptInput);
    console.log(`Input after arrow up: ${inputValue}`);
  });
});
