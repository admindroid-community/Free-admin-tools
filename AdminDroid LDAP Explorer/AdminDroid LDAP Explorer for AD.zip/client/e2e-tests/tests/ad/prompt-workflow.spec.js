const { test } = require('../../fixtures/base');
const { expect } = require('@playwright/test');
const selectors = require('../../helpers/test-selectors');

/**
 * Acceptance Test: AD Engine - Prompt Workflow
 *
 * Tests the complete workflow of:
 * 1. Entering a prompt
 * 2. Submitting the query
 * 3. Receiving and displaying results
 */

test.describe('AD Engine - Prompt Workflow', () => {
  test.beforeEach(async ({ enginePage }) => {
    // Navigate to AD engine
    await enginePage.goto('ad');
    await enginePage.waitForEmber();
  });

  test('should load AD engine successfully', async ({ page }) => {
    // Verify we're on the AD engine
    expect(page.url()).toContain('/ad');

    // Verify key components are visible
    await expect(page.locator(selectors.ad.promptBox)).toBeVisible();
    await expect(page.locator(selectors.ad.promptInput)).toBeVisible();
  });

  test('should accept and submit a prompt', async ({ page, waitHelpers }) => {
    const testPrompt = 'Get all users from Active Directory';

    // Fill in the prompt
    await page.fill(selectors.ad.promptInput, testPrompt);

    // Verify the input has the correct value
    const inputValue = await page.inputValue(selectors.ad.promptInput);
    expect(inputValue).toBe(testPrompt);

    // Submit the prompt
    await page.click(selectors.ad.submitButton);

    // Wait for loading to complete
    await waitHelpers.waitForNoLoading();

    console.log('✅ Prompt submitted successfully');
  });

  test('should display response after query submission', async ({ page, waitHelpers }) => {
    // Note: This test assumes you have authentication and API connectivity
    // You may need to mock the API or setup test authentication

    const testPrompt = 'Get all users';

    await page.fill(selectors.ad.promptInput, testPrompt);
    await page.click(selectors.ad.submitButton);

    // Wait for response
    await waitHelpers.waitForNoLoading();

    // Verify response box appears
    await expect(page.locator(selectors.ad.responseBox)).toBeVisible({ timeout: 10000 });

    console.log('✅ Response displayed successfully');
  });

  test('should handle Enter key submission', async ({ page }) => {
    const testPrompt = 'Get all groups';

    await page.fill(selectors.ad.promptInput, testPrompt);

    // Press Enter
    await page.press(selectors.ad.promptInput, 'Enter');

    // Verify submission started (loading indicator or response)
    // Adjust based on your actual UI behavior
    const hasLoading = await page.locator(selectors.common.loadingIndicator).count() > 0;
    const hasResponse = await page.locator(selectors.ad.responseBox).count() > 0;

    expect(hasLoading || hasResponse).toBeTruthy();
  });

  test('should handle Shift+Enter for new line', async ({ page }) => {
    const line1 = 'First line';
    const line2 = 'Second line';

    await page.fill(selectors.ad.promptInput, line1);

    // Press Shift+Enter for new line
    await page.press(selectors.ad.promptInput, 'Shift+Enter');

    // Type second line
    await page.fill(selectors.ad.promptInput, `${line1}\n${line2}`);

    const inputValue = await page.inputValue(selectors.ad.promptInput);
    expect(inputValue).toContain(line1);
    expect(inputValue).toContain(line2);
  });

  test('should show write confirmation dialog for write operations', async ({ page }) => {
    // This test assumes certain prompts trigger write confirmations
    const writePrompt = 'Delete user John Doe';

    await page.fill(selectors.ad.promptInput, writePrompt);
    await page.click(selectors.ad.submitButton);

    // Wait for confirmation dialog
    // Adjust timeout based on your needs
    await page.waitForSelector(selectors.ad.writeConfirmation, { timeout: 5000 }).catch(() => {
      console.log('⚠️  Write confirmation not triggered (may need specific setup)');
    });
  });

  test('should handle authentication requirement', async ({ page, authHelpers }) => {
    // If not logged in, should show authentication requirement
    const isLoggedIn = await authHelpers.isLoggedIn();

    if (!isLoggedIn) {
      await page.fill(selectors.ad.promptInput, 'Get users');
      await page.click(selectors.ad.submitButton);

      // Should show login prompt or redirect
      // Adjust based on your authentication flow
      console.log('⚠️  Authentication flow needs to be implemented in authHelpers');
    }
  });
});
