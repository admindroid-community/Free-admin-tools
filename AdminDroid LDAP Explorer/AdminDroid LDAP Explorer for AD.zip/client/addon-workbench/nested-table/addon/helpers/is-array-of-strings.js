import { helper } from '@ember/component/helper';

export default helper(function isArrayOfStrings([value]) {
  if (!Array.isArray(value)) {
    return false;
  }

  return value.every((item) => typeof item === 'string');
});
