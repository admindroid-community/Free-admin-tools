import { helper } from '@ember/component/helper';

export default helper(function dec([value]) {
  return value - 1;
});
