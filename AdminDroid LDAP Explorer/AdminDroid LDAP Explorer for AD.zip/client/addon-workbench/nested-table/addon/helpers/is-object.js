import { helper } from '@ember/component/helper';

export default helper(function isObject([value]) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
});
