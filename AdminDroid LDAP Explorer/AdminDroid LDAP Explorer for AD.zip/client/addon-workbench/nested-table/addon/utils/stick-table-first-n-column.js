// ✅ Updated: Accept table element instead of tableClass
export async function stickFirstNCols(table, n = 1) {
  // Changed from: const table = document.getElementsByClassName(tableClass)[0];
  if (!table) return;

  const theadRows = table.querySelectorAll('thead tr');
  const tbodyRows = table.querySelectorAll('tbody tr');
  const allRows = [...theadRows, ...tbodyRows];

  if (!allRows.length || n <= 0) return;

  // ✅ Changed: pass table element instead of class name
  resetStickyCols(table);

  requestAnimationFrame(() => {
    const firstRow = theadRows[0] || tbodyRows[0];
    if (!firstRow || firstRow.children.length < n) return;

    let leftOffset = 0;

    for (let colIndex = 0; colIndex < n; colIndex++) {
      const cell = firstRow.children[colIndex];
      if (!cell) continue;

      const colWidth = cell.offsetWidth;

      theadRows.forEach((row) => {
        const th = row.children[colIndex];
        if (th) {
          th.style.minWidth = `${colWidth}px`;
          th.style.position = 'sticky';
          th.style.left = `${leftOffset}px`;
          th.style.zIndex = '6';

          if (colIndex === n - 1) addDivider(th);
        }
      });

      tbodyRows.forEach((row) => {
        const td = row.children[colIndex];
        if (td) {
          td.style.minWidth = `${colWidth}px`;
          td.style.position = 'sticky';
          td.style.left = `${leftOffset}px`;
          td.style.zIndex = '2';

          if (colIndex === n - 1) addDivider(td);
        }
      });

      // console.log("afetr apply ", leftOffset);

      leftOffset += colWidth;
    }
  });
}

// ✅ Updated: Accept table element instead of class name
export function resetStickyCols(table) {
  // Changed from: const table = document.getElementsByClassName(tableClass)[0];
  if (!table) return;

  const allCells = table.querySelectorAll('th, td');
  allCells.forEach((cell) => {
    cell.style.width = '';
    cell.style.minWidth = '';
    cell.style.position = '';
    cell.style.left = '';
    cell.style.zIndex = '';
    cell.style.background = '';

    // console.log("reset called", cell.style.left );

    const oldDivider = cell.querySelector('.sticky-col-divider');
    if (oldDivider) oldDivider.remove();
  });
}

function addDivider(cell) {
  if (
    cell.style.position !== 'relative' &&
    cell.style.position !== 'sticky'
  ) {
    cell.style.position = 'relative';
  }

  const divider = document.createElement('div');
  divider.className = 'sticky-col-divider';
  Object.assign(divider.style, {
    content: '""',
    position: 'absolute',
    height: '100%',
    width: '2px',
    right: '0',
    top: '0',
    backgroundColor: 'rgba(173, 164, 164, 0.12)',
    pointerEvents: 'none',
    zIndex: '10',
  });
  cell.appendChild(divider);
}
