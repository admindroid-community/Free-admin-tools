export { default } from 'nested-table/helpers/wrap-array';
