export { default } from 'nested-table/helpers/get-header';
