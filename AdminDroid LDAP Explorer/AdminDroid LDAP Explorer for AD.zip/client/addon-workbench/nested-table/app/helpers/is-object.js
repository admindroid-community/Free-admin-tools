export { default } from 'nested-table/helpers/is-object';
