export { default } from '@admindroid/shared-components/helpers/object-value';
