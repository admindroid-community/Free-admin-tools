export { default } from '@admindroid/shared-components/helpers/format-key-for-display';
