export { default } from '@admindroid/shared-components/components/tenant-switch-dropdown';
