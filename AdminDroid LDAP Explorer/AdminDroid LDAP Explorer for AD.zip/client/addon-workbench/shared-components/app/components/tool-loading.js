export { default } from '@admindroid/shared-components/components/tool-loading';
