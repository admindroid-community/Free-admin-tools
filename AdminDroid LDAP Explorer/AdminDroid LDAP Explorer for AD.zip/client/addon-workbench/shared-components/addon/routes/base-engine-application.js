import Route from '@ember/routing/route';
import { service } from '@ember/service';

/**
 * Base application route for all engine modules.
 * Provides common loading logic with progress messaging.
 *
 * To use this base class:
 * 1. Extend this class in your engine's application route
 * 2. Implement the `getLoadingSteps()` method to define your loading steps
 * 3. Optionally override `onLoadingComplete()` for post-load actions
 *
 * @example
 * export default class ApplicationRoute extends BaseEngineApplicationRoute {
 *   getLoadingSteps() {
 *     return [
 *       { message: 'Checking session...', action: () => this.userService.checkSession(AUTH_TYPES.M365.id) },
 *       { message: 'Loading data...', action: () => this.dataService.loadData() }
 *     ];
 *   }
 * }
 */
export default class BaseEngineApplicationRoute extends Route {
  @service('user') userService;
  @service('tool-information') toolInfoService;

  /**
   * Override this method in your subclass to define loading steps.
   * Each step should have a message and an action function.
   *
   * @returns {Array<{message: string, action: Function}>}
   */
  getLoadingSteps() {
    throw new Error('Subclass must implement getLoadingSteps()');
  }

  /**
   * Optional hook called after all loading steps complete successfully.
   * Override in subclass if needed.
   */
  onLoadingComplete() {
    // Default: do nothing
  }

  /**
   * Sets auth type and initiates non-blocking loading.
   * @param {string} authType - The authentication type ID
   */
  beforeModel() {
    this.toolInfoService.isToolLoading = true;
    this._loadApplicationData();
  }

  /**
   * Executes all loading steps sequentially with progress updates.
   * @private
   */
  async _loadApplicationData() {
    try {
      const steps = this.getLoadingSteps();

      for (const step of steps) {
        this.toolInfoService.loadingMessage = step.message;
        await step.action();
      }

      // Call optional completion hook
      this.onLoadingComplete();

      // Small delay to ensure smooth transition
      setTimeout(() => {
        this.toolInfoService.isToolLoading = false;
        this.toolInfoService.loadingMessage = '';
      }, 500);
    } catch (error) {
      console.error('Error loading application:', error);
      this.toolInfoService.isToolLoading = false;
      this.toolInfoService.loadingMessage = '';
    }
  }
}
