import { helper } from '@ember/component/helper';

export default helper(function formatKeyForDisplay([key]) {


  const SPECIAL = {
    cn: 'Common Name',
    dn: 'Distinguished Name',
    c: 'Country',
    co: 'Country',
    l: 'City',
    st: 'State / Province',
    o: 'Organization',
    ou: 'Organizational Unit',
    sn: 'Surname',
    thumbnailphoto: 'Photo',
    pwdlastset: 'Password Last Set'
  };

  if (!key || typeof key !== 'string') return '';
  key = key.trim();

  if (SPECIAL[key.toLowerCase()]) {
    return SPECIAL[key.toLowerCase()];
  }

  let protectedToken = null;
  let temp = key;
  const m = temp.match(/^([a-z])([A-Z]{2,}.*)/);
  if (m) {
    protectedToken = `${m[1]}§${m[2]}`;
    temp = protectedToken;
  }

  temp = temp
    .replace(/(?<=[a-z0-9])(?=[A-Z])/g, ' ')
    .replace(/(?<=[A-Z])(?=[A-Z][a-z])/g, ' ');

  if (protectedToken) {
    temp = temp.replace('§', '');
  }

  const result = temp
    .split(' ')
    .map(w => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');

  return result;
});
