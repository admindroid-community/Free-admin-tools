import config from 'community-base-tool/config/environment';

const BASE_URL = `${config.APP.apiHost}`;

/**
 * Makes an API request to the server
 * @param {string} endpoint - The API endpoint (e.g., '/api/users')
 * @param {string} method - HTTP method (GET, POST, PUT, DELETE, etc.)
 * @param {Object|null} data - Request body data (will be JSON stringified)
 * @param {Object} options - Additional options
 * @param {Object} options.headers - Additional headers to include
 * @param {string} options.credentials - Credentials mode (default: 'same-origin')
 * @returns {Promise<Object|Blob>} - Response data (JSON object or Blob)
 * @throws {Error} - Throws error object from server or generic error
 */
export async function apiRequest(
  endpoint,
  method = 'GET',
  data = null,
  options = {},
) {
  const fetchConfig = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    credentials: options.credentials || 'same-origin',
  };

  if (data) {
    fetchConfig.body = JSON.stringify(data);
  }

  const url = `${BASE_URL}${endpoint}`;

  try {
    const response = await fetch(url, fetchConfig);
    const contentType = response.headers.get('Content-Type');

    if (!response.ok) {
      let errorText = await response.text();

      // Try to parse error as JSON if possible
      try {
        const errorJson = JSON.parse(errorText);
        throw errorJson;
      } catch (parseError) {
        // If parsing fails, throw error text wrapped in Error object
        throw new Error(errorText || 'Network response was not ok');
      }
    }

    // Handle JSON response
    if (contentType && contentType.includes('application/json')) {
      return await response.json();
    }

    // Handle binary data (images, files, etc.)
    return await response.blob();
  } catch (error) {
    console.error(`API Error [${method} ${endpoint}]:`, error);
    throw error;
  }
}
