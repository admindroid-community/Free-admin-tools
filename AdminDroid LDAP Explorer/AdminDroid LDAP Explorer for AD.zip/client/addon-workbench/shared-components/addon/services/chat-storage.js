import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import localforage from 'localforage';
import { task } from 'ember-concurrency';
import { CHAT_STORAGE_CONFIG } from '../utils/tool-informations';

export default class ChatStorageService extends Service {
  @service('ai-providers') AIProvidersService;

  // Engine configuration - should be set during initialization
  engineConfig = null;
  dbStorage = null;

  get providers() {
    return this.AIProvidersService.providers;
  }
  isNewConversation = false;
  @tracked chatStorage = [];
  @tracked selectedAdditionalChatDataPopup = null;
  @tracked providerChat = null;
  @tracked modelChat = null;
  @tracked responseTabs = [
    {
      name: 'table',
      isActive: false,
      iconName: 'custom-icon-table-medium',
      value: null,
    },
    {
      name: 'graphical/Table',
      isActive: false,
      iconName: 'custom-icon-table-pie-chart-semi-medium',
      value: null,
    },
  ];

  @tracked _selectedIndex = null;

  get selectedLHSTableIndex() {
    return this._selectedIndex;
  }

  set selectedLHSTableIndex(value) {
    if (!this.engineConfig) {
      console.warn('Engine config not initialized');
      return;
    }
    this._selectedIndex = value;
    if (value) {
      localStorage[this.engineConfig.localStorageKeys.selectedIndex] = value;
    }
    localStorage[this.engineConfig.localStorageKeys.isResponseTabOpen] = value ? true : false;
    this.updateLHSResponse.perform();
  }

  get isTableResponseAvailable() {
    return !this.selectedLHSTableIndex && this.localStorageUtils.get(this.engineConfig.localStorageKeys.selectedIndex) ? true : false
  }

  @tracked tableMaxData = 20;

  /**
   * Initialize the service with engine-specific configuration
   * @param {string} engineType - Either 'AD' or 'M365'
   * @param {object} apiRequest - The API request utility function
   * @param {object} localStorageUtils - The local storage utility
   */
  @action
  initializeEngine(engineType, apiRequest, localStorageUtils) {
    this.engineConfig = CHAT_STORAGE_CONFIG[engineType];
    this.apiRequest = apiRequest;
    this.localStorageUtils = localStorageUtils;

    if (!this.engineConfig) {
      throw new Error(`Invalid engine type: ${engineType}`);
    }

    // Initialize database storage instances
    this.dbStorage = {
      [this.engineConfig.dbStorageKeys.history]: localforage.createInstance({
        name: 'chatTool',
        storeName: this.engineConfig.storeNames.history,
      }),
      [this.engineConfig.dbStorageKeys.aiHistory]: localforage.createInstance({
        name: 'chatTool',
        storeName: this.engineConfig.storeNames.aiHistory,
      }),
    };

    // Load selected index from localStorage
    const val = localStorage.getItem(
      this.engineConfig.localStorageKeys.selectedIndex,
    );

    this._selectedIndex = this.localStorageUtils.get(this.engineConfig.localStorageKeys.isResponseTabOpen) ? val !== null ? Number(val) : null : null;
  }

  updateLHSResponse = task({ drop: true }, async () => {
    let data = this.chatStorage[this.selectedLHSTableIndex];
    let key = this.getAIResponseTextKey(data);
    data = key ? data[key][0].text : null;

    this.updateChartResponse(data?.chartData ?? null);
    await this.updateJsonResponseTable(data?.tableData ?? null);
  });

  @action
  updateChartResponse(data) {
    let temp = this.responseTabs;
    temp[1].value = data;
    this.setData('responseTabs', temp);
    this.handleTabClick(1);
  }

  @action
  async updateJsonResponseTable(res) {
    let temp = this.responseTabs;
    temp[0].value = res;
    this.setData('responseTabs', temp);
    this.tableHeader = await this.getTableHeader(res);
    this.handleTabClick(0);
  }

  @action
  handleTabClick(index) {
    let temp = this.responseTabs;
    temp = temp.map((tab, i) => ({
      ...tab,
      isActive: i === index,
    }));
    this.setData('responseTabs', temp);
  }

  @action
  async getTableHeader(response) {
    if (!Array.isArray(response)) return [];

    const keySet = new Set();
    response.forEach((item) => {
      if (item && typeof item === 'object') {
        Object.keys(item).forEach((key) => keySet.add(key));
      }
    });

    let headers = Array.from(keySet);
    headers = await this.fetchPriorityHeader(headers);

    return headers.priorityKeys;
  }

  @action
  async fetchPriorityHeader(headers) {
    try {
      const response = await this.apiRequest('/ad/ai/keys', 'POST', {
        model: this.modelChat.name,
        prompt: headers,
        provider: this.providerChat.name,
      });

      return response;
    } catch (error) {
      this.checkAndHandleError(error);
    }
  }

  getAIResponseTextKey(obj) {
    if (!obj) {
      return null;
    }
    for (const [key, value] of Object.entries(obj)) {
      if (Array.isArray(value) && value[0]?.text) {
        return key;
      }
    }
    return null;
  }

  @action
  loadProviderAndModel() {
    if (!this.engineConfig) {
      console.warn('Engine config not initialized');
      return;
    }

    const providersAI = this.providers;

    if (providersAI?.length > 0) {
      const providerKey = this.engineConfig.localStorageKeys.provider;
      const modelKey = this.engineConfig.localStorageKeys.model;

      if (!this.localStorageUtils.get(providerKey)) {
        this.localStorageUtils.set(providerKey, providersAI[0]);
      }

      let storedProvider = this.localStorageUtils.get(providerKey);

      if (storedProvider) {
        storedProvider = providersAI.find(
          (item) => item.name === storedProvider.name,
        );

        this.localStorageUtils.set(providerKey, storedProvider);

        if (
          !this.localStorageUtils.get(modelKey) &&
          storedProvider?.models?.length > 0
        ) {
          this.localStorageUtils.set(modelKey, storedProvider.models[0]);
        }
      }

      this.providerChat = this.localStorageUtils.get(providerKey);
      this.modelChat = this.localStorageUtils.get(modelKey);
    } else {
      console.warn('No providers available to load.');
    }
  }

  @action
  async loadChatStorage(dbName) {
    let res = await this.getIndexDBData('0', dbName);
    this.chatStorage = res?.conversations ?? [];
  }

  @action
  async setData(name, value) {
    this[name] = value;
  }

  @action
  setLocalData(name, value) {
    if (!this.engineConfig) {
      console.warn('Engine config not initialized');
      return;
    }

    const providerKey = this.engineConfig.localStorageKeys.provider;
    const modelKey = this.engineConfig.localStorageKeys.model;

    const storageKey =
      name === 'providerChat'
        ? providerKey
        : name === 'modelChat'
          ? modelKey
          : name;

    this.localStorageUtils.set(storageKey, value);
    this[name] = this.localStorageUtils.get(storageKey);

    if (name === 'providerChat') {
      this.localStorageUtils.set(modelKey, value.models[0]);
      this.modelChat = this.localStorageUtils.get(modelKey);
    }
  }

  @action
  async updateChatStorage(response, index, dbName) {
    // console.log('update data', this.isNewConversation);
    if (this.isNewConversation) {
      return;
    }
    let data = (await this.getIndexDBData('0', dbName)) || {};
    let chatConversation = data?.conversations || [];

    if (index && chatConversation.length) {
      chatConversation[index] = response;
    } else {
      chatConversation.push(response);
    }
    data.conversations = chatConversation;
    await this.setIndexDBData('0', data, dbName);
    this.setData('chatStorage', chatConversation);
  }

  @action
  async clearAllData(dbName) {
    await this.deleteAllIndexDBData('0', dbName);
    this.chatStorage = [];
    this.selectedLHSTableIndex = null;
    this.responseTabs.forEach((item) => {
      item.value = null;
    });
    this.isNewConversation = true;
    this.localStorageUtils.set(this.engineConfig.localStorageKeys.selectedIndex, null)
  }

  async setIndexDBData(field, data, dataBase) {
    if (!this.dbStorage) {
      console.warn('Database storage not initialized');
      return;
    }
    await this.dbStorage[dataBase].setItem(field, data);
  }

  async getIndexDBData(field, dataBase) {
    if (!this.dbStorage) {
      console.warn('Database storage not initialized');
      return null;
    }
    return await this.dbStorage[dataBase].getItem(field);
  }

  async getAllIndexDBData(dataBase) {
    if (!this.dbStorage) {
      console.warn('Database storage not initialized');
      return [];
    }

    const result = [];

    await this.dbStorage[dataBase].iterate((value) => {
      result.push(value);
    });
    return result;
  }

  async deleteAllIndexDBData(field, dataBase) {
    if (!this.dbStorage) {
      console.warn('Database storage not initialized');
      return;
    }
    await this.dbStorage[dataBase].removeItem(field);
  }
}
