import Component from '@glimmer/component';
import { AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';

export default class ToolHeaderComponent extends Component {
  get m365Id() {
    return AUTH_TYPES?.M365?.id;
  }
}
