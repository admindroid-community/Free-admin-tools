import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';

export default class TenantSwitchDropdownComponent extends Component {
  @tracked isDomainDropdownOpen = false;
  @service('user') userService;

  get authDetails() {
    return AUTH_TYPES
  }
  @action
  handleDropdownClick(value) {
    if (typeof value === 'boolean') {
      this.isDomainDropdownOpen = value;
    } else {
      this.isDomainDropdownOpen = !this.isDomainDropdownOpen;
    }
  }

  @action
  async handleSwitchDomain(data) {
    //console.log('handleProfileClick called', data);
    this.handleDropdownClick(false);
    if (this.args.authType == AUTH_TYPES.AD.id) {
      let foundAccount = this.args.sessionData?.find(
        (item) => item.userBindID == data.userBindID,
      );
      if (foundAccount) {
        await this.userService.sessionSwitchAccount(
          AUTH_TYPES.AD.id,
          foundAccount,
        );
        return;
      }
      this.userService.openADLoginForm(data);
    } else if (this.args.authType == AUTH_TYPES.M365.id) {
      let foundAccount = this.args.sessionData.find(
        (i) => i.username == data.username,
      );
      if (foundAccount) {
        await this.userService.sessionSwitchAccount(
          AUTH_TYPES.M365.id,
          foundAccount,
        );
        return;
      }
      await this.userService.login.perform(AUTH_TYPES.M365.id, {
        mode: 'accountSpecific',
        loginHint: data.username,
      });
    } else {
      console.warn('Invalid auth type');
    }
  }

  @action
  async handleAddAccount(event) {
    event.stopPropagation();
    this.handleDropdownClick(false);
    if (this.args.authType == AUTH_TYPES.AD.id) {
      this.userService.openADLoginForm(null, true);
    } else {
      await this.userService.login.perform(this.args.authType, {
        mode: 'addAccount',
        loginHint: '',
      });
    }
  }
}
