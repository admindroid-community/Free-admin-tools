import Component from '@glimmer/component';
import {
  TOOL_INFORMATIONS,
  AUTH_TYPES
} from '@admindroid/shared-components/utils/tool-informations';
import { service } from '@ember/service';
import { action } from '@ember/object';
import { task } from 'ember-concurrency';

export default class ToolHeaderComponent extends Component {
  @service('user') userService;
  @service('chat-storage') chatStorageService

  get toolDetails() {
    return TOOL_INFORMATIONS;
  }

  get isTableResponseAvailable() {
    return this.chatStorageService.isTableResponseAvailable
  }

  get authentication() {
    return this.args.authentication;
  }
  get storedData() {
    return this.args.authType === AUTH_TYPES.M365.id
      ? this.authentication.storedProfileData
      : Object.values(this.authentication.storedData || {});
  }

  get sessionData() {
    return this.authentication.sessionData;
  }
  get currentActiveUser() {
    return this.authentication.currentActiveUser;
  }

  get selectedDomain() {
    const { authType } = this.args;

    if (authType === AUTH_TYPES.M365.id) {
      return (
        this.storedData?.find(
          (item) => item.username === this.currentActiveUser?.username,
        ) ||
        this.sessionData?.find(
          (item) => item.username === this.currentActiveUser?.username,
        )
      );
    }

    if (authType === AUTH_TYPES.AD.id) {
      return (
        Object.values(this.storedData || {}).find(
          (item) => item?.domainName === this.currentActiveUser?.domainName,
        ) ||
        this.sessionData?.find(
          (item) => item?.domainName === this.currentActiveUser?.domainName,
        )
      );
    }

    return null; // fallback for unsupported or unknown authType
  }


  handleLogin = task(async(type, userDetails) => {
    if(type == AUTH_TYPES.M365.id) {
      await this.userService.login.perform(type, userDetails)
    } else if(type == AUTH_TYPES.AD.id) {
      this.userService.openADLoginForm()
    } else {
      console.warn("Invalid auth type from tool header login", type)
    }
  })

  @action
  openResponseTab() {
    this.chatStorageService.set("selectedLHSTableIndex", localStorage.getItem(this.chatStorageService.engineConfig.localStorageKeys.selectedIndex))
  }
}
