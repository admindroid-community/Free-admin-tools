'use strict';

const EmberApp = require('ember-cli/lib/broccoli/ember-app');

module.exports = function (defaults) {
  const app = new EmberApp(defaults, {
    // Add options here
    babel: {
      plugins: [
        // ... any other plugins
        require.resolve('ember-concurrency/async-arrow-task-transform'),

        // NOTE: put any code coverage plugins last, after the transform.
      ],
    },
    fingerprint: {
      enabled: false,
    },
    minifyCSS: {
      enabled: false,
    },
    SRI: {
      enabled: false,
    },
    sourcemaps: {
      enabled: true,
      extensions: ['js']
    },
     'ember-composable-helpers': {
      only: ['call','includes'] 
    }
  });

  return app.toTree();
};
