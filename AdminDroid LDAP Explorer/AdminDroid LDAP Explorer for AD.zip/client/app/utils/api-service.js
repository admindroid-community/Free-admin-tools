import config from 'community-base-tool/config/environment';
const BASE_URL = `${config.APP.apiHost}`;

export async function apiRequest(
  endpoint,
  method = 'GET',
  data = null,
  options = {},
) {
  const config = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    credentials: options.credentials || 'same-origin',
  };

  if (data) {
    config.body = JSON.stringify(data);
  }

  const url = `${BASE_URL}${endpoint}`;

  try {
    const response = await fetch(url, config);
    const contentType = response.headers.get('Content-Type');
    //console.log(response);

    if (!response.ok) {
      let errorText = await response.text();
      //console.log('here throw sss', errorText)
      errorText = await JSON.parse(errorText);
      throw errorText;
    }

    if (contentType && contentType.includes('application/json')) {
      return await response.json();
    }

    return await response.blob();
  } catch (error) {
    console.error(`API Error [${method} ${endpoint}]:`, error);
    throw error;
  }
}
