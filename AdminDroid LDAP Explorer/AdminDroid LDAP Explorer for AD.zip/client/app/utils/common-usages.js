import localStorageUtils from './local-storage-utils';

export function getLocalUserProfileId(tool, authType) {
    let localProfiles = localStorageUtils.get('loggedProfiles');
    let profile = null
    if (localProfiles) {
        profile = localProfiles[`${tool}`]

        if (!profile) {
            profile = localProfiles[`auth${authType}`]
        }
    }
    // console.log("before return",profile)
    return profile
}
