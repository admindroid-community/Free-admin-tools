import Controller from '@ember/controller';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

export default class ApplicationController extends Controller {
  @service('settings-data') settingsDataService;
  @service('update-app') updateAppService;
  @service('authentication-active-directory') authenticationAD;
  @service('authentication-microsoft-365') authenticationM365
  @service('tool-info') toolInfoService;
  @service('tool-installer') toolInstaller;
  @service('user') userService

  @service flashMessages;

  get isExtraSidebarOpen() {
    return this.settingsDataService.isExtraSidebarOpen;
  }

  get loginPopupM365() {
    return this.authenticationM365.loginPopupM365
  }

  get updateAppData() {
    return this.updateAppService.availableUpdates;
  }

  get isToolUpdatePopup() {
    return this.updateAppService.isToolUpdatePopup;
  }
  get updateAllAppPopup() {
    return this.updateAppService.updateAllAppPopup;
  }

  get loginFormAdPopup() {
    return this.authenticationAD.loginFormAdPopup;
  }

  get currentActiveTool() {
    return this.toolInfoService.currentActiveTool;
  }

  get isToolLoading() {
    return this.toolInfoService.isToolLoading;
  }

  get isBaseAppLoading() {
    return this.toolInfoService.isBaseAppLoading;
  }

  get toolInformations(){
    return TOOL_INFORMATIONS
  }

  get currentActiveToolName() {
    return this.toolInfoService.baseToolList.find(
      (tool) => tool.moduleId === this.currentActiveTool,
    )?.moduleName;
  }

  get loadingMessage() {
    return this.toolInfoService.loadingMessage;
  }
  get appDetails() {
    return TOOL_INFORMATIONS.APP_DETAILS
  }

  @action
  preventFlashMsgClose(event) {
    event.stopPropagation();
  }
}
