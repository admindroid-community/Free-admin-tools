import Controller from '@ember/controller';
import { action } from '@ember/object';
import { tracked } from '@glimmer/tracking';
import { service } from '@ember/service';

export default class IndexController extends Controller {
  @service('settings-data') settingsDataService;

  get selectedSidebarTab() {
    return this.settingsDataService.selectedSidebarTab;
  }

  @tracked isScrolled = false;

  @action
  handleScroll() {
    this.isScrolled = window.scrollY > 0;
  }

  @action
  setupScrollListener() {
    window.addEventListener('scroll', this.handleScroll);
    this.handleScroll(); // check immediately on load
  }

  willDestroy() {
    window.removeEventListener('scroll', this.handleScroll);
  }
}
