import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import localStorageUtils from '../utils/local-storage-utils';
import {
  TOOL_INFORMATIONS,
  AUTH_TYPES,
} from '@admindroid/shared-components/utils/tool-informations';
import { task, timeout } from 'ember-concurrency';
import {getLocalUserProfileId} from '../utils/common-usages'

export default class UserService extends Service {
  @service('authentication-active-directory') authenticationAD;
  @service('authentication-microsoft-365') authenticationM365;
  @service('tool-info') toolInfoService;
  @service('engine-registry') engineRegistryService;

  @tracked authType =
    this.toolInfoService.currentActiveTool ==
      TOOL_INFORMATIONS.MODULE_M365.id ||
      this.toolInfoService.currentActiveTool ==
      TOOL_INFORMATIONS.MODULE_GRAPH_EXPLORER.id
      ? AUTH_TYPES.M365.id
      : AUTH_TYPES.AD.id;

  get ldapStateService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_LDAP_EXPLORER.id,
      'state',
    );
  }

  login = task(async (type = this.authType, { mode = 'login', loginHint = '' } = {}) => {
    if (!type) {
      type = this.authType
    }
    if (type == AUTH_TYPES.AD.id) {
      let authRes = await this.authenticationAD.adminAuthentication();
      if (!this.authenticationAD.loginFormErrorMsg) {
        await this.checkSession(type, authRes.userBindID);
      }
    } else if (type == AUTH_TYPES.M365.id) {
      let authRes = await this.authenticationM365.login({ mode, loginHint });
      await this.checkSession(type, authRes.username);
    } else {
      console.warn('Invalid user type');
    }
  });

  @action
  async handleDeleteWhileSwitchAccount() {
    // this.toolInfoService.isToolLoading = true;

    let currentProfile = getLocalUserProfileId(this.toolInfoService.currentActiveTool, this.authType)

    if (
      !this.authenticationM365.currentActiveUser &&
      !this.authenticationAD.currentActiveUser
    ) {
      await this.toolInfoService.clearAllData();
      return;
    }

    let newUserID =
      this.authType == AUTH_TYPES.M365.id
        ? this.authenticationM365.currentActiveUser?.username
        : this.authenticationAD.currentActiveUser?.userBindID;

    if (currentProfile) {
      if (!newUserID || currentProfile != newUserID) {
        await this.toolInfoService.clearAllData();
      }
    }
  }

  @action
  async logout(type) {
    if (!type) {
      type = this.authType
    }
    if (type == AUTH_TYPES.AD.id) {
      await this.authenticationAD.logout();
    } else if (type == AUTH_TYPES.M365.id) {
      await this.authenticationM365.logout();
    } else {
      console.warn('Invalid user type');
    }
    await this.checkSession(type);
  }

  @action
  async checkSession(type, username, isTempCheck) {
    if (!type) {
      type = this.authType;
    }
    if (type == AUTH_TYPES.AD.id) {
      await this.authenticationAD.getAdminDetails(username ?? getLocalUserProfileId(this.toolInfoService.currentActiveTool, this.authType)?? this.authenticationAD.currentActiveUser?.userBindID ?? null);
      if (!isTempCheck) {
        await this.handleDeleteWhileSwitchAccount();
      }
      this.storeAuthDetails(this.authenticationAD.currentActiveUser?.userBindID);

    } else if (type == AUTH_TYPES.M365.id) {
      await this.authenticationM365.checkSession(username ?? getLocalUserProfileId(this.toolInfoService.currentActiveTool, this.authType)?? this.authenticationM365.currentActiveUser?.username ?? null);
      // console.log('after logout')
      if (!isTempCheck) {
        await this.handleDeleteWhileSwitchAccount();
      }
      this.storeAuthDetails(this.authenticationM365.currentActiveUser?.username);
      // await this.toolInfoService.clearAllData();

      // if (!this.authenticationM365.currentActiveUser) {
      //   await this.toolInfoService.clearAllData()
      // }
    } else {
      console.warn('Invalid user type');
    }
  }

  @action
  async sessionSwitchAccount(type, foundAccount) {
    if (!foundAccount) {
      console.warn("Account not found to switch", foundAccount)
    }
    if (!type) {
      type = this.authType;
    }
    if (type == AUTH_TYPES.AD.id) {
      await this.checkSession(type, foundAccount.userBindID)
    } else if (type == AUTH_TYPES.M365.id) {
      await this.checkSession(type, foundAccount.username);
    } else {
      console.warn('Invalid user type');
    }
  }

  @action
  storeAuthDetails(user) {
    let localProfiles = localStorageUtils.get('loggedProfiles');
    localStorageUtils.set('loggedProfiles', {
      ...localProfiles,
      [`auth${this.authType}`]: user,
      [this.toolInfoService.currentActiveTool]: user
    });
  }

  @action
  openADLoginForm(data, isNewUser) {
    if (data) {
      this.authenticationAD.storeProfileData(data)
    } else {
      this.authenticationAD.existingUser = false
    }
    if (isNewUser !== undefined && isNewUser !== null) {
      this.authenticationAD.addNewUser = isNewUser;
    } else {
      this.authenticationAD.addNewUser = (Object.keys(this.authenticationAD.storedData ?? {}).length === 0);
    }

    this.authenticationAD.loginFormAdPopup = true;
  }

  @action
  openM365Login() {
    this.authenticationM365.set("loginPopupM365", true)
  }
}
