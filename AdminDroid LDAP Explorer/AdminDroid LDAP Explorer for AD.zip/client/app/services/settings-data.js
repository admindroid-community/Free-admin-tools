import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { TrackedArray } from 'tracked-built-ins';
import localStorageUtils from '../utils/local-storage-utils';

export default class SettingsDataService extends Service {
  history = [];
  historyMaskValues = {};
  promptChat = null;
  @tracked isMasked = localStorageUtils.get('isMasked') ?? true;
  @tracked maskedInfoPopupCount = 0;
  @tracked maskingWarningEnabled =
    localStorageUtils.get('maskingWarningEnabled') ?? true;

  @tracked selectedSidebarTab = this.sidebarTabs[0];
  @tracked isExtraSidebarOpen = true;
  @tracked askConfimationBeforeAccess =
    localStorageUtils.get('askConfimationBeforeAccess') ?? true;

  @tracked activatedTab = null;

  sidebarTabs = [
    {
      name: 'general',
      description:
        'Manage how sensitive information is protected during AI processing',
      icon: 'custom-icon-globe-with-lock',
      url: 'settings.general',
    },
    {
      name: 'provider',
      description:
        'Connect your AI provider to get answers in your chat.',
      icon: 'custom-icon-bot-node-semi-medium',
      url: 'settings.provider',
    },
    {
      name: 'about',
      description:
        'Keep your tool running smoothly with quick updates and management',
      icon: 'custom-icon-info-stroke',
      url: 'settings.about',
    },
  ];

  @action
  setData(name, value) {
    this[name] = value;
  }

  @action
  setLocalData(name, value) {
    localStorageUtils.set(name, value);
    this[name] = localStorageUtils.get(name);
  }
}
