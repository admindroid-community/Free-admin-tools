import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { task } from 'ember-concurrency';
import { apiRequest } from '../utils/api-service';
import localStorageUtils from '../utils/local-storage-utils';
import { AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';
import {getLocalUserProfileId} from '../utils/common-usages'

export default class AuthenticationActiveDirectoryService extends Service {
  // @service('user') userService;
  @service('anonymous-data-tracking') anonymousDataTrackingService;
  @service('encrypt-and-decrypt') encryptAndDecryptService;
  @service('tool-info') toolInfoService;
  @tracked loginFormErrorMsg = null;
  @tracked loginFormAdPopup = false;

  @tracked username = null;
  @tracked domainName = null;
  @tracked ipAddress = null;
  @tracked bindPassword = null;
  @tracked isStoreDetails = true;
  @tracked isUPN = false;
  @tracked isAnonymousDataStored = false;

  @tracked sessionData = null;
  @tracked storedData = null;
  @tracked currentActiveUser = null;

  @tracked isFormUI = true;
  @tracked existingUser = false;
  @tracked addNewUser = false;
  @tracked isBindDNAvailable = false;
  @tracked bindDNMsg = null;

  @action
  async adminAuthentication() {
    try {
      const response = await apiRequest(
        `/${this.toolInfoService.currentActiveTool?? this.toolInfoService.getFutureToolId()}/login`,
        'POST',
        {
          username: this.username,
          domainName: this.ipAddress ?? this.domainName,
          bindPassword: this.encryptAndDecryptService.encryption(
            this.bindPassword,
          ),
          isUPN: this.isUPN,
          storeDetails: this.isStoreDetails,
          isAnonymousDataStored:
            this.anonymousDataTrackingService.anonymousDataTracking ?? false,
        },
        {
          credentials: 'include',
        },
      );
      return response;
    } catch (error) {
      this.loginFormErrorMsg =
        error.error || 'Enter valid credentials to connect';
      console.warn(error);
      return error;
    }
  }

  @action
  async deleteProfile(profile) {
    try {
      const response = await apiRequest(
        `/${this.toolInfoService.currentActiveTool?? this.toolInfoService.getFutureToolId()}/profile/${profile.userBindID}`,
        'DELETE',
        null,
        {
          credentials: 'include',
        },
      );

      await this.getAdminDetails();
    } catch (err) {
      console.error("Delete profile", err)
    }
  }

  storeProfileData(data) {
    this.resetData();
    this.username = data.username;
    this.domainName = data.domainName;
    this.ipAddress = data.ipAddress? data.ipAddress: null;
    this.isUPN = data.isUPN;
    this.isStoreDetails = true;
    this.isFormUI = true;
    this.isBindDNAvailable = true;
    this.existingUser = true;
    // this.addNewUser = isNewUser
  }

  @action
  async getProfilePhotos() {
    if (this.sessionData.length) {
      for (const item of this.sessionData) {
        const res = await this.fetchProfilePhoto(
          item.username,
          item.userBindID,
        );
        item.thumbnailPhoto = res?.thumbnailPhoto;
      }
    }

    // if (this.storedData) {
    //   let newStoredData = {};
    //   for (let key in this.storedData) {
    //     let data = this.storedData[key]
    //     let res = await this.fetchProfilePhoto(data.username)

    //     newStoredData[key] = {
    //       ...data,
    //       thumbnailPhoto: res.thumbnailPhoto
    //     };
    //   }
    //   this.storedData = newStoredData;
    // }
  }

  @action
  async fetchProfilePhoto(username, userBindID) {
    try {
      const response = await apiRequest(
        `/${this.toolInfoService.currentActiveTool?? this.toolInfoService.getFutureToolId()}/thumbnail-photo/${userBindID}`,
        'POST',
        {
          username: username,
        },
        {
          credentials: 'include',
        },
      );
      return response;
    } catch (error) {
      console.error("fetchProfilePhoto", error)
      return error
    }

  }

  @action
  async getAdminDetails(id) {
    const response = await apiRequest(
      `/${this.toolInfoService.currentActiveTool?? this.toolInfoService.getFutureToolId()}/profile`,
      'GET',
      null,
      {
        credentials: 'include',
      },
    );

    //console.log('data', response.data);
    if (response && response.data?.sessionData.length) {
      this.sessionData = response.data.sessionData;
      await this.getProfilePhotos();

      if (!id) {
        const localUserProfileId = getLocalUserProfileId(this.toolInfoService.currentActiveTool, AUTH_TYPES.AD.id);
        id = localUserProfileId ?? this.sessionData[0].userBindID;
      }
      let foundUser = this.sessionData.find((item) => item.userBindID == id);
      if (!foundUser && this.sessionData.length) {
        foundUser = this.sessionData[0];
      }
      if (foundUser?.userBindID != this.currentActiveUser?.userBindID) {
        this.set('currentActiveUser', foundUser ?? null);
      }

    } else {
      this.sessionData = null;
      this.currentActiveUser = null;
    }
    this.storedData = response?.data?.storedData;
    return response;
  }

  @action
  async logout() {
    const response = await apiRequest(
      `/${this.toolInfoService.currentActiveTool?? this.toolInfoService.getFutureToolId()}/logout/${this.currentActiveUser.userBindID}`,
      'POST',
      null,
      {
        credentials: 'include',
      },
    );

    return response;
  }

  @action
  updateData(field, data) {
    this[field] = data;
  }

  @action
  updateInputData(event) {
    let { name, value, checked } = event.target;

    if (name === 'isUPN') {
      value = value === 'UPNName' ? true : false;
    }

    if (this.isCheckbox(event.target)) {
      this[name] = checked;
    } else {
      this[name] = value;
    }

    this.loginFormErrorMsg = null;
  }

  isCheckbox(element) {
    return element instanceof HTMLInputElement && element.type === 'checkbox';
  }

  @action
  toggleIsFormUI() {
    this.isFormUI = !this.isFormUI;
  }

  @action
  toggleExistingUser() {
    this.existingUser = !this.existingUser;
  }

  @action
  resetData() {
    this.username = null;
    this.domainName = null;
    this.ipAddress = null;
    this.bindPassword = null;
    this.isStoreDetails = true;
    this.isUPN = false;
    this.isAnonymousDataStored = false;
    this.existingUser = false;
    this.loginFormErrorMsg = null;
  }

  // @action
  // isStoredDataAvailable() {
  //   if (this.storedData == null || !this.storedData) {
  //     return false;
  //   }
  //   return Object.keys(this.storedData).length >= 1;
  // }

  @action
  async checkBindDN() {
    const response = await apiRequest(
      `/${this.toolInfoService.currentActiveTool?? this.toolInfoService.getFutureToolId()}/bind-dn/validate`,
      'POST',
      {
        username: this.username,
        domainName: this.ipAddress ?? this.domainName,
        isUPN: this.isUPN,
      },
      {
        credentials: 'include',
      },
    );

    return response;
  }

  @action
  hasValue(field) {
    //console.log('this[field] ? true: false', this[field] ? true : false);
    return this[field] ? true : false;
  }
}
