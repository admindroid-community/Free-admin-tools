import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import localStorageUtils from '../utils/local-storage-utils';

export default class AnonymousDataTrackingService extends Service {
  @tracked anonymousDataTracking =
    localStorageUtils.get('anonymousDataTracking') ?? true;

  setData(field, value) {
    this[field] = value;
  }
}
