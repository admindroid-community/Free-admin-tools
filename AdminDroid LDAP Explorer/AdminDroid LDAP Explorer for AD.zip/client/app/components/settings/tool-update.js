import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { task, timeout } from 'ember-concurrency';

export default class ToolUpdateComponent extends Component {
  @service('update-app') updateAppService;
  @service('tool-info') toolInfoService;

  get newVersion() {
    return "1.0.0.2"
  }
  get updateDetails() {
    return this.updateAppService.filteredUpdates(this.updateAppService.availableUpdates)
  }

  get currentActiveToolDetails() {
    return this.toolInfoService.baseToolList?.find(
      (item) => item.moduleId == 'ad',
    );
  }

  @action
  moveToUpdateAll() {
    this.updateAppService.setData('isToolUpdatePopup', true);
  }

  @action
  async downloadTool(id) {
    this.updateAppService.updateAllAppPopup = true;
    let tools = (typeof id === 'string') ? [id] : (this.updateAppService.availableUpdates ?? [])
      .map(item => item?.moduleId)     // get moduleId
      .filter(Boolean)                 // remove undefined/null/0
      .map(String);
    await this.updateAppService.UpdateAllApps.perform(tools);
    if (this.updateAppService.isBaseServerUpdate) {
      // return
    }
    await this.updateAppService.restartApp();

    if (!this.updateAppService.isErrorOccured) {
      await this.delay(9000);
      window.location.reload();
    }
  }

  delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  checkUpdate = task({ drop: true }, async () => {
    await this.updateAppService.checkUpdate();
    timeout(2000);
  });
}
