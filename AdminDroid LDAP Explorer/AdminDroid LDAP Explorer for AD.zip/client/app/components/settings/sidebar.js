import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';

export default class SidebarComponent extends Component {
  @service('settings-data') settingsDataService;
  @service('tool-info') toolInfoService;
  @service router;

  get selectedSidebarTab() {
    return this.settingsDataService.selectedSidebarTab;
  }

  get sidebarTabs() {
    return this.settingsDataService.sidebarTabs;
  }

  get currentActiveTool() {
    return this.toolInfoService.currentActiveTool;
  }

  @action
  handleTabClick(tab) {
    //console.log("handleTabClick called")
    this.settingsDataService.setData('selectedSidebarTab', tab);
  }
}
