import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';

export default class SidebarComponent extends Component {
  @service('settings-data') settingsDataService;
  @service router;

  get isMasked() {
    return this.settingsDataService.isMasked;
  }

  @action
  toggleMasking(event) {
    this.settingsDataService.setLocalData('isMasked', event.target.checked);
  }
}
