import Component from '@glimmer/component';
import { service } from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import config from 'community-base-tool/config/environment';
import logger from '../utils/logger';
import { task } from 'ember-concurrency';
import localStorageUtils from '../utils/local-storage-utils';
import sessionStorageUtils from '../utils/session-storage-utils';
import { AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';

export default class LoginPopupM365Component extends Component {
    @service('user') userService;
    @service('authentication-microsoft-365') authenticationM365;

    handleLogin = task(async () => {
        await this.userService.login.perform(AUTH_TYPES.M365.id);
        if (this.authenticationM365.currentActiveUser) {
            this.authenticationM365.set('loginPopupM365', false)
        }
    });

    @action
    closePopup() {
        this.authenticationM365.set('loginPopupM365', false)
    }
}
