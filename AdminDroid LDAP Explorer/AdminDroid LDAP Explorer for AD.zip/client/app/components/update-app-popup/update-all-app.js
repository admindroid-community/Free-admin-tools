import Component from '@glimmer/component';
import { service } from '@ember/service';
import { action } from '@ember/object';
import { htmlSafe } from '@ember/template';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

export default class UpdateAppPopupComponent extends Component {
  @service('update-app') updateAppService;

  get isErrorOccured() {
    return this.updateAppService.isErrorOccured;
  }

  get appDetails() {
    return TOOL_INFORMATIONS.APP_DETAILS
  }

  get currentUpdateTool() {
    return this.updateAppService.currentUpdateTool;
  }

  get UpdateAllApps() {
    return this.updateAppService.UpdateAllApps;
  }

  get updateStatusText() {
    if (this.updateAppService.UpdateAllApps.isRunning) {
      return htmlSafe(
        `Updating your AdminDroid ${this.currentUpdateTool.moduleName}... <span class="droid-custom-icon-inportal-updates"></span>`,
      );
    } else if (this.isErrorOccured) {
      return htmlSafe(
        `<span class="droid-custom-icon-exclamation-solid"></span> Failed to update, try later`,
      );
    }  else if (this.updateAppService.isBaseServerUpdate) {
      return htmlSafe(
        `🚀 Launching tool in a new tab. Refresh if it doesn’t open. <span class="droid-custom-icon-spinner3 spinner"></span>`,
      );
    }  else {
      return htmlSafe(
        `🚀 Preparing to launch, wait a moment... <span class="droid-custom-icon-spinner3 spinner"></span>`,
      );
    }
  }

  @action
  closePopup() {
    this.updateAppService.setData('updateAllAppPopup', false);
  }
}
