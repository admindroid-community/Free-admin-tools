import Application from '@ember/application';
import Resolver from 'ember-resolver';
import loadInitializers from 'ember-load-initializers';
import 'ember-power-select/styles';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';
import config from 'community-base-tool/config/environment';

export default class App extends Application {
  modulePrefix = config.modulePrefix;
  podModulePrefix = config.podModulePrefix;
  Resolver = Resolver;

  engines = {
    [TOOL_INFORMATIONS.MODULE_AD.id]: {
      dependencies: {
        services: [
          'router',
          'engine-registry',
          { 'authentication-ad': 'authentication-active-directory' },
          'settings-data',
          'ai-providers',
          'user',
          { 'tool-information': 'tool-info' },
          'flashMessages',
        ],
        externalRoutes: {
          'settings': 'settings',
          'settingsProvider': 'settings.provider'
        }
      },

    },
    [TOOL_INFORMATIONS.MODULE_M365.id]: {
      dependencies: {
        services: [
          'router',
          'engine-registry',
          { 'authentication-m365': 'authentication-microsoft-365' },
          'settings-data',
          'ai-providers',
          'user',
          { 'tool-information': 'tool-info' },
          'flashMessages',
        ],
        externalRoutes: {
          'settings': 'settings',
          'settingsProvider': 'settings.provider'
        }
      },
    },
    [TOOL_INFORMATIONS.MODULE_GRAPH_EXPLORER.id]: {
      dependencies: {
        services: [
          'router',
          { 'authentication-m365': 'authentication-microsoft-365' },
          'settings-data',
          'engine-registry',
          'user',
          'index-db-storage',
          { 'tool-information': 'tool-info' },
          'flashMessages',
        ],
      },
    },
    [TOOL_INFORMATIONS.MODULE_LDAP_EXPLORER.id]: {
      dependencies: {
        services: [
          'router',
          { 'authentication-ad': 'authentication-active-directory' },
          'engine-registry',
          'settings-data',
          'user',
          { 'tool-information': 'tool-info' },
          'flashMessages'
        ],
      },
    },
  };
}

loadInitializers(App, config.modulePrefix);
