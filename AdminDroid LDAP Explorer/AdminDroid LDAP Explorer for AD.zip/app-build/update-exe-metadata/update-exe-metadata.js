import * as PELibrary from 'pe-library';
import * as ResEdit from 'resedit';
import * as fs from 'fs';


console.log("\nModifying EXE metadata")


const filename = 'tool.exe';
const modifiedFilename = 'tool_modified.exe'
const info = {
    FileDescription: 'AdminDroid Community Tool',
    ProductName: 'Community Tool',
    CompanyName: 'AdminDroid',
    LegalCopyright: '© 2025 AdminDroid',
    OriginalFilename: filename,
    InternalName: 'AdminDroid Community Tool'
};

const version = '1.0.0.3';

try {

    const versionSplit = version.split('.');
    const major = versionSplit[0] ?? 1;
    const minor = versionSplit[1] ?? 0;
    const micro = versionSplit[2] ?? 0;
    const revision = versionSplit[3] ?? 0;

    console.log(`Reading ${filename}...`);
    const data = fs.readFileSync(filename);

    const exe = PELibrary.NtExecutable.from(data);
    const res = PELibrary.NtExecutableResource.from(exe);

    console.log('Original file size:', data.length, 'bytes');

    const viList = ResEdit.Resource.VersionInfo.fromEntries(res.entries);

    if (viList.length > 0) {
        const vi = viList[0];

        vi.setFileVersion(major, minor, micro, revision, 1033);
        vi.setProductVersion(major, minor, micro, revision, 1033);

        vi.setStringValues(
            { lang: 1033, codepage: 1200 },
            info
        );

        vi.outputToResourceEntries(res.entries);
        console.log('Version info updated');
    }

    const iconPath = 'icon.ico';
    let iconReplaced = false;

    if (fs.existsSync(iconPath)) {
        try {
            const iconFile = ResEdit.Data.IconFile.from(fs.readFileSync(iconPath));
            const iconGroups = ResEdit.Resource.IconGroupEntry.fromEntries(res.entries);

            if (iconGroups.length > 0) {
                const originalIcons = iconGroups[0];
                const iconGroupID = originalIcons.id;

                console.log(`\nIcon analysis:`);
                console.log(`- New icon file: ${fs.statSync(iconPath).size} bytes`);
                console.log(`- Number of icons in new file: ${iconFile.icons.length}`);

                const smallerIcons = iconFile.icons.filter(icon => {
                    const size = icon.height;
                    return size <= 256;
                });

                if (smallerIcons.length > 0) {
                    console.log(`- Using ${smallerIcons.length} smaller icons (≤256x256)`);

                    ResEdit.Resource.IconGroupEntry.replaceIconsForResource(
                        res.entries,
                        iconGroupID,
                        1033,
                        smallerIcons.map((item) => item.data)
                    );

                    iconReplaced = true;
                    console.log(`Icons replaced (ID: ${iconGroupID})`);
                } else {
                    console.log('No suitable small icons found in icon file');
                }
            }
        } catch (iconError) {
            console.error('Icon error:', iconError.message);
        }
    } else {
        console.log(`Icon file not found: ${iconPath}`);
    }

    try {
        res.outputResource(exe, true);

        const newBinary = exe.generate();
        const peSize = newBinary.byteLength;
        const originalSize = data.length;

        console.log('\nModified PE size:', peSize, 'bytes');

        if (originalSize > peSize) {
            console.log('Preserving PKG overlay data...');

            const overlay = data.slice(peSize);
            console.log(`Overlay size: ${overlay.length} bytes`);

            const finalBinary = Buffer.concat([
                Buffer.from(newBinary),
                overlay
            ]);

            fs.writeFileSync(modifiedFilename, finalBinary);
            console.log(`\nSuccess! Created ${modifiedFilename}`);
            console.log(`Final size: ${finalBinary.length} bytes (original: ${originalSize})`);

            if (!iconReplaced) {
                console.log('\nNote: Icons were NOT replaced due to size constraints');
                console.log('   Version info and other metadata were updated successfully');
            }
        } else {
            fs.writeFileSync(modifiedFilename, Buffer.from(newBinary));
            console.log(`\nSuccess! Created ${modifiedFilename}`);
        }

    } catch (outputError) {
        if (outputError.message.includes('larger than original')) {
            console.error('\nResource section too large!');
            console.log('\nPossible solutions:');
            console.log('1. Use a smaller icon file (< 100KB)');
            console.log('2. Use Resource Hacker tool instead (Windows GUI tool)');
            console.log('3. Skip icon replacement - only update version info');

            console.log('\nAttempting to create file WITHOUT icon changes...');

            const data2 = fs.readFileSync(filename);
            const exe2 = PELibrary.NtExecutable.from(data2);
            const res2 = PELibrary.NtExecutableResource.from(exe2);

            const viList2 = ResEdit.Resource.VersionInfo.fromEntries(res2.entries);
            if (viList2.length > 0) {
                const vi2 = viList2[0];
                vi2.setFileVersion(major, minor, micro, revision, 1033);
                vi2.setProductVersion(major, minor, micro, revision, 1033);
                vi2.setStringValues(
                    { lang: 1033, codepage: 1200 },
                    info
                );
                vi2.outputToResourceEntries(res2.entries);
            }

            res2.outputResource(exe2, true);
            const newBinary2 = exe2.generate();
            const overlay2 = data2.slice(newBinary2.byteLength);
            const finalBinary2 = Buffer.concat([Buffer.from(newBinary2), overlay2]);

            fs.writeFileSync(modifiedFilename, finalBinary2);
            console.log('Created file with version info only (no icon changes)');
        } else {
            throw outputError;
        }
    }

} catch (error) {
    console.error('\nFatal Error:', error.message);
    console.error(error.stack);
}
