Build & Deploy Guide
====================

This project provides two Windows batch scripts that allow you to build and deploy the application on your local system.

IMPORTANT:
Run the scripts in the given order:
1. build.bat
2. deploy.bat

--------------------------------------------------

Prerequisites
-------------

This project requires the following tools to be installed on your system
before running the build process.

Required:
---------
1. Windows 10 or later
2. Node.js version 18 or higher
3. npm (installed with Node.js)
4. Ember CLI (global installation)

Optional but Recommended:
-------------------------
- Git
- Administrator privileges

Notes:
------
- Node.js must be added to the system PATH
- Ember CLI must be installed globally using npm
- The build script will automatically check and install missing dependencies

Always run the batch files using **Run as Administrator** to avoid permission issues.

--------------------------------------------------

Step 1: Build the Application
-----------------------------
The build.bat script prepares and builds the application.

How to run:
1. Open Command Prompt or PowerShell
2. Navigate to the project root directory
3. Run:
   build.bat as Admin

What this does:
- Validates required paths and dependencies
- Creates necessary directories if missing
- Copies essential source files
- Builds the application output

Wait until the script finishes completely before proceeding.

--------------------------------------------------

Step 2: Deploy the Application
------------------------------
After a successful build, run the deploy.bat script as Admin.

How to run:
deploy.bat

What this does:
- Deploys the built application to the target directory
- Performs final setup and configuration
- Prepares the application for execution

--------------------------------------------------

Running the Application
-----------------------
After deployment, run the generated executable:

<DEPLOY_PATH>\AdminDroid_Community_Tool.exe

It is recommended to run the executable as Administrator.

--------------------------------------------------

Common Issues
-------------
- Permission denied: Run scripts as Administrator
- Missing dependency: Ensure all required software is installed and added to PATH
- Path not found: Do not move files during build or deploy

--------------------------------------------------

Support
-------
If you face issues:
- Re-run build.bat followed by deploy.bat
- Check console output for errors
- Open an issue in the repository with logs

--------------------------------------------------

You are now ready to build and deploy the application.
