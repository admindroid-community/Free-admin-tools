# Contributing to the MCP Tool

Thanks for your interest in contributing! This project is a Node.js app that hosts an Ember.js client with four Ember Engines, plus a Windows launcher and build tooling. The repository is structured as a small monorepo with distinct `server` and `client` projects and a build pipeline that packages updateable modules.

This guide covers how to set up your environment, run the app locally, make changes, and submit pull requests.

## Project Overview

- `server/` — Express server that:
  - Serves the built Ember app in non‑development builds
  - Exposes APIs and dynamically loads server “modules” from `server/module/<name>`
  - Handles auto‑update integration and app config via `server/config/appInfo.js`
- `client/` — Ember host app with four Engines under `client/lib/`:
  - Engines: `ad`, `graph-explorer`, `ldap-explorer`, `m365`
  - Additional local addons in `client/addon-workbench`

Refer to `server/README.md` and `client/README.md` for component‑specific details.

## Prerequisites

- Node.js 18+ and npm
- Git
- Ember CLI (`npm i -g ember-cli`) for local dev convenience
- Windows (required to run the provided `.bat` build scripts). Development on macOS/Linux is fine for code/test.

## Getting Started (Local Dev)

Install dependencies:

1. Backend

```
cd server
npm install
```

2. Frontend

```
cd client
npm install
```

Run in two terminals:

- Backend: `cd server && npm start`
- Frontend: `cd client && npm start`

By default, the server allows CORS from `http://localhost:4200` and similar (see `server/config/appInfo.js`). Visit the client at `http://localhost:4200`.

Environment toggles (server):

- `BUILD_TYPE=development|testing|production`
- `CORS_ORIGINS`, `PREFERRED_PORTS`, `SESSION_SECRET` or `SESSION_SECRETS`, etc. See `server/config/appInfo.js` for full list.

## Tests & Linting

- Frontend (Ember):
  - `npm run test`
  - `npm run lint`
  - `npm run lint:fix`
- Backend: follow patterns in `server/` and run any linters/tests as added. The server uses a structured logger and error pattern (see `server/README.md`).

## Coding Standards

- JavaScript/Ember conventions via ESLint, Prettier, ember-template-lint, and stylelint (see config in `client/`).
- Prefer small, focused PRs.
- Commit messages: please use Conventional Commits (e.g., `feat:`, `fix:`, `docs:`, `refactor:`, `chore:`). This helps with changelogs and release notes.

## Making Changes

1. Create a feature branch: `git checkout -b feat/my-change`
2. Implement changes in `server/` and/or `client/`
3. Add/adjust tests where appropriate
4. Run linters and tests locally
5. Open a Pull Request (PR) against the default branch

### Adding a New Ember Engine

- Create a new engine under `client/lib/<engine-name>` following the existing engines as examples.
- Ensure the engine’s `package.json` lists `ember-engine` keywords and necessary addons.
- Register the engine in the host app routing or loader as required by the UI flow.
- Build and verify: `cd client && npm run build` and run the server in development.

### Adding a New Backend Module

- Create a module under `server/module/<module-id>` with at least:
  - `src/router.js` exporting an Express router (development loading)
  - `config/info.json` with `moduleId`, `moduleName`, and `version`
- During development, modules are loaded from `server/module` via `ModuleLoaderService`.
- For packaging, modules are bundled with Rollup: see the build section below.

## Error Handling & Logging (Backend)

- Use `sendAndLogError` and the namespaced logger as described in `server/README.md`.
- Avoid `console.log`; prefer the logger.

## Build & Packaging (High Level)

For local packaging and release artifacts, see RELEASES.md. In short:

- Run `app-build/common-build.bat` on Windows to:
  - Pick the environment (testing/production)
  - Update versions for base server/client and each module
  - Build client, roll up server modules, package the server binary, and produce zip artifacts under `app-build/output/`
- Optionally use `app-build/test-build-locally.bat` to expand the zips into a local install for quick validation.

## Security and Conduct

- Please report security issues privately. See `SECURITY.md`.
- Be respectful and follow our `CODE_OF_CONDUCT.md`.

## Pull Requests

- Fill out the PR template to explain the change, testing, and any risk.
- Ensure CI (if present) is green.
- Maintainers may request small follow‑ups for style or test coverage.

## Questions

Open a Discussion/Issue with context, logs, repro steps, and environment details. We’re happy to help you get started.
