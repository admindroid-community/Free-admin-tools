<#
.SYNOPSIS
  Start the Tool development environment: set env vars, ensure dependencies, and launch server + client.

.DESCRIPTION
  - Determines script root and locates ../server and ../client.
  - Sets environment variables used by child processes: BUILD_TYPE, SERVER_PORT, CORS_ORIGINS.
  - Creates the install directory if missing.
  - Runs "npm install" in each project when node_modules is absent.
  - Starts server and client in separate PowerShell windows (client is started with the specified client port).

.PARAMETER BuildType
  Build configuration to expose to child processes via BUILD_TYPE. Default: "development".

.PARAMETER ServerPort
  Port assigned to the server and exposed via SERVER_PORT. Default: 3000.

.PARAMETER ClientPort
  Port used by the client and included in CORS_ORIGINS. Default: 4200.

.EXAMPLE
  ./scripts/dev-start.ps1

.EXAMPLE
  ./scripts/dev-start.ps1 -ServerPort 3001 -ClientPort 4201
#>

param(
  [int]$ServerPort = 3000,
  [int]$ClientPort = 4200
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

[string]$BuildType = "development"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$BackendDir = Join-Path $Root '..' | Join-Path -ChildPath 'server'
$FrontendDir = Join-Path $Root '..' | Join-Path -ChildPath 'client'
$InstallPath =  $Root 

if (-not (Test-Path $InstallPath)) {
  New-Item -ItemType Directory -Force -Path $InstallPath | Out-Null
}

# Environment for child processes
$env:BUILD_TYPE = $BuildType
$env:SERVER_PORT = $ServerPort
$env:CORS_ORIGINS = "http://localhost:$ClientPort"

Write-Host "Environment configured:" -ForegroundColor Cyan
Write-Host "  BUILD_TYPE       = $($env:BUILD_TYPE)"
Write-Host "  SERVER_PORT      = $($env:SERVER_PORT)"
Write-Host "  CORS_ORIGINS     = $($env:CORS_ORIGINS)"

function Ensure-NpmInstall($Dir) {
  if (-not (Test-Path (Join-Path $Dir 'package.json'))) { return }
  if (-not (Test-Path (Join-Path $Dir 'node_modules'))) {
    Write-Host "Installing npm packages in $Dir ..." -ForegroundColor Yellow
    Push-Location $Dir
    try {
      npm install | Write-Output
    } finally {
      Pop-Location
    }
  }
}

Ensure-NpmInstall $BackendDir
Ensure-NpmInstall $FrontendDir

Write-Host "Starting server and client in separate windows..." -ForegroundColor Cyan

# Start server
Start-Process -FilePath "powershell.exe" -WorkingDirectory $BackendDir -ArgumentList @('-NoExit','-Command','npm start') | Out-Null

# Start client
Start-Process -FilePath "powershell.exe" -WorkingDirectory $FrontendDir -ArgumentList @('-NoExit',"-Command","npm start -- --port $ClientPort") | Out-Null

Write-Host "Open http://localhost:$ClientPort in your browser." -ForegroundColor Green

