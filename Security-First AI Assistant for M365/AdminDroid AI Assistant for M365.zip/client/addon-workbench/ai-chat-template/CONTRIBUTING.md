# How To Contribute

## Installation

- `git clone <repository-url>`
- `cd ai-chat-template`
- `npm install`

## Linting

- `npm run lint`
- `npm run lint:fix`

## Running tests

- `npm run test` – Runs the test suite on the current Ember version
- `npm run test:ember -- --server` – Runs the test suite in "watch mode"
- `npm run test:ember-compatibility` – Runs the test suite against multiple Ember versions

## Running the dummy application

- `npm run start`
- Visit the dummy application at [http://localhost:4200](http://localhost:4200).

For more information on using ember-cli, visit [https://cli.emberjs.com/release/](https://cli.emberjs.com/release/).
