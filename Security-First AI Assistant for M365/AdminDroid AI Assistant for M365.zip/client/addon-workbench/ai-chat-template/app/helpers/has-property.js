export { default } from 'ai-chat-template/helpers/has-property';
