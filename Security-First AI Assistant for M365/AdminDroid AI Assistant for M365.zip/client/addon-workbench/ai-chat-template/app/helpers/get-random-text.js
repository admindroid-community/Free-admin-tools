export { default } from 'ai-chat-template/helpers/get-random-text';
