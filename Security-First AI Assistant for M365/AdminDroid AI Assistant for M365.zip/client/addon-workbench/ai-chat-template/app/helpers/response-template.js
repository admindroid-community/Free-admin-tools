export { default } from 'ai-chat-template/helpers/response-template';
