export { default } from 'ai-chat-template/helpers/decrement';
