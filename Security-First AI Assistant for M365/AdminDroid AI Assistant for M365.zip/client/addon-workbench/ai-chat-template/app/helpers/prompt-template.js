export { default } from 'ai-chat-template/helpers/prompt-template';
