export { default } from 'ai-chat-template/helpers/is-string';
