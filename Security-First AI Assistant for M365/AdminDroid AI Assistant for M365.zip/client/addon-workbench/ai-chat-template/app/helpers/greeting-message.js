export { default } from 'ai-chat-template/helpers/greeting-message';
