export { default } from 'ai-chat-template/helpers/print-json';
