export { default } from 'ai-chat-template/helpers/admin-prompt';
