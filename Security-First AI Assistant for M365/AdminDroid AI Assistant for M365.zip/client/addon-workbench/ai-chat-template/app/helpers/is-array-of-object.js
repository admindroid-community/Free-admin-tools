export { default } from 'ai-chat-template/helpers/is-array-of-object';
