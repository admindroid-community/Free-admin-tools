export { default } from 'ai-chat-template/components/resize-bar';
