export { default } from 'prompt-box/components/ai-chat-box';
