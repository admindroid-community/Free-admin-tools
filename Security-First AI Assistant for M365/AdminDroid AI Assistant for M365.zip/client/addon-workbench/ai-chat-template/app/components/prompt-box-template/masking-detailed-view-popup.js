export { default } from 'ai-chat-template/components/prompt-box-template/masking-detailed-view-popup';
