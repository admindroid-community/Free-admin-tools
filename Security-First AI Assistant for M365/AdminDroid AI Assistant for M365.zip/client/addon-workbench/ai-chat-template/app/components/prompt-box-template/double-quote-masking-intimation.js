export { default } from 'ai-chat-template/components/prompt-box-template/double-quote-masking-intimation';
