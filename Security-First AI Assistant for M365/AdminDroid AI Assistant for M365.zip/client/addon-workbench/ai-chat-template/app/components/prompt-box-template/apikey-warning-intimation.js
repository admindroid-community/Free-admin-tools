export { default } from 'ai-chat-template/components/prompt-box-template/apikey-warning-intimation';
