export { default } from 'ai-chat-template/components/prompt-box-template/consent-permission-popup';
