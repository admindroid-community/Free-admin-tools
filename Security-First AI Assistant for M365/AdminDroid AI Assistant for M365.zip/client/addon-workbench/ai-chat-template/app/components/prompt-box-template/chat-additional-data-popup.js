export { default } from 'ai-chat-template/components/prompt-box-template/chat-additional-data-popup';
