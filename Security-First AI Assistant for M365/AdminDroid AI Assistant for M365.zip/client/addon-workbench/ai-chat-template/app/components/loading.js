export { default } from 'ai-chat-template/components/loading';
