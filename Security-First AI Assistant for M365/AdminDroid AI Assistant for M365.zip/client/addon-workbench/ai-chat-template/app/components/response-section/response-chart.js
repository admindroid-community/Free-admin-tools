export { default } from 'ai-chat-template/components/response-section/response-chart';
