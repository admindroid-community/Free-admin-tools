export { default } from 'ai-chat-template/components/ai-chat-template';
