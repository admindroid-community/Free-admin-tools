export { default } from 'ai-chat-template/components/input-suggestions';
