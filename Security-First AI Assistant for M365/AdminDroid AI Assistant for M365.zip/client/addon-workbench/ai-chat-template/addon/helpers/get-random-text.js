import { helper } from '@ember/component/helper';

export default helper(function getRandomText([data]) {
  if (!Array.isArray(data) || data.length === 0) {
    return 'Loading...';
  }

  const index = Math.floor(Math.random() * data.length);
  return data[index];
});
