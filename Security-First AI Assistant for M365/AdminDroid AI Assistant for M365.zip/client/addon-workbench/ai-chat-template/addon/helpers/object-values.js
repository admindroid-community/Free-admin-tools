import { helper } from '@ember/component/helper';

export default helper(function objectValues([obj]) {
  if (!obj || typeof obj !== 'object') {
    return [];
  }
  return Object.values(obj);
});
