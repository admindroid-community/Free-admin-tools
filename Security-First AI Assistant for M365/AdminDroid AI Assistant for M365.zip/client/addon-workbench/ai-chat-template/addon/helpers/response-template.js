import { helper } from '@ember/component/helper';
import { htmlSafe } from '@ember/template';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

export default helper(function responseTemplate([data],{ currentActiveTool }) {
  if (!data) return htmlSafe('');

  let url =TOOL_INFORMATIONS.MODULE_AD.id == currentActiveTool?"https://admindroid.com/active-directory-all-in-one-tool":"https://admindroid.com"

  let result = data
    .replace(/\n/g, '<br>') // Replace \n with <br>
    .replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;') // Replace \t with tab (4 spaces)
    .replace(/\*\*(.*?)\*\*/g, '<span class="title">$1</span>') // Replace **word** with <span class="title">word</span>
    .replace(/`([^`]+)`/g, '<strong>$1</strong>') // Replace `word` with <strong>word</strong>
    .replace(/\[\[RESTRICTED\]\]/g, `<span>Try <span class="admin-link"><a style="text-decoration: none;" href=${url} target="_blank" rel="noopener noreferrer">AdminDroid 365</a> </span> to explore additional features, deeper insights and management actions.</span>`);

  return htmlSafe(result);
});
