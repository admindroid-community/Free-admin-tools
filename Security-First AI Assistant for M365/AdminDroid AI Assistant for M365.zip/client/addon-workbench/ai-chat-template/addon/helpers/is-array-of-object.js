import { helper } from '@ember/component/helper';

export default helper(function isArrayOfObjects([data]) {
  // Basic sanity check
  if (!Array.isArray(data) || data.length === 0) {
    return false;
  }

  // Ensure every element is an object (and not null or array)
  return data.every(item =>
    Object.prototype.toString.call(item) === '[object Object]'
  );
});
