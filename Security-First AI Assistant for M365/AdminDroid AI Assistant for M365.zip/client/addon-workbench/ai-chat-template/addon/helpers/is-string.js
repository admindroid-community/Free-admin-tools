import { helper } from '@ember/component/helper';
import { typeOf } from '@ember/utils';

export default helper(function isString([value]) {
  return typeOf(value) === 'string';
});
