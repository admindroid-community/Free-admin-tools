import Helper from '@ember/component/helper';

const STORAGE_KEY = 'admin-helper-prompt';
const STORAGE_TIME_KEY = 'admin-helper-time';
const FIVE_HOURS_MS = 5 * 60 * 60 * 1000;

export default class AdminPromptHelper extends Helper {
  prompts = [
    'What administrative task can I assist with?',
    'How can I help, Administrator?',
    'What administrative insights do you need?',
    'What would you explore today, Admin?',
    'What admin task needs attention today?',
    'How can I assist you, Admin?',
  ];

  compute() {
    const storedPrompt = localStorage.getItem(STORAGE_KEY);
    const storedTime = localStorage.getItem(STORAGE_TIME_KEY);
    const now = Date.now();

    if (storedPrompt && storedTime && now - storedTime < FIVE_HOURS_MS) {
      // Return stored prompt if 5 hours haven't passed
      return storedPrompt;
    } else {
      // Pick a new prompt and save it with current time
      const newPrompt =
        this.prompts[Math.floor(Math.random() * this.prompts.length)];
      localStorage.setItem(STORAGE_KEY, newPrompt);
      localStorage.setItem(STORAGE_TIME_KEY, now);
      return newPrompt;
    }
  }
}
