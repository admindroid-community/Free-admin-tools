import { helper } from '@ember/component/helper';
import { htmlSafe } from '@ember/template';

export default helper(function promptTemplate([
  str,
  suggestions = [],
  isMasked,
]) {
  let result = str;

  // Only apply masking if isMasked is true
  if (isMasked) {
    // Highlight quoted substrings
    result = result.replace(
      /"([^"]+)"/g,
      '<span class="masked-data">$1</span>',
    );

    const patterns = [
      /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, // email
      /\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b/g, // id
      /\b(?=(?:\D*\d){10,})(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{2,4}\)?[\s-]?)?\d{3,4}[\s-]?\d{4}\b/g, // phone
      /\bhttps?:\/\/[^\s/$.?#].[^\s]*\b/g, // url
      // /\b(?:\d{1,2}[-\/]\d{1,2}[-\/]\d{4}|\d{4}[-\/]\d{1,2}[-\/]\d{1,2})\b/g, // date
      /\b(?:\d{1,3}\.){3}\d{1,3}\b/g, // ip
      /\b\d{5,6}\b/g, // postal
      /\b(?:\d[ -]*?){13,19}\b/g, // card
      /(?:^|\s)@[A-Za-z0-9_]{3,20}\b/g, // username
      /(?:(?:CN|OU|DC|L|ST|O|C|UID|SN|GN)=(?:(?!(?:CN|OU|DC|L|ST|O|C|UID|SN|GN)=)[^,\n])+,)+(?:CN|OU|DC|L|ST|O|C|UID|SN|GN)=(?:[^\s,\n]+)/gi, // dn
    ];

    patterns.forEach((r) => {
      result = result.replace(
        /(<span class="masked-data">.*?<\/span>)|([^<]+)/g,
        (m, masked, text) =>
          masked ||
          text.replace(r, (x) => `<span class="masked-data">${x}</span>`),
      );
    });
  }

  // Only apply suggestions if suggestions array exists and has length
  // 2. Handle Suggestions
  if (Array.isArray(suggestions) && suggestions.length > 0) {
    const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    suggestions.forEach((word) => {
      const regex = new RegExp(`\\b${escapeRegex(word)}\\b`, 'gi');

      result = result.replace(
        /(<span class="masked-data">.*?<\/span>)|([^<]+)/gi,
        (match, maskedPart, textPart) => {
          if (maskedPart) return maskedPart;

          return textPart.replace(regex, (m) => {
            return `<span class="suggested-data">${m}</span>`;
          });
        },
      );
    });
  }

  // Replace newlines with <br> after all replacements
  result = result.replace(/\n/g, '<br>');

  return htmlSafe(result);
});
