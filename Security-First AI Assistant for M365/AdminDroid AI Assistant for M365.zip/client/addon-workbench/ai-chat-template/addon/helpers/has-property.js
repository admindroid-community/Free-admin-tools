// app/helpers/has-property.js
import { helper } from '@ember/component/helper';

export default helper(function hasProperty([obj, propName]) {
  if (obj && typeof obj === 'object') {
    if (propName in obj) {
      return true;
    }
    for (let key in obj) {
      if (typeof obj[key] === 'object' && hasProperty([obj[key], propName])) {
        return true;
      }
    }
  }
  return false;
});
