// app/helpers/are-values-equal.js
import { helper } from '@ember/component/helper';

export default helper(function areValuesEqual([val1, val2] /*, named*/) {
  // Convert both to string and compare
  return String(val1) === String(val2);
});
