import { helper } from '@ember/component/helper';

export default helper(function printJson([value]) {
  return JSON.stringify(value, null, 4);
});
