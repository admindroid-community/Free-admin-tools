import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action, set, setProperties } from '@ember/object';
import { task } from 'ember-concurrency';
import { service } from '@ember/service';
import { Chart, registerables } from 'chart.js';
import { htmlSafe } from '@ember/template';
import { apiRequest } from '../utils/api-service';
import {
  TOOL_INFORMATIONS,
  AUTH_TYPES,
  getExportToolName,
} from '@admindroid/shared-components/utils/tool-informations';

import ensureCallback from '@admindroid/shared-components/utils/common-usages'
import { extractDomTable, buildExportFilename, formatGeneratedAt } from '@admindroid/shared-components/utils/report-export';

export default class AIChatTemplateComponent extends Component {
  @tracked consentPermissionPopup = false;
  @tracked writeOperationConfirmation = false;
  MCPResponse = null;

  @tracked chatWidth = localStorage.getItem('chatWidth') || 380;
  resizer = null;
  isResizing = false;

  @tracked tableHeader = [];
  @tracked currentPrompt = this.chatFormDataService.promptChat ?? '';
  @tracked tablePrompt = '';
  @tracked isCurrentPromptMasked = false;
  @tracked showLimitationErrorBanner = {
    isShow: false,
    message: ''
  }

  @service('common-store-data') commonStoreDataService;
  @service flashMessages;
  @service('user') userService;
  @service router;

  get currentActiveUser() {
    return this.args.currentActiveUser;
  }
  get askConfimationBeforeAccess() {
    return this.args.askConfimationBeforeAccess;
  }
  get chatStorage() {
    return this.chatStorageService.chatStorage;
  }

  get maskingIntimation() {
    return this.commonStoreDataService.maskingIntimation;
  }
  get isNewConversation() {
    return this.chatFormDataService.isNewConversation;
  }

  get selectedAdditionalChatDataPopup() {
    return this.chatStorageService.selectedAdditionalChatDataPopup;
  }
  @action
  async updateChatStorage(response, index, dbName) {
    await this.chatStorageService.updateChatStorage(response, index, dbName);
  }

  get chatStorageService() {
    return this.args.chatStorageService;
  }
  get providers() {
    return this.AIProvidersService.providers;
  }

  get isResponseOpen() {
    return this.chatStorageService.isResponseOpen;
  }
  get providerChat() {
    return this.chatStorageService.providerChat;
  }
  get modelChat() {
    return this.chatStorageService.modelChat;
  }
  get isMasked() {
    return this.args.isMasked;
  }
  get responseTabs() {
    return this.chatStorageService.responseTabs;
  }
  get selectedLHSTableIndex() {
    return this.chatStorageService.selectedLHSTableIndex;
  }
  get isSwitchConfirmation() {
    return this.commonStoreDataService.isSwitchConfirmation;
  }
  get chatFormDataService() {
    return this.args.chatFormDataService;
  }
  get engineConfig() {
    return this.chatStorageService.engineConfig;
  }
  get currentActiveTool() {
    return this.args.currentActiveTool;
  }

  loadingMessages = [
    'Fetching data',
    'Almost there',
    'Compiling thoughts',
    'Generating response',
    'Just a moment',
    'Processing your request',
  ];
  handleSubmitChatForm = task(
    { restartable: true },
    async (event, errorMsg) => {
      await this.getAIResponse.perform(event, errorMsg);
    },
  );

  handleSubmitChartGeneration = task({ drop: true }, async (event) => {
    event.preventDefault();
    if (!this.isUserLoggedIn()) {
      return;
    }

    if (!this.chatStorageService.responseTabs[1].value) {
      this.chatStorageService.responseTabs[1].value = {};
      this.chatStorageService.responseTabs[1].value.prompt = this.tablePrompt;
    } else {
      this.chatStorageService.responseTabs[1].value.prompt = this.tablePrompt;
    }

    this.chatStorageService.updateLHSTabValue(1, {
      prompt: this.tablePrompt
    })

    this.chatStorageService.handleTabClick(1);
    this.chatFormDataService.setData('promptTable', this.tablePrompt);
    this.tablePrompt = null;
    const response = await this.generateChartCode(3);
    await this.handleChartResponse(response);
    this.chatFormDataService.setData('promptTable', null);
  });

  handleLinkChartGeneration = task({ drop: true }, async (event) => {
    const response = await this.generateChartCode(3);
    await this.handleChartResponse(response);
    this.chatStorageService.handleTabClick(1);
  });

  @action
  isUserLoggedIn() {
    if (this.currentActiveUser) {
      return true;
    }
    if (ensureCallback(this.args.openUserLogin, "openUserLogin")) {
      this.args.openUserLogin?.()
    }

    return false;
  }

  getAIResponse = task({ restartable: true }, async (event, errInput) => {
    if (event) {
      event.preventDefault();
    }

    if (!this.isUserLoggedIn()) {
      return;
    }

    if (!this.providerChat.apiKeys.length) {
      // this.checkAndShowAPIKeyWarning();
      return;
    }

    this.chatStorageService.isNewConversation = false;

    if (!this.currentPrompt && !errInput) {
      this.flashMessages.warning('Enter a valid input!', {
        sticky: true,
        preventDuplicates: true,
      });
      return;
    }

    this.chatFormDataService.setData(
      'promptChat',
      errInput ? JSON.stringify(errInput) : this.currentPrompt,
    );

    if (!errInput) {
      this.currentPrompt = '';
      this.isCurrentPromptMasked = false;
      event.target.style.height = 'auto';
      // this.checkAndShowAPIKeyWarning()
      this.checkAndShowMaskingIntimation();
    }
    //prompt storage FE

    let unMaskedText = {
      ...(errInput || { text: this.chatFormDataService.promptChat }),
      isMasked: this.isMasked,
    };
    await this.updateChatStorage(
      this.getParsedMessage(unMaskedText, true, false),
      null,
      `${this.engineConfig.dbStorageKeys.history}`,
    );

    let response = null;

    if (this.chatFormDataService.isJSONOperation) {
      response = await this.generateCallToolCode();
      await this.handleCallToolResponse(response);
    } else {
      response = await this.generateJSONCode(errInput ? true : false);
      this.jsonResponse = response;
      await this.handleJSONResponse(response);
    }

    this.scrollToBottom('messageBody');
    this.chatFormDataService.setData('promptChat', null);
    return;
  });

  @action
  async generateJSONCode(isSmarterRetry) {
    try {
      if (ensureCallback(this.args.generateAIJSONResponse, "generateAIJSONResponse")) {
        return await this.args.generateAIJSONResponse?.(isSmarterRetry)
      }

    } catch (err) {
      await this.checkAndHandleError(err);
    }
  }

  @action
  async handleJSONResponse(response) {
    if (!response || this.chatStorageService.isNewConversation) {
      this.chatFormDataService.isJSONOperation = false;
      this.handleSubmitChatForm.cancelAll();
      return;
    }
    //Checking if response has JSON
    this.chatFormDataService.isJSONOperation =
      response.text.json && Object.keys(response.text.json).length
        ? true
        : false;
    await this.chatFormDataService.updateChatStorage(
      'historyMaskValues',
      response.maskingHistory,
      true,
    );

    //history Backend (user)
    let maskedText = this.getParsedMessage(
      response.maskedQuery.template,
      true,
      true,
    );
    await this.chatFormDataService.updateChatStorage(
      'history',
      maskedText,
      false,
    );

    //history Backend (response)
    maskedText = this.getParsedMessage(response.text, false, true);
    await this.chatFormDataService.updateChatStorage(
      'history',
      maskedText,
      false,
    );

    let responseParsed = this.getParsedMessage(
      response.unmaskedText,
      false,
      false,
    );

    if (Object.keys(response.maskedQuery?.values ?? {}).length > 0) {
      const textKey = this.getAIResponseTextKey(responseParsed);
      responseParsed[textKey][0]['masked'] = {};
      responseParsed[textKey][0]['masked'].maskedData =
        response.maskedQuery.values;
    }

    if (Object.keys(response.maskingSuggestion?.values ?? {}).length > 0) {
      const textKey = this.getAIResponseTextKey(responseParsed);
      if (!responseParsed[textKey][0]['masked']) {
        responseParsed[textKey][0]['masked'] = {};
      }
      responseParsed[textKey][0]['masked'].suggestedData =
        response.maskingSuggestion.values;
      responseParsed[textKey][0]['masked'].suggestedQuery =
        response.maskingSuggestion.text;
    }
    await this.updateChatStorage(
      responseParsed,
      null,
      `${this.engineConfig.dbStorageKeys.history}`,
    );

    //Proceed automatic mcp call
    let jsonBody = this.getLastJson();

    if (jsonBody?.method == 'GET' || jsonBody?.operation == 'search') {
      if (
        !this.askConfimationBeforeAccess &&
        this.chatFormDataService.isJSONOperation
      ) {

        await this.generateAndHandleMcpServerData.perform()
      }
    }
  }

  @action
  async generateCallToolCode(response) {
    // console.log('response generateCallToolCode', response);
    let data = this.getLastJsonData(this.selectedLHSTableIndex);
    try {
      const response = await apiRequest(
        `/${this.currentActiveTool}/ai/callTool`,
        'POST',
        {
          provider: this.providerChat.name,
          model: this.modelChat.name,
          prompt: this.chatFormDataService.promptChat,
          summary: data.summaryOfUserQuery,
        },
      );
      return response;
    } catch (err) {
      console.error(err);
      await this.checkAndHandleError(err);
    }
  }

  @action
  async handleCallToolResponse(response) {
    this.chatFormDataService.isJSONOperation = false;
    if (!response || this.chatStorageService.isNewConversation) {
      this.handleSubmitChatForm.cancelAll();
      return;
    }
    if (response.callTool) {
      await this.generateAndHandleMcpServerData.perform();
    } else {
      let res = await this.generateJSONCode();
      this.jsonResponse = res;
      await this.handleJSONResponse(res);
    }
  }

  @action
  async generateConsentPermissionCode(errorMsg) {
    try {
      const response = await apiRequest(
        `/${this.currentActiveTool}/ai/consentPermission`,
        'POST',
        {
          provider: this.providerChat.name,
          model: this.modelChat.name,
          prompt: JSON.stringify({
            endpoint: this.getLastJson(),
            errorMessage: errorMsg,
            scope: this.currentActiveUser.scopes,
          }),
        },
      );
      return response;
    } catch (err) {
      await this.checkAndHandleError(err);
    }
  }

  @action
  async handleConsentPermissionResponse() {
    if (!this.consentRes || this.chatStorageService.isNewConversation) {
      this.handleSubmitChatForm.cancelAll();
      return;
    }
    if (this.consentRes.isConsentCall) {
      this.consentPermissionPopup = true;
      return;
    }

    let data = this.getParsedMessage(
      this.MCPResponse.text.message
        ? {
          isSuccess: this.MCPResponse.isSuccess,
          message: this.MCPResponse.text.message,
        }
        : 'Error in response',
      false,
      false,
    );
    await this.updateChatStorage(
      data,
      null,
      `${this.engineConfig.dbStorageKeys.history}`,
    );

    //history Backend (response)
    let maskedText = this.getParsedMessage(
      this.MCPResponse.text.message ?? 'Failed to generate data',
      false,
      true,
    );
    await this.chatFormDataService.updateChatStorage('history', maskedText);
    return;
  }

  @action
  async generateMCPServerCode(json) {
    let jsonBody = json ?? this.getLastJson();

    if (ensureCallback(this.args.ensureValidationBeforeFetchData, "ensureValidationBeforeFetchData"))
      await this.args.ensureValidationBeforeFetchData();

    try {
      const response = await this.args.fetchDirectoryData(jsonBody, 0, 6)

      if (!response.isSuccess) {
        return response;
      }

      if (response.hasLimitedFeatures) {
        setProperties(this.showLimitationErrorBanner, {
          isShow: true,
          message: response.limitedErrorMessage
        })
      }
      if (response.type == 'text') {
        response.text.data = Array.isArray(response.text.data)
          ? response.text.data
          : Object.keys(response.text.data).length
            ? [response.text.data]
            : [];
      }
      return response;
    } catch (err) {
      await this.checkAndHandleError(err);
    }
  }

  @action
  async handleMCPServerResponse(response) {
    this.chatFormDataService.isJSONOperation = false;

    if (!response || this.chatStorageService.isNewConversation) {
      this.handleSubmitChatForm.cancelAll();
      return;
    }

    this.MCPResponse = response;

    let maskedText;
    if (this.askConfimationBeforeAccess) {
      // history Backend (user)
      maskedText = this.getParsedMessage(
        this.chatFormDataService.promptChat,
        true,
        true,
      );
      await this.chatFormDataService.updateChatStorage('history', maskedText);
    }

    if (!response.isSuccess) {
      if (this.args.onFailureCheckAndGetConsentPermission) {
        this.consentRes = await this.generateConsentPermissionCode(
          response.text.message,
        );
        await this.handleConsentPermissionResponse();
        return;
      } else {
        await this.updateChatStorage(
          this.getParsedMessage(
            response.text.message
              ? {
                message: response.text.message,
                isSuccess: response.isSuccess,
              }
              : 'Error in response',
            false,
            false,
          ),
          null,
          'historyStorageAD',
        );

        let maskedText = this.getParsedMessage(
          response.text.message ?? 'Failed to generate data',
          false,
          true,
        );
        await this.chatFormDataService.updateChatStorage('history', maskedText);
        return;
      }
    }

    const jsondata = this.getLastJsonData();

    if (response.type == 'text') {
      let data = response.text.data;

      if (data.length < 1) {
        await this.updateChatStorage(
          this.getParsedMessage(
            response.text.message
              ? jsondata?.successMessage
              : 'No records found. Please try with different criteria',
            false,
            false,
          ),
          null,
          `${this.engineConfig.dbStorageKeys.history}`,
        );
      } else {
        const tableHeader = await this.getTableHeader(
          data,
          jsondata?.summaryOfUserQuery ?? null,
        );

        await this.updateChatStorage(
          this.getParsedMessage(
            {
              tableData: {
                tableHeader: tableHeader,
                tableValue: data,
                isChartLinkGenerated: false,
                paginationMeta: response.paginationId,
                hasMore: response.hasMore,
                supportsPagination: response.supportsPagination
              },
              message: response.text.message,
              isSuccess: response.isSuccess,
            },
            false,
            false,
          ),
          null,
          `${this.engineConfig.dbStorageKeys.history}`,
        );

        if (this.chatStorageService.isNewConversation) {
          this.handleSubmitChatForm.cancelAll();
          return;
        }
        if (
          Array.isArray(data) &&
          data.length > 0 &&
          typeof data[0] === 'object' &&
          data[0] !== null
        ) {
          this.chatStorageService.set(
            'selectedLHSTableIndex',
            this.chatStorage.length - 1,
          );
        }
      }
    } else if (response.type == 'image') {
      await this.updateChatStorage(
        this.getParsedMessage(
          {
            imageUrl: response.imageUrl,
            isSuccess: response.isSuccess,
          },
          false,
          false,
        ),
        null,
        `${this.engineConfig.dbStorageKeys.history}`,
      );
    } else {
      await this.updateChatStorage(
        this.getParsedMessage('Undefined mcp response type', false, false),
        null,
        `${this.engineConfig.dbStorageKeys.history}`,
      );
    }

    //history Backend (response)
    maskedText = this.getParsedMessage(
      `${jsondata.successMessage}`,
      false,
      true,
    );
    this.chatFormDataService.updateChatStorage('history', maskedText, false);
  }

  @action
  async generateChartCode(count, errPrompt) {
    if (!count) return null;

    const getChartPromptFromSummary = () => {
      let data = this.getLastJsonData(this.selectedLHSTableIndex);
      return (
        `This is the summary of the user query for this data "${data.summaryOfUserQuery}". Generate a bar chart relevent to this context.` ||
        'Generate a pie chart with all available data.'
      );
    };
    try {
      const response = await apiRequest(
        `/${this.currentActiveTool}/ai/code`,
        'POST',
        {
          prompt:
            errPrompt ||
            this.chatFormDataService.promptTable || getChartPromptFromSummary(),
          // 'Generate a pie chart with all available data.',
          provider: this.providerChat.name,
          model: this.modelChat.name,
          allKeys: this.responseTabs[0].value.tableHeader,
        },
        { credentials: 'include' },
      );

      let code = response.code;
      if (
        code &&
        ((code.startsWith('"') && code.endsWith('"')) ||
          (code.startsWith("'") && code.endsWith("'")))
      ) {
        code = code.slice(1, -1);
      }

      try {
        new Function('data', 'Chart', `"use strict"; ${code} return renderData(data);`);
      } catch (error) {
        console.error(error);
        return await this.generateChartCode(
          --count,
          JSON.stringify({
            text: 'The provided function threw an error during execution. Please correct the code so that it executes successfully and produces the intended chart output. Ensure all required variables and functions are defined and used properly.',
            error: {
              name: error.name,
              message: error.message,
            },
            code: response.code,
          }),
        );
      }
      return response;
    } catch (error) {
      return error;
    }
  }

  @action
  async handleChartResponse(response) {
    this.chatFormDataService.isJSONOperation = false;

    if (!response) {
      response = {
        error: 'Execution Failed',
        details:
          'We encountered an internal error while executing the code. Try again changing your query.',
      };
    }

    // await this.ensureChartDataReady()

    response.prompt = this.chatFormDataService.promptTable;
    let data = this.chatStorage[this.selectedLHSTableIndex];
    const textKey = this.getAIResponseTextKey(data);
    data[textKey][0].text.chartData = response;

    if (!data[textKey][0].text.tableData.isChartLinkGenerated) {
      data[textKey][0].text.tableData.isChartLinkGenerated = true;
      this.chatStorageService.updateLHSTabValue(0, {
        ...this.responseTabs[0].value,
        isChartLinkGenerated: true
      })
    }

    await this.updateChatStorage(
      data,
      this.selectedLHSTableIndex,
      `${this.engineConfig.dbStorageKeys.history}`,
    );
    this.chatStorageService.updateLHSTabValue(1, response)

    // let temp = this.responseTabs;
    // temp[1].value = response;
    // this.chatStorageService.setData('responseTabs', temp);
    // this.handleTabClick(1);
  }

  @action
  async fetchPriorityHeader(headers, summaryQuery) {
    try {
      const response = await apiRequest(
        `/${this.currentActiveTool}/ai/keys`,
        'POST',
        {
          model: this.modelChat.name,
          headers: headers,
          provider: this.providerChat.name,
          query: summaryQuery,
        },
      );

      return response;
    } catch (error) {
      await this.checkAndHandleError(error);
    }
  }

  @action
  getParsedMessage(result, isUser, isString) {
    if (this.providerChat.name === 'Gemini') {
      return {
        role: isUser ? 'user' : 'model',
        parts: [{ text: isString ? JSON.stringify(result) : result }],
      };
    } else if (
      this.providerChat.name === 'Groq' ||
      this.providerChat.name === 'Cohere'
    ) {
      return {
        role: isUser ? 'user' : 'system',
        content: isString
          ? JSON.stringify([{ text: result }])
          : [{ text: result }],
      };
    } else if (
      this.providerChat.name === 'OpenAI' ||
      this.providerChat.name === 'Claude'
    ) {
      return {
        role: isUser ? 'user' : 'assistant',
        content: isString
          ? JSON.stringify([{ text: result }])
          : [{ text: result }],
      };
    }
  }

  @action
  async getTableHeader(response, summaryQuery) {
    if (!Array.isArray(response)) return [];

    let headers = this.returnAllHeaders(response)
    headers = await this.fetchPriorityHeader(headers, summaryQuery);

    // console.log('ppp', headers.priorityKeys);
    return headers.priorityKeys;
  }

  returnAllHeaders(response) {
    if (!Array.isArray(response)) return [];

    const keySet = new Set();
    response.forEach((item) => {
      if (item && typeof item === 'object') {
        Object.keys(item).forEach((key) => keySet.add(key));
      }
    });

    let headers = Array.from(keySet);
    return headers
  }

  getAIResponseTextKey(obj) {
    if (!obj) {
      return null;
    }

    for (const [key, value] of Object.entries(obj)) {
      if (Array.isArray(value) && value[0].text) {
        return key;
      }
    }
    return null;
  }

  @action
  getLastAIModelJson(startIndex) {
    let i =
      typeof startIndex === 'number' &&
        startIndex < this.chatFormDataService.history.length - 1
        ? startIndex
        : this.chatFormDataService.history.length - 1;

    while (i >= 0) {
      let data = this.chatFormDataService.history[i];

      const key = this.providerChat.name == 'Gemini' ? 'parts' : 'content';
      data = data[key];
      if (typeof data == 'string') {
        data = JSON.parse(data);
        data = data[0];
      } else {
        data = data[0];
        if (typeof data == 'string') {
          data = JSON.parse(data);
        }
      }
      let entry = data?.text;
      if (this.providerChat.name == 'Gemini' && typeof entry == 'string') {
        entry = JSON.parse(entry);
      }
      if (entry?.json && Object.keys(entry.json).length > 0) {
        return entry.json;
      }

      i--;
    }

    return null;
  }

  @action
  getLastJson(startIndex) {
    let i =
      typeof startIndex === 'number' ? startIndex : this.chatStorage.length - 1;

    while (i >= 0) {
      const data = this.chatStorage[i];
      const key = this.getAIResponseTextKey(data);
      const entry = data[key]?.[0]?.text;
      if (entry?.json && Object.keys(entry.json).length > 0) {
        return entry.json;
      }

      i--;
    }

    return null;
  }

  @action
  getLastJsonData(startIndex) {
    let i =
      typeof startIndex === 'number' ? startIndex : this.chatStorage.length - 1;

    while (i >= 0) {
      const data = this.chatStorage[i];
      const key = this.getAIResponseTextKey(data);
      const entry = data[key]?.[0]?.text;
      if (entry?.json && Object.keys(entry.json).length > 0) {
        return entry;
      }

      i--;
    }

    return null;
  }

  @action
  handleYesOrNo(response, event) {
    this.currentPrompt = response ? 'Yes, Proceed' : 'Cancel';
    this.handleSubmitChatForm.perform(event);
  }

  @action
  handleRetryAction(errorMsg, index) {
    if (!this.handleSubmitChatForm.isRunning) {
      this.handleSubmitChatForm.perform(null, {
        error_info: {
          error: errorMsg,
          json: this.getLastAIModelJson(index),
        },
      });
    }
  }

  @action
  async handleWriteOperationConfirmation(value) {
    this.writeOperationConfirmation = false;
    if (!value) {
      let data = this.getParsedMessage(
        'Confirmation request cancelled',
        false,
        false,
      );
      await this.updateChatStorage(
        data,
        null,
        `${this.engineConfig.dbStorageKeys.history}`,
      );
      return;
    }
    await this.generateAndHandleMcpServerData.perform();
  }

  generateAndHandleMcpServerData = task({ drop: true }, async (jsonBody) => {
    const reponse = await this.generateMCPServerCode(jsonBody);
    this.MCPResponse = reponse;
    await this.handleMCPServerResponse(reponse);
  });

  @action
  async checkAndHandleError(error) {
    console.error("Error from checkAndHandleError", error)
    let parsedError = {
      error: error.error || 'Failed to connect',
      message:
        error.details ||
        "Due to some technical reason, we can't connect with server",
      status: error.status,
    };

    if (error.status == '401') {
      await this.args.checkSession(
        this.currentActiveUser == TOOL_INFORMATIONS.MODULE_M365.id
          ? AUTH_TYPES.M365.id
          : AUTH_TYPES.AD.id,
        null,
        true,
      );
    }

    if (error instanceof Error) {
      try {
        const json = JSON.parse(error.message);
        parsedError = { ...parsedError, ...json };
      } catch {
        parsedError.message = error.message;
      }
    } else if (typeof error === 'object' && error !== null) {
      parsedError = { ...parsedError, ...error };
    }
    if (parsedError) {
      const data = this.getParsedMessage(parsedError, false, false);
      await this.updateChatStorage(
        data,
        null,
        `${this.engineConfig.dbStorageKeys.history}`,
      );
    }

    if (this.chatFormDataService.promptChat) {
      //history Backend (user)
      let maskedText = this.getParsedMessage(
        this.chatFormDataService.promptChat,
        true,
        true,
      );
      await this.chatFormDataService.updateChatStorage(
        'history',
        maskedText,
        false,
      );

      //history Backend (response)
      maskedText = this.getParsedMessage(
        `${(parsedError.error, parsedError.message)}`,
        false,
        true,
      );
      await this.chatFormDataService.updateChatStorage(
        'history',
        maskedText,
        false,
      );
    }
  }

  @action
  switchProviderOrModel() {
    this.switchSelectedData();
    if (this.currentPrompt) {
      // this.checkAndShowAPIKeyWarning();
      this.checkAndShowMaskingIntimation();
    }
  }

  @action
  updateData(event) {
    const { name, value } = event.target;
    this[name] = value;

    if (name === 'currentPrompt') {
      this.chatFormDataService.setData('promptChat', this.currentPrompt);

      this.auto_grow(event.target);
      if (this.isMasked) {
        let count = (value.match(/"/g) || []).length;
        this.isCurrentPromptMasked = !(count <= 1);
      } else {
        this.isCurrentPromptMasked = false;
      }
      if (value != '') {
        // this.checkAndShowAPIKeyWarning();
        this.checkAndShowMaskingIntimation();
      } else {
        this.commonStoreDataService.maskingIntimation = false;
      }
    }
  }

  @action
  checkAndShowMaskingIntimation() {
    if (
      this.currentActiveUser &&
      this.providerChat.apiKeys.length &&
      this.isMasked &&
      this.args.maskingWarningEnabled &&
      this.currentPrompt
    ) {
      // this.settingsDataService.setData(
      //   'maskingIntimation',
      //   !this.isCurrentPromptMasked,
      // );

      // console.log('log', this.isCurrentPromptMasked);
      this.commonStoreDataService.maskingIntimation =
        !this.isCurrentPromptMasked;
    } else {
      this.commonStoreDataService.maskingIntimation = false;
    }
  }

  @action
  selectData(selectedField, selectedValue) {
    if (this[selectedField].name == selectedValue.name) {
      return;
    }
    this.pendingSelectedField = selectedField;
    this.pendingSelectedData = selectedValue;

    if (!this.chatStorage.length) {
      this.switchProviderOrModel();
    } else {
      this.commonStoreDataService.setData('isSwitchConfirmation', true);
    }
  }

  @action
  switchSelectedData() {
    this.chatStorageService.setLocalData(
      this.pendingSelectedField,
      this.pendingSelectedData,
    );
  }

  handleConsentPopup = task({ drop: true }, async (value) => {
    this.consentPermissionPopup = false;
    if (!value) {
      let data = this.getParsedMessage(
        this.MCPResponse.text.message
          ? {
            isSuccess: this.MCPResponse.isSuccess,
            text: this.MCPResponse.text.message,
            isConsentCall: true,
            consentScopes: this.consentRes.consent,
          }
          : 'Error in response',
        false,
        false,
      );
      await this.updateChatStorage(
        data,
        null,
        `${this.engineConfig.dbStorageKeys.history}`,
      );
      return;
    }
    const res = await this.args.getConsent(this.consentRes.consent);
    if (!res) {
      let data = this.getParsedMessage(
        this.MCPResponse.text.message
          ? {
            isSuccess: this.MCPResponse.isSuccess,
            text: this.MCPResponse.text.message,
            isConsentCall: true,
            consentScopes: this.consentRes.consent,
          }
          : 'Error in response',
        false,
        false,
      );
      await this.updateChatStorage(
        data,
        null,
        `${this.engineConfig.dbStorageKeys.history}`,
      );
    } else {
      await this.generateAndHandleMcpServerData.perform();
    }
  });

  @action
  getActiveApikey(apikeys) {
    return apikeys.find((item) => item.enabled);
  }

  getConsentPermission = task({ drop: true }, async (scopes, index) => {
    const res = await this.args.getConsent(scopes);
    if (res) {
      let data = { ...this.chatStorage[index] };
      let key = this.getAIResponseTextKey(data);
      data[key][0].text.isConsentCall = false;
      await this.updateChatStorage(
        data,
        index,
        `${this.engineConfig.dbStorageKeys.history}`,
      );

      let jsonBody = this.getLastJson(index);
      await this.generateAndHandleMcpServerData.perform(jsonBody);
    }
  });

  @action
  async executePrompt(index) {
    let jsonBody = this.getLastJson(index);
    await this.getAIResponse.perform(null, {
      try_again: {
        text: 'Execute it',
        json: jsonBody,
      },
    });
  }

  displayChartData = task({ drop: true }, async (data) => {
    let code = data.code;

    if (
      code &&
      ((code.startsWith('"') && code.endsWith('"')) ||
        (code.startsWith("'") && code.endsWith("'")))
    ) {
      code = code.slice(1, -1);
    }

    await this.ensureChartDataReady()

    const generatedFunction = new Function(
      'data',
      'Chart',
      `${code} return renderData(data);`,
    );

    generatedFunction(
      this.responseTabs[0].value.tableValue,
      Chart
    );
  });

  @action
  async ensureChartDataReady() {
    let currentData = this.responseTabs[0].value;
    let requiredData = 2000
    if (currentData.tableValue.length < requiredData && currentData.supportsPagination && currentData.hasMore) {
      const res = await this.args.fetchDirectoryData(currentData.json, currentData.paginationMeta, requiredData - currentData.tableValue.length)
      if (res.isSuccess) {
        this.chatStorageService.updateLHSTabValue(0, {
          ...this.responseTabs[0].value,
          tableValue: [...this.responseTabs[0].value.tableValue, ...res.text?.data],
          supportsPagination: res.supportsPagination,
          hasMore: res.hasMore,
          entriesProcessed: res.entriesProcessed,
          paginationMeta: res.paginationId
        })
      }
    }
  }

  @action
  scrollToBottom(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollTo({
        top: element.scrollHeight,
        behavior: 'smooth',
      });
    }
  }

  formatTime(date) {
    return `${date.getHours()}:${date.getMinutes()}`;
  }

  @action
  addSuggesstionsToCurrentPrompt(suggestion) {
    this.currentPrompt = suggestion + ' ';
    this.chatFormDataService.setData('promptChat', this.currentPrompt);
    const element = document.getElementById('currentPrompt');
    element.focus();
    // this.checkAndShowAPIKeyWarning();
    this.checkAndShowMaskingIntimation();
  }

  @action
  toggleIsResponseOpen() {
    this.chatStorageService.selectedLHSTableIndex = null;
  }

  auto_grow(element) {
    element.style.height = '5px';
    element.style.height = element.scrollHeight + 'px';
  }

  get getChatWidth() {
    return htmlSafe(`width: ${this.chatWidth}px`);
  }

  @action
  enableResizeBar() {
    const resizeBar = this.resizer.children[0];
    resizeBar.style.display = 'block';
  }

  @action
  disableResizeBar() {
    if (!this.isResizing) {
      const resizeBar = this.resizer.children[0];
      resizeBar.style.display = 'none';
    }
  }

  @action
  setupResizer() {
    if (!localStorage.getItem('chatWidth')) {
      localStorage.setItem('chatWidth', 380);
    }
    this.resizer = document.getElementById('chatResizer');
    this.resizer.addEventListener('mousedown', this.onMouseDown.bind(this));
  }

  @action
  teardownResizer() {
    if (this.resizer) {
      this.resizer.removeEventListener('mousedown', this.onMouseDown);
    }
  }

  @action
  onMouseDown(event) {
    event.preventDefault(); // Prevent text selection while dragging

    const chatPanel = document.getElementById('chat-panel');
    const container = document.getElementById('chat-layout-container');

    this.isResizing = true;
    //enable bar
    this.enableResizeBar();

    if (!chatPanel || !container) {
      console.warn('DOM not found');
      return;
    }

    let startX = event.clientX;
    let startWidth = chatPanel.offsetWidth;

    const onMouseMove = (moveEvent) => {
      const deltaX = moveEvent.clientX - startX;
      // For right panel: subtract deltaX to increase width when moving left
      let newWidth = startWidth - deltaX;

      const minWidth = 350;
      const maxWidth = container.offsetWidth - 350; // leave space for left panel
      newWidth = Math.max(minWidth, Math.min(newWidth, maxWidth));
      localStorage.setItem('chatWidth', newWidth);
      this.chatWidth = localStorage.getItem('chatWidth');
    };

    const onMouseUp = () => {
      this.isResizing = false;
      this.disableResizeBar();
      container.removeEventListener('mousemove', onMouseMove);
      container.removeEventListener('mouseup', onMouseUp);
    };

    container.addEventListener('mousemove', onMouseMove);
    container.addEventListener('mouseup', onMouseUp);
  }

  get maskingDetailedPopup() {
    return this.commonStoreDataService.maskingDetailedPopup;
  }

  @action
  goToSettings() {
    this.commonStoreDataService.maskingDetailedPopup = false;
    this.router.transitionTo('settings');
  }

  @action
  setupMaskingPosition() {
    const parent = document.getElementById('ad-learn-more');
    const child = document.querySelector('.masking-small-popup');

    if (!parent || !child) return;

    // Get parent position and size
    const parentRect = parent.getBoundingClientRect();

    // Top position: just above parent with a small gap
    const top = window.scrollY + parentRect.top - child.offsetHeight - 5; // 5px gap

    // Left position: center child horizontally relative to parent
    const left = window.scrollX + parentRect.left + (parentRect.width - child.offsetWidth) / 2;

    // Apply absolute positioning
    child.style.position = 'absolute';
    child.style.top = `${top}px`;
    child.style.left = `${left}px`;
    child.style.zIndex = '9999';
  }

  @action
  moveToSettings() {
    this.commonStoreDataService.maskingDetailedPopup = false;
    this.router.transitionTo('settings');
  }

  handleNextPageNavigation = task({ drop: true }, async (pageSize) => {
    const res = await this.args.fetchDirectoryData(this.responseTabs[0].value?.json, this.responseTabs[0].value.paginationMeta, pageSize)

    if (!res.isSuccess) {
      this.flashMessages.danger('Oops! We couldn’t load more. Check your connection and try again later.', {
        timeout: 5000,
        preventDuplicates: true,
      })
    }

    let data = res.text?.data;
    let newHeaders = this.checkAndAdjustHeader(data, this.responseTabs[0].value.tableHeader);

    let updatedTabValue  = {
      ...this.responseTabs[0].value,
      tableValue: [...this.responseTabs[0].value.tableValue, ...data],
      paginationMeta: res.paginationId,
      supportsPagination: res.supportsPagination,
      hasMore: res.hasMore,
      entriesProcessed: res.entriesProcessed,
      // currentTablePage: data.length && res.isSuccess ? (this.responseTabs[0].value?.currentTablePage + 1) : this.responseTabs[0].value?.currentTablePage
    }

    if(newHeaders.length) {
      let chatData = this.chatStorage[this.selectedLHSTableIndex];
      let key = this.getAIResponseTextKey(chatData)
      let chatWholeData = chatData[key][0]?.text
      chatWholeData.tableData.tableHeader = newHeaders
      this.updateChatStorage(chatData, this.selectedLHSTableIndex, `${this.engineConfig.dbStorageKeys.history}`)
      updatedTabValue.tableHeader = newHeaders; 
    }

    this.chatStorageService.updateLHSTabValue(0, updatedTabValue);

    return data.length ? true : false
  });

  checkAndAdjustHeader(data, existingHeaders) {
    let newHeaders = this.returnAllHeaders(data);

    let missedHeaders = newHeaders.filter(header => !existingHeaders.includes(header));

    if (missedHeaders.length > 0) {
      existingHeaders.push(...missedHeaders);
      return existingHeaders;
    } else {
      return [];
    }
  }

  handleChartLoadMore = task({ drop: true }, async (pageSize) => {
    await this.handleNextPageNavigation.perform(pageSize)
    this.chatStorageService.handleTabClick(1)
  });

  @action
  updateCurrentPageSize(pageNumber) {
    this.chatStorageService.updateLHSTabValue(0, {
      ...this.responseTabs[0].value,
      currentTablePage: pageNumber
    });
  }

  @action
  onchangePagesizeSuccessCallback(pageSize) {
    this.chatStorageService.setData("tableMaxData", pageSize)
  }

  initializeResponseTabs = task({ drop: true }, async () => {
    this.chatStorageService.resetResponseTab()
    this.chatStorageService.handleTabClick(0)

    let chatData = this.chatStorage[this.selectedLHSTableIndex]
    let key = this.getAIResponseTextKey(chatData)
    let chatWholeData = chatData[key][0]?.text

    let data;
    let res;

    let jsonData = this.getLastJsonData(this.selectedLHSTableIndex)

    if (chatWholeData.tableData.supportsPagination) {
      const delay = new Promise(resolve => setTimeout(resolve, 500))

      const [response] = await Promise.all([
        this.args.fetchDirectoryData(
          jsonData.json,
          0,
          this.chatStorageService.tableMaxData
        ),
        delay
      ])

      res = response

      if (!res.isSuccess) {
        this.flashMessages.danger('Oops! We couldn’t load more. Check your connection and try again later.', {
          timeout: 5000,
          preventDuplicates: true,
        })
      }

      data = res.text?.data
    } else {
      data = chatWholeData.tableData.tableValue
    }

    this.chatStorageService.updateLHSTabValue(0, {
      tableValue: data,
      tableHeader: chatWholeData.tableData.tableHeader,
      json: jsonData.json,
      paginationMeta: res?.paginationId,
      supportsPagination: res?.supportsPagination,
      hasMore: res?.hasMore,
      entriesProcessed: res?.entriesProcessed,
      currentTablePage: 1,
      isChartLinkGenerated: chatWholeData.tableData.isChartLinkGenerated
    })

    if (chatWholeData.chartData) {
      this.chatStorageService.updateLHSTabValue(1, chatWholeData.chartData)
    }
  })

  @action
  handleLimitationErrorBanner(isShow) {
    set(this, 'showLimitationErrorBanner.isShow', isShow ? true : false)
  }

  // ---------------------------------------------------------------------------
  // buildExportChartJob — grabs the live Chart.js canvas and saves as PNG.
  //
  // Chart tab only. Returns null when no chart has been rendered yet.
  // The export-button handles this job directly (no export-manager loop).
  // ---------------------------------------------------------------------------
  @action
  buildExportChartJob() {
    const chartTab = this.responseTabs?.[1];
    if (!chartTab?.value?.code) return null;

    const tableTab = this.responseTabs?.[0];
    const toolId = this.currentActiveTool ?? 'explorer';
    // `now` is reused for both the filename timestamp and the header's "Generated"
    // time so they always agree (LOCAL time, not UTC). The filename is just the
    // short report title + timestamp (built via buildExportFilename below).
    const now = new Date();
    const jsonData = this.getLastJsonData(this.selectedLHSTableIndex);

    // The exact text the user typed in the chart "Ask AI" box (may be empty when
    // the chart was generated via the "see it graphically" link).
    const userRequest = chartTab.value.prompt ?? '';
    // The AI's summary of the underlying data query.
    const summary = jsonData?.summaryOfUserQuery ?? '';
    // How many records the chart was generated from (the loaded/paginated count).
    const recordCount = tableTab?.value?.tableValue?.length ?? 0;

    const metaBase = {
      title: `AdminDroid — ${String(toolId).toUpperCase()} Chart`,
      request: userRequest,
      summary,
      recordCount,
      generatedAt: formatGeneratedAt(now),
      toolName: getExportToolName(toolId),
    };

    // When the AI rendered a data table, the chart tab shows that table (not a
    // canvas). Export the table exactly as rendered in the DOM — this is a
    // different dataset from the main Table tab (often aggregated / summarised).
    if (chartTab.value.type === 'table') {
      const { rows, headers } = extractDomTable('#responsive-chart-table');
      return {
        isChartTableExport: true,
        chartContentType: 'table',
        fetchPage: async () => ({ rows, nextCursor: 0, hasMore: false }),
        initialCursor: 0,
        headers,
        // export-manager derives the filename from the report title + timestamp.
        meta: metaBase,
      };
    }

    // Canvas-based chart — image export only. The AI-generated renderData()
    // code may place the <canvas> anywhere inside the chart container, so look
    // broadly rather than assuming a fixed parent.
    const findCanvas = () =>
      document.querySelector('#responsive-chart-table canvas') ||
      document.querySelector('[data-test-chart-canvas] canvas') ||
      document.querySelector('.response-tab-values canvas') ||
      document.querySelector('.chart-parent canvas');

    // Image export uses this filename directly (it doesn't go through
    // export-manager), so build "<short report title>-<timestamp>" here.
    const filename = buildExportFilename(summary, now);
    return {
      isChartExport: true,
      chartContentType: 'chart',
      filename,
      getCanvas: findCanvas,
      meta: metaBase,
    };
  }

  // ---------------------------------------------------------------------------
  // buildExportJob  — snapshot current table state for the export-manager loop
  //
  // Called by <ExportButton> at the moment the user picks a format.
  // Returns a job object that is completely independent of live UI state (D7).
  // ---------------------------------------------------------------------------
  @action
  buildExportJob() {
    const tabData = this.responseTabs?.[0]?.value;
    if (!tabData?.tableValue?.length) return null;

    // The json body is stored on the tab value after initializeResponseTabs runs,
    // or we fall back to walking the chat history.
    const jsonData = this.getLastJsonData(this.selectedLHSTableIndex);
    const jsonBody = tabData.json ?? jsonData?.json;
    if (!jsonBody) return null;

    const toolId = this.currentActiveTool ?? 'explorer';
    const headers = [...(tabData.tableHeader ?? [])];

    return {
      fetchPage: async (cursor) => {
        const response = await this.args.fetchDirectoryData(jsonBody, cursor, 1000);
        if (!response.isSuccess) {
          throw new Error(response.text?.message || 'Failed to fetch page');
        }
        return {
          rows: response.text?.data ?? [],
          nextCursor: response.paginationId ?? 0,
          hasMore: response.hasMore ?? false,
        };
      },
      initialCursor: 0,
      headers,
      meta: {
        title: `AdminDroid — ${String(toolId).toUpperCase()} Explorer Report`,
        summary: jsonData?.summaryOfUserQuery ?? '',
        toolName: getExportToolName(toolId),
      },
    };
  }

}
