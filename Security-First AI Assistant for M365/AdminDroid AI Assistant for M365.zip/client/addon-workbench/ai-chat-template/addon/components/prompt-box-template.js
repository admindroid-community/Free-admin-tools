import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { task } from 'ember-concurrency';
import {
  TOOL_INFORMATIONS,
  AUTH_TYPES,
} from '@admindroid/shared-components/utils/tool-informations';

export default class PromptBoxTemplateComponent extends Component {
  @service('common-store-data') commonStoreDataService;
  @service('settings-data') settingsDataService;
  @service flashMessages;
  @service('user') userService;

  handleSubmitChatForm = task({ drop: true }, async (event, errorMsg) => {
    await this.getAIResponse.perform(event, errorMsg);
  });

  get authDbName() {
    return this.args.currentActiveTool == TOOL_INFORMATIONS.MODULE_M365.id
      ? AUTH_TYPES.M365.name
      : AUTH_TYPES.AD.name;
  }

  @action
  moveToSettings() {
    this.hostRouter.transitionTo('settings.provider', {
      queryParams: {
        providerName: this.args.providerChat.name, // or whatever value you want
      },
    });
  }

  @action
  handleKeyDown(event) {
    if (event.target.name === 'currentPrompt' && event.key === 'Enter') {
      if (event.shiftKey) {
        this.args.updateData(event);
      } else {
        if (!this.args.currentPrompt) {
          this.flashMessages.warning("Enter valid query to continue!", {
            preventDuplicates: true,
            timeout: 10000,
            // sticky: true
          })
        }
        if (!this.args.handleSubmitChatForm.isRunning) {
          this.args.handleSubmitChatForm.perform(event);
        } else {
          event.preventDefault();
        }
      }
    }
  }

  @action
  selectData(selectedField, selectedValue) {
    if (this[selectedField].name == selectedValue.name) {
      return;
    }
    this.pendingSelectedField = selectedField;
    this.pendingSelectedData = selectedValue;

    if (!this.chatStorage.length) {
      this.switchProviderOrModel();
    } else {
      this.commonStoreDataService.setData('isSwitchConfirmation', true);
    }
  }

  @action
  switchSelectedData() {
    this.chatStorageService.setLocalData(
      this.pendingSelectedField,
      this.pendingSelectedData,
    );
  }
  @action
  updateData() { }

  @action
  addSuggesstionsToCurrentPrompt() { }

  @action
  closePopup() {
    this.commonStoreDataService.maskingIntimation = false;
  }

  @action
  handleMaskingShow(event) {
    this.settingsDataService.setLocalData(
      'maskingWarningEnabled',
      !event.target.checked,
    );
  }
}
