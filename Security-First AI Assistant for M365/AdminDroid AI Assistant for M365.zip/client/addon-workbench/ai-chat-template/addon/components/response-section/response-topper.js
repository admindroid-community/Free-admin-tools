import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';

export default class ResponseTableComponent extends Component {
  @service('authentication-m365') authenticationM365;
  @service flashMessages;

  get user() {
    return this.authenticationM365.currentActiveUser;
  }
  @action
  async handleKeyDown(event) {
    if (event.target.name === 'tablePrompt' && event.key === 'Enter') {
      if (event.shiftKey) {
        this.args.updateData(event);
      } else {
        // if (!this.args.currentActiveUser) {
        //   this.userService.openM365Login()
        //   event.preventDefault();
        //   return;
        // }

        if (!this.args.tablePrompt) {
          this.flashMessages.warning('Enter a valid prompt!', {
            sticky: true,
          });
          event.preventDefault();
          return;
        }

        // if (!this.args.providerChat.apiKeys.length) {
        //   this.args.checkAndShowAPIKeyWarning()
        //   event.preventDefault();
        //   return;
        // }

        if (
          !this.args.handleLinkChartGeneration.isRunning &&
          !this.args.handleSubmitChartGeneration.isRunning
        ) {
          await this.args.handleSubmitChartGeneration.perform(event);
        } else {
          event.preventDefault();
        }
      }
    }
  }
}
