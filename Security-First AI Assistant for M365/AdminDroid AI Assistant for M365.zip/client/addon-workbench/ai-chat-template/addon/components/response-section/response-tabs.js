import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { setProperties, set, action, computed } from '@ember/object';
import { service } from '@ember/service';

export default class ResponseTableComponent extends Component {
  @service('chat-storage') chatStorageService;

  get tableMaxData() {
    return this.chatStorageService.tableMaxData;
  }

  availableCharPageSizes = [500, 2000, 5000, 10000]

  @tracked selectedCustomPageSize = this.availableCharPageSizes[1]

  @action
  onChangeCurrentChartPageSize(size) {
    this.selectedCustomPageSize = size
  }
}
