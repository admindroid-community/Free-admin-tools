import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { setProperties, set, action, computed } from '@ember/object';
import { service } from '@ember/service';

export default class ResponseTableComponent extends Component {
  @service('chat-storage') chatStorageService;

  get tableMaxData() {
    return this.chatStorageService.tableMaxData;
  }

  get activeTab() {
    return this.args.responseTabs?.find((t) => t.isActive);
  }

  get hasTabData() {
    return Boolean(this.activeTab?.value);
  }

  get isChartTabActive() {
    return this.activeTab?.name !== 'table';
  }

  // 'chart' (canvas) or 'table' (AI-rendered HTML table) when the chart tab is
  // active — drives which formats the export dropdown offers.
  get chartContentType() {
    return this.activeTab?.value?.type;
  }

  availableCharPageSizes = [500, 2000, 5000, 10000]

  @tracked selectedCustomPageSize = this.availableCharPageSizes[1]

  @action
  onChangeCurrentChartPageSize(size) {
    this.selectedCustomPageSize = size
  }
}
