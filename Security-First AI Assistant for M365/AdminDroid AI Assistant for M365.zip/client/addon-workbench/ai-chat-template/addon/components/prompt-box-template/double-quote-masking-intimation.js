import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';

export default class DoubleQuoteMaskingIntimationComponent extends Component {
  popupElement = null;
  openedByClick = false;

  @service('common-store-data') commonStoreDataService;

  @action
  savePopupElement(element) {
    this.popupElement = element;
    document.addEventListener('click', this.handleOutsideClick);
  }

  @action
  teardown() {
    document.removeEventListener('click', this.handleOutsideClick);
  }

  handleOutsideClick = (event) => {
    const popupElement = this.popupElement; // your main popup
    const maskingSmallPopup = document.getElementById('maskingSmallPopup'); // the one you want to exclude from close

    setTimeout(() => {
      const clickedOutsideMainPopup =
        !popupElement || !popupElement.contains(event.target);
      const clickedOutsideMaskingPopup =
        !maskingSmallPopup || !maskingSmallPopup.contains(event.target);

      // Only close if clicked outside BOTH
      if (clickedOutsideMainPopup && clickedOutsideMaskingPopup) {
        this.commonStoreDataService.maskingDetailedPopup = false;
        this.openedByClick = false;
      }
    }, 0);
  };

  @action
  popupEventHandler(event) {
    switch (event.type) {
      case 'mouseover':
        this.commonStoreDataService.maskingDetailedPopup = true;
        break;

      case 'mouseout':
        if (
          !this.openedByClick &&
          (!event.relatedTarget ||
            !this.popupElement.contains(event.relatedTarget))
        ) {
          this.commonStoreDataService.maskingDetailedPopup = false;
        }
        break;

      case 'click':
        this.openedByClick = true;
        this.commonStoreDataService.maskingDetailedPopup = true;
        break;
    }
  }
}
