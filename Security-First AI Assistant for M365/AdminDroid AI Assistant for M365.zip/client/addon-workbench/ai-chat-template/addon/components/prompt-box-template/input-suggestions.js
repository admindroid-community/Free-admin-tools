import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

export default class InputSuggestionsComponent extends Component {
  @tracked canScrollLeft = false;
  @tracked canScrollRight = false;

  @action
  setupHorizontalScroll(element) {
    // element.scrollLeft = 0
    element.addEventListener(
      'wheel',
      function (event) {
        if (Math.abs(event.deltaX) > Math.abs(event.deltaY)) {
          return;
        }
        event.preventDefault();
        element.scrollLeft += event.deltaY * 3;
      },
      { passive: false },
    );
    this.updateScrollButtons(element);

    element.addEventListener('scroll', () => {
      this.updateScrollButtons(element);
    });
  }

  updateScrollButtons(parent) {
    const epsilon = 1; // tolerance for rounding errors

    this.canScrollLeft = parent.scrollLeft > epsilon;
    this.canScrollRight =
      parent.scrollLeft < parent.scrollWidth - parent.clientWidth - epsilon;
  }

  @action
  scrollRight() {
    const parent = document.getElementById('suggestions-parent');
    if (!parent) return;

    parent.scrollBy({
      left: 200, // scroll 200px to the right
      behavior: 'smooth', // smooth scrolling
    });
  }

  @action
  scrollLeft() {
    const parent = document.getElementById('suggestions-parent');
    if (!parent) return;

    parent.scrollBy({
      left: -200, // scroll 200px to the left
      behavior: 'smooth',
    });
  }

  get maxCount() {
    if (this.args.currentActiveTool == TOOL_INFORMATIONS.MODULE_M365.id) {
      return 10;
    } else {
      return 8;
    }
  }
}
