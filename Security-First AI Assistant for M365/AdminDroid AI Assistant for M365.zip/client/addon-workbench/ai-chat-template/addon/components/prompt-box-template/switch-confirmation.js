import Component from '@glimmer/component';
import { action } from '@ember/object';
import { tracked } from '@glimmer/tracking';
import { service } from '@ember/service';

export default class SwitchConfirmationComponent extends Component {
  @service('common-store-data') commonStoreDataService;
  @service authenticationM365;
  @service('tool-information') toolInfoService;

  get confirmSwitchActionData() {
    return this.commonStoreDataService.confirmSwitchActionData;
  }
  @action
  handleOnEnter(event) {
    // console.log("handleOnEnter", event)
    if (event.key === 'Enter') {
      this.handleConfirmation(true);
    }
  }

  @action
  focusSelf(element) {
    element.focus();
  }

  @action
  async handleConfirmation(confirm) {
    this.commonStoreDataService.isSwitchConfirmation = false;

    if (confirm) {
      // console.log('data', this.confirmSwitchActionData);
      if (this.confirmSwitchActionData == 'logout') {
        await this.logout();
      } else if (this.confirmSwitchActionData == 'switch account') {
        await this.switchAccount(
          this.authenticationM365.selectedProfileToSwitchAccount,
        );
      } else {
        this.args.switchProviderOrModel();
      }

      await this.toolInfoService.clearAllData();
    }

    this.commonStoreDataService.confirmSwitchActionData = null;
  }

  @action
  async switchAccount(profile) {
    await this.authenticationM365.accountSpecificLogin(profile);
    await this.authenticationM365.checkSession();
  }
  @action
  async logout() {
    await this.authenticationM365.logout();
    await this.authenticationM365.checkSession();
  }
}
