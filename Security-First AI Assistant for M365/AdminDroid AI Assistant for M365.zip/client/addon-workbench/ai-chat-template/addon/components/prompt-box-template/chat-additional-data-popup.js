import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';

export default class ChatAdditionalDataPopupComponent extends Component {
  @service('chat-storage') chatStorageService;

  get selectedLHSTableIndex() {
    return this.chatStorageService.selectedLHSTableIndex;
  }

  @action
  setupPopupPosition() {
    const parent = this.args.dataDetails?.parentElement;
    const child = document.getElementById('display-additional-data');
    if (!parent || !child) return;

    child.style.position = 'fixed';

    requestAnimationFrame(() => {
      const parentRect = parent.getBoundingClientRect();
      const childRect = child.getBoundingClientRect();

      const buttonCenter = parentRect.left + parentRect.width / 2;
      const finalLeft = buttonCenter - childRect.width / 2;
      const constrainedLeft = Math.max(
        10,
        Math.min(finalLeft, window.innerWidth - childRect.width - 10),
      );

      const top = parentRect.top - childRect.height - 10;
      const isBelow = top < 0;
      const finalTop = isBelow ? parentRect.bottom + 2 : top + 8;

      child.style.top = `${finalTop}px`;
      child.style.left = `${constrainedLeft}px`;
      child.classList.toggle('below', isBelow);
    });

    if (!this.scrollListenerAdded) {
      this.boundCheckVisibility = this.checkPopupVisibility.bind(this);
      window.addEventListener('scroll', this.boundCheckVisibility, true);
      this.scrollListenerAdded = true;
    }
  }

  @action
  checkPopupVisibility() {
    const parent = this.args.dataDetails?.parentElement;
    if (!parent) return;

    const messageBody = document.getElementById('messageBody');
    if (!messageBody) return;

    const parentRect = parent.getBoundingClientRect();
    const containerRect = messageBody.getBoundingClientRect();

    const isButtonHidden =
      parentRect.bottom < containerRect.top ||
      parentRect.top > containerRect.bottom ||
      parentRect.right < containerRect.left ||
      parentRect.left > containerRect.right;

    if (isButtonHidden) {
      this.handleOutsideClick();
    } else {
      this.updatePopupVerticalPosition(parent);
    }
  }

  updatePopupVerticalPosition(parent) {
    const child = document.getElementById('display-additional-data');
    if (!child) return;

    const parentRect = parent.getBoundingClientRect();
    const childRect = child.getBoundingClientRect();

    const top = parentRect.top - childRect.height - 10;
    const isBelow = top < 0;
    const finalTop = isBelow ? parentRect.bottom + 2 : top + 8;

    child.style.top = `${finalTop}px`;
    child.classList.toggle('below', isBelow);
  }

  @action
  handleOutsideClick() {
    this.chatStorageService.set('selectedAdditionalChatDataPopup', null);
    this.cleanupScrollListener();
  }

  cleanupScrollListener() {
    if (this.scrollListenerAdded) {
      window.removeEventListener('scroll', this.boundCheckVisibility, true);
      this.scrollListenerAdded = false;
    }
  }

  willDestroy() {
    super.willDestroy(...arguments);
    this.cleanupScrollListener();
  }
}
