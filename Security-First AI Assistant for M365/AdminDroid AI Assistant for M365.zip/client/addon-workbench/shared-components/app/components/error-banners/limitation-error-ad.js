export { default } from '@admindroid/shared-components/components/error-banners/limitation-error-ad';
