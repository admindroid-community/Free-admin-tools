export { default } from '@admindroid/shared-components/components/loading-skeleton/table1';
