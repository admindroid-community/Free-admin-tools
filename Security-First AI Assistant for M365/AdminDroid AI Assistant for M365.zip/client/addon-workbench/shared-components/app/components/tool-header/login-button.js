export { default } from '@admindroid/shared-components/components/tool-header/login-button';
