export { default } from '@admindroid/shared-components/helpers/get-header';
