export { default } from '@admindroid/shared-components/helpers/is-array-of-strings';
