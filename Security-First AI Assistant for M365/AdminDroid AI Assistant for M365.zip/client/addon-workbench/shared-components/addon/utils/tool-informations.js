const TOOL_INFORMATIONS = {
  APP_DETAILS: {
    name: 'AdminDroid Community Tool',
    author: 'AdminDroid',
    shortName: 'Community Tool',
  },
  MODULE_M365: {
    id: 'm365',
    name: 'AI assistant for Microsoft 365',
    service: "Microsoft 365"
  },
  MODULE_AD: {
    id: 'ad',
    name: 'AI assistant for Active Directory',
    service: "Active Directory"
  },
  MODULE_GRAPH_EXPLORER: {
    id: 'graph-explorer',
    name: 'Graph Explorer for M365',
    service: "Microsoft 365"
  },
  MODULE_LDAP_EXPLORER: {
    id: 'ldap-explorer',
    name: 'LDAP Explorer',
    service: "Active Directory"
  },
};

const AUTH_TYPES = {
  AD: {
    id: 'ad',
    name: 'Active Directory',
  },
  M365: {
    id: 'm365',
    name: 'Microsoft 365',
  },
};

const CHAT_STORAGE_CONFIG = {
  AD: {
    engineType: 'AD',
    dbStorageKeys: {
      history: 'historyStorageAD',
      aiHistory: 'aiHistoryStorageAD',
    },
    storeNames: {
      history: 'adChatStorage',
      aiHistory: 'modelAdChatStorage',
    },
    localStorageKeys: {
      provider: 'providerChatAD',
      model: 'modelChatAD',
      selectedIndex: '_selectedIndexAD',
      isResponseTabOpen: 'isResponseTabOpenAD',
    },
  },
  M365: {
    engineType: 'M365',
    dbStorageKeys: {
      history: 'historyStorageM365',
      aiHistory: 'aiHistoryStorageM365',
    },
    storeNames: {
      history: 'm365ChatStorage',
      aiHistory: 'modelM365ChatStorage',
    },
    localStorageKeys: {
      provider: 'providerChatM365',
      model: 'modelChatM365',
      selectedIndex: '_selectedIndexM365',
      isResponseTabOpen: 'isResponseTabOpenM365',
    },
  },
};

// Full, user-facing tool name for export branding (e.g. 'AdminDroid LDAP Explorer').
// Lets a reader of an exported report identify and reach the exact tool.
function getExportToolName(toolId) {
  const entry = Object.values(TOOL_INFORMATIONS).find((t) => t.id === toolId);
  return entry ? `AdminDroid ${entry.name}` : TOOL_INFORMATIONS.APP_DETAILS.name;
}

export { TOOL_INFORMATIONS, AUTH_TYPES, CHAT_STORAGE_CONFIG, getExportToolName };
