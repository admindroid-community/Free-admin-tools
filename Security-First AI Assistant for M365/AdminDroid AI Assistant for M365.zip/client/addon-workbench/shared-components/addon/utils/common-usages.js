export default function ensureCallback(callback, name) {
  if (typeof callback === 'function') {
    return true;
  }

  console.warn(`@${name} was not passed or is not a function`);

  return false;
}
