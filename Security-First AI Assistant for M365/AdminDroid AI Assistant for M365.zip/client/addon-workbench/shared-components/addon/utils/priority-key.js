function getPriorityKeys(keys) {
  let priorities = [
    //user properties
    'displayName',
    'userPrincipalName',
    'description',
    'mail',
    'mobilePhone',
    'jobTitle',
    'officeLocation',
    'givenName',
    'surname',
    'mailNickname',
    'accountEnabled',
    'department',
    'companyName',
    'employeeId',
    'userType',
    'lastPasswordChangeDateTime',
    'aboutMe',
    'skills',
    'birthday',
    'interests',
    'schools',
    'pastProjects',

    //chat properties
    'chatId',
    'chatType',
    'topic',
    'attendees',
    'messageType',
    'subject',
    'from',
    'body',
    'bodyPreview',
    'attachments',
    'conversationId',
    'sentDateTime',
    'receivedDateTime',
    'isRead',
    'isDraft',

    //mail properties
    'toRecipients',
    'ccRecipients',
    'bccRecipients',
    'replyTo',
    'internetMessageId',
    'inferenceClassification',
    'hasAttachments',

    //oneDrive properties
    'name',
    'webUrl',
    'createdBy',
    'parentReference',
    'size',
    'fileSystemInfo',

    //oneNote properties
    'links',
    'pagesUrl',
    'parentNotebook',
    'parentSectionGroup',

    //event properties
    'start',
    'end',
    'location',
    'onlineMeetingInfo',
    'onlineMeetingProvider',
    'reminderMinutesBeforeStart',
    'iCalUId',
    'uid',
    'importance',
    'type',
    'showAs',
    'isAllDay',

    //group properties
    'groupTypes',
    'visibility',
    'mailEnabled',
    'securityEnabled',
    'renewedDateTime',
    'resourceBehaviorOptions',
    'resourceProvisioningOptions',
    'creationOptions',

    //security properties
    'assignedLicenses',
    'assignedPlans',
    'licenseAssignmentStates',
    'memberOf',
    'manager',
    'signInActivity',
    'authentication',
    'authenticationMethods',
    'passwordPolicies',
    'passwordProfile',
    'onPremisesUserPrincipalName',
    'onPremisesSamAccountName',
    'onPremisesSecurityIdentifier',
    'securityIdentifier',

    //device properties
    'presence',
    'availability',
    'status',
    'deviceId',
    'deviceDisplayName',
    'operatingSystem',
    'complianceState',
    'isManaged',
    'preferredLanguage',
    'createdDateTime',

    //id
    'id',
  ];
  let priorityKeys = {};

  priorities.forEach((key, index) => {
    priorityKeys[key] = index + 1;
  });

  let sortedKeys = keys.sort((a, b) => {
    return (priorityKeys[a] || 1000) - (priorityKeys[b] || 1000);
  });
  return sortedKeys;
}
export default getPriorityKeys;
