import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import {
  EXPORT_FORMATS,
  fitColumnsToPdf,
  exportChartImage,
} from '@admindroid/shared-components/utils/report-export';

/**
 * <ExportButton>
 *
 * Args:
 *   @buildExportJob      {Function}  () => table job (fetchPage, headers, …)
 *   @buildExportChartJob {Function}  () => chart job; chartContentType is either
 *                                    'chart' (canvas → image) or 'table' (DOM → data)
 *   @chartExport         {Boolean}   true when the chart tab is active
 *   @chartContentType    {String}    'chart' | 'table' — controls which formats show
 *   @disabled            {Boolean}   disables the button
 *   @hasLdapColumnPicker {Boolean}   shows column-picker hint in the PDF warning
 */
export default class ExportButtonComponent extends Component {
  @service('export-manager') exportManager;

  @tracked isOpen = false;
  @tracked showPdfWarning = false;
  @tracked pdfColInfo = null; // { total, shown, dropped } for the warning dialog
  @tracked _pendingJob = null;

  // Data formats — table tab and AI-rendered table in the chart tab
  get tableFormats() {
    // Order: HTML, CSV, Excel, PDF. PDF stays last because it has column
    // constraints (wide tables drop columns to fit the page).
    return [
      { id: EXPORT_FORMATS.HTML,  label: 'HTML',  icon: 'droid-custom-icon-html-file' },
      { id: EXPORT_FORMATS.CSV,   label: 'CSV',   icon: 'droid-custom-icon-csv' },
      { id: EXPORT_FORMATS.EXCEL, label: 'Excel', icon: 'droid-custom-icon-xlsx' },
      { id: EXPORT_FORMATS.PDF,   label: 'PDF',   icon: 'droid-custom-icon-pdf-file' },
    ];
  }

  // Image formats — canvas chart in the chart tab
  get chartImageFormats() {
    return [
      { id: EXPORT_FORMATS.PNG,       label: 'PNG',  icon: 'droid-custom-icon-image-semi-medium' },
      { id: EXPORT_FORMATS.JPEG,      label: 'JPEG', icon: 'droid-custom-icon-image-semi-medium' },
      { id: EXPORT_FORMATS.CHART_PDF, label: 'PDF',  icon: 'droid-custom-icon-pdf-file' },
    ];
  }

  get isDisabled() {
    return this.args.disabled || this.exportManager.isExporting;
  }

  get isChartExport() {
    return Boolean(this.args.chartExport);
  }

  // Chart tab is showing a canvas chart → offer image formats only.
  get isChartImageMode() {
    return this.isChartExport && this.args.chartContentType !== 'table';
  }

  // The format list shown in the dropdown for the current context.
  get activeFormats() {
    return this.isChartImageMode ? this.chartImageFormats : this.tableFormats;
  }

  @action
  toggleDropdown() {
    if (this.isDisabled) return;
    this.isOpen = !this.isOpen;
  }

  @action
  closeDropdown() {
    this.isOpen = false;
  }

  @action
  async pickFormat(format) {
    this.isOpen = false;
    if (this.isDisabled) return;

    // ── Chart canvas → image export (PNG / JPEG / chart PDF) ─────────────────
    if (this.isChartImageMode) {
      const chartJob = this.args.buildExportChartJob?.();
      if (!chartJob?.isChartExport) return;
      const labels = {
        [EXPORT_FORMATS.PNG]: 'PNG',
        [EXPORT_FORMATS.JPEG]: 'JPEG',
        [EXPORT_FORMATS.CHART_PDF]: 'PDF',
      };
      await this.exportManager.runSimple(
        () => exportChartImage(format, chartJob),
        {
          working: `Exporting chart as ${labels[format] ?? 'image'}…`,
          done: `Chart exported as ${labels[format] ?? 'image'}`,
        },
      );
      return;
    }

    // ── Chart tab showing an AI-rendered table → export that DOM table's data ─
    if (this.isChartExport) {
      const chartJob = this.args.buildExportChartJob?.();
      if (chartJob?.isChartTableExport) {
        // Same column-overflow warning as the standard table.
        if (this._maybeWarnPdfColumns(chartJob, format)) return;
        await this.exportManager.start(chartJob, format);
      }
      return;
    }

    // ── Standard table tab export ─────────────────────────────────────────────
    const job = this.args.buildExportJob?.();
    if (!job) return;

    if (this._maybeWarnPdfColumns(job, format)) return;

    await this.exportManager.start(job, format);
  }

  // Returns true (and shows the warning dialog) when a PDF export would drop
  // columns; the actual export is deferred until the user confirms.
  _maybeWarnPdfColumns(job, format) {
    if (format !== EXPORT_FORMATS.PDF) return false;
    // How many columns actually fit the PDF page — same calc the export uses.
    const { total, shown } = fitColumnsToPdf(job.headers);
    if (!total || total <= shown) return false;
    this._pendingJob = { job, format };
    this.pdfColInfo = {
      total,
      shown,
      dropped: total - shown,
    };
    this.showPdfWarning = true;
    return true;
  }

  @action
  confirmPdfWarning() {
    this.showPdfWarning = false;
    if (this._pendingJob) {
      const { job, format } = this._pendingJob;
      this._pendingJob = null;
      this.pdfColInfo = null;
      this.exportManager.start(job, format);
    }
  }

  // Keep clicks inside the dialog from reaching the backdrop (which closes it).
  @action
  stopPropagation(event) {
    event.stopPropagation();
  }

  @action
  dismissPdfWarning() {
    this.showPdfWarning = false;
    this.pdfColInfo = null;
    this._pendingJob = null;
  }
}