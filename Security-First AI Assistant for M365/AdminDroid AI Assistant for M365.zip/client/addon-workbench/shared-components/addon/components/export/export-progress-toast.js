import Component from '@glimmer/component';
import { service } from '@ember/service';
import { action } from '@ember/object';

/**
 * <ExportProgressToast>
 *
 * Persistent corner toast that reads from the export-manager service.
 * No args needed — it self-shows/hides based on exportManager.isExporting.
 * Renders on top of everything; survives tab and filter changes (D6 / D7).
 */
export default class ExportProgressToastComponent extends Component {
  @service('export-manager') exportManager;

  get isVisible() {
    return (
      this.exportManager.isExporting ||
      Boolean(this.exportManager.errorMessage) ||
      (this.exportManager.statusLabel && !this.exportManager.isExporting)
    );
  }

  @action
  cancel() {
    this.exportManager.cancel();
  }
}