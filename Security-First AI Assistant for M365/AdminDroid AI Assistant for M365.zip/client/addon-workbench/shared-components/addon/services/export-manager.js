import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import {
  EXPORT_FORMATS,
  exportReport,
  fileSpecForFormat,
  requestSaveHandle,
  buildExportFilename,
  formatGeneratedAt,
} from '@admindroid/shared-components/utils/report-export';

// Human-readable labels for the success toast (e.g. "37 rows exported to Excel").
const FORMAT_LABELS = {
  [EXPORT_FORMATS.PDF]: 'PDF',
  [EXPORT_FORMATS.CSV]: 'CSV',
  [EXPORT_FORMATS.EXCEL]: 'Excel',
  [EXPORT_FORMATS.HTML]: 'HTML',
};

/**
 * export-manager
 *
 * Drives the full export flow — page-loop → accumulate rows → generate file.
 *
 * Design decisions from the plan:
 *  D6: progress shown in <ExportProgressToast> which reads this service's
 *      tracked state, not in a full-screen blocker.
 *  D7: the job object (fetchPage / headers / filename / meta) is snapshotted
 *      at the moment the user picks a format, so changing filters / tabs /
 *      pages in the live table has zero effect on the in-flight export.
 */
export default class ExportManagerService extends Service {
  // ---- Public tracked state (read by <ExportProgressToast>) ----------------
  @tracked isExporting = false;
  @tracked rowCount = 0;
  @tracked statusLabel = '';
  @tracked errorMessage = null;
  @tracked wasCancelled = false;

  // ---- Private ---------------------------------------------------------------
  // Monotonic token identifying the active export. Cancelling (or starting a new
  // export) bumps it; any older run whose id no longer matches aborts at its next
  // checkpoint. This is race-free even if a slow fetchPage resolves late.
  _runId = 0;

  // ---------------------------------------------------------------------------
  // start(job, format)
  //
  // job = {
  //   fetchPage : async (cursor) => { rows: [...], nextCursor, hasMore }
  //   initialCursor : 0 | string | null
  //   headers       : string[]          — ordered column keys at click-time
  //   meta          : { title, summary, subtitle, generatedAt, toolName }
  //                   — title/summary drive the filename; the rest the header
  // }
  // format = EXPORT_FORMATS.CSV | .EXCEL | .PDF
  // ---------------------------------------------------------------------------
  @action
  async start(job, format) {
    if (this.isExporting) return; // only one export at a time

    const runId = ++this._runId;
    const active = () => runId === this._runId;

    this.wasCancelled = false;
    this.isExporting = true;
    this.rowCount = 0;
    this.errorMessage = null;
    this.statusLabel = `Preparing export…`;

    // Snapshot everything from the job at call-time (D7).
    const { fetchPage, initialCursor, headers, meta } = job;

    // Filename = "<short report title>-<HH-MM-SS>". The title comes from the
    // report summary (falls back to the title); the timestamp uses LOCAL time so
    // the filename matches the header's "Generated" time (same `now`) and stays
    // unique for simultaneous exports.
    const now = new Date();
    const reportTitle = meta?.summary || meta?.title || '';
    const filename = buildExportFilename(reportTitle, now);

    // Ask WHERE to save up front — while the click's user activation is still
    // valid. If we wait until after the (potentially long) page-loop, the
    // browser drops activation and the picker silently turns into a direct
    // download. Doing it now also lets the user cancel before any data is fetched.
    let saveHandle = null;
    try {
      const spec = fileSpecForFormat(format);
      saveHandle = await requestSaveHandle(`${filename}.${spec.extension}`, spec);
    } catch (err) {
      if (err?.isCancellation) {
        this._markCancelled(runId);
        return;
      }
      // Non-cancellation errors: fall through and let saveFile retry / fallback.
    }

    if (!active()) return; // cancelled while the save dialog was open

    try {
      const allRows = [];
      let cursor = initialCursor ?? 0;
      let hasMore = true;

      while (hasMore) {
        if (!active()) return; // cancelled between pages — stop fetching

        const page = await fetchPage(cursor);

        if (!active()) return; // cancelled while this page was in flight

        if (!page || !Array.isArray(page.rows)) {
          throw new Error('Unexpected response from fetchPage — expected { rows, nextCursor, hasMore }');
        }

        allRows.push(...page.rows);
        cursor = page.nextCursor;
        hasMore = Boolean(page.hasMore);
        this.rowCount = allRows.length;
        this.statusLabel = `Fetching… ${allRows.length.toLocaleString()} rows`;
      }

      if (!active()) return;

      this.statusLabel = 'Generating file…';

      // Reuse the same `now` captured for the filename so the header's
      // "Generated" time and the filename timestamp always agree.
      const generatedAt = formatGeneratedAt(now);
      const pdfMeta = { ...meta, generatedAt };

      await exportReport(format, { rows: allRows, headers, filename, meta: pdfMeta, saveHandle });

      if (!active()) return; // cancelled during generation — don't report success

      this.isExporting = false;
      const formatLabel = FORMAT_LABELS[format];
      this.statusLabel = formatLabel
        ? `${allRows.length.toLocaleString()} rows exported to ${formatLabel}`
        : `Exported ${allRows.length.toLocaleString()} rows`;
      this._scheduleClear(runId);
    } catch (err) {
      if (!active()) return; // a cancel already took over the UI
      this.isExporting = false;
      this.errorMessage = err?.message || 'Export failed.';
      this.statusLabel = 'Export failed.';
      console.error('[export-manager]', err);
      this._scheduleClear(runId);
    }
  }

  // ---------------------------------------------------------------------------
  // runSimple(asyncFn, { working, done }) — drive the progress toast for a
  // one-shot export that has no page-loop (e.g. chart image export). Shows the
  // spinner while asyncFn runs, then a success / error message that auto-clears.
  // ---------------------------------------------------------------------------
  @action
  async runSimple(asyncFn, { working = 'Exporting…', done = 'Export complete' } = {}) {
    if (this.isExporting) return;

    const runId = ++this._runId;
    const active = () => runId === this._runId;

    this.wasCancelled = false;
    this.isExporting = true;
    this.rowCount = 0;
    this.errorMessage = null;
    this.statusLabel = working;

    try {
      await asyncFn();
      if (!active()) return; // cancelled mid-render
      this.isExporting = false;
      this.statusLabel = done;
    } catch (err) {
      if (!active()) return;
      this.isExporting = false;
      if (err?.isCancellation) {
        this.wasCancelled = true;
        this.statusLabel = 'Export cancelled.';
      } else {
        this.errorMessage = err?.message || 'Export failed.';
        this.statusLabel = 'Export failed.';
        console.error('[export-manager] runSimple', err);
      }
    }
    if (active()) this._scheduleClear(runId);
  }

  // Cancel the in-flight export. Bumping _runId makes the running loop abort at
  // its next checkpoint; the toast shows a brief "cancelled" state then clears.
  @action
  cancel() {
    if (!this.isExporting) return;
    this._runId++; // invalidate the active run (race-free)
    this.isExporting = false;
    this.wasCancelled = true;
    this.rowCount = 0;
    this.statusLabel = 'Export cancelled.';
    setTimeout(() => this._clear(), 2000);
  }

  // Show the cancelled state for a run that aborted itself (e.g. user dismissed
  // the save-file picker), then clear after a moment.
  _markCancelled(runId) {
    if (runId !== this._runId) return;
    this.isExporting = false;
    this.wasCancelled = true;
    this.statusLabel = 'Export cancelled.';
    this._scheduleClear(runId);
  }

  // Auto-clear the toast after a completed / failed export, unless a newer run
  // has since started.
  _scheduleClear(runId) {
    setTimeout(() => {
      if (runId === this._runId) this._clear();
    }, 3000);
  }

  _clear() {
    this.isExporting = false;
    this.rowCount = 0;
    this.statusLabel = '';
    this.errorMessage = null;
    this.wasCancelled = false;
  }
}