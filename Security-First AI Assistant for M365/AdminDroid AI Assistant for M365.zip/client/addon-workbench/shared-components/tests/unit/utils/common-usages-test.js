import commonUsages from 'dummy/utils/common-usages';
import { module, test } from 'qunit';

module('Unit | Utility | common-usages', function () {
  // TODO: Replace this with your real tests.
  test('it works', function (assert) {
    let result = commonUsages();
    assert.ok(result);
  });
});
