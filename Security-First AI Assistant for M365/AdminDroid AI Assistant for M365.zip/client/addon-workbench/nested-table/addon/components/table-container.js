import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import {
  stickFirstNCols as applyStickyHelper,
  resetStickyCols,
} from '../utils/stick-table-first-n-column';
import { getHeaderFromData } from '../utils/get-header';

export default class TableContainerComponent extends Component {
  @tracked currentPage = this.args.currentTablePage ?? 1;
  @tracked isPagination = this.args.isPagination ?? false;

  @tracked expandedKeys = new Set();

  availablePageSizes = [20, 25, 50, 100];
  @tracked selectedCustomPageSize = this.availablePageSizes[0];
  previousData = null;

  datetimeFields = [
    'createdDateTime',
    'lastModifiedDateTime',
    'lastPasswordChangeDateTime',
    'startDateTime',
    'expirationDateTime',
    'activityDateTime',
    'deletedDateTime',
    'receivedDateTime',
    'sentDateTime',
    'start',
    'end',
    'dueDateTime',
    'completedDateTime',
  ];

  @action
  isDate(value) {
    return (
      typeof value === 'string' &&
      this.datetimeFields.some((field) =>
        value.toLowerCase().includes(field.toLowerCase()),
      )
    );
  }

  @action
  localDate(value) {
    if(value === null || value === undefined) return "-";
    const date = new Date(value);
    return isNaN(date) ? value : date.toLocaleString();
  }

  @action
  isSkuId(value) {
    if (value === "skuId" || value === "SkuId" || value === "SKUId" || value === "SKUID") {
      console.log('found skuid', this.mapSkuId(value));
    }
    return (typeof value === 'string' &&
      value.toLowerCase()=== "skuid");
  }

@action
mapSkuId(value) {
  const skuMap = {
    // Microsoft 365 / Office 365 SKUs
    "6fd2c87f-b296-42f0-b197-1e91e994b900": "ENTERPRISEPACK",
    "c7df2760-2c81-4ef7-b578-5b5392b571df": "ENTERPRISEPREMIUM",
    "05e9a617-0261-4cee-bb44-138d3ef5d965": "ENTERPRISEPACK_NO_TEAMS",
    "06ebc4ee-1bb5-47dd-8120-11324bc54e06": "ENTERPRISEPREMIUM_NO_TEAMS",
    "f245ecc8-75af-4f8e-b61f-27d8114de5f3": "BUSINESS_STANDARD",
    "cbdc14ab-d96c-4c30-b9f4-6ada7cdc1d46": "BUSINESS_PREMIUM",
    "3b555118-da6a-4418-894f-7df1e2096870": "BUSINESS_BASIC",

    // Exchange
    "4b9405b0-7788-4568-add1-99614e613b69": "EXCHANGE_S_ENTERPRISE",
    "19ec0d23-8335-4cbd-94ac-6050e30712fa": "EXCHANGE_ENTERPRISE",

    // SharePoint / OneDrive
    "c7699d2e-19aa-44de-8edf-1736da088ca1": "SHAREPOINTWAVE1",
    "5dbe027f-2339-4123-9542-606e4d348a72": "SHAREPOINTENTERPRISE",
    "f30db892-07e9-47e9-837c-80727f46fd3d": "FLOW_FREE",

    // Teams
    "57ff2da0-773e-42df-b2af-ffb7a2317929": "TEAMS_ESSENTIALS",
    "fca3e605-0a6f-4b5e-9f0a-6c8e8a6a8c9d": "TEAMS_EXPLORATORY",

    // Power Platform
    "6a0f6da5-0b87-4190-a6ae-9bb5a2b9546a": "POWER_BI_STANDARD",
    "a403ebcc-fae0-4ca2-8c8c-7a907fd6c235": "POWER_BI_PREMIUM_PU",
    "dcb1a3ae-b33f-4487-846a-a640262fadf4": "POWER_APPS_PLAN1",
    "f20fedf3-f3c3-43c3-8261-4e9c4c8e9bff": "POWER_APPS_PLAN2",

    // Azure AD / Security
    "078d2b04-f1bd-4111-bbd4-b4b1b354cef4": "AAD_PREMIUM_P1",
    "84a661c4-e949-4bd2-a560-ed7766fcaf2b": "AAD_PREMIUM_P2",

    // Project / Visio
    "2b9c4092-4240-4d87-b4cc-0f8a4e7c5c0e": "PROJECT_PLAN1",
    "53818b1b-4a27-454b-8896-0dba576410e6": "PROJECT_PLAN3",
    "09015f9f-377f-4538-bbb5-f75ceb09358a": "PROJECT_PLAN5",
    "4a51c7f3-3c3b-4f8a-9f38-1b0c7d5e5f2c": "VISIO_PLAN1",
    "c5928f49-12ba-48f7-ada3-0d743a3601d5": "VISIO_PLAN2",

    // Forms Pro / Customer Voice
    "e2ae107b-a571-426f-9367-6d4c8f1390ba": "FORMS_PRO_USL",

    // Add your other SKUs here
    "5b631642-bd26-49fe-bd20-1daaa972ef80": "CCIBOTS_PRIVPREV_VIRAL"
  };

  return skuMap[value] || value;
}

  constructor() {
    super(...arguments);
    this.currentPage = this.args.currentTablePage ?? 1;
    this.isPagination = this.args.isPagination ?? false;
    // this.onChangeCurrentPageSize(this.args.tableMaxData?? this.availablePageSizes[0])
    this.selectedCustomPageSize =
      this.args.tableMaxData ?? this.availablePageSizes[0];
  }

  get hasDataChanged() {
    const newData = this.args.tableData?.tableValue;
    if (newData !== this.previousData) {
      this.previousData = newData;
    }
    if (!this.args.doNotResetOnChangeData) this.reset();
  }

  reset() {
    this.currentPage = this.args.currentTablePage ?? 1;
    this.isPagination = this.args.isPagination ?? false;
  }

  @action
  async onChangeCurrentPageSize(pageSize) {
    this.selectedCustomPageSize = pageSize;
    this.currentPage = 1;

    await this.ensurePageSizeAvailable();
    this.args.onchangePagesizeSuccessCallback(this.selectedCustomPageSize);
  }

  @action
  async ensurePageSizeAvailable(totalSize) {
    const currentSize = totalSize ?? this.args.tableData.tableValue.length;
    if (
      (this.selectedCustomPageSize > currentSize ||
        currentSize % this.selectedCustomPageSize != 0) &&
      this.args.supportsExternalPagination &&
      this.args.hasMoreNextData
    ) {
      let remainingToFetch =
        this.selectedCustomPageSize > currentSize
          ? this.selectedCustomPageSize - currentSize
          : currentSize % this.selectedCustomPageSize != 0
            ? this.selectedCustomPageSize -
              (currentSize % this.selectedCustomPageSize)
            : 0;
      if (await this.args.handleNextPage?.perform(remainingToFetch)) {
        this.args.updateCurrentPageSize?.(this.currentPage);
      }
    }
  }

  @action
  toggleKey(key, event) {
    event.stopPropagation();
    if (this.expandedKeys.has(key)) {
      this.expandedKeys.delete(key);
    } else {
      this.expandedKeys.add(key);
    }

    // Force reactivity
    this.expandedKeys = new Set(this.expandedKeys);
  }

  isExpanded(key) {
    return this.expandedKeys.has(key);
  }

  @action
  setupTable(element) {
    // console.log("tav", element)
    let tableContainer = element;
    this.stickFirstNCols(tableContainer);
    if (tableContainer) {
      tableContainer.scrollLeft = 0;
      tableContainer.scrollTop = 0;
    }
  }

  @action
  stickFirstNCols(tableContainer) {
    if (!this.args.isNestedTable) {
      this.setupTableIntializer(tableContainer);
    }
  }

  get tableMaxData() {
    return this.isPagination && this.args.tableMaxData
      ? this.selectedCustomPageSize
      : this.args.tableData.tableValue.length;
  }

  get upperLimit() {
    const upper = this.currentPage * this.tableMaxData;
    return !this.isPagination && !this.tableMaxData
      ? this.args.tableData.tableValue.length
      : Math.min(upper, this.args.tableData.tableValue.length);
  }

  get lowerLimit() {
    const lower = (this.currentPage - 1) * this.tableMaxData;
    return !this.isPagination && !this.tableMaxData ? 0 : Math.max(0, lower);
  }

  get tableDatas() {
    return this.args.tableData?.tableValue?.slice(
      this.lowerLimit,
      this.upperLimit,
    );
  }

  get tableHeader() {
    return (
      this.args.tableData?.tableHeader ??
      getHeaderFromData(this.args.tableData.tableValue)
    );
  }
  get hasNextPage() {
    return this.upperLimit < this.args.tableData.tableValue.length;
  }

  get hasPrevPage() {
    return this.currentPage > 1;
  }

  get isLastPage() {
    return (
      !this.hasNextPage &&
      !this.args.hasMoreNextData &&
      this.args.tableData.tableValue.length >=
        (this.args.maxCountForRestriction ?? 2000)
    );
  }

  @action
  movePrevPage() {
    if (this.hasPrevPage) {
      --this.currentPage;
      this.args.updateCurrentPageSize?.(this.currentPage);
    }
  }

  @action
  async moveNextPage() {
    if (this.hasNextPage) {
      ++this.currentPage;
      this.args.updateCurrentPageSize?.(this.currentPage);
    } else if (
      this.args.supportsExternalPagination &&
      this.args.hasMoreNextData
    ) {
      const result = await this.args.handleNextPage?.perform(
        this.selectedCustomPageSize,
      );
      if (result) {
        ++this.currentPage;
        this.args.updateCurrentPageSize?.(this.currentPage);
      }
    }
  }

  @action
  onRowClick(row, index) {
    this.args.handleRowClick?.(row, index);
  }

  setupTableIntializer(tableContainer) {
    const parent = tableContainer;
    const table = tableContainer.querySelector('table');

    if (!parent || !table) {
      console.warn('Parent or table element not found');
      return;
    }

    const parentRect = parent.getBoundingClientRect();
    const tableRect = table.getBoundingClientRect();

    const parentWidth = parentRect.width;
    const tableWidth = tableRect.width;

    // console.log('parent', parentWidth, 'child', tableWidth);
    // Only proceed if parent is wider than table
    if (parentWidth >= tableWidth) {
      console.log(
        'Parent width is less than or equal to table width — skipping sticky logic',
      );
      resetStickyCols(table);
      return;
    }

    // Existing logic
    const firstRow = table.rows[0];
    const col1 = firstRow.cells[0];
    const col2 = firstRow.cells[1];

    const col1Width = col1.offsetWidth;
    const col2Width = col2.offsetWidth;
    const combinedWidth = col1Width + col2Width;

    const threshold = parentWidth * 0.4;

    if (combinedWidth < threshold) {
      applyStickyHelper(table, 2);
    } else if (col1Width < threshold) {
      applyStickyHelper(table, 1);
    } else {
      resetStickyCols(table);
    }
  }
}
