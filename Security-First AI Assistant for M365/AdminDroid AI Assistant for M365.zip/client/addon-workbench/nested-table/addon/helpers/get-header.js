import { helper } from '@ember/component/helper';
import { getHeaderFromData } from '../utils/get-header';
import getPriorityKeys from '@admindroid/shared-components/utils/priority-key';

export default helper(([data, usePriority]) => {
  const headers = getHeaderFromData(data);

  if (usePriority) {
    return getPriorityKeys(headers); // ✅ pass headers, not raw data
  }

  return headers;
});