// app/helpers/get-initials.js
import { helper } from '@ember/component/helper';

export default helper(function getInitials([name]) {
  if (typeof name !== 'string') {
    return ''; // Return an empty string if name is not a valid string
  }
  return name
    .trim()
    .split(' ')
    .filter((word) => word.length > 0) // Filter out empty strings from multiple spaces
    .map((word) => word.charAt(0).toUpperCase())
    .slice(0, 2)
    .join('');
});
