import Route from '@ember/routing/route';

export default class SettingsGeneralRoute extends Route {}
