import Route from '@ember/routing/route';

export default class SettingsAdoutRoute extends Route {}
