import Service from '@ember/service';

import { action } from '@ember/object';
import { service } from '@ember/service';
import { TrackedArray } from 'tracked-built-ins';
import AES from 'crypto-js/aes';
import { apiRequest } from '../utils/api-service';

export default class EncryptAndDecryptService extends Service {
  @action
  async encryption(data) {
    let response = await apiRequest(
      '/settings/sessionKey',
      'GET',
      null,
      {
        credentials: 'include',
      },
    );

    return AES.encrypt(data, response.key).toString();
  }
}
