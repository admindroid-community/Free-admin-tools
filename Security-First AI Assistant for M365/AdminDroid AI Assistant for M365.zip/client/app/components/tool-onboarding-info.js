import Component from '@glimmer/component';
import { service } from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';

import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

export default class ToolOnboardingInfoComponent extends Component {
  @service authenticationAd;
  @service router;
  @service('chat-form-data') chatFormDataService;
  @service('update-app') updateAppService;

  @tracked isCompatibilityUpdate = true;

  get compatibilityCheck() {
    return this.updateAppService.compatibilityCheck;
  }

  get isCompatibilityUpdateAvailable() {
    return this.compatibilityCheck.some((item) => item.isMandatory ?? false);
  }

  @action
  getFeatureIndex(index, maxIndex = 4) {
    return index % maxIndex
  }

  @action
  updateData() {
    this.isCompatibilityUpdate = !this.isCompatibilityUpdate;
  }

  @action
  getTagInfo(moduleId) {
    console.log("mo", moduleId);
    if (TOOL_INFORMATIONS.MODULE_AD.id == moduleId) {
      return "Meet your Copilot for Active Directory!"
    }
    else if (TOOL_INFORMATIONS.MODULE_M365.id == moduleId) {
      return "Meet your Copilot for Microsoft 365!"
    }
    else {
      return "Your Gateway to Smarter Data Exploration Begins Here!"
    }
  }
}
