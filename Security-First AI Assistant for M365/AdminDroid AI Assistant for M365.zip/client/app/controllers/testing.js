import Controller from '@ember/controller';
import { action } from '@ember/object';
import { tracked } from '@glimmer/tracking';
import { service } from '@ember/service';

export default class IndexController extends Controller {
    tableData = [
        {
            id: 1,
            name: "John Doe",
            email: "john.doe@example.com",
            role: "Admin",
            status: "Active",
            createdAt: "2024-01-05"
        },
        {
            id: 2,
            name: "Jane Smith",
            email: "jane.smith@example.com",
            role: "User",
            status: "Inactive",
            createdAt: "2024-01-12"
        },
        {
            id: 3,
            name: "Michael Brown",
            email: "michael.brown@example.com",
            role: "Manager",
            status: "Active",
            createdAt: "2024-01-18"
        },
        {
            id: 4,
            name: "Emily Davis",
            email: "emily.davis@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-02-01"
        },
        {
            id: 5,
            name: "Chris Wilson",
            email: "chris.wilson@example.com",
            role: "User",
            status: "Suspended",
            createdAt: "2024-02-07"
        },
        {
            id: 6,
            name: "Sarah Johnson",
            email: "sarah.johnson@example.com",
            role: "Admin",
            status: "Active",
            createdAt: "2024-02-10"
        },
        {
            id: 7,
            name: "David Miller",
            email: "david.miller@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-02-15"
        },
        {
            id: 8,
            name: "Laura Martinez",
            email: "laura.martinez@example.com",
            role: "Manager",
            status: "Inactive",
            createdAt: "2024-02-20"
        },
        {
            id: 9,
            name: "Daniel Anderson",
            email: "daniel.anderson@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-02-25"
        },
        {
            id: 10,
            name: "Sophia Taylor",
            email: "sophia.taylor@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-03-01"
        },
        {
            id: 11,
            name: "James Thomas",
            email: "james.thomas@example.com",
            role: "User",
            status: "Inactive",
            createdAt: "2024-03-03"
        },
        {
            id: 12,
            name: "Olivia White",
            email: "olivia.white@example.com",
            role: "Manager",
            status: "Active",
            createdAt: "2024-03-05"
        },
        {
            id: 13,
            name: "William Harris",
            email: "william.harris@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-03-07"
        },
        {
            id: 14,
            name: "Ava Martin",
            email: "ava.martin@example.com",
            role: "Admin",
            status: "Active",
            createdAt: "2024-03-10"
        },
        {
            id: 15,
            name: "Ethan Thompson",
            email: "ethan.thompson@example.com",
            role: "User",
            status: "Suspended",
            createdAt: "2024-03-12"
        },
        {
            id: 16,
            name: "Mia Garcia",
            email: "mia.garcia@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-03-15"
        },
        {
            id: 17,
            name: "Alexander Martinez",
            email: "alexander.martinez@example.com",
            role: "Manager",
            status: "Active",
            createdAt: "2024-03-18"
        },
        {
            id: 18,
            name: "Charlotte Robinson",
            email: "charlotte.robinson@example.com",
            role: "User",
            status: "Inactive",
            createdAt: "2024-03-20"
        },
        {
            id: 19,
            name: "Benjamin Clark",
            email: "benjamin.clark@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-03-22"
        },
        {
            id: 20,
            name: "Amelia Lewis",
            email: "amelia.lewis@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-03-25"
        },
        {
            id: 21,
            name: "Henry Walker",
            email: "henry.walker@example.com",
            role: "Admin",
            status: "Active",
            createdAt: "2024-03-27"
        },
        {
            id: 22,
            name: "Isabella Hall",
            email: "isabella.hall@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-03-28"
        },
        {
            id: 23,
            name: "Lucas Young",
            email: "lucas.young@example.com",
            role: "Manager",
            status: "Inactive",
            createdAt: "2024-03-29"
        },
        {
            id: 24,
            name: "Harper King",
            email: "harper.king@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-03-30"
        },
        {
            id: 25,
            name: "Jack Wright",
            email: "jack.wright@example.com",
            role: "User",
            status: "Active",
            createdAt: "2024-04-01"
        }
    ];

}