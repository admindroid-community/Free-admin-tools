const { OpenAI } = require("openai");
const CoreAIProvider = require("./coreAIProvider.js");
const {
  extractJson,
  getTextFromList,
  isValidJson,
} = require("../../util/parse.js");
const { sendAndLogError } = require("../../util/errorResponse.js");
const { logger } = require("../../util/logger.js");

class OpenAISharedProvider extends CoreAIProvider {
  initClient(apiKey) {
    this.client = new OpenAI({ apiKey: apiKey });
  }

  async getResponse(model, prompt, history = [], prevIn = 0, prevOut = 0) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        model: model || "gpt-4.1",
        messages: [
          { role: "user", content: this.ctx.context },
          { role: "assistant", content: "How can I help you?" },
          ...history,
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
      });
      resultText = response.choices[0]?.message?.content;
      const totalInput = prevIn + (response.usage?.prompt_tokens || 0);
      const totalOutput = prevOut + (response.usage?.completion_tokens || 0);

      resultText = extractJson(resultText || "");

      logger.development.ai.debug(`openAI json, ${JSON.stringify(resultText)}`);
      if (!isValidJson(resultText)) {
        let retryResponse = await this.handleRetry(() =>
          this.getResponse(
            model,
            `${this.ctx.retryContext} ${resultText} users previous query:${this.currentPrompt}`,
            history,
            totalInput,
            totalOutput,
          ),
        );
        this.retryCount = 0;
        return retryResponse;
      }
      try {
        resultText = getTextFromList(resultText);
      } catch (e) {
        let retryResponse = await this.handleRetry(() =>
          this.getResponse(
            model,
            `${this.ctx.retryContext} ${resultText} users previous query:${this.currentPrompt}`,
            history,
            totalInput,
            totalOutput,
          ),
        );
        this.retryCount = 0;
        return retryResponse;
      }
      this.retryCount = 0;
      return {
        text: resultText,
        inputToken: totalInput,
        outputToken: totalOutput,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getCode(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        model: model || "gpt-4.1",
        messages: [
          { role: "user", content: this.ctx.codeContext },
          { role: "assistant", content: "How can I help you?" },
          { role: "user", content: prompt },
        ],
        temperature: 0.5,
      });
      resultText = response.choices[0]?.message?.content;
      const cleaned = extractJson(resultText || "");
      return {
        text: JSON.parse(cleaned),
        inputToken: response.usage?.prompt_tokens || 0,
        outputToken: response.usage?.completion_tokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getPriorityContext(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        model: model || "gpt-4.1",
        messages: [
          { role: "user", content: this.ctx.priorityContext },
          { role: "assistant", content: "How can I help you?" },
          { role: "user", content: JSON.stringify(prompt) },
        ],
        temperature: 0.7,
      });
      resultText = response.choices[0]?.message?.content;
      const cleaned = extractJson(resultText || "");
      return {
        text: JSON.parse(cleaned),
        inputToken: response.usage?.prompt_tokens || 0,
        outputToken: response.usage?.completion_tokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getConsentPermission(
    model,
    prompt,
    isRetry,
    suggestion = null,
    prevIn = 0,
    prevOut = 0,
  ) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        model: model || "gpt-4.1",
        messages: [
          {
            role: "user",
            content: isRetry
              ? this.ctx.retryConsentPermissionContext + suggestion
              : this.ctx.consentPermissionContext,
          },
          { role: "assistant", content: "How can I help you?" },
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
      });
      resultText = response.choices[0]?.message?.content;
      const totalInput = prevIn + (response.usage?.prompt_tokens || 0);
      const totalOutput = prevOut + (response.usage?.completion_tokens || 0);
      let cleaned = extractJson(resultText || "");

      logger.development.ai.debug(`PermissionConsent Response: ${cleaned}`);

      try {
        cleaned = JSON.parse(cleaned);
      } catch (ex) {
        logger.development.ai.debug("permission consent retry called");
        let retryResponse = await this.handleRetry(
          () =>
            this.getConsentPermission(
              model,
              `${this.ctx.retryConsentContext} ${resultText} user previous query:${prompt}`,
              isRetry,
              suggestion,
              totalInput,
              totalOutput,
            ),
          "retryContextCount",
          1,
          totalInput,
          totalOutput,
        );
        this.retryContextCount = 0;
        return retryResponse;
      }

      return {
        text: cleaned,
        inputToken: totalInput,
        outputToken: totalOutput,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async handleCallTool(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        model: model || "gpt-4.1",
        messages: [
          { role: "user", content: this.ctx.callToolContext },
          { role: "assistant", content: "How can I help you?" },
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
      });
      resultText = response.choices[0]?.message?.content;
      const cleaned = extractJson(resultText || "");
      return {
        callTool: JSON.parse(cleaned).callTool,
        inputToken: response.usage?.prompt_tokens || 0,
        outputToken: response.usage?.completion_tokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  handleErrorResponse(error, resultText) {
    logger.ai.error(`openai error response ${JSON.stringify(error)}`);
    const log = logger.ai;
    if (error.status == 401) {
      sendAndLogError(
        log,
        "Authentication failed",
        401,
        this.ctx.authMessage || "Authentication failed.",
      );
    } else if (error.status == 429) {
      sendAndLogError(
        log,
        "Rate limited",
        429,
        this.ctx.rateLimitMessage || "Rate limited.",
      );
    } else if (error.status == 500) {
      sendAndLogError(
        log,
        "Provider internal error",
        500,
        this.ctx.modelInternalError || "Internal error.",
      );
    }
    sendAndLogError(
      log,
      error.code || "Internal Server Error",
      error.status || 500,
      error.status ? `${error.message}` : `Error in OpenAI generation`,
    );
  }
}

module.exports = OpenAISharedProvider;
