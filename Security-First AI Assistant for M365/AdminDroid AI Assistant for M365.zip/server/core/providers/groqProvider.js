const { Groq } = require("groq-sdk");
const CoreAIProvider = require("./coreAIProvider.js");
const {
  extractJson,
  getTextFromList,
  isValidJson,
} = require("../../util/parse.js");
const { sendAndLogError } = require("../../util/errorResponse.js");
const { logger } = require("../../util/logger.js");

class GroqSharedProvider extends CoreAIProvider {
  initClient(apiKey) {
    this.client = new Groq({ apiKey: apiKey });
  }
  async getResponse(model, prompt, history = [], prevIn = 0, prevOut = 0) {
    let resultText;
    try {
      const client = this.getClient();
      const messages = [];
      if (this.ctx.context) {
        messages.push(
          { role: "user", content: this.ctx.context },
          {
            role: "system",
            content: JSON.stringify([
              {
                text: JSON.stringify({ text: "How can I help you?", json: {} }),
              },
            ]),
          },
        );
      }
      if (Array.isArray(history) && history.length) messages.push(...history);
      messages.push({ role: "user", content: prompt });

      const response = await client.chat.completions.create({
        messages,
        model: model || "llama3-8b-8192",
        temperature: 0.7,
      });
      resultText = response.choices[0]?.message?.content?.trim();
      const totalInput = prevIn + (response.usage?.prompt_tokens || 0);
      const totalOutput = prevOut + (response.usage?.completion_tokens || 0);

      resultText = extractJson(resultText || "");
      logger.development.ai.debug(`groq json, ${JSON.stringify(resultText)} `);
      if (!isValidJson(resultText)) {
        let retryResponse = await this.handleRetry(() =>
          this.getResponse(
            model,
            `${this.ctx.retryContext} ${resultText} users previous query:${this.currentPrompt}`,
            history,
            totalInput,
            totalOutput,
          ),
        );
        this.retryCount = 0;
        return retryResponse;
      }
      try {
        resultText = getTextFromList(resultText);
      } catch (e) {
        let retryResponse = await this.handleRetry(() =>
          this.getResponse(
            model,
            `${this.ctx.retryContext} ${resultText} users previous query:${this.currentPrompt}`,
            history,
            totalInput,
            totalOutput,
          ),
        );
        this.retryCount = 0;
        return retryResponse;
      }
      return {
        text: resultText,
        inputToken: totalInput,
        outputToken: totalOutput,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getCode(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        messages: [
          { role: "user", content: this.ctx.codeContext },
          { role: "system", content: "Generate code based on the prompt." },
          { role: "user", content: prompt },
        ],
        model: model || "llama3-8b-8192",
        temperature: 0.5,
      });
      resultText = response.choices[0]?.message?.content;
      const cleaned = extractJson(resultText || "");
      return {
        text: JSON.parse(cleaned),
        inputToken: response.usage?.prompt_tokens || 0,
        outputToken: response.usage?.completion_tokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getPriorityContext(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        messages: [
          { role: "user", content: this.ctx.priorityContext },
          { role: "system", content: "Sort the fields based on priority." },
          { role: "user", content: JSON.stringify(prompt) },
        ],
        model: model,
        temperature: 0.5,
      });
      resultText = response.choices[0]?.message?.content?.trim();
      const cleaned = extractJson(resultText || "");
      return {
        text: JSON.parse(cleaned),
        inputToken: response.usage?.prompt_tokens || 0,
        outputToken: response.usage?.completion_tokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getConsentPermission(
    model,
    prompt,
    isRetry,
    suggestion = null,
    prevIn = 0,
    prevOut = 0,
  ) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        messages: [
          {
            role: "user",
            content: isRetry
              ? this.ctx.retryConsentPermissionContext + suggestion
              : this.ctx.consentPermissionContext,
          },
          { role: "system", content: "Provide consent permission." },
          { role: "user", content: prompt },
        ],
        model: model || "llama3-8b-8192",
        temperature: 0.7,
      });
      resultText = response.choices[0]?.message?.content?.trim();
      const totalInput = prevIn + (response.usage?.prompt_tokens || 0);
      const totalOutput = prevOut + (response.usage?.completion_tokens || 0);
      let cleaned = extractJson(resultText || "");

      logger.development.ai.debug(`PermissionConsent Response: ${cleaned}`);

      try {
        cleaned = JSON.parse(cleaned);
      } catch (ex) {
        logger.development.ai.debug("permission consent retry called");
        let retryResponse = await this.handleRetry(
          () =>
            this.getConsentPermission(
              model,
              `${this.ctx.retryConsentContext} ${resultText} user previous query:${prompt}`,
              isRetry,
              suggestion,
              totalInput,
              totalOutput,
            ),
          "retryContextCount",
          1,
          totalInput,
          totalOutput,
        );
        this.retryContextCount = 0;
        return retryResponse;
      }

      return {
        text: cleaned,
        inputToken: totalInput,
        outputToken: totalOutput,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async handleCallTool(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat.completions.create({
        messages: [
          { role: "user", content: this.ctx.callToolContext },
          {
            role: "system",
            content: "Determine if the user gives permission to proceed.",
          },
          { role: "user", content: prompt },
        ],
        model: model || "llama3-8b-8192",
        temperature: 0.7,
      });
      resultText = response.choices[0]?.message?.content?.trim();
      const cleaned = extractJson(resultText || "");
      return {
        callTool: JSON.parse(cleaned).callTool,
        inputToken: response.usage?.prompt_tokens || 0,
        outputToken: response.usage?.completion_tokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  handleErrorResponse(error, resultText) {
    logger.ai.error(`groq error response ${JSON.stringify(error)}`);
    const log = logger.ai;
    if (error.status == 401) {
      sendAndLogError(
        log,
        "Authentication failed",
        401,
        this.ctx.authMessage || "Authentication failed.",
      );
    } else if (error.status == 429) {
      sendAndLogError(
        log,
        "Rate limited",
        429,
        this.ctx.rateLimitMessage || "Rate limited.",
      );
    } else if (error.status == 500) {
      sendAndLogError(
        log,
        "Provider internal error",
        500,
        this.ctx.modelInternalError || "Internal error.",
      );
    }
    sendAndLogError(
      log,
      error.error?.error?.code || "Internal Server Error",
      error.status || 500,
      error.status ? `${error.message}` : `Error in Groq generation`,
    );
  }
}

module.exports = GroqSharedProvider;
