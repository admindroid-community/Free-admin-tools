const CoreAIProvider = require("./coreAIProvider.js");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const {
  extractJson,
  getTextFromList,
  isValidJson,
} = require("../../util/parse.js");
const { sendAndLogError } = require("../../util/errorResponse.js");
const { logger, Logger } = require("../../util/logger.js");

class GeminiSharedProvider extends CoreAIProvider {

  initClient(apiKey) {
    this.client = new GoogleGenerativeAI(apiKey);
  }

  async getResponse(model, prompt, history = [], prevIn = 0, prevOut = 0) {
    let resultText;
    try {
      const client = this.getClient();
      const geminiModel = client.getGenerativeModel({
        model: model || "gemini-2.0",
        generationConfig: { temperature: 0.7 },
      });
      const chatHistory = [
        { role: "user", parts: [{ text: this.ctx.context }] },
        { role: "model", parts: [{ text: "How can I help you?" }] },
        ...history,
      ];
      const chat = geminiModel.startChat({ history: chatHistory });
      const response = await chat.sendMessage(prompt);
      resultText = response.response.text();
      const totalInput =
        prevIn + (response.response?.usageMetadata?.promptTokenCount || 0);
      const totalOutput =
        prevOut + (response.response?.usageMetadata?.candidatesTokenCount || 0);

      resultText = extractJson(resultText || "");
      logger.development.ai.debug(
        `gemini json, ${JSON.stringify(resultText)} `,
      );

      if (!isValidJson(resultText)) {
        logger.development.ai.debug("not a valid json");
        let retryResponse = await this.handleRetry(
          () =>
            this.getResponse(
              model,
              `${this.ctx.retryContext} ${resultText} users previous query:${this.currentPrompt}`,
              history,
              totalInput,
              totalOutput,
            ),
          "retryCount",
          2,
          totalInput,
          totalOutput,
        );
        this.retryCount = 0;
        return retryResponse;
      }
      try {
        resultText = getTextFromList(resultText);
      } catch (e) {
        logger.development.ai.debug("mismatch in response format");
        let retryResponse = await this.handleRetry(
          () =>
            this.getResponse(
              model,
              `${this.ctx.retryContext} ${resultText}  users previous query:${this.currentPrompt}`,
              history,
              totalInput,
              totalOutput,
            ),
          "retryCount",
          2,
          totalInput,
          totalOutput,
        );
        this.retryCount = 0;
        return retryResponse;
      }
      return {
        text: resultText,
        inputToken: totalInput,
        outputToken: totalOutput,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getCode(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const geminiModel = client.getGenerativeModel({
        model: model || "gemini-2.0",
        generationConfig: { temperature: 0.5 },
      });
      const chat = geminiModel.startChat({
        history: [
          { role: "user", parts: [{ text: this.ctx.codeContext }] },
          { role: "model", parts: [{ text: "How can I help you?" }] },
        ],
      });
      const response = await chat.sendMessage(prompt);
      resultText = response.response.text();
      const cleaned = extractJson(resultText || "");
      return {
        text: JSON.parse(cleaned),
        inputToken: response.response?.usageMetadata?.promptTokenCount || 0,
        outputToken:
          response.response?.usageMetadata?.candidatesTokenCount || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getPriorityContext(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const geminiModel = client.getGenerativeModel({
        model: model || "gemini-2.0",
        generationConfig: { temperature: 0.7 },
      });
      const chat = geminiModel.startChat({
        history: [
          { role: "user", parts: [{ text: this.ctx.priorityContext }] },
          { role: "model", parts: [{ text: "How can I help you?" }] },
        ],
      });
      const response = await chat.sendMessage(JSON.stringify(prompt));
      logger.development.ai.debug(`response ${response}`);
      resultText = response.response.text();
      const cleaned = extractJson(resultText || "");
      return {
        text: JSON.parse(cleaned),
        inputToken: response.response?.usageMetadata?.promptTokenCount || 0,
        outputToken:
          response.response?.usageMetadata?.candidatesTokenCount || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getConsentPermission(
    model,
    prompt,
    isRetry,
    suggestion = null,
    prevIn = 0,
    prevOut = 0,
  ) {
    let resultText;
    try {
      const client = this.getClient();
      const geminiModel = client.getGenerativeModel({
        model: model || "gemini-2.0",
        generationConfig: { temperature: 0.7 },
      });
      const chat = geminiModel.startChat({
        history: [
          {
            role: "user",
            parts: [
              {
                text: isRetry
                  ? this.ctx.retryConsentPermissionContext + suggestion
                  : this.ctx.consentPermissionContext,
              },
            ],
          },
          { role: "model", parts: [{ text: "How can I help you?" }] },
        ],
      });
      const response = await chat.sendMessage(prompt);
      resultText = response.response.text();
      const totalInput =
        prevIn + (response.response?.usageMetadata?.promptTokenCount || 0);
      const totalOutput =
        prevOut + (response.response?.usageMetadata?.candidatesTokenCount || 0);
      let cleaned = extractJson(resultText || "");

      logger.development.ai.debug(`PermissionConsent Response: ${cleaned}`);

      try {
        cleaned = JSON.parse(cleaned);
      } catch (ex) {
        logger.development.ai.debug("permission consent retry called");
        let retryResponse = await this.handleRetry(
          () =>
            this.getConsentPermission(
              model,
              `${this.ctx.retryConsentContext} ${resultText} user previous query:${prompt}`,
              isRetry,
              suggestion,
              totalInput,
              totalOutput,
            ),
          "retryContextCount",
          1,
          totalInput,
          totalOutput,
        );
        this.retryContextCount = 0;
        return retryResponse;
      }

      return {
        text: cleaned,
        inputToken: totalInput,
        outputToken: totalOutput,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async handleCallTool(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const geminiModel = client.getGenerativeModel({
        model: model || "gemini-2.0",
        generationConfig: { temperature: 0.7 },
      });
      const chat = geminiModel.startChat({
        history: [
          { role: "user", parts: [{ text: this.ctx.callToolContext }] },
          { role: "model", parts: [{ text: "How can I help you?" }] },
        ],
      });
      const response = await chat.sendMessage(prompt);
      resultText = response.response.text();
      const cleaned = extractJson(resultText || "");
      return {
        callTool: JSON.parse(cleaned).callTool,
        inputToken: response.response?.usageMetadata?.promptTokenCount || 0,
        outputToken:
          response.response?.usageMetadata?.candidatesTokenCount || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  handleErrorResponse(error, resultText) {
    logger.ai.error(`Gemini error response: ${JSON.stringify(error)},`);
    const log = logger.ai;
    if (error.status == 400) {
      sendAndLogError(
        log,
        "Authentication failed",
        401,
        this.ctx.authMessage || "Authentication failed.",
      );
    } else if (error.status == 429) {
      sendAndLogError(
        log,
        "Rate limited",
        429,
        this.ctx.rateLimitMessage || "Rate limited.",
      );
    } else if (error.status == 500) {
      sendAndLogError(
        log,
        "Provider internal error",
        500,
        this.ctx.modelInternalError || "Internal error.",
      );
    } else if (error.status == 503) {
      sendAndLogError(
        log,
        "Provider internal error",
        503,
        this.ctx.modelOverloadedError || "Internal error.",
      );
    }

    sendAndLogError(
      log,
      error.statusText || "Internal Server Error",
      error.status || 500,
      error.status ? `${error.message}` : `Error in gemini generation`,
    );
  }
}

module.exports = GeminiSharedProvider;
