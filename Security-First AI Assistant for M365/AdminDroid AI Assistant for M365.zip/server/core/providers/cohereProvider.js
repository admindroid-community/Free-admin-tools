const CoreAIProvider = require("./coreAIProvider.js");
const { CohereClientV2 } = require("cohere-ai");
const {
  extractJson,
  getTextFromList,
  isValidJson,
} = require("../../util/parse.js");
const { sendAndLogError } = require("../../util/errorResponse.js");
const { logger } = require("../../util/logger.js");

class CohereSharedProvider extends CoreAIProvider {
  initClient(apiKey) {
    this.client = new CohereClientV2({ token: apiKey });
  }

  async getResponse(model, prompt, history = [], prevIn = 0, prevOut = 0) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat({
        model: model || "command-xlarge-2023-10-01",
        messages: [
          { role: "user", content: this.ctx.context },
          { role: "assistant", content: "How can I help you?" },
          ...history,
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
      });
      resultText = response.message?.content?.[0]?.text;
      const totalInput = prevIn + (response.usage?.tokens?.inputTokens || 0);
      const totalOutput = prevOut + (response.usage?.tokens?.outputTokens || 0);

      resultText = extractJson(resultText || "");
      logger.development.ai.debug(
        `cohere json, ${JSON.stringify(resultText)} `,
      );
      if (!isValidJson(resultText)) {
        logger.development.ai.debug("not a valid json");
        let retryResponse = await this.handleRetry(() =>
          this.getResponse(
            model,
            `${this.ctx.retryContext} ${resultText} users previous query:${this.currentPrompt}`,
            history,
            totalInput,
            totalOutput,
          ),
        );
        this.retryCount = 0;
        return retryResponse;
      }
      try {
        resultText = getTextFromList(resultText);
      } catch (e) {
        logger.development.ai.debug("mismatch in response format");
        let retryResponse = await this.handleRetry(() =>
          this.getResponse(
            model,
            `${this.ctx.retryContext} ${resultText} users previous query:${this.currentPrompt}`,
            history,
            totalInput,
            totalOutput,
          ),
        );
        this.retryCount = 0;
        return retryResponse;
      }
      return {
        text: resultText,
        inputToken: totalInput,
        outputToken: totalOutput,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getCode(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat({
        model: model || "command-xlarge-2023-10-01",
        messages: [
          { role: "user", content: this.ctx.codeContext },
          { role: "assistant", content: "How can I help you?" },
          { role: "user", content: prompt },
        ],
        temperature: 0.5,
      });
      resultText = response.message?.content?.[0]?.text;
      const cleaned = extractJson(resultText || "");
      return {
        text: JSON.parse(cleaned),
        inputToken: response.usage?.tokens?.inputTokens || 0,
        outputToken: response.usage?.tokens?.outputTokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getPriorityContext(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat({
        model: model || "command-xlarge-2023-10-01",
        messages: [
          { role: "user", content: this.ctx.priorityContext },
          { role: "assistant", content: "How can I help you?" },
          { role: "user", content: JSON.stringify(prompt) },
        ],
        temperature: 0.7,
      });
      resultText = response.message?.content?.[0]?.text;
      const cleaned = extractJson(resultText || "");
      return {
        text: JSON.parse(cleaned),
        inputToken: response.usage?.tokens?.inputTokens || 0,
        outputToken: response.usage?.tokens?.outputTokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async getConsentPermission(
    model,
    prompt,
    isRetry,
    suggestion = null,
    prevIn = 0,
    prevOut = 0,
  ) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat({
        model: model || "command-xlarge-2023-10-01",
        messages: [
          {
            role: "user",
            content: isRetry
              ? this.ctx.retryConsentPermissionContext + suggestion
              : this.ctx.consentPermissionContext,
          },
          { role: "assistant", content: "How can I help you?" },
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
      });
      resultText = response.message?.content?.[0]?.text;
      const totalInput = prevIn + (response.usage?.tokens?.inputTokens || 0);
      const totalOutput = prevOut + (response.usage?.tokens?.outputTokens || 0);
      let cleaned = extractJson(resultText || "");

      logger.development.ai.debug(`PermissionConsent Response: ${cleaned}`);

      try {
        cleaned = JSON.parse(cleaned);
      } catch (ex) {
        logger.development.ai.debug("permission consent retry called");
        let retryResponse = await this.handleRetry(
          () =>
            this.getConsentPermission(
              model,
              `${this.ctx.retryConsentContext} ${resultText} user previous query:${prompt}`,
              isRetry,
              suggestion,
              totalInput,
              totalOutput,
            ),
          "retryContextCount",
          1,
          totalInput,
          totalOutput,
        );
        this.retryContextCount = 0;
        return retryResponse;
      }

      return {
        text: cleaned,
        inputToken: totalInput,
        outputToken: totalOutput,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  async handleCallTool(model, prompt) {
    let resultText;
    try {
      const client = this.getClient();
      const response = await client.chat({
        model: model || "command-a-03-2025",
        messages: [
          { role: "user", content: this.ctx.callToolContext },
          { role: "assistant", content: "How can I help you?" },
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
      });
      resultText = response.message?.content?.[0]?.text;
      const cleaned = extractJson(resultText || "");
      return {
        callTool: JSON.parse(cleaned).callTool,
        inputToken: response.usage?.tokens?.inputTokens || 0,
        outputToken: response.usage?.tokens?.outputTokens || 0,
      };
    } catch (error) {
      this.handleErrorResponse(error, resultText);
    }
  }

  handleErrorResponse(error, resultText) {
    logger.ai.error(`cohere error response: ${JSON.stringify(error)}`);
    const log = logger.ai;
    if (error.statusCode == 401) {
      sendAndLogError(
        log,
        "Authentication failed",
        401,
        this.ctx.authMessage || "Authentication failed.",
      );
    } else if (error.statusCode == 422) {
      sendAndLogError(
        log,
        "Authentication failed",
        401,
        this.ctx.authMessage || "Authentication failed.",
      );
    } else if (error.statusCode == 429) {
      sendAndLogError(
        log,
        "Search Unsuccessful",
        429,
        this.ctx.rateLimitMessage || "Try again",
      );
    } else if (error.statusCode == 500) {
      sendAndLogError(
        log,
        "Provider internal error",
        500,
        this.ctx.modelInternalError || "Internal error.",
      );
    }
    sendAndLogError(
      log,
      (error.body && error.body.message) || "Internal Server Error",
      error.statusCode || 500,
      error.statusCode ? `${error.message}` : `Error in Cohere generation`,
    );
  }
}

module.exports = CohereSharedProvider;
