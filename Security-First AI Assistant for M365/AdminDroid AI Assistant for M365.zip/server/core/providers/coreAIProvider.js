const { logger } = require("../../util/logger.js");

class CoreAIProvider {
  constructor(apiKey = null, contexts = {}, currentPrompt = null) {
    this.ctx = contexts || {};
    this.currentPrompt = currentPrompt;
    this.retryCount = 0;
    this.retryContextCount = 0;

    if (apiKey) {
      this.initClient(apiKey);
    }
  }


  getClient() {
    return this.client;
  }

  async handleRetry(
    fn,
    counterName = "retryCount",
    max = 2,
    inputToken,
    outputToken,
  ) {
    if (this[counterName] < max) {
      this[counterName]++;
      return await fn();
    }

    return {
      statusCode: 500,
      error: "AI Response Generation Error",
      message: "Something went wrong! Please try again later",
      inputToken,
      outputToken,
    };
  }

  initClient(apiKey) {}
}

module.exports = CoreAIProvider;
