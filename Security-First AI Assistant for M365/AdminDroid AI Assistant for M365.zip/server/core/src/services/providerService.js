const CredentialFileService = require("./credentialFileService");
const encryptionService = require("../../../util/encryptService");
const { logger } = require("../../../util/logger");
const fileServices = require("../../../util/fileServices");
const { sendAndLogError } = require("../../../util/errorResponse.js");

class ProviderService extends CredentialFileService {
    constructor() {
        super();
    }


    async getProviders() {
        try {
            var providersData = await fileServices.readFile(this.providersFilePath);
            providersData = JSON.parse(providersData);
            const newModels = {
                "Gemini": [
                    {
                        name: "gemini-3.1-flash-lite-preview",
                        features: ["Adaptive thinking", "cost efficiency"]
                    }
                ],
                "Groq": [{
                    name: "openai/gpt-oss-120b",
                    features: ["Adaptive thinking", "cost efficiency"]
                    }
                ]
            };
            for (const key in newModels) {               
                for (const model of newModels[key]) {
                    providersData = this.addModel(providersData, key, model);
                }
            }
            // const updatedJson = this.addModel(providersData, "Gemini", newModel);
            return providersData;
        } catch (error) {
            logger.apikey.error(`Error fetching providers: ${JSON.stringify(error)}`);
            return {};
        }
    }

    addModel(data, providerName, model) {
        if (!data[providerName]) {
            return data;
        }

        const models = data[providerName].models;

        const exists = models.some(m => m.name === model.name);

        if (!exists) {
            models.unshift(model);
        }

        return data;
    }

    async setApiKeyData(inputData) {
        return this.withCredentialLock(async () => {
            try {
                let data = await this.getStoredCredentialData("ALL");
                let oldApiKeyData = await this.getStoredCredentialData("API_KEY");
                data.API_KEY_USAGE = data.API_KEY_USAGE || {};

                if (!data.API_KEY_USAGE[inputData.provider]) {
                    data.API_KEY_USAGE[inputData.provider] = {
                        "inputTokenCount": 0,
                        "outputTokenCount": 0,
                        "requestCount": 0
                    }
                }

                if ((oldApiKeyData[inputData.provider] || []).length === 0) {
                    oldApiKeyData[inputData.provider] = [{
                        keyName: inputData.keyName,
                        apiKey: encryptionService.encrypt(inputData.apiKey),
                        enabled: true,
                        lastUsed: null
                    }];
                } else {


                    let apiKeyData = oldApiKeyData[inputData.provider];
                    const keynameConflict = apiKeyData.find(item =>
                        item?.keyName?.toLowerCase() === inputData?.keyName?.toLowerCase()
                    );

                    if (keynameConflict) return { message: `Key name '${inputData.keyName}' already exists. Please choose a different name.`, isSuccess: false };

                    const apikeyConflict = apiKeyData.find(item =>
                        encryptionService.decrypt(item.apiKey) === inputData.apiKey
                    );

                    if (apikeyConflict) return { message: `API key already stored under key name: ${apikeyConflict.keyName}`, isSuccess: false };

                    apiKeyData.push({
                        keyName: inputData.keyName,
                        apiKey: encryptionService.encrypt(inputData.apiKey),
                        enabled: false,
                        lastUsed: null
                    });
                    oldApiKeyData[inputData.provider] = apiKeyData;
                }
                data["API_KEY"] = oldApiKeyData;

                const encryptedData = encryptionService.encrypt(JSON.stringify(data));
                await fileServices.writeFile(this.credentialFilePath, encryptedData, true);

                //console.log("Data successfully stored");
                return { message: "Api Key stored successfully", isSuccess: true };
            } catch (error) {
                logger.testing.ai.error(`Error set apikey writing JSON to file: ${JSON.stringify(error)}`);
                sendAndLogError(logger.apikey, "Error updating API key", 500, "Failed to update API key data.");
            }
        });
    }

    async updateApiKeyData(inputData) {
        return this.withCredentialLock(async () => {
            try {
                let data = await this.getStoredCredentialData("ALL");
                let oldApiKeyData = await this.getStoredCredentialData("API_KEY");

                if (!(inputData.provider in oldApiKeyData)) {
                    return { message: "Invalid provider", isSuccess: false };
                }
                let apiKeyData = oldApiKeyData[inputData.provider];
                if (inputData.type === "enable") {
                    let updateIndex, previousIndex;
                    apiKeyData.forEach((item, index) => {
                        if (item.keyName === inputData.keyName) updateIndex = index;
                        if (item.enabled) previousIndex = index;
                        item.enabled = false;
                    });
                    if (updateIndex === -1) {
                        apiKeyData[previousIndex].enabled = true;
                        return { message: "Api Key enable failed! Keyname not found", isSuccess: false };
                    }
                    apiKeyData[updateIndex].enabled = true;
                } else if (inputData.type === "delete") {
                    const deleteIndex = apiKeyData.findIndex(item => item.keyName === inputData.keyName);
                    if (deleteIndex === -1) {
                        return { message: "Api Key deletion failed! Keyname not found", isSuccess: false };
                    }
                    if (apiKeyData[deleteIndex].enabled && apiKeyData.length > 1) {
                        if ((apiKeyData.length - 1) === deleteIndex)
                            apiKeyData[deleteIndex - 1].enabled = true;
                        else
                            apiKeyData[deleteIndex + 1].enabled = true;
                    }
                    apiKeyData.splice(deleteIndex, 1);
                }

                oldApiKeyData[inputData.provider] = apiKeyData;
                data["API_KEY"] = oldApiKeyData;

                const encryptedData = encryptionService.encrypt(JSON.stringify(data));
                await fileServices.writeFile(this.credentialFilePath, encryptedData, true);

                return { message: "Api Key data updated successfully", isSuccess: true };

            } catch (error) {
                logger.apikey.error(`Error updating writing JSON to file: ${JSON.stringify(error)}`);
                sendAndLogError(logger.apikey, "Error updating API key", 500, "Failed to update API key data.");
            }
        });
    }

    async updateApiUsage(provider, inputToken, outputToken) {
        return this.withCredentialLock(async () => {
            try {
                let data = await this.getStoredCredentialData("ALL");

                if (data.API_KEY_USAGE) {
                    if (data.API_KEY_USAGE[provider]) {
                        const usageData = data.API_KEY_USAGE[provider];
                        const newInputTokenCount = (usageData.inputTokenCount || 0) + inputToken;
                        const newOutputTokenCount = (usageData.outputTokenCount || 0) + outputToken;
                        const newRequestCount = (usageData.requestCount || 0) + 1;
                        const updatedData = {
                            "inputTokenCount": newInputTokenCount,
                            "outputTokenCount": newOutputTokenCount,
                            "requestCount": newRequestCount
                        }
                        data.API_KEY_USAGE[provider] = updatedData;
                    }
                }
                if (data.API_KEY) {
                    if (data.API_KEY[provider]) {
                        let oldApiKeyData = data.API_KEY[provider] ?? [];

                        const index = oldApiKeyData.findIndex(item => item.enabled)
                        if (index !== -1) {
                            const utcNow = new Date().toISOString();
                            oldApiKeyData[index].lastUsed = utcNow;
                        }

                        data.API_KEY[provider] = oldApiKeyData;
                    }
                }

                const encryptedData = encryptionService.encrypt(JSON.stringify(data));
                await fileServices.writeFile(this.credentialFilePath, encryptedData, true);

                return { message: "Data successfully stored" };

            } catch (error) {
                logger.apikey.error(`Error updating apikey usage writing JSON to file: ${JSON.stringify(error)}`);
                return sendAndLogError(logger.apikey, "Error updating API usage", 500, "Failed to update API usage data.");

            }
        });
    }

    async getStoredCredentialData(type) {
        try {

            const data = await fileServices.readFile(this.credentialFilePath);

            if (!data.length) {
                await this.ensureFileInitialized();
            }

            const decryptedData = encryptionService.decrypt(data);
            const jsonData = JSON.parse(decryptedData || "{}");

            if (type === "API_KEY") {
                let apiKeyData = jsonData.API_KEY || {};
                return apiKeyData;
            } else if (type === "API_KEY_HIDE") {
                let apiKeyData = jsonData.API_KEY || {};
                Object.entries(apiKeyData).forEach(([key, value]) => {
                    apiKeyData[key] = value.map(item => ({
                        keyName: item?.keyName || "-",
                        // apiKey: item.apiKey ? this.maskApiKey(encryptionService.decrypt(item.apiKey)) : "",
                        enabled: item.enabled || false,
                        lastUsed: this.getLastUsed(item?.lastUsed)
                    }));
                });
                return apiKeyData;
            } else if (type === "ALL") {
                return jsonData;
            } else {
                return jsonData[type] || {};
            }

        } catch (err) {
            logger.apikey.error(`Error getting  stored credential reading or parsing file: ${JSON.stringify(err)}`);
            return {};
        }
    }

    async getApiKey(provider) {
        const response = await this.getStoredCredentialData("API_KEY");
        const activeKey = response[provider]?.find((key) => key.enabled) || null;    
        return activeKey && activeKey.apiKey ? {"apiKey": encryptionService.decrypt(activeKey.apiKey),"keyName":activeKey.keyName } : null;
    }

    async switchApiKey(provider) {
        return this.withCredentialLock(async () => {
            try {
                let data = await this.getStoredCredentialData("ALL");
                let oldApiKeyData = await this.getStoredCredentialData("API_KEY");
                let apiKeyData = oldApiKeyData[provider] || [];

                if (apiKeyData.length <= 1) return false;

                let currentIndex;
                apiKeyData.forEach((item, index) => {
                    if (item.enabled) currentIndex = index;
                    item.enabled = false;
                });
                const newIndex = (currentIndex === (apiKeyData.length - 1)) ? 0 : currentIndex + 1;
                apiKeyData[newIndex].enabled = true;

                oldApiKeyData[provider] = apiKeyData;
                data["API_KEY"] = oldApiKeyData;

                const encryptedData = encryptionService.encrypt(JSON.stringify(data));
                await fileServices.writeFile(this.credentialFilePath, encryptedData, true);

                return true;

            } catch (error) {
                logger.apikey.error(`Error updating writing JSON to file: ${JSON.stringify(error)}`);
                sendAndLogError(logger.apikey, "Error updating API key", 500, "Failed to update API key data.");
            }
        });
    }

    maskApiKey(apiKey) {
        if (apiKey.length <= 8) {
            return apiKey;
        }
        const lastPart = apiKey.slice(-4);
        return `***************${lastPart}`;
    }

    plural(value, word) {
        return `${value} ${value === 1 ? word : word + "s"}`;
    }

    getLastUsed(utcTimeString) {
        if (!utcTimeString) return "Never used";

        const past = new Date(utcTimeString);

        if (isNaN(past.getTime())) return "Never used";

        const now = new Date();
        const diffMs = now - past;

        if (diffMs < 0) return "Future time";

        const seconds = Math.floor(diffMs / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (seconds < 60) return this.plural(seconds, "second") + " ago";
        if (minutes < 60) return this.plural(minutes, "minute") + " ago";
        if (hours < 24) return this.plural(hours, "hour") + " ago";
        return this.plural(days, "day") + " ago";
    }

}

module.exports = new ProviderService();
