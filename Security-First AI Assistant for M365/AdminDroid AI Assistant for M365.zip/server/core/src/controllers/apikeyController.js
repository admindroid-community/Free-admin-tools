const providerService = require("../services/providerService.js");
const usageService = require("../services/usageService.js");
const { sendAndLogError } = require("../../../util/errorResponse.js");
const { logger } = require("../../../util/logger.js");
const encryptService = require("../../../util/encryptService.js");
const crypto = require("crypto");
class ApiKeyController {
  async getApiKey(req, res, next) {
    try {
      const response =
        await providerService.getStoredCredentialData("API_KEY_HIDE");
      const usageData =
        await providerService.getStoredCredentialData("API_KEY_USAGE");
      let providers = await providerService.getProviders();
      providers = Object.values(providers);
      providers = providers.map((provider) => ({
        ...provider,
        apiKeys: response[provider.name] || [],
        usage: usageData[provider.name] || {},
      }));

      res.status(200).json(providers);
    } catch (error) {
      next(error);
    }
  }

  async setApiKey(req, res, next) {
    try {
      const keyNameMaxSize = 36;

      let { provider, apiKey, keyName } = req.body;

      if (!apiKey) {
        sendAndLogError(
          logger.apikey,
          "Missing apiKey in request body",
          400,
          "API key is required for Validation.",
        );
      }

      if (!keyName) {
        sendAndLogError(
          logger.apikey,
          "Missing keyName in request body",
          400,
          "Key name is required for Validation.",
        );
      }

      if (keyName.length > keyNameMaxSize) {
        return res.json({
          message: `Key name is too long. Please use ${keyNameMaxSize} characters or fewer.`,
          isSuccess: false,
        });
      }

      apiKey = encryptService.keyBasedDecrypt(apiKey, req.session.encKey);

      if (keyName.length > 5 && apiKey.includes(keyName)) {
        return res.json({ message: `Invalid Key name.`, isSuccess: false });
      }

      let response = await usageService.validateKey(provider, apiKey);

      if (response.isSuccess) {
        const data = { provider, apiKey, keyName };
        response = await providerService.setApiKeyData(data);
      }

      return res.json(response);
    } catch (error) {
      next(error);
    }
  }

  async enableKey(req, res, next) {
    try {
      const { provider, keyName } = req.body;
      if (!keyName) {
        sendAndLogError(
          logger.apikey,
          "Missing keyname in request body",
          400,
          "Keyname is required.",
        );
      }

      const data = { provider, keyName, type: "enable" };
      const response = await providerService.updateApiKeyData(data);

      return res.json(response);
    } catch (error) {
      next(error);
    }
  }

  async deleteKey(req, res, next) {
    try {
      const { provider, keyName } = req.body;
      if (!keyName) {
        sendAndLogError(
          logger.apikey,
          "Missing keyname in request body",
          400,
          "Keyname is required.",
        );
      }

      const data = { provider, keyName, type: "delete" };
      const response = await providerService.updateApiKeyData(data);

      return res.json(response);
    } catch (error) {
      next(error);
    }
  }

  async getSessionKey(req, res, next) {
    try {
      if (!req.session) {
        return sendAndLogError(
          logger.session,
          "No active session",
          401,
          "User session not found.",
        );
      }

      if (!req.session.encKey) {
        req.session.encKey = crypto.randomBytes(32).toString("hex");
      }

      res.json({
        key: req.session.encKey,
      });

      return;
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new ApiKeyController();
