const { z } = require("zod");

const setApiKeySchema = z.object({
  provider: z.string().min(1, 'provider must be at least more than 1 characters'),
  apiKey: z.string().min(1, 'Apikey must be at least more than 1 characters'),
  keyName: z.string().min(1, 'keyNname must be at least more than 1 characters'),
});

const enableKeySchema = z.object({
  provider: z.string().min(1),
  keyName: z.string().min(1),
});

const deleteKeySchema = enableKeySchema;

const ldapOperationSchema = z.discriminatedUnion("operation", [

  z.object({
    operation: z.literal("search"),
    dn: z.string().min(1),
    params: z.object({
      scope: z.enum(["base", "one", "sub"]),
      filter: z.string().min(1),
      attributes: z.array(z.string()).min(1)
    }),
    sortKeys: z.array(
      z.object({
        attribute: z.string().min(1),
        type: z.number().int()
      })
    ).optional(),
    size: z.number().int().min(-1).optional()
  }),

  z.object({
    operation: z.literal("modify"),
    dn: z.string().min(1),
    changes: z.array(
      z.object({
        operation: z.enum(["add", "delete", "replace"]),
        modification: z.object({
          type: z.string().min(1),
          vals: z.array(z.string())
        })
      })
    ).min(1)
  }),

  z.object({
    operation: z.literal("move"),
    olddn: z.string().min(1),
    newdn: z.string().min(1)
  }),

  z.object({
    operation: z.literal("add"),
    dn: z.string().min(1),
    params: z.object({
      objectClass: z.array(z.string()).min(1)
    }).passthrough()
  }),

  z.object({
    operation: z.literal("delete"),
    dn: z.string().min(1)
  })

]);

module.exports = { setApiKeySchema, enableKeySchema, deleteKeySchema, ldapOperationSchema };

