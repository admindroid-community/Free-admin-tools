require("../../../config/polyfills.js");

const express = require("express");
const path = require("path");

const sessionController = require("./controllers/sessionController.js");
const aiController = require("./controllers/aiController.js");

const profileController = require("./controllers/profileController.js");

const graphController = require("./controllers/graphController.js");
const { logger } = require("../../../util/logger.js");
const router = express.Router();
logger.production.core.info(`m36Router`)
// ai routes
router.post("/ai/json/:username", aiController.getResponse.bind(aiController));
router.post("/ai/code", aiController.generateCode.bind(aiController));
router.post("/ai/keys", aiController.priorityContext.bind(aiController));
router.post("/ai/consentPermission", aiController.getConsentPermission.bind(aiController));
router.post("/ai/CallTool", aiController.handleCallTool.bind(aiController));

//session routes
router.post("/user", sessionController.storeSession);
router.get("/user", sessionController.getSession);
router.patch("/user/:username", sessionController.updateSession);
router.delete("/user/:username", sessionController.deleteSession);
router.get("/user/:username/photo", sessionController.userPhoto);

// graph routes
router.post("/graph/:username", graphController.executeGraphRequest);


router.get("/profiles", profileController.profiles);
router.delete("/profiles/:upn", profileController.deleteUserProfile);

router.use(express.static(path.join(__dirname)));


module.exports = router;
