const aiService = require("../services/aiService.js");
const { regexMasking } = require("../../../../util/mask.js");
const {
  getText,
  getTextCode,
  validateSuggestedQuery,
  replacePlaceHolder,
  fixBodyTypes,
} = require("../../../../util/parse.js");
const { unMaskMacro } = require("../../../../util/unmask.js");
const ProviderService = require("../../../../core/src/services/providerService.js");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const { logger } = require("../../../../util/logger.js");
const permissions = require("../utils/permissions.js");
const graphService = require("../services/graphService.js");
const { validateIdLookups } = require("../utils/validationSchema.js");

class AiController {
  async generateCode(req, res, next) {
    try {
      const { prompt, provider, model, allKeys } = req.body;

      let response = await aiService.generateCode(
        provider,
        model,
        prompt,
        allKeys,
      );

      response = getTextCode(response);

      await ProviderService.updateApiUsage(
        provider,
        response.inputToken,
        response.outputToken,
      );

      let code;
      logger.development.ai.info(
        `response: ${JSON.stringify(response)},code:${JSON.stringify(response.text.code)}`,
      );

      if (response.text.type === "table") {
        const headers = response.text.code.headers;
        const tableDataFnCode = response.text.code.tableDataFn;

        code = `function renderData(data) {
      const container = document.getElementById('responsive-chart-table');
      container.innerHTML = '';

      const tableDataFn = new Function("rawData", \`${tableDataFnCode}\`);
      const sortedData = tableDataFn(data);

       if (!sortedData || sortedData.length === 0) {
        const msg = document.createElement('div');
        msg.className = "not-found-msg";   
        msg.textContent = "No record found!";

        container.appendChild(msg);
        return;
      }

      const tableDiv = document.createElement('div');
      tableDiv.className = 'graphical-table';

      const table = document.createElement('table');
      const thead = document.createElement('thead');
      const tbody = document.createElement('tbody');

      const headers = ${JSON.stringify(headers)};

      const dateHeaders = [
  'createdDateTime',
  'lastModifiedDateTime',
  'lastPasswordChangeDateTime',
  'startDateTime',
  'expirationDateTime',
  'activityDateTime',
  'deletedDateTime',
  'receivedDateTime',
  'sentDateTime',
  'start',
  'end',
  'dueDateTime',
  'completedDateTime'
];

      const headerRow = document.createElement('tr');
      headers.forEach(headerText => {
        const th = document.createElement('th');
        th.textContent = headerText;
        headerRow.appendChild(th);
      });
      thead.appendChild(headerRow);

    function createExpandableCell(value) {
    const td = document.createElement('td');

    const wrapper = document.createElement('div');
    wrapper.style.maxHeight = '120px';
    wrapper.style.overflow = 'auto';

    const closeLabel = document.createElement('div');
    closeLabel.textContent = '▼ Close';
    closeLabel.style.cursor = 'pointer';
    closeLabel.style.marginBottom = '5px';
    closeLabel.style.fontSize = '12px';

    const pre = document.createElement('pre');
    pre.textContent = JSON.stringify(value, null, 2);
    pre.style.whiteSpace = 'pre-wrap';
    pre.style.wordBreak = 'break-word';
    pre.style.margin = 0;

    wrapper.appendChild(closeLabel);
    wrapper.appendChild(pre);

    const preview = document.createElement('div');
    preview.textContent = JSON.stringify(value).slice(0, 60) + '...';
    preview.style.cursor = 'pointer';
    preview.style.fontSize = '12px';

    preview.onclick = () => td.replaceChild(wrapper, preview);
    closeLabel.onclick = () => td.replaceChild(preview, wrapper);

    td.appendChild(preview);
    return td;
  }

  sortedData.forEach(item => {
    const row = document.createElement('tr');

    headers.forEach(header => {
      const td = document.createElement('td');
      const rawValue = item?.[header];

      if (dateHeaders.includes(header)) {
        if (!rawValue) {
          td.textContent = '-';
        } else {
          const date = new Date(rawValue);
          td.textContent = isNaN(date) ? rawValue : date.toLocaleString();
        }
      }

      else if (Array.isArray(rawValue)) {
        if (rawValue.length === 0) {
          td.textContent = '-';
        } else if (rawValue.some(v => typeof v === 'object' && v !== null)) {
          const expandable = createExpandableCell(rawValue);
          row.appendChild(expandable);
          return;
        } else {
          td.textContent = rawValue.join(', ');
        }
      }

      else if (typeof rawValue === 'object' && rawValue !== null) {
        const expandable = createExpandableCell(rawValue);
        row.appendChild(expandable);
        return;
      }

      else {
        const dataValue =
          rawValue === null || rawValue === undefined || rawValue === ''
            ? '-'
            : rawValue.toString();

        td.textContent = dataValue;
      }

      row.appendChild(td);
    });

    tbody.appendChild(row);
  });

      table.appendChild(thead);
      table.appendChild(tbody);
      tableDiv.appendChild(table);
      container.appendChild(tableDiv);
    }`;
      } else {
        const chartsData = response.text.code.chartsData ?? [];
        const summaryText = response.text.code.summaryText ?? [];

        // const displayNextChart = chartsData.length > 1 ? "inline" : "none";
        const displayNextChart = "none";

        code = `function renderData(data) {
  const chartsData = ${JSON.stringify(chartsData)};
  const summaryText = ${JSON.stringify(summaryText)};
  const container = document.getElementById("responsive-chart-table");
  container.innerHTML = "";

  const chartsWrapper = document.createElement("div");
  chartsWrapper.style.display = "flex";
  chartsWrapper.style.overflowX = "hidden";
  chartsWrapper.style.scrollBehavior = "smooth";
  chartsWrapper.style.width = "100%";
  chartsWrapper.style.flexDirection = "column-reverse";

  const summary = document.createElement("p");
  summary.textContent = summaryText || "";
  summary.style.fontSize = "12px";
  summary.style.borderBottom = "1px solid black";
  summary.style.width = "fit-content";
  summary.style.margin = "auto";
  summary.style.textAlign = "center";
  //chartsWrapper.appendChild(summary);
  container.appendChild(chartsWrapper);

  const canvases = [];
  const colorPalette = [
    "#f72585", "#b5179e", "#7209b7", "#560bad", "#480ca8",
    "#3a0ca3", "#3f37c9", "#4361ee", "#4895ef", "#4cc9f0"
  ];

  chartsData.forEach((item, index) => {
    const chartWrapper = document.createElement("div");
    chartWrapper.style.position = "relative";
    chartWrapper.style.minWidth = "100%";
    chartWrapper.style.flexShrink = 0;
    chartWrapper.style.padding = "10px";
    chartWrapper.style.borderRadius = "8px";

    const serial = document.createElement("div");
    serial.textContent = index + 1;
    serial.style.position = "absolute";
    serial.style.top = "5px";
    serial.style.left = "10px";
    serial.style.backgroundColor = "#ffecb3";
    serial.style.color = "#000";
    serial.style.fontWeight = "bold";
    serial.style.padding = "2px 6px";
    serial.style.borderRadius = "4px";

    if("${displayNextChart}" !== "none"){
      chartWrapper.appendChild(serial);
    }

    const canvas = document.createElement("canvas");
    chartWrapper.appendChild(canvas);
    canvases.push(canvas);

    chartsWrapper.appendChild(chartWrapper);

    const ctx = canvas.getContext("2d");
  const counts = {};

data.forEach(u => {
  let value = u?.[item.field];
  const fieldName = item.field;

  if (value === null || value === undefined || value === "") {
    value = \`Without \${fieldName}\`;
  }

  else if (typeof value === "object") {
    const hasData =
      value &&
      ((Array.isArray(value) && value.length > 0) ||
       (!Array.isArray(value) && Object.keys(value).length > 0));

    value = hasData ? \`With \${fieldName}\` : \`Without \${fieldName}\`;
  }

  else if (typeof value === "boolean") {
    value = value ? \`With \${fieldName}\` : \`Without \${fieldName}\`;
  }

  else if (typeof value === "string") {
    value = value.trim();
    if (!value) {
      value = \`Without \${fieldName}\`;
    }
  }

  else {
    value = value.toString();
  }

  counts[value] = (counts[value] || 0) + 1;
});


    const labels = Object.keys(counts);
    const values = Object.values(counts);
    const chartType = item.type || "bar";

    const dataset = {
      label: item.label,
      data: values
    };

    if (chartType === "bar" || chartType === "doughnut" || chartType === "pie") {
      dataset.backgroundColor = colorPalette;
      dataset.borderColor = "rgba(255,255,255,0.3)";
      dataset.borderWidth = 1;
    }
    if (chartType === "line") {
      dataset.fill = false;
      dataset.borderColor = colorPalette[0];
      dataset.tension = 0.3;
    }

    new Chart(ctx, {
      type: chartType,
      data: {
        labels: labels,
        datasets: [dataset]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true },
          title: {
            display: true,
            text: item.label,
            color: "black",
            font: { size: 16, weight: "bold" },
            padding: { top: 10, bottom: 10 }
          }
        }
      }
    });
  });

  const prevBtn = document.createElement("button");
  prevBtn.textContent = "Previous";
  prevBtn.style.marginRight = "10px";
  prevBtn.style.padding = "6px 12px";
  prevBtn.style.border = "none";
  prevBtn.style.borderRadius = "4px";
  prevBtn.style.backgroundColor = "#3a0ca3";
  prevBtn.style.color = "#fff";
  prevBtn.style.cursor = "pointer";

  const nextBtn = document.createElement("button");
  nextBtn.textContent = "Next";
  nextBtn.style.padding = "6px 12px";
  nextBtn.style.border = "none";
  nextBtn.style.borderRadius = "4px";
  nextBtn.style.backgroundColor = "#4361ee";
  nextBtn.style.color = "#fff";
  nextBtn.style.cursor = "pointer"; 

  if("${displayNextChart}" !== "none"){
    container.appendChild(prevBtn);
    container.appendChild(nextBtn);
  }

  let current = 0;

  function showChart(i) {
    const offset = i * chartsWrapper.clientWidth;
    chartsWrapper.scrollLeft = offset;
  }

  prevBtn.onclick = () => {
    current = (current - 1 + canvases.length) % canvases.length;
    showChart(current);
  };

  nextBtn.onclick = () => {
    current = (current + 1) % canvases.length;
    showChart(current);
  };
}
`;
      }
      return res.json({
        code: code,
        type: response.text.type,
        tokenCount: response.inputToken + response.outputToken,
      });
    } catch (error) {
      logger.ai.error(`generate code error, ${JSON.stringify(error)}`);
      return next(error);
      // await this.handleError(error, this.generateCode, req, res, next);
    }
  }

  async getResponse(req, res, next) {
    try {
      const {
        prompt,
        type,
        provider,
        model,
        isMasked,
        history,
        historyMaskValues,
        isSmarterRetry,
      } = req.body;

      let maskedQuery,
        text,
        unmaskedText,
        maskingHistory,
        maskingSuggestion,
        idLookupResult;
      if (isMasked && !isSmarterRetry) {
        const maskedResult = regexMasking(prompt, historyMaskValues, type);
        maskingHistory = maskedResult.history;
        maskedQuery = maskedResult.current;
      } else {
        maskingHistory = historyMaskValues;
        maskedQuery = { template: prompt, values: {} };
      }

      logger.ai.info(`query send to ai ${JSON.stringify(maskedQuery)}`);

      text = await aiService.getResponse(
        provider,
        model,
        maskedQuery.template,
        history,
      );
      text.text = validateSuggestedQuery(maskedQuery.template, text.text);

      await ProviderService.updateApiUsage(
        provider,
        text.inputToken,
        text.outputToken,
      );

      if (text.error) {
        sendAndLogError(
          logger.ai,
          "Search Unsuccessful",
          422,
          "Request understood but could not retrieve meaningful data",
        );
      } else {
        unmaskedText = await unMaskMacro(
          JSON.stringify(text),
          maskingHistory.values,
        );
        unmaskedText = JSON.parse(unmaskedText);

        if (unmaskedText?.text?.json?.body) {
          unmaskedText.text.json.body = fixBodyTypes(
            unmaskedText.text.json.body,
          );
        }

        logger.development.ai.debug(
          `unmasked text ${JSON.stringify(unmaskedText)}`,
        );
        console.log("isidlookup", text?.text?.json?.idLookUp);
        if (text?.text?.json?.idLookUp) {
          idLookupResult = await this.handleIdlookUp(
            req,
            res,
            unmaskedText.text.json.idLookUp,
            unmaskedText.text.json,
          );
          if (idLookupResult?.updatedPayload) {
            unmaskedText.text.json = idLookupResult.updatedPayload;
          }
        }

        if (!isSmarterRetry && getText(text).suggestedQuery) {
          const suggestionMaskResult = regexMasking(
            getText(text).suggestedQuery,
            {},
            type,
          );
          const suggestedMaskedQueryValues =
            suggestionMaskResult.current.values;
          const suggestedNewMaskedQueryValues = Object.fromEntries(
            Object.entries(suggestedMaskedQueryValues).filter(([k, v]) => {
              return !(
                typeof v === "string" &&
                v.includes("{{{") &&
                v.includes("}}}")
              );
            }),
          );

          maskingSuggestion = {
            text: unmaskedText.text.suggestedQuery,
            values: suggestedNewMaskedQueryValues,
          };
        }
        logger.development.ai.debug(
          `text,unmaskedText: ${JSON.stringify(text)} ${JSON.stringify(
            unmaskedText,
          )}`,
        );
        res.json({
          text: getText(text),
          unmaskedText: getText(unmaskedText),
          maskedQuery,
          tokenCount: text.inputToken + text.outputToken,
          maskingHistory: maskingHistory || {},
          maskingSuggestion: maskingSuggestion || {},
          disambiguation: idLookupResult?.disambiguationList || [],
        });
      }
    } catch (error) {
      logger.ai.error(`generate json error, ${JSON.stringify(error)}`);
      return next(error);
      // await this.handleError(error, this.getResponse, req, res, next);
    }
  }

  async priorityContext(req, res, next) {
    try {
      const { provider, model, headers, query } = req.body;

      const response = await aiService.priorityContext(
        provider,
        model,
        headers,
        query,
      );

      await ProviderService.updateApiUsage(
        provider,
        response.inputToken,
        response.outputToken,
      );

      // console.log("priorityContext response", JSON.stringify(response));
      return res.json({
        priorityKeys: response.text,
        tokenCount: response.inputToken + response.outputToken,
      });
    } catch (error) {
      logger.ai.error(`Priority context error, ${JSON.stringify(error)}`);
      return next(error);
      // await this.handleError(error, this.getConsentPermission, req, res, next);
    }
  }

  async getConsentPermission(req, res, next) {
    try {
      let { provider, model, prompt } = req.body;

      let response = await aiService.getConsentPermission(
        provider,
        model,
        prompt,
        false,
        null,
      );
      logger.development.ai.debug(
        `consent response,${JSON.stringify(response)}`,
      );
      await ProviderService.updateApiUsage(
        provider,
        response.inputToken,
        response.outputToken,
      );

      if (response.error) {
        sendAndLogError(
          logger.ai,
          "AI Response Generation Error",
          400,
          "Something went wrong! Please try again later",
        );
      }

      // response={"text":{"text":["IdentityRiskySignIn.Read.All"],"isCallConsent":true},"inputToken":465,"outputToken":37}

      let isValidScope = (scopes) =>
        scopes.every((scope) => permissions.includes(scope));

      if (!isValidScope(response.text.text)) {
        let matchingPermissions = [];
        for (const scope of response.text.text) {
          if (!permissions.includes(scope)) {
            const prefix = scope.substring(0, 7);
            const matching = permissions.filter((perm) =>
              perm.startsWith(prefix),
            );
            matchingPermissions.push(...matching);
          }
        }

        let suggestion = `the scope that AI provided: invalid_client: AADSTS650053: The application asked for scope ${JSON.stringify(
          response.text.text,
        )} that doesn't exist on the resource`;

        if (matchingPermissions.length > 0) {
          suggestion += `\n\nMay be try with this following permission: ${JSON.stringify(
            matchingPermissions,
          )}`;
        }

        response = await aiService.getConsentPermission(
          provider,
          model,
          prompt,
          true,
          suggestion,
        );
        if (!isValidScope(response.text.text)) {
          return res.json({
            consent: [],
            isConsentCall: false,
            tokenCount: response.inputToken + response.outputToken,
          });
        }
      }

      let isConsentCall = response.text.isCallConsent;
      let AiConsents = response.text.text;

      let userScope = JSON.parse(prompt).scope;
      let isHavingScopeAlready = AiConsents.every((scope) =>
        userScope.includes(scope),
      );
      if (isHavingScopeAlready) {
        isConsentCall = false;
      }
      if (!AiConsents) {
        isConsentCall = false;
      }

      return res.json({
        consent: AiConsents,
        isConsentCall: isConsentCall,
        tokenCount: response.inputToken + response.outputToken,
      });
    } catch (error) {
      logger.ai.error(`consent permission error, ${JSON.stringify(error)}`);
      return next(error);
      // await this.handleError(error, this.getConsentPermission, req, res, next);
    }
  }
  async handleCallTool(req, res, next) {
    try {
      const { provider, model, prompt, summary } = req.body;
      // console.log("API Key for handle call tool:", apiKey);

      const response = await aiService.handleCallTool(
        provider,
        model,
        prompt,
        summary,
      );
      await ProviderService.updateApiUsage(
        provider,
        response.inputToken,
        response.outputToken,
      );

      return res.json({
        callTool: response.callTool,
        tokenCount: response.inputToken + response.outputToken,
      });
    } catch (error) {
      logger.ai.error(`handle calltool error, ${JSON.stringify(error)}`);
      return next(error);
      // await this.handleError(error, this.handleCallTool, req, res, next);
    }
  }

  async handleError(error, fn, req, res, next) {
    if (error.statusCode === 429) {
      const { provider } = req.body;
      const keySwitchResult = await ProviderService.switchApiKey(provider);
      if (keySwitchResult) {
        logger.apikey.info(provider + " api key switched");
        return fn(req, res, next);
      } else {
        return next(error);
      }
    } else {
      return next(error);
    }
  }

  async handleIdlookUp(req, res, idLookUp, jsonPayload) {
    let { username } = req.params;
    if (!req.session.m365user || !req.session.m365user[username]) {
      return sendAndLogError(
        logger.session,
        "No active session",
        401,
        "User session not found.",
      );
    }

    const accessToken = req.session.m365user[username].accessToken;

    if (!accessToken) {
      return sendAndLogError(
        logger.graph,
        "Authentication Required",
        401,
        "Session expired. Please log in again.",
      );
    }

    // Validate AI-generated lookups before executing
    const lookupValidation = validateIdLookups(idLookUp);
    if (!lookupValidation.valid) {
      logger.ai.warn(`Invalid ID lookup rejected: ${lookupValidation.error}`);
      return sendAndLogError(
        logger.graph,
        "Invalid ID lookup",
        400,
        lookupValidation.error,
      );
    }

    let updatedPayload = JSON.parse(JSON.stringify(jsonPayload)); // deep clone
    let disambiguationList = [];

    for (const lookUp of idLookUp) {
      try {
        const { path, queryParams, replaceWord } = lookUp;

        const result = await graphService.executeGraphRequest(
          path,
          "GET",
          queryParams,
          {},
          accessToken,
        );

        if (!result?.isSuccess) continue;

        const data = result?.text?.data || [];

        if (!data.length) {
          return sendAndLogError(
            logger.graph,
            "Object Not Found",
            404,
            "No record found for the provided name",
          );
        }

        if (data.length >= 1) {
          const resolvedId = data[0].id;
          updatedPayload = replacePlaceHolder(
            updatedPayload,
            replaceWord,
            resolvedId,
          );
        } else {
          const options = data.map((item) => {
            let displayItem = "";

            if (item.userPrincipalName) {
              displayItem = `${item.displayName} (${item.userPrincipalName})`;
            } else if (item.mailNickname) {
              displayItem = `${item.displayName} (${item.mailNickname})`;
            } else {
              displayItem = item.displayName;
            }

            return {
              id: item.id,
              displayItem,
            };
          });

          disambiguationList.push({
            replaceWord,
            options,
          });
        }
      } catch (e) {
        logger.graph.error(`Lookup failed: ${JSON.stringify(e)}`);

        return sendAndLogError(
          logger.graph,
          "object not found",
          e.statusCode || 500,
          e.details || "Failed to resolve identifier. Please try again later.",
        );
      }
    }

    delete updatedPayload?.idLookUp;

    return {
      updatedPayload,
      disambiguationList,
    };
  }
}

module.exports = new AiController();
