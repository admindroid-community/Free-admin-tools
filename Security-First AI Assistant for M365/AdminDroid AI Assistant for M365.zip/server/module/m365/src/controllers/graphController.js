const graphService = require("../services/graphService");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const { logger } = require("../../../../util/logger.js");
const { paginationId } = require("../services/graphPaginationManager.js");
const {
  validateGraphPath,
  validateHttpMethod,
  sanitizeQueryParams,
} = require("../utils/validationSchema.js");

class GraphController {
  async executeGraphRequest(req, res, next) {
    try {
      const { path, method, queryParams, body} = req.body;
      const { username } = req.params;
      const pageSize = Number(req.query.pageSize ?? 20);
      const paginationId = Number(req.query.paginationId ?? 0)


      if (!req.session.m365user || !req.session.m365user[username]) {
        return sendAndLogError(
          logger.session,
          "No active session",
          401,
          "User session not found.",
        );
      }
      const accessToken = req.session.m365user[username].accessToken;
      if (!accessToken) {
        return sendAndLogError(
          logger.graph,
          "Authentication Required",
          401,
          "Your session has expired or no access token was found. Please log in again or refresh the page.",
        );
      }

      if (!path || !method) {
        return sendAndLogError(
          logger.graph,
          "Missing required parameters: path and method",
          400,
          "Path and method are required.",
        );
      }

      // Validate Graph API path
      const pathValidation = validateGraphPath(path);
      if (!pathValidation.valid) {
        return sendAndLogError(
          logger.graph,
          "Invalid Graph API path",
          400,
          pathValidation.error,
        );
      }

      // Validate HTTP method
      const methodValidation = validateHttpMethod(method);
      if (!methodValidation.valid) {
        return sendAndLogError(
          logger.graph,
          "Invalid HTTP method",
          400,
          methodValidation.error,
        );
      }

      // Sanitize query parameters
      const qpValidation = sanitizeQueryParams(queryParams);
      if (!qpValidation.valid) {
        return sendAndLogError(
          logger.graph,
          "Invalid query parameters",
          400,
          qpValidation.error,
        );
      }

      const response = await graphService.executeGraphRequest(
        path,
        method.toLowerCase(),
        qpValidation.sanitized,
        body || {},
        accessToken,
        pageSize,
        paginationId,
      );

      res.json(response);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new GraphController();
