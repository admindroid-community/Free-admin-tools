const ProfileService = require("../services/profileService.js");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const { logger } = require("../../../../util/logger.js");

class ProfileController {
  async profiles(req, res, next) {
    try {
      // console.log("Fetching stored profiles...");
      let response = await ProfileService.getStoredProfileData();
      response = response.MS || {};
      res.status(200).json(Object.values(response));
    } catch (error) {
      next(error);
    }
  }
  async deleteUserProfile(req, res, next) {
    try {
      const upn = req.params.upn;
      if (!upn) {
        return sendAndLogError(logger.session, "Missing UPN", 400, "User UPN is required.");
      }

      const response = await ProfileService.deleteUserProfile(upn);
      res.status(200).json({
        message: "User profile deleted successfully",
        isSuccess: true,
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new ProfileController();
