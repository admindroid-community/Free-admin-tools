const { z } = require("zod");
const storeSessionSchema = z.object({
  id: z.string().min(1, "id must be at least 1 character long"),
  name: z.string().min(1, "name must be at least 1 character long"),
  username: z.string().min(1, "username must be at least 1 character long"),
  tenantId: z.string().min(1, "tenantId must be at least 1 character long"),
  domainName: z.string().min(1, "domainName must be at least 1 character long"),
  expiresOn: z.number().int().positive(),
  scopes: z.array(z.string()).optional(),
  storeVisit: z.boolean().optional(),
});

const ALLOWED_METHODS = ["get", "post", "put", "patch", "delete"];
const MAX_ID_LOOKUPS = 5;

/**
 * Validates that a Graph API path is safe and well-formed.
 * Since all Graph endpoints are supported, this validates format rather than allowlisting.
 */
function validateGraphPath(path) {
  if (!path || typeof path !== "string") {
    return { valid: false, error: "Path is required and must be a string." };
  }

  // Must start with /
  if (!path.startsWith("/")) {
    return { valid: false, error: "Path must start with '/'." };
  }

  // Block path traversal sequences
  if (/\.\.[\\/]/.test(path) || path.includes("..")) {
    return { valid: false, error: "Path must not contain directory traversal sequences." };
  }

  // Block encoded traversal attempts (%2e = '.', %2f = '/')
  if (/%2e/i.test(path) || /%5c/i.test(path)) {
    return { valid: false, error: "Path must not contain encoded traversal characters." };
  }

  // Block null bytes
  if (path.includes("\0") || /%00/.test(path)) {
    return { valid: false, error: "Path must not contain null bytes." };
  }

  // Limit path length to prevent abuse
  if (path.length > 2048) {
    return { valid: false, error: "Path exceeds maximum allowed length." };
  }

  return { valid: true };
}

/**
 * Validates that the HTTP method is one of the allowed Graph API methods.
 */
function validateHttpMethod(method) {
  if (!method || typeof method !== "string") {
    return { valid: false, error: "Method is required and must be a string." };
  }
  if (!ALLOWED_METHODS.includes(method.toLowerCase())) {
    return { valid: false, error: `Invalid HTTP method '${method}'. Allowed: ${ALLOWED_METHODS.join(", ")}.` };
  }
  return { valid: true };
}

/**
 * Sanitizes OData query parameters to prevent injection.
 * Blocks dangerous operators while allowing standard OData params.
 */
function sanitizeQueryParams(queryParams) {
  if (!queryParams || typeof queryParams !== "object") {
    return { valid: true, sanitized: {} };
  }

  const ALLOWED_ODATA_PARAMS = [
    "$top", "$skip", "$filter", "$select", "$orderby",
    "$expand", "$count", "$search", "$format", "$skiptoken",
  ];

  const sanitized = {};

  for (const [key, value] of Object.entries(queryParams)) {
    // Only allow known OData params and custom headers prefixed with known patterns
    const lowerKey = key.toLowerCase();
    if (!ALLOWED_ODATA_PARAMS.includes(lowerKey) && !lowerKey.startsWith("$")) {
      sanitized[key] = value;
      continue;
    }

    if (typeof value !== "string" && typeof value !== "number" && typeof value !== "boolean") {
      return { valid: false, error: `Query parameter '${key}' has an invalid value type.` };
    }

    const strValue = String(value);

    // Block script injection in query values
    if (/<script/i.test(strValue) || /javascript:/i.test(strValue)) {
      return { valid: false, error: `Query parameter '${key}' contains disallowed content.` };
    }

    // Limit individual param value length
    if (strValue.length > 2048) {
      return { valid: false, error: `Query parameter '${key}' exceeds maximum allowed length.` };
    }

    sanitized[key] = value;
  }

  return { valid: true, sanitized };
}

/**
 * Validates an array of AI-generated ID lookups.
 * Ensures each lookup has valid structure and caps total count.
 */
function validateIdLookups(idLookUp) {
  if (!Array.isArray(idLookUp)) {
    return { valid: false, error: "idLookUp must be an array." };
  }

  if (idLookUp.length > MAX_ID_LOOKUPS) {
    return { valid: false, error: `Too many ID lookups. Maximum allowed: ${MAX_ID_LOOKUPS}.` };
  }

  for (let i = 0; i < idLookUp.length; i++) {
    const lookup = idLookUp[i];

    if (!lookup || typeof lookup !== "object") {
      return { valid: false, error: `Lookup at index ${i} is invalid.` };
    }

    // Validate path
    const pathResult = validateGraphPath(lookup.path);
    if (!pathResult.valid) {
      return { valid: false, error: `Lookup[${i}] path: ${pathResult.error}` };
    }

    // Validate replaceWord exists
    if (!lookup.replaceWord || typeof lookup.replaceWord !== "string") {
      return { valid: false, error: `Lookup[${i}] must have a valid replaceWord.` };
    }

    // Validate queryParams if present
    if (lookup.queryParams) {
      const qpResult = sanitizeQueryParams(lookup.queryParams);
      if (!qpResult.valid) {
        return { valid: false, error: `Lookup[${i}] queryParams: ${qpResult.error}` };
      }
    }

    // ID lookups must only use GET
    lookup._method = "get";
  }

  return { valid: true };
}

const DANGEROUS_KEYS = ["__proto__", "constructor", "prototype"];

/**
 * Validates a username to prevent prototype pollution, path traversal, and malformed keys.
 */
function validateUsername(username) {
  if (!username || typeof username !== "string") {
    return { valid: false, error: "Username is required." };
  }
  if (username.length > 320) {
    return { valid: false, error: "Username exceeds maximum length." };
  }
  if (DANGEROUS_KEYS.includes(username)) {
    return { valid: false, error: "Invalid username." };
  }

  return { valid: true };
}

module.exports = {
  storeSessionSchema,
  validateGraphPath,
  validateHttpMethod,
  sanitizeQueryParams,
  validateIdLookups,
  validateUsername,
  MAX_ID_LOOKUPS,
};

