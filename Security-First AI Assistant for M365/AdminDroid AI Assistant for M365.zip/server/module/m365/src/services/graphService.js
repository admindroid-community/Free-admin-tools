const { Client } = require("@microsoft/microsoft-graph-client");
const { parse } = require("csv-parse/sync");
const { logger } = require("../../../../util/logger");
const GraphPaginationmanager = require("./graphPaginationManager");

class GraphService {
  constructor() {
    this.graphClient = null;
  }
  buildGraphApiPath(path, queryParams = {}) {
    if (!queryParams || Object.keys(queryParams).length === 0) {
      return path;
    }

    const queryString = Object.entries(queryParams)
      .map(
        ([key, value]) =>
          `${encodeURIComponent(key)}=${encodeURIComponent(value)}`,
      )
      .join("&");

    return `${path}?${queryString}`;
  }

  async executeGraphRequest(
    path,
    method,
    queryParams,
    body,
    accessToken,
    pageSize = 100,
    paginationId = null,
  ) {
    try {
      this.graphClient = Client.init({
        authProvider: (done) => done(null, accessToken),
      });
      logger.graph.debug(`Executing Graph request
        ${path},
        ${JSON.stringify(queryParams)},
        ${method},
        ${JSON.stringify(body)},
        ${paginationId},
        ${pageSize}`);

      let nextLink,
        entriesProcessed = 0;

      if (paginationId <= 0 || !paginationId) {
        nextLink = null;
      } else {
        let paginationEntity = GraphPaginationmanager.get(paginationId);
        nextLink = paginationEntity.nextLink;
        entriesProcessed = paginationEntity.entriesProcessed;
      }

      let newQueryParam = { ...(queryParams || {}) };

      let userSetLimit = newQueryParam.$top;

      let totalRemainingForUser = userSetLimit
        ? userSetLimit - entriesProcessed
        : Infinity;

      let supportsTop = !this.isTopNotSupported(path, method);

      let effectiveLimit = Math.min(totalRemainingForUser, pageSize);

      if (supportsTop) {
        newQueryParam.$top = Math.min(effectiveLimit, 500);
      } else {
        delete newQueryParam.$top;
      }

      let apiPath;

      if (nextLink) {
        const url = new URL(nextLink);

        if (supportsTop) {
          url.searchParams.set("$top", newQueryParam.$top);
        } else {
          url.searchParams.delete("$top");
        }

        apiPath = url.toString();
      } else {
        apiPath = this.buildGraphApiPath(path, newQueryParam);
      }

      let request = this.graphClient.api(apiPath);
      request = request.header("ConsistencyLevel", "eventual");

      let graphResponse;
      let msg = "";
      switch (method.toLowerCase()) {
        case "get": {
          const isPhotoRequest =
            path.endsWith("/photo/$value") ||
            /branding\/(logo|icon|backgroundImage)$/.test(path);

          const isCsvReportRequest =
            /^\/?reports\/get/i.test(path) ||
            /^\/?deviceManagement\/reports\//i.test(path);

          if (isPhotoRequest) {
            try {
              const imageBuffer = await request
                .responseType("arraybuffer")
                .get();
              const base64Image = Buffer.from(imageBuffer).toString("base64");
              return {
                type: "image",
                imageUrl: `data:image/png;base64,${base64Image}`,
                isSuccess: true,
                hasMore: false,
                supportsPagination: false,
              };
            } catch (error) {
              return {
                type: "image",
                imageUrl: null,
                isSuccess: false,
                hasMore: false,
                supportsPagination: false,
              };
            }
          } else if (isCsvReportRequest) {
            try {
              const MAX_CSV_SIZE = 10 * 1024 * 1024; // 10 MB limit
              const csvBuffer = await request.responseType("arraybuffer").get();

              if (csvBuffer.byteLength > MAX_CSV_SIZE) {
                return {
                  type: "text",
                  text: {
                    message: `CSV report too large (${(csvBuffer.byteLength / (1024 * 1024)).toFixed(2)} MB). Maximum allowed: ${MAX_CSV_SIZE / (1024 * 1024)} MB.`,
                  },
                  isSuccess: false,
                  hasMore: false,
                  supportsPagination: false,
                };
              }

              const csvText = Buffer.from(csvBuffer).toString("utf8");

              const records = parse(csvText, {
                columns: true,
                skip_empty_lines: true,
              });

              for (const record of records) {
                for (const key in record) {
                  if (record[key] && key.includes("Byte")) {
                    let value = parseInt(record[key], 10);
                    record[key] = (value / (1024 * 1024)).toFixed(2) + " MB";
                  }
                }
              }

              return {
                type: "text",
                text: {
                  data: records,
                  message: null,
                },
                hasMore: false,
                supportsPagination: false,
                isSuccess: true,
              };
            } catch (err) {
              const errorText = Buffer.from(err.body).toString("utf8");
              const errorObj = JSON.parse(errorText);

              return {
                type: "text",
                paginationId: "",
                text: {
                  message:
                    JSON.parse(errorObj.error?.message)?.error?.message ||
                    "Failed to parse CSV report",
                  details:
                    JSON.parse(errorObj.error?.message)?.error?.code || null,
                  statusCode: err.statusCode || null,
                },
                isSuccess: false,
                hasMore: false,
                supportsPagination: false,
              };
            }
          } else {
            let allData = [];

            graphResponse = await request.get();

            let odataNextLink = graphResponse["@odata.nextLink"];

            if (graphResponse?.value) {
              allData.push(...graphResponse.value);
            } else {
              break;
            }

            while (odataNextLink && allData.length < effectiveLimit) {
              const remaining = effectiveLimit - allData.length;
              const nextTop = Math.min(remaining, 500);

              const url = new URL(odataNextLink);
              url.searchParams.set("$top", nextTop);

              graphResponse = await this.graphClient.api(url.toString()).get();

              if (graphResponse?.value) {
                allData.push(...graphResponse.value);
              }

              odataNextLink = graphResponse["@odata.nextLink"];
            }
            entriesProcessed += allData.length;

            if (userSetLimit && entriesProcessed >= userSetLimit) {
              odataNextLink = null;
            }

            let hasMore = odataNextLink ? true : false;

            paginationId = GraphPaginationmanager.set(
              paginationId,
              odataNextLink,
              entriesProcessed,
            );

            if (!hasMore) {
              GraphPaginationmanager.delete(paginationId);
            }

            return {
              type: "text",
              paginationId,
              text: { data: allData, message: null },
              entriesProcessed: entriesProcessed,
              hasMore,
              isSuccess: true,
              supportsPagination: supportsTop,
            };
          }
        }
        case "post":
          graphResponse = await request.post(body);
          msg = `Created ${path} successfully`;
          break;

        case "put":
          graphResponse = await request.put(body);
          msg = `Updated ${path} successfully`;
          break;

        case "patch":
          graphResponse = await request.patch(body);
          msg = `Updated ${path} successfully`;
          break;

        case "delete":
          graphResponse = await request.delete();
          msg = `Deleted ${path} successfully`;
          break;

        default:
          throw new Error(`Unsupported HTTP method: ${method}`);
      }

      return {
        type: "text",
        text: { data: graphResponse || [], message: msg },
        isSuccess: true,
        supportsPagination: false,
        hasMore: false,
      };
    } catch (err) {
      logger.graph.error(
        `Error executing Graph request: ${JSON.stringify(err)}`,
      );
      return {
        type: "text",
        text: {
          message: err.message,
          details: err.code || null,
          statusCode: err.statusCode || null,
        },
        isSuccess: false,
      };
    }
  }

  isTopNotSupported(path, method) {
    if (method.toLowerCase() != "get") return true;

    if (!path) return true;

    const cleanPath = path.split("?")[0].replace(/\/+$/, "");
    const lowerPath = cleanPath.toLowerCase();

    if (lowerPath.includes("(")) return true;

    if (lowerPath.startsWith("/reports")) return true;
    if (lowerPath.startsWith("/directoryroles")) return true;

    if (lowerPath.includes("/$value")) return true;
    if (lowerPath.includes("/photo")) return true;
    if (lowerPath.includes("/content")) return true;

    if (lowerPath.endsWith("/$count")) return true;
    if (lowerPath.endsWith("/directoryroletemplates")) return true;
    if (lowerPath.endsWith("/subscribedskus")) return true;
    if (lowerPath.endsWith("/auditlogs")) return true;

    const segments = lowerPath.split("/").filter(Boolean);
    const last = segments[segments.length - 1];

    const guidRegex =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

    const emailRegex = /^[^@]+@[^@]+\.[^@]+$/;

    if (guidRegex.test(last)) return true;
    if (emailRegex.test(last)) return true;

    return false;
  }
}

module.exports = new GraphService();
