const { logger } = require("../../../../util/logger.js");
const AIProviderFactory = require("./providers/aiProviderFactory.js");

class AiService {
  constructor() {}

  async getResponse(aiProvider, model, prompt, historyList) {
    try {
      let currentTimeStamp = new Date();
      let promptText = `This is the user response : ${prompt}.This is the current time : ${currentTimeStamp}`;
      const provider = await AIProviderFactory.createProvider(
        aiProvider,
        prompt,
      );
      return await provider.getResponse(model, promptText, historyList);
    } catch (error) {
      throw error;
    }
  }

  async generateCode(aiProvider, model, query, allKeys) {
    try {
      const provider = await AIProviderFactory.createProvider(aiProvider);

      const prompt = `Made changes in the above function, the example function given in the previous message, check the history. Made changes for this query ${query}. And this is my input schema ${allKeys}.`;

      const response = await provider.getCode(model, prompt);
      return response;
    } catch (error) {
      throw error;
    }
  }

  async priorityContext(aiProvider, model, headers, query) {
    try {
      const provider = await AIProviderFactory.createProvider(aiProvider);
      const prompt = `This is the user query: ${query}. This is the keyfields: ${JSON.stringify(
        headers,
      )}.`;
      return await provider.getPriorityContext(model, prompt);
    } catch (error) {
      throw error;
    }
  }

  async getConsentPermission(
    aiProvider,
    model,
    prompt,
    isRetry,
    suggestion = null,
  ) {
    try {
      logger.development.ai.debug(`prompt ${prompt},suggestion: ${suggestion}`);
      const provider = await AIProviderFactory.createProvider(aiProvider);
      return await provider.getConsentPermission(
        model,
        JSON.stringify(prompt),
        isRetry,
        suggestion,
      );
    } catch (error) {
      throw error;
    }
  }

  async handleCallTool(aiProvider, model, prompt, summary) {
    try {
      const provider = await AIProviderFactory.createProvider(
        aiProvider,
        null,
        summary,
      );
      return await provider.handleCallTool(model,prompt);
    } catch (error) {
      throw error;
    }
  }
}
module.exports = new AiService();
