const GeminiProvider = require("../../../../../core/providers/geminiProvider.js");
const GroqProvider = require("../../../../../core/providers/groqProvider.js");
const CohereProvider = require("../../../../../core/providers/cohereProvider.js");
const ClaudeProvider = require("../../../../../core/providers/claudeProvider.js");
const OpenAIProvider = require("../../../../../core/providers/openaiProvider.js");
const ModuleAIContext = require("./aiProvider.js");
const { sendAndLogError } = require("../../../../../util/errorResponse.js");
const { logger } = require("../../../../../util/logger.js");
const providerService = require("../../../../../core/src/services/providerService.js");

class AIProviderFactory {
  static providers = {};

  static async createProvider(
    providerType,
    currentPrompt,
    pendingAction = null,
  ) {
    let { keyName, apiKey } = await providerService.getApiKey(providerType);

    if (!apiKey) {
      sendAndLogError(
        logger.ai,
        "Missing API key",
        400,
        "API key is required for authentication.",
      );
    }

    const providerKey = `${providerType.toLowerCase()}_${keyName}`;
    const ctx = new ModuleAIContext(pendingAction);

    if (!this.providers[providerKey]) {
      switch (providerType.toLowerCase()) {
        case "gemini":
          this.providers[providerKey] = new GeminiProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        case "groq":
          this.providers[providerKey] = new GroqProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        case "cohere":
          this.providers[providerKey] = new CohereProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        case "claude":
          this.providers[providerKey] = new ClaudeProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        case "openai":
          this.providers[providerKey] = new OpenAIProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        default:
          console.error(`Unsupported provider type: ${providerType}`);
          return sendAndLogError(
            logger.ai,
            `Unsupported provider type: ${providerType}`,
            400,
            "The specified AI provider is not supported.",
          );
      }
    }
    return this.providers[providerKey];
  }
}

module.exports = AIProviderFactory;
