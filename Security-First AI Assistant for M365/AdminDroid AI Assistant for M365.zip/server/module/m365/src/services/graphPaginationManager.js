class GraphPaginationmanager {
  static nextLinks = new Map();
  static paginationId = 1;

  static set(paginationId, nextLink, entriesProcessed) {
    const id =
      paginationId <= 0 || !this.nextLinks.has(paginationId)
        ? this.paginationId++
        : paginationId;
    this.nextLinks.set(id, {
      nextLink,
      entriesProcessed,
    });



    return id;
  }

  static has(paginationId) {
    return this.nextLinks.has(paginationId);
  }

  static get(paginationId) {
    return this.nextLinks.has(paginationId)
      ? this.nextLinks.get(paginationId)
      : null;
  }

  static delete(paginationId) {
    return this.nextLinks.delete(paginationId);
  }

  static clearAll() {
    this.nextLinks.clear();
    this.paginationId = 1;
  }
}

module.exports = GraphPaginationmanager;
