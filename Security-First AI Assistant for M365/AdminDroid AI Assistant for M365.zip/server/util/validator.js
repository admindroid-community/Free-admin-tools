const { ZodError } = require("zod");
const { logger } = require("./logger");

function validateBody(schema) {
  return (req, res, next) => {
    try {
      req.body = schema.parse(req.body);
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        logger.core.error("Validation failed" + JSON.stringify(err.issues || {}));
        return res.status(400).json({ error: "Validation failed", details: err.issues });
      }
      next(err);
    }
  };
}

module.exports = { validateBody };

