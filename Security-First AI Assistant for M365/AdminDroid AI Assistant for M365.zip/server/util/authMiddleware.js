const { sendAndLogError } = require("./errorResponse.js");
const { logger } = require("./logger.js");

// Session slots used across the tool modules to hold the signed-in user:
// "ad_user" (AD / LDAP) and "m365user" (M365 / Graph). Each module's server
// process only ever populates its own slot, so checking all of them keeps this
// guard common to every module.
const SESSION_KEYS = ["ad_user", "m365user"];

// A session slot counts as "present" only when it actually holds a signed-in
// user: a non-empty array of profiles (AD) or a non-empty user map (M365).
const isEmptySession = (value) => {
  if (!value) return true;
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === "object") return Object.keys(value).length === 0;
  return false;
};

// Shared guard for the AI endpoints of the AD and M365 modules. Throws a 401
// ErrorResponse (handled by the global errorHandler) when no user session is
// present. Used identically in every module's router.
const requireSession = (req, res, next) => {
  const hasSession =
    req.session && SESSION_KEYS.some((key) => !isEmptySession(req.session[key]));
  if (!hasSession) {
    sendAndLogError(
      logger.session,
      "Unauthorized request: no active user session.",
      401,
      "Session Closed, Please Login again.",
    );
  }
  next();
};

module.exports = { requireSession };
