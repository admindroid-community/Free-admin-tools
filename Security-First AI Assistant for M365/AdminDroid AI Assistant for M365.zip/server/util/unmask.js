const Mustache = require("mustache");

function escapeForJson(str) {
  if (typeof str !== "string") return str;
  return str
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "\\r")
    .replace(/\t/g, "\\t");
}

async function unMaskMacro(template, value = {}) {
  const escapedValues = {};
  for (const [k, v] of Object.entries(value)) {
    escapedValues[k] = escapeForJson(v);
  }

  const safeValue = new Proxy(escapedValues, {
    get: (target, prop) => (prop in target ? target[prop] : ""),
  });

  return Mustache.render(template, safeValue);
}

module.exports = { unMaskMacro };
