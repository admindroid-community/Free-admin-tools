const fetch = require('node-fetch');
const { Headers, Request, Response } = fetch;
const Blob = require('fetch-blob');
const FormDataMod = require('formdata-node');
const AbortController = require('abort-controller');

const { FormData, File } = FormDataMod;

if (typeof globalThis.fetch === 'undefined') globalThis.fetch = fetch;
if (typeof globalThis.Headers === 'undefined') globalThis.Headers = Headers;
if (typeof globalThis.Request === 'undefined') globalThis.Request = Request;
if (typeof globalThis.Response === 'undefined') globalThis.Response = Response;
if (typeof globalThis.Blob === 'undefined') globalThis.Blob = Blob;
if (typeof globalThis.FormData === 'undefined') globalThis.FormData = FormData;
if (typeof globalThis.File === 'undefined') globalThis.File = File;
if (typeof globalThis.AbortController === 'undefined') globalThis.AbortController = AbortController;
