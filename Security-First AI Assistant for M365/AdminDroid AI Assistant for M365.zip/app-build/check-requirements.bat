@echo off
setlocal ENABLEDELAYEDEXPANSION

echo.
echo ================================
echo Checking Build Prerequisites
echo ================================

:: --------------------------------
:: Temp paths
:: --------------------------------
set TEMP_DIR=%TEMP%\build-tools
set NODE_MSI=%TEMP_DIR%\node-v20.11.1-x64.msi
set NODE_URL=https://nodejs.org/dist/v20.11.1/node-v20.11.1-x64.msi

if not exist "%TEMP_DIR%" mkdir "%TEMP_DIR%"

:: --------------------------------
:: Check curl
:: --------------------------------
where curl >nul 2>&1
if errorlevel 1 (
    echo curl is not available on this system.
    echo Please update Windows or install curl.
    exit /b 1
)

:: --------------------------------
:: Check Node.js
:: --------------------------------
where node >nul 2>&1
if errorlevel 1 (
    echo Node.js not found.
    echo Downloading Node.js v20.11.1...
    echo.

    curl -L --progress-bar "%NODE_URL%" -o "%NODE_MSI%"

    if errorlevel 1 (
        echo Failed to download Node.js installer.
        exit /b 1
    )

    if not exist "%NODE_MSI%" (
        echo Node.js installer not found after download.
        exit /b 1
    )

    echo.
    echo Installing Node.js silently...
    msiexec /i "%NODE_MSI%" /qn /norestart

    if errorlevel 1 (
        echo Node.js installation failed.
        exit /b 1
    )

    echo Cleaning up Node installer...
    del /f /q "%NODE_MSI%"
)

:: Refresh PATH for current session
set "PATH=%ProgramFiles%\nodejs;%PATH%"

:: --------------------------------
:: Check Node version (>= 20)
:: --------------------------------
for /f "tokens=1 delims=." %%a in ('node -v') do set NODE_MAJOR=%%a
set NODE_MAJOR=%NODE_MAJOR:v=%

if %NODE_MAJOR% LSS 20 (
    echo Node.js version is less than 20.
    echo Please upgrade Node.js to version 20 or higher.
    exit /b 1
)

echo Node.js OK (v20+)

:: --------------------------------
:: Check npm
:: --------------------------------
where npm >nul 2>&1
if errorlevel 1 (
    echo npm not found. Node installation may be corrupted.
    exit /b 1
)

echo npm OK

:: --------------------------------
:: Check Ember CLI
:: --------------------------------
where ember >nul 2>&1
if errorlevel 1 (
    echo Ember CLI not found.
    echo Installing Ember CLI globally...
    npm install -g ember-cli

    if errorlevel 1 (
        echo Failed to install Ember CLI.
        exit /b 1
    )
)

echo Ember CLI OK

:: --------------------------------
:: Cleanup temp folder
:: --------------------------------
if exist "%TEMP_DIR%" rmdir /s /q "%TEMP_DIR%"

echo ================================
echo All prerequisites satisfied
echo ================================

endlocal

set "NODE_HOME=%ProgramFiles%\nodejs"
set "PATH=%NODE_HOME%;%NODE_HOME%\node_modules\npm\bin;%PATH%"

exit /b 0
