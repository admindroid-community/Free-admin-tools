@echo off
setlocal enabledelayedexpansion
cls

cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -WindowStyle Hidden -Command "Start-Process '%~f0' -Verb RunAs -WorkingDirectory '%~dp0'"
    exit /b
)

echo ===========================================================
echo            Building AdminDroid Community Tool
echo ===========================================================
echo.

echo Running prerequisite checks...
call check-requirements.bat
if errorlevel 1 (
    echo Build aborted due to missing requirements.
    pause
    exit /b 1
)

where node >nul 2>&1 || (
    echo ERROR: Node.js still not available in PATH.
    pause
    exit /b 1
)

echo Requirements OK. Continuing build...
echo.

cd ..

set "folderPath=%cd%\server\module"
set "folderList="

set environment=production

echo Checking available tools details...

for /d %%A in ("%folderPath%\*") do (
    set "subFolder=%%~nxA"
    if !subFolder! NEQ build (
        set "folderList=!folderList! %%~nxA"
    )
)

echo Available tools : !folderList!
echo.

if exist "%~dp0output" (
    rmdir /S /Q "%~dp0output"
)

echo [1/3] Setting up client (Ember)...
cd client
call npm install >nul 2>&1
echo        -Node packages installed (client).
call npm run build >nul 2>&1
cd ..
echo        -Ember client build completed.
echo.

echo [2/3] Setting up server router and server...
cd server
call npm install >nul 2>&1
echo        - Node packages installed (server).

cd module
for %%B in (%folderList%) do (
    cd %%B
    call npx rollup -c >nul 2>&1
    cd ..
    echo        - %%B router build completed.
)
cd ..

cd core
call npx rollup -c >nul 2>&1
echo        - Server build completed.
cd ..

call npm run build-app >nul 2>&1
echo        - Tool build completed.
cd ..

cd app-build/update-exe-metadata
call npm install >nul 2>&1
call node update-exe-metadata.js
cd ../..

set "TOOL_DEST_DIR=app-build\output\base\tool"

if not exist "%TOOL_DEST_DIR%" (
    mkdir "%TOOL_DEST_DIR%"
)
copy "app-build\update-exe-metadata\AdminDroid_Community_Tool_modified.exe" "!TOOL_DEST_DIR!\AdminDroid_Community_Tool.exe" /Y >nul 2>&1
echo        - Server build metadata updated.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "'BUILD_TYPE=!environment!' | Add-Content '!TOOL_DEST_DIR!\.env'"

echo [3/3] Bundling the module and base files...


for %%B in (%folderList%) do (

    set "moduleFolderPath=app-build\output\module\%%B\"
    set "moduleZipFilePath=app-build\output\module\%%B.zip"

    if exist "%moduleZipFilePath%" (
        del /Q "%moduleZipFilePath%"
    )

    robocopy "server\module\build\%%B" "!moduleFolderPath!\server" /E >nul 2>&1
    xcopy "server\module\%%B\config\info.json" "!moduleFolderPath!\server\" /Y >nul 2>&1
    robocopy "client\dist\engines-dist\%%B" "!moduleFolderPath!\client\%%B" /E >nul 2>&1

    call powershell Compress-Archive -Path !moduleFolderPath! -DestinationPath !moduleZipFilePath!  >nul 2>&1

    rmdir /s /q "!moduleFolderPath:~0,-1!\"

    echo    - %%B build files successfully compressed and saved to "!moduleZipFilePath!".

)

set "distPath=app-build\output\base\dist"
set "baseClientZipFilePath=app-build\output\base\baseClient.zip"

robocopy "client\dist" "!distPath!" /E /XD "engines-dist" >nul 2>&1
xcopy "client\app\config\info.json" "!distPath!\" /Y >nul 2>&1
call powershell Compress-Archive -Path !distPath! -DestinationPath !baseClientZipFilePath! >nul 2>&1
echo    - baseClient build files successfully compressed and saved to "!baseClientZipFilePath!".

set "baseServerPath=app-build\output\baseServer"
set "baseServerZipFilePath=app-build\output\base\baseServer.zip"
xcopy "server\core\build\baseServer.cjs" "!baseServerPath!\" /Y >nul 2>&1
xcopy "server\config\info.json" "!baseServerPath!\" /Y >nul 2>&1
call powershell Compress-Archive -Path "!baseServerPath!\*" -DestinationPath !baseServerZipFilePath! >nul 2>&1
echo    - baseServer build files successfully compressed and saved to "!baseServerZipFilePath!".

set "toolPath=!TOOL_DEST_DIR!"
set "toolZipFilePath=app-build\output\base\tool.zip"
xcopy "server\config\tool-info.json" "!toolPath!\" /Y >nul 2>&1
call powershell Compress-Archive -Path "!toolPath!\*" -DestinationPath !toolZipFilePath! >nul 2>&1
echo    - tool build files successfully compressed and saved to "!toolZipFilePath!".


rmdir /s /q "!distPath!"
rmdir /s /q "!baseServerPath!"
rmdir /s /q "!toolPath!"

echo.
echo ===========================================================
echo                Build completed successfully
echo ===========================================================
echo.

echo Press any key to exit...
pause >nul
exit /b