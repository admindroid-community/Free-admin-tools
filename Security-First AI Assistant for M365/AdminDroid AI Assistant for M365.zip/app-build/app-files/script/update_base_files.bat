@echo off
setlocal enabledelayedexpansion

cd ..

set "APP_NAME=AdminDroid Community Tool"
set "DOWNLOAD_URL=%~1"
set "INSTALL_PATH=%cd%"
set "RANDOM_SUFFIX=%RANDOM%"
set "TOOL_FILE_ZIP_FILE=%TEMP%\tool_!RANDOM_SUFFIX!.zip"
set "FILE_DES_PATH=%INSTALL_PATH%\"

set "SERVICE_NAME=AdminDroid_Community_Tool"
set "SERVICE_FILE_PATH=%INSTALL_PATH%\AdminDroidCT-Service.exe"

echo ======================================================
echo         AdminDroid Community Tool - Update Tool
echo ======================================================
echo.
echo Install Path : !INSTALL_PATH!
echo.

echo [1/2] Updating base tool launcher...
call :DownloadFile "!TOOL_FILE_ZIP_FILE!" "!FILE_DES_PATH!"

echo [2/2] Updating timestamp...
call :UpdateInfo

sc query "%SERVICE_NAME%" >nul 2>&1
if errorlevel 1060 (
    echo Service NOT installed
    goto FAIL_ACTION
)

if not exist "%SERVICE_FILE_PATH%" (
    echo %SERVICE_FILE_PATH% NOT found
    goto FAIL_ACTION
)

echo Restarting service...
cd ./script
call service_restart.bat

echo.
echo Update completed. Launching application...
start "" "!FILE_DES_PATH!AdminDroidCT-Launcher.exe"

endlocal
exit /b 0

:DownloadFile
set "TEMP_PATH=%~1"
set "DES_PATH=%~2"
set "FILE_NAME=%~3"

echo Downloading from: !DOWNLOAD_URL!
curl -# -L "!DOWNLOAD_URL!" -o "!TEMP_PATH!"

if exist "!TEMP_PATH!" (
    echo Download completed.

    set "serviceInitialized=true"

    if not exist "!DES_PATH!" (
        echo Creating destination directory: !DES_PATH!
        mkdir "!DES_PATH!"
    )

    set "serviceName=AdminDroid_Community_Tool"

    echo Checking service "!serviceName!"...

    sc query "!serviceName!" >nul 2>&1
    if errorlevel 1060 (
        echo Service "!serviceName!" not found or not accessible.
        set "serviceInitialized=false"
    ) else (
        echo Service found. Attempting to stop...
        net stop "!serviceName!" >nul 2>&1
        if errorlevel 1 (
            echo Warning: Service "!serviceName!" could not be stopped or was not running.
        ) else (
            echo Service stopped successfully.
        )
    )

    call script\check_and_kill.bat !FILE_NAME!

    if not exist "%SERVICE_FILE_PATH%" (
        echo %SERVICE_FILE_PATH% NOT found
        set "serviceInitialized=false"
    )

    echo Extracting archive...
    powershell -Command "Expand-Archive -Path '!TEMP_PATH!' -DestinationPath '!DES_PATH!' -Force"

    if "!serviceInitialized!"=="false" (
        del /f /q "!DES_PATH!\AdminDroidCT-Launcher.exe"
        del /f /q "!DES_PATH!\AdminDroidCT-Service.exe"
    ) 

    del /f /q "!TEMP_PATH!"
    echo Temporary file deleted.

) else (
    echo Download failed for: !FILE_NAME!
    exit /b 1
)

goto :eof

:UpdateInfo
set "jsonFile=!INSTALL_PATH!\files\appInfo.json"

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'"') do set "timestamp=%%i"

powershell -NoProfile -Command ^
  "(Get-Content -Raw '%jsonFile%') | ConvertFrom-Json | ForEach-Object { $_.lastUpdated = '%timestamp%'; $_ } | ConvertTo-Json -Depth 10 | Set-Content '%jsonFile%'"

echo Timestamp updated to: %timestamp%
goto :eof


:FAIL_ACTION

echo Please close all other running instances of the app and relaunch it to apply the updates.

endlocal
exit /b 0