@echo off
set "FILE_NAME=%~1"
for %%A in ("%FILE_NAME%") do set "BASE_NAME=%%~nA"
powershell -command "Get-Process %BASE_NAME% -ErrorAction SilentlyContinue"
if %errorlevel%==0 (
    echo Killing process: %FILE_NAME%
    taskkill /f /im %FILE_NAME%
    timeout /t 2 >nul
    exit /b 1
)
exit /b 0