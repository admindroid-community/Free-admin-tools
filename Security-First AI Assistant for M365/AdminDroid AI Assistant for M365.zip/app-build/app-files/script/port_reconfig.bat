@echo off
setlocal enabledelayedexpansion

cd /d "%~dp0.."

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -WindowStyle Hidden -Command "Start-Process '%~f0' -Verb RunAs -WorkingDirectory '%CD%'"
    exit /b
)

echo =========================================
echo            Port Configuration
echo =========================================

set "configFile=port.txt"

if not exist "%configFile%" type nul > "%configFile%"

set /p configValue=<"%configFile%"

if "%configValue%"=="" (
    echo Custom Port not configured.
) else (
    echo Current port configuration: %configValue%
)

:input
set /p userInput=Enter a port number (1024 - 65535): 


if %userInput% lss 1024 (
    echo Invalid port. Must be 1024-65535.
    goto input
)
if %userInput% gtr 65535 (
    echo Invalid port. Must be 1024-65535.
    goto input
)

> "%configFile%" echo %userInput%
echo Configuration updated successfully! Port set to %userInput%.
echo.

echo Please close all other running instances of the app and relaunch it to apply the updated port number.

:end
echo.
pause