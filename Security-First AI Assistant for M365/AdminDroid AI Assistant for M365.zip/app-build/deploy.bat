@echo off
setlocal EnableDelayedExpansion
cls

cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -WindowStyle Hidden -Command "Start-Process '%~f0' -Verb RunAs -WorkingDirectory '%~dp0'"
    exit /b
)


echo ============================================
echo        Deploy Build Files Locally
echo ============================================
echo.

set "SOURCE_PATH=%~dp0"
set "SOURCE_PATH=%SOURCE_PATH:~0,-1%"

echo Source path (batch location):
echo %SOURCE_PATH%
echo.

set /p DEST_PATH=Enter the path where the app needs to be deployed: 

if "%DEST_PATH%"=="" (
    echo ERROR: Destination path cannot be empty
    pause
    exit /b 1
)

if not exist "%DEST_PATH%\" (
    echo Destination not found. Creating folder...
    mkdir "%DEST_PATH%"
)

if not exist "%DEST_PATH%\" (
    echo ERROR: Destination path is not a folder
    pause
    exit /b 1
)

echo.
echo Using destination folder:
echo %DEST_PATH%
echo.

mkdir "%DEST_PATH%\files" >nul 2>&1
mkdir "%DEST_PATH%\modules\client" >nul 2>&1
mkdir "%DEST_PATH%\modules\server" >nul 2>&1
mkdir "%DEST_PATH%\script" >nul 2>&1

echo Folder structure created.
echo.

echo Copying files to files folder...
robocopy "%SOURCE_PATH%\app-files\files\config" "%DEST_PATH%\files" *.* /XF /R:0 /W:0 >nul

echo Copying files to script folder...
robocopy "%SOURCE_PATH%\app-files\script" "%DEST_PATH%\script" *.* /XF /R:0 /W:0 >nul

echo Copying files to root folder...
robocopy "%SOURCE_PATH%\app-files\files\core" "%DEST_PATH%" *.* /XF /R:0 /W:0 >nul

echo.
echo Folder setup completed successfully.

echo.
echo Deploying built files locally...

set "baseSourcePath=%cd%\output\base"
set "moduleSourcePath=%cd%\output\module"

set "enginesDistPath=%DEST_PATH%\modules\client\engines-dist"
set "moduleDestinationPath=%DEST_PATH%\modules\server"

set "toolFileName=AdminDroid_Community_Tool.exe"

echo Files deployed locally: 

echo.
echo    - base server
powershell -command "Expand-Archive -LiteralPath '%baseSourcePath%\baseServer.zip' -DestinationPath '%baseSourcePath%\baseServer' -Force"
robocopy "%baseSourcePath%\baseServer" "%moduleDestinationPath%\baseServer" /E /IS /R:3 /W:5 /NJH /NJS /NDL /NFL /NC /NS /NP >nul
if %ERRORLEVEL% GEQ 8 (
    echo ERROR copying - "%moduleDestinationPath%\baseServer\"
    goto ERROR
) else (
    echo        - "%moduleDestinationPath%\baseServer\"
)
rd /s /q "%baseSourcePath%\baseServer"

echo.
echo    - base client
powershell -command "Expand-Archive -LiteralPath '%baseSourcePath%\baseClient.zip' -DestinationPath '%baseSourcePath%\baseClient' -Force"
robocopy "%baseSourcePath%\baseClient\dist" "%DEST_PATH%\modules\client" /E /IS /R:3 /W:5 /NJH /NJS /NDL /NFL /NC /NS /NP >nul
if %ERRORLEVEL% GEQ 8 (
    echo ERROR copying - "%DEST_PATH%\modules\client\"
    goto ERROR
) else (
    echo        - "%DEST_PATH%\modules\client\"
)
rd /s /q "%baseSourcePath%\baseClient"

echo.
echo    - tool
for %%A in ("%toolFileName%") do set "BASE_NAME=%%~nA"
powershell -command "Get-Process %BASE_NAME% -ErrorAction SilentlyContinue" >nul
if %errorlevel%==0 (
    echo        - Killing process: %toolFileName%
    taskkill /f /im %toolFileName% >nul
    timeout /t 2 >nul
)
powershell -command "Expand-Archive -LiteralPath '%baseSourcePath%\tool.zip' -DestinationPath '%baseSourcePath%\tool' -Force"
robocopy "%baseSourcePath%\tool" "%DEST_PATH%" /E /IS /R:3 /W:5 /NJH /NJS /NDL /NFL /NC /NS /NP >nul
if %ERRORLEVEL% GEQ 8 (
    echo ERROR copying - "%DEST_PATH%"
    goto ERROR
) else (
    echo        - "%DEST_PATH%\AdminDroid_Community_Tool.exe"
    echo        - "%DEST_PATH%\.env"
    echo        - "%DEST_PATH%\files\tool-info.json"
)
rd /s /q "%baseSourcePath%\tool"

if not exist "%enginesDistPath%" (
    echo            - "%enginesDistPath%" Folder not found, creating...
    mkdir "%enginesDistPath%"
)

for %%A in ("%moduleSourcePath%\*.zip") do (
    
    set "flag=1"
    set "filename=%%~nA"

    setlocal enabledelayedexpansion

    set "basename=!filename!"

    echo    - !basename! module

    powershell -command "Expand-Archive -LiteralPath '!moduleSourcePath!\!filename!.zip' -DestinationPath '!moduleSourcePath!\' -Force"
    robocopy "!moduleSourcePath!\!basename!\server" "!moduleDestinationPath!\!basename!" /E /IS /R:3 /W:5 /NJH /NJS /NDL /NFL /NC /NS /NP >nul
    if %ERRORLEVEL% GEQ 8 (
        echo ERROR copying - "!moduleDestinationPath!\!basename!" 
        goto ERROR
    ) else (
        echo        - "!moduleDestinationPath!\!basename!" 
    )
    robocopy "!moduleSourcePath!\!basename!\client" "!enginesDistPath!" /E /IS /R:3 /W:5 /NJH /NJS /NDL /NFL /NC /NS /NP >nul
    if %ERRORLEVEL% GEQ 8 (
        echo ERROR copying - "!enginesDistPath!\!basename!"
        goto ERROR        
    ) else (
        echo        - "!enginesDistPath!\!basename!"
    )
    rd /s /q "!moduleSourcePath!\!basename!"

    endlocal
)

echo.
echo All files copied successfully!
goto END

:ERROR
echo.
echo Error occurred while copying files!

:END
echo.
echo Deployment successful.
echo Launch the app by running "%DEST_PATH%\AdminDroid_Community_Tool.exe" as Administrator.
echo.

pause
exit /b
