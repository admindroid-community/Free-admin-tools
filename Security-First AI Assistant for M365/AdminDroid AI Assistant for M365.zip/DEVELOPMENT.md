# Development Guide

This document consolidates how to set up, run, and iterate on the MCP Tool in development across the server (Node/Express) and client (Ember with Engines).

## Overview

- server (Express): `server/`
  - Serves the Ember build in non‑development modes
  - Loads server modules from `server/module/<module-id>`
  - Manages app config in `server/config/appInfo.js`
- client (Ember host app + Engines): `client/`
  - Engines located under `client/lib/{ad,graph-explorer,ldap-explorer,m365}`
  - Local addon workbench in `client/addon-workbench`
- Build Scripts: `app-build/` for packaging base server/client and module artifacts
- Windows launcher: `launcher/`

## Prerequisites

- Node.js 18+ and npm
- Git
- Ember CLI (optional but recommended for local dev): `npm i -g ember-cli`
- Windows is required to run the provided `.bat` packaging scripts; day‑to‑day dev on macOS/Linux is fine.

## Quick Start

Open two terminals:

1. server

```
cd server
npm install
npm start
```

2. client

```
cd client
npm install
npm start
```

- client runs at `http://localhost:4200`.
- server selects the first available port from `PREFERRED_PORTS` (default: 3000, 4000, 5000, 6000, 7000). Check the server console for the chosen port.

Alternatively, use the helper script to configure env vars and start both services in separate terminals:

```
./scripts/dev-start.ps1
```

Options:

```
./scripts/dev-start.ps1 -BuildType development -ClientPort 4201 -PreferredPorts 3100,4100,5100 -InstallPath C:\dev\mcp-tool-data
```

## Environment & Configuration (server)

Key settings are defined in `server/config/appInfo.js` and may be overridden by environment variables:

- `BUILD_TYPE`: `development` | `testing` | `production` (default: `development`)
- `CORS_ORIGINS`: comma‑separated list (defaults include `http://localhost:4200`)
- `PREFERRED_PORTS`: comma‑separated list of ports to try
- `SESSION_SECRET` or `SESSION_SECRETS`: cookie session secrets
- `APP_INSTALL_PATH`: base path for modules/files/logs/backups
- `ADMIN_SERVER_URL`, `LOG_CLEAR_INTERVAL_DAYS`, etc.

Important note for development paths:

- When `BUILD_TYPE=development`, paths used by the app (modules/files/logs/etc.) resolve under `APP_INSTALL_PATH` or the default `C:\\Program Files\\AdminDroid\\Community Tool`.
- For a smoother dev experience, set `APP_INSTALL_PATH` to a writable location, e.g. your repo workspace:

```
# PowerShell example
$env:APP_INSTALL_PATH = (Get-Location).Path + "\\_devdata"
$env:BUILD_TYPE = "development"
# then start the server
npm start
```

## Running End‑to‑End (Built UI served by server)

In development, the client is served by Ember CLI while the server runs separately. To test the integrated serving flow (server serves the Ember build):

1. Build the client:

```
cd client
npm run build
```

2. Ensure server `BUILD_TYPE` is not `development` (e.g., `testing`):

```
# PowerShell example
$env:BUILD_TYPE = "testing"
cd server
npm start
```

The server will serve the contents of the built dist under its chosen port.

For full packaging (server binary, modules, and zips), see the Packaging section below.

## Common Tasks

- Lint (client): `cd client && npm run lint` (and `npm run lint:fix`)
- Test (client): `cd client && npm run test`
- Update CORS origins: set `CORS_ORIGINS` to include your dev host(s)
- Check server is live: open `/admindroid` on the server port

## Engines and Modules in Dev

- Ember Engines live under `client/lib/<engine>`; they build into `client/dist/engines-dist/<engine>`.
- server modules live under `server/module/<module-id>`:
  - In development, `ModuleLoaderService` looks for `src/router.js` inside each module folder and mounts it at `/<module-id>`.
  - In packaged builds, modules are rolled up and loaded from the installed modules directory.

## Packaging & Local Install Validation (Windows)

- Use `app-build/common-build.bat` to:
  - Choose environment (testing/production)
  - Bump versions for base server/client and each module
  - Build client, roll up server modules, package server, and emit zips into `app-build/output/`
- Optionally run `app-build/test-build-locally.bat` to expand the produced zips into `%ProgramFiles%` and `%ProgramData%` for quick validation of an installed‑like layout.

Details on artifacts and versioning are in `RELEASES.md`.

## Troubleshooting

- Port already in use: set `PREFERRED_PORTS` to include free ports or stop the conflicting process.
- CORS errors in the browser: add your client origin to `CORS_ORIGINS`.
- Paths not writable on Windows: set `APP_INSTALL_PATH` to a user‑writable folder for development.
- Module not mounted: verify `server/module/<id>/src/router.js` exists and exports an Express router.
- Session/cookie issues: set `SESSION_SECRET` (or `SESSION_SECRETS`) and clear cookies during debugging.

## References

- server notes: `server/README.md`
- client notes: `client/README.md`
- Contribution guidelines: `CONTRIBUTING.md`
- Packaging and releases: `RELEASES.md`
