# Security-First AI Assistant for M365

- Module: Microsoft 365
- Module ID: m365
- Module version: 1.7.9.59
- Server (base): 2.0.0.33
- Client (base): 2.0.0.66
