---
name: Bug report
about: Create a report to help us improve
labels: bug
---

## Describe the bug

A clear and concise description of what the bug is.

## To Reproduce

Steps to reproduce the behavior:

1. Go to '...'
2. Click on '...'
3. See error

## Expected behavior

What you expected to happen.

## Screenshots / Logs

Add screenshots and relevant logs (server logs, browser console).

## Environment

- OS:
- Node version:
- client `client/app/config/info.json` version:
- server `server/config/info.json` version:
- Module(s) affected (if any):

## Additional context

Add any other context about the problem here.
