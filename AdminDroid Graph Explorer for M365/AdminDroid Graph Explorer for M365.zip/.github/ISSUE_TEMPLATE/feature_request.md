---
name: Feature request
about: Suggest an idea for this project
labels: enhancement
---

## Summary

Describe the problem this feature solves and the desired outcome.

## Proposed solution

Describe the approach, UI/UX impacts, and affected areas (client engines, server modules).

## Alternatives considered

Any alternative solutions or features you've considered.

## Additional context

Mockups, references, or related issues.
