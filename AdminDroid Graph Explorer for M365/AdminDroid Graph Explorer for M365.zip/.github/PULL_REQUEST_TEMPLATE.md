## Summary

Describe the change and the problem it solves.

## Type of change

- [ ] feat (new feature)
- [ ] fix (bug fix)
- [ ] refactor (no functional change)
- [ ] docs (documentation only)
- [ ] chore (build/CI/tooling)

## How to test

Steps to validate locally (include commands, env vars, screenshots if helpful):

## Risks and mitigations

Potential impact areas and how you mitigated (tests, guards, fallbacks):

## Checklist

- [ ] I ran Ember tests and linters in `client/`
- [ ] I exercised the affected server routes in `server/`
- [ ] I updated docs (CONTRIBUTING/RELEASES/README) if needed
- [ ] I followed Conventional Commits in the title
