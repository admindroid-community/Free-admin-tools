# Releases and Versioning

This document describes how we version, build, and publish release artifacts for the MCP Tool. The app auto‑updates by consuming versioned zip packages for the base client/server and each module (engine), so consistent versioning and packaging is important.

## Components and Versions

We track versions in the following files:

- Base Server: `server/config/info.json` (field: `version`)
- Base Client: `client/app/config/info.json` (field: `version`)
- Modules (server + engine pair): `server/module/<name>/config/info.json` (fields: `moduleId`, `moduleName`, `version`)

We follow semantic versioning where practical. Patch releases should be safe to auto‑apply; minor/major communicate broader changes.

## Build Outputs

Running the build produces zip files under `app-build/output/`:

- Base artifacts (in `app-build/output/base/`):
  - `baseServer.zip` — packaged server binary and metadata (e.g., `AdminDroid_Community_Tool.exe`, `launcher.exe`, `info.json`)
  - `baseClient.zip` — Ember client distribution and `info.json`
- Module artifacts (in `app-build/output/module/`):
  - `<module>.zip` — contains `server/` (rolled up router) and `client/<module>/` (engine build)

For testing builds, files are prefixed with `testing-` (see the prompt in the build script). Production builds omit this prefix.

## End‑to‑End Build (Windows)

Use the interactive build script to bump versions and produce all artifacts:

1. Run `app-build/common-build.bat`
2. Choose environment:
   - `1` = testing (artifacts prefixed with `testing-`)
   - `2` = production
3. When prompted, enter the new versions for:
   - Each module (e.g., `ad`, `graph-explorer`, `ldap-explorer`, `m365`)
   - Base server version (`server/config/info.json`)
   - Base client version (`client/app/config/info.json`)
4. The script builds and packages:
   - Frontend: `client/dist` (engines under `dist/engines-dist/*`)
   - Backend modules: Rollup builds for each module
   - Server binary: `server` packaged via `pkg`, then metadata updated
   - Final zips written to `app-build/output/base/` and `app-build/output/module/`

Optional: Validate locally using `app-build/test-build-locally.bat` (expands artifacts into `%ProgramFiles%` and `%ProgramData%` locations for quick testing).

## Publishing a Release

Typical flow:

1. Verify the app locally with the freshly built artifacts
2. Tag the repo (optional but recommended):
   - Example: `git tag -a v3.1.0 -m "Release v3.1.0" && git push --tags`
3. Create a GitHub Release and attach artifacts in `app-build/output`:
   - `base/baseServer.zip`, `base/baseClient.zip`
   - `module/<module>.zip` for each module
   - For testing channels, attach `testing-*` files or publish to the update service’s testing channel
4. If using an external update service (`ADMIN_SERVER_URL`), upload the zips as required by that service

## Auto‑Update Notes

- The server reads environment and update details from `server/config/appInfo.js`.
- Ensure version bumps are correct; clients compare versions to decide whether to download an update.
- Keep module ids stable; they map routes and packaging layout across server/client.

## Hotfixes

- For a hotfix, bump only the affected component(s) and rebuild. For example, a client fix may only require a new `baseClient.zip`.
- If a single module is updated, rebuild and publish only that module’s zip.

## Troubleshooting

- Port conflicts during dev: adjust `PREFERRED_PORTS` in environment or `appInfo.js`.
- CORS issues: ensure `CORS_ORIGINS` allows your client dev origin.
- Backend errors: follow the error patterns in `server/README.md` and check logs under `%ProgramData%/<app>/logs` when running installed builds.
