# Folder Renaming Summary: e2e → e2e-tests

## What Changed

Renamed the Playwright end-to-end tests directory from `e2e/` to `e2e-tests/` for better clarity.

## Why?

- **E2E** = "End-to-End" testing (testing complete user workflows)
- **e2e-tests** is more explicit and self-documenting
- Matches user preference for clearer naming

## Files Updated

### Configuration Files

- ✅ [playwright.config.js](playwright.config.js)
  - `testDir: './e2e-tests/tests'`
  - `globalSetup: './e2e-tests/setup.js'`

- ✅ [package.json](package.json)
  - All test:playwright:\* scripts updated

- ✅ [.eslintignore](.eslintignore)
  - `/e2e-tests/` instead of `/e2e/`

### Documentation Files

- ✅ [TESTING.md](TESTING.md) - Complete testing guide
- ✅ [TESTING_QUICKSTART.md](TESTING_QUICKSTART.md) - Quick start guide
- ✅ [TESTING_SETUP_SUMMARY.md](TESTING_SETUP_SUMMARY.md) - Setup summary
- ✅ [tests/README.md](tests/README.md) - Tests directory guide
- ✅ [tests/TEST_COMMANDS_REFERENCE.md](tests/TEST_COMMANDS_REFERENCE.md) - Command reference
- ✅ [e2e-tests/README.md](e2e-tests/README.md) - E2E tests guide (enhanced with explanation)

### Test Files

- ✅ All test files in `e2e-tests/tests/` updated with correct require paths

## New Directory Structure

```
client/
├── e2e-tests/              # Playwright End-to-End Tests
│   ├── fixtures/           # Custom test fixtures
│   │   └── base.js        # enginePage, authHelpers, waitHelpers
│   ├── helpers/           # Test utilities
│   │   └── test-selectors.js  # Centralized selectors
│   ├── tests/             # Test files by engine
│   │   ├── ad/
│   │   ├── graph-explorer/
│   │   ├── ldap-explorer/
│   │   ├── m365/
│   │   └── shared/
│   ├── setup.js           # Global setup
│   └── README.md          # E2E testing guide
│
└── tests/                  # Ember Tests (Unit + Integration)
    ├── unit/
    ├── integration/
    └── helpers/
```

## Commands (Unchanged)

All npm commands remain the same:

```bash
# All E2E tests
npm run test:playwright

# UI mode
npm run test:playwright:ui

# Engine-specific
npm run test:playwright:ad
npm run test:playwright:graph
npm run test:playwright:ldap
npm run test:playwright:m365
```

## Terminology Clarification

| Term            | Meaning                        | Usage                                 |
| --------------- | ------------------------------ | ------------------------------------- |
| **E2E**         | End-to-End                     | Complete user workflows, real browser |
| **Unit**        | Isolated function/method tests | Fast, no browser                      |
| **Integration** | Component interaction tests    | Medium speed, no browser              |
| **Acceptance**  | Same as E2E                    | Synonym for end-to-end                |

## Verification

To verify everything works:

```bash
# 1. Check Playwright config is valid
npx playwright test --list

# 2. Run Ember tests (should work fine)
npm run test:ember

# 3. Run Playwright tests
npm run test:playwright:ui
```

All paths and references have been updated. The setup is ready to use! ✅

---

**Summary:** `e2e/` → `e2e-tests/` for clearer, more self-documenting directory naming.
