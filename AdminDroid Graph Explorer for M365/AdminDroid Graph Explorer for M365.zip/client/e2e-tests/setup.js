/**
 * Playwright Global Setup
 *
 * This file runs once before all tests.
 * Use it for global authentication, database seeding, etc.
 */

module.exports = async (config) => {
  console.log('🚀 Starting Playwright global setup...');

  // Add any global setup here
  // For example:
  // - Set up test database
  // - Create test users
  // - Configure environment variables

  console.log('✅ Playwright global setup complete');
};
