const { test } = require('../../fixtures/base');
const { expect } = require('@playwright/test');
const selectors = require('../../helpers/test-selectors');

/**
 * Acceptance Test: Graph Explorer Engine - API Requests
 *
 * Tests the Microsoft Graph API explorer functionality:
 * 1. Selecting HTTP methods
 * 2. Entering API endpoints
 * 3. Sending requests
 * 4. Viewing responses
 */

test.describe('Graph Explorer - API Requests', () => {
  test.beforeEach(async ({ enginePage }) => {
    // Navigate to Graph Explorer engine
    await enginePage.goto('graph-explorer');
    await enginePage.waitForEmber();
  });

  test('should load Graph Explorer successfully', async ({ page }) => {
    // Verify we're on the Graph Explorer engine
    expect(page.url()).toContain('/graph-explorer');

    // Verify key components are visible
    await expect(page.locator(selectors.graphExplorer.sidebar)).toBeVisible();
    await expect(page.locator(selectors.graphExplorer.methodSelect)).toBeVisible();
    await expect(page.locator(selectors.graphExplorer.urlInput)).toBeVisible();
  });

  test('should display sample queries', async ({ page }) => {
    // Click on sample queries tab/section
    const sampleQueriesButton = page.locator(selectors.graphExplorer.sampleQueries);

    if (await sampleQueriesButton.isVisible()) {
      await sampleQueriesButton.click();

      // Verify sample queries are displayed
      const sampleQueryItems = page.locator('[data-test-sample-query-item]');
      const count = await sampleQueryItems.count();

      expect(count).toBeGreaterThan(0);
      console.log(`✅ Found ${count} sample queries`);
    }
  });

  test('should allow selecting HTTP method', async ({ page }) => {
    const methods = ['GET', 'POST', 'PATCH', 'DELETE'];

    // If your method selector is a dropdown
    const methodSelect = page.locator(selectors.graphExplorer.methodSelect);

    if (await methodSelect.isVisible()) {
      await methodSelect.click();

      // Select GET method
      await page.click('text=GET');

      console.log('✅ HTTP method selected successfully');
    }
  });

  test('should accept API endpoint URL', async ({ page }) => {
    const testEndpoint = '/v1.0/me';

    await page.fill(selectors.graphExplorer.urlInput, testEndpoint);

    const inputValue = await page.inputValue(selectors.graphExplorer.urlInput);
    expect(inputValue).toBe(testEndpoint);
  });

  test('should send GET request and display response', async ({ page, waitHelpers }) => {
    // Note: This requires authentication
    const endpoint = '/v1.0/me';

    // Enter endpoint
    await page.fill(selectors.graphExplorer.urlInput, endpoint);

    // Click send button
    await page.click(selectors.graphExplorer.sendButton);

    // Wait for response
    await waitHelpers.waitForNoLoading();

    // Verify response section is visible
    await expect(page.locator(selectors.graphExplorer.responseSection)).toBeVisible({ timeout: 15000 });

    console.log('✅ API request sent and response received');
  });

  test('should switch between JSON and table view', async ({ page }) => {
    // First send a request that returns data
    // Then test view switching

    const jsonViewButton = page.locator('[data-test-view-json]');
    const tableViewButton = page.locator('[data-test-view-table]');

    if (await jsonViewButton.isVisible()) {
      // Switch to JSON view
      await jsonViewButton.click();
      await expect(page.locator(selectors.graphExplorer.jsonView)).toBeVisible();

      // Switch to table view
      if (await tableViewButton.isVisible()) {
        await tableViewButton.click();
        await expect(page.locator(selectors.graphExplorer.tableView)).toBeVisible();
      }

      console.log('✅ View switching works correctly');
    }
  });

  test('should save query to history', async ({ page, waitHelpers }) => {
    const endpoint = '/v1.0/users';

    // Send a request
    await page.fill(selectors.graphExplorer.urlInput, endpoint);
    await page.click(selectors.graphExplorer.sendButton);
    await waitHelpers.waitForNoLoading();

    // Navigate to history
    const historyButton = page.locator(selectors.graphExplorer.historyExplorer);

    if (await historyButton.isVisible()) {
      await historyButton.click();

      // Verify the query appears in history
      const historyItems = page.locator('[data-test-history-item]');
      const count = await historyItems.count();

      expect(count).toBeGreaterThan(0);
      console.log(`✅ Query saved to history (${count} items)`);
    }
  });

  test('should handle API errors gracefully', async ({ page, waitHelpers }) => {
    // Send a request to an invalid endpoint
    const invalidEndpoint = '/v1.0/invalid-endpoint-that-does-not-exist';

    await page.fill(selectors.graphExplorer.urlInput, invalidEndpoint);
    await page.click(selectors.graphExplorer.sendButton);

    await waitHelpers.waitForNoLoading();

    // Should display error message
    const errorMessage = page.locator(selectors.common.errorMessage);
    if (await errorMessage.isVisible()) {
      console.log('✅ Error message displayed correctly');
    }
  });

  test('should display required permissions', async ({ page }) => {
    // Some endpoints show required permissions
    const permissionsSection = page.locator('[data-test-required-permissions]');

    if (await permissionsSection.isVisible()) {
      const permissionText = await permissionsSection.textContent();
      expect(permissionText).toBeTruthy();
      console.log(`✅ Permissions displayed: ${permissionText}`);
    }
  });
});
