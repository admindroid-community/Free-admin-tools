const { test } = require('../../fixtures/base');
const { expect } = require('@playwright/test');
const selectors = require('../../helpers/test-selectors');

/**
 * Acceptance Test: LDAP Explorer - Tree Navigation
 *
 * Tests the LDAP directory tree navigation:
 * 1. Loading the tree view
 * 2. Expanding/collapsing nodes
 * 3. Viewing object details
 * 4. Searching and filtering
 */

test.describe('LDAP Explorer - Tree Navigation', () => {
  test.beforeEach(async ({ enginePage }) => {
    // Navigate to LDAP Explorer engine
    await enginePage.goto('ldap-explorer');
    await enginePage.waitForEmber();
  });

  test('should load LDAP Explorer successfully', async ({ page }) => {
    // Verify we're on the LDAP Explorer engine
    expect(page.url()).toContain('/ldap-explorer');

    // Verify tree view is visible
    await expect(page.locator(selectors.ldapExplorer.treeView)).toBeVisible();
  });

  test('should display LDAP directory tree', async ({ page, waitHelpers }) => {
    // Wait for tree to load
    await waitHelpers.waitForNoLoading();

    // Verify tree nodes are present
    const treeNodes = page.locator('[data-test-tree-node]');
    const count = await treeNodes.count();

    if (count > 0) {
      console.log(`✅ Tree loaded with ${count} nodes`);
      expect(count).toBeGreaterThan(0);
    } else {
      console.log('⚠️  No tree nodes found - may require authentication or connection');
    }
  });

  test('should expand and collapse tree nodes', async ({ page }) => {
    // Find an expandable node
    const expandableNode = page.locator('[data-test-tree-node-expandable]').first();

    if (await expandableNode.isVisible()) {
      // Expand the node
      await expandableNode.click();

      // Wait for child nodes to appear
      await page.waitForTimeout(500);

      // Verify children are visible
      const childNodes = page.locator('[data-test-tree-node-child]');
      const childCount = await childNodes.count();

      console.log(`✅ Node expanded, showing ${childCount} children`);

      // Collapse the node
      await expandableNode.click();
      await page.waitForTimeout(500);

      console.log('✅ Node collapsed successfully');
    }
  });

  test('should display object details when node is selected', async ({ page, waitHelpers }) => {
    // Click on a tree node
    const treeNode = page.locator('[data-test-tree-node]').first();

    if (await treeNode.isVisible()) {
      await treeNode.click();

      // Wait for details to load
      await waitHelpers.waitForNoLoading();

      // Verify object details panel is visible
      await expect(page.locator(selectors.ldapExplorer.objectDetails)).toBeVisible({ timeout: 5000 });

      console.log('✅ Object details displayed');
    }
  });

  test('should filter tree nodes by search', async ({ page, waitHelpers }) => {
    const searchInput = page.locator(selectors.ldapExplorer.searchInput);

    if (await searchInput.isVisible()) {
      const searchTerm = 'user';

      // Enter search term
      await searchInput.fill(searchTerm);

      // Wait for filtering
      await waitHelpers.waitForNoLoading();

      // Verify filtered results
      const visibleNodes = page.locator('[data-test-tree-node]:visible');
      const count = await visibleNodes.count();

      console.log(`✅ Search filtered to ${count} results for "${searchTerm}"`);
    }
  });

  test('should display object attributes in table', async ({ page, waitHelpers }) => {
    // Select a node
    const treeNode = page.locator('[data-test-tree-node]').first();

    if (await treeNode.isVisible()) {
      await treeNode.click();
      await waitHelpers.waitForNoLoading();

      // Verify attribute table is visible
      const attributeTable = page.locator('[data-test-attribute-table]');

      if (await attributeTable.isVisible()) {
        const rows = page.locator('[data-test-attribute-row]');
        const rowCount = await rows.count();

        console.log(`✅ Attribute table showing ${rowCount} attributes`);
        expect(rowCount).toBeGreaterThan(0);
      }
    }
  });

  test('should filter table columns', async ({ page }) => {
    const columnFilterButton = page.locator(selectors.ldapExplorer.columnFilter);

    if (await columnFilterButton.isVisible()) {
      await columnFilterButton.click();

      // Wait for filter popup
      await page.waitForSelector('[data-test-column-filter-popup]', { timeout: 2000 }).catch(() => {
        console.log('⚠️  Column filter popup not found');
      });

      // Toggle some columns
      const columnCheckboxes = page.locator('[data-test-column-checkbox]');
      const checkboxCount = await columnCheckboxes.count();

      if (checkboxCount > 0) {
        await columnCheckboxes.first().click();
        console.log('✅ Column filter working');
      }
    }
  });

  test('should handle connection errors gracefully', async ({ page }) => {
    // If not connected to LDAP server, should show appropriate message
    const errorMessage = page.locator('[data-test-connection-error]');
    const connectionPrompt = page.locator('[data-test-connection-prompt]');

    // Either tree is loaded, or there's a connection message
    const hasTree = await page.locator(selectors.ldapExplorer.treeView).isVisible();
    const hasError = await errorMessage.isVisible();
    const hasPrompt = await connectionPrompt.isVisible();

    expect(hasTree || hasError || hasPrompt).toBeTruthy();
    console.log('✅ Connection state handled appropriately');
  });

  test('should support keyboard navigation in tree', async ({ page }) => {
    // Focus on tree
    const treeView = page.locator(selectors.ldapExplorer.treeView);

    if (await treeView.isVisible()) {
      await treeView.focus();

      // Try arrow key navigation
      await page.keyboard.press('ArrowDown');
      await page.waitForTimeout(200);
      await page.keyboard.press('ArrowUp');

      console.log('✅ Keyboard navigation tested');
    }
  });
});
