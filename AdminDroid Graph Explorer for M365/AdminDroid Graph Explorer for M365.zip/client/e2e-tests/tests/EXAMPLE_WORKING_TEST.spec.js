const { test } = require('../fixtures/base');
const { expect } = require('@playwright/test');

/**
 * WORKING Example: Basic Navigation Test
 *
 * This test works WITHOUT data-test attributes.
 * It only checks URLs and basic page loading.
 *
 * Run with: npm run test:playwright:ui
 */

test.describe('Basic Navigation (Working Example)', () => {
  test('can navigate to all engine URLs', async ({ page }) => {
    const engines = [
      { name: 'AD', url: '/ad' },
      { name: 'Graph Explorer', url: '/graph-explorer' },
      { name: 'LDAP Explorer', url: '/ldap-explorer' },
      { name: 'M365', url: '/m365' },
    ];

    for (const engine of engines) {
      console.log(`Testing ${engine.name}...`);

      await page.goto(engine.url);
      await page.waitForLoadState('networkidle');

      // Verify we're on the correct URL
      expect(page.url()).toContain(engine.url);

      console.log(`✅ ${engine.name} loaded successfully`);
    }
  });

  test('homepage loads', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Check that we're on some valid page (not 404)
    const title = await page.title();
    expect(title).toBeTruthy();

    console.log(`✅ Homepage loaded with title: "${title}"`);
  });

  test('can navigate between engines', async ({ page }) => {
    // Go to AD
    await page.goto('/ad');
    await page.waitForLoadState('networkidle');
    expect(page.url()).toContain('/ad');

    // Go to M365
    await page.goto('/m365');
    await page.waitForLoadState('networkidle');
    expect(page.url()).toContain('/m365');

    // Go to Graph Explorer
    await page.goto('/graph-explorer');
    await page.waitForLoadState('networkidle');
    expect(page.url()).toContain('/graph-explorer');

    console.log('✅ Can navigate between all engines');
  });
});
