const { test } = require('../../fixtures/base');
const { expect } = require('@playwright/test');

/**
 * Acceptance Test Example: Cross-Engine Navigation
 *
 * Acceptance tests should:
 * - Test complete user workflows
 * - Test navigation between engines
 * - Test real user interactions
 * - Run in a real browser
 * - Test end-to-end functionality
 */

test.describe('Engine Navigation', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to the application root
    await page.goto('/');
  });

  test('should navigate to all four engines', async ({ enginePage }) => {
    const engines = ['ad', 'graph-explorer', 'ldap-explorer', 'm365'];

    for (const engine of engines) {
      await enginePage.goto(engine);

      // Wait for the engine to load
      await enginePage.waitForEmber();

      // Verify we're on the correct engine by checking URL
      expect(enginePage.page.url()).toContain(`/${engine}`);

      console.log(`✅ Successfully navigated to ${engine} engine`);
    }
  });

  test('should maintain state when switching between engines', async ({ enginePage, page }) => {
    // Navigate to AD engine
    await enginePage.goto('ad');

    // Perform some action (e.g., enter text)
    const testInput = 'Test query for AD';
    await page.fill('[data-test-prompt-input]', testInput);

    // Navigate to another engine
    await enginePage.goto('m365');

    // Navigate back to AD
    await enginePage.goto('ad');

    // Verify state is maintained (or reset, depending on your requirements)
    // This is just an example - adjust based on your actual behavior
    const inputValue = await page.inputValue('[data-test-prompt-input]');
    console.log(`Input value after navigation: ${inputValue}`);
  });

  test('should handle direct URL access to engines', async ({ page, enginePage }) => {
    const engines = [
      { name: 'ad', url: '/ad' },
      { name: 'graph-explorer', url: '/graph-explorer' },
      { name: 'ldap-explorer', url: '/ldap-explorer' },
      { name: 'm365', url: '/m365' },
    ];

    for (const engine of engines) {
      await page.goto(engine.url);
      await enginePage.waitForEmber();

      // Verify the engine loaded correctly
      expect(page.url()).toContain(engine.url);

      console.log(`✅ Direct access to ${engine.name} successful`);
    }
  });

  test('should display proper 404 for invalid routes', async ({ page }) => {
    await page.goto('/invalid-route');

    // Check for 404 page or redirect to home
    const url = page.url();
    const has404 = await page.locator('text=/not found|404/i').count() > 0;
    const redirectedHome = url.endsWith('/');

    expect(has404 || redirectedHome).toBeTruthy();
  });
});
