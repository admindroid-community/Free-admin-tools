# End-to-End Tests (Playwright)

This directory contains Playwright end-to-end (E2E) tests for all 4 engines.

**Note:** These files are kept separate from `tests/` directory to avoid Ember's build process trying to compile them (they use Node.js CommonJS syntax).

## What is E2E Testing?

**End-to-End (E2E) testing** means testing complete user workflows from start to finish in a real browser, simulating how actual users interact with your application.

## Structure

```
e2e-tests/
├── fixtures/          # Custom Playwright fixtures
│   └── base.js       # enginePage, authHelpers, waitHelpers
├── helpers/          # Test utilities
│   └── test-selectors.js  # Centralized selectors for all engines
├── tests/            # Test files organized by engine
│   ├── ad/          # Active Directory tests
│   ├── graph-explorer/  # Microsoft Graph Explorer tests
│   ├── ldap-explorer/   # LDAP Explorer tests
│   ├── m365/        # Microsoft 365 tests
│   └── shared/      # Cross-engine navigation tests
└── setup.js          # Global setup/teardown
```

## Running Tests

```bash
# All E2E tests
npm run test:playwright

# With UI (recommended for development)
npm run test:playwright:ui

# Specific engine tests
npm run test:playwright:ad         # Active Directory
npm run test:playwright:graph      # Graph Explorer
npm run test:playwright:ldap       # LDAP Explorer
npm run test:playwright:m365       # Microsoft 365

# Debugging
npm run test:playwright:headed     # See browser
npm run test:playwright:debug      # Debug mode

# View report
npm run test:playwright:report
```

## Writing Tests

Example test structure:

```javascript
// e2e-tests/tests/ad/my-test.spec.js
const { test } = require('../../fixtures/base');
const { expect } = require('@playwright/test');
const selectors = require('../../helpers/test-selectors');

test.describe('My Feature', () => {
  test('should work end-to-end', async ({ enginePage, page }) => {
    // Navigate to engine
    await enginePage.goto('ad');

    // Interact with page
    await page.fill(selectors.ad.promptInput, 'Test query');
    await page.click(selectors.ad.submitButton);

    // Verify results
    await expect(page.locator(selectors.ad.responseBox)).toBeVisible();
  });
});
```

## Available Fixtures

### `enginePage`
Helper for navigating between engines:
```javascript
await enginePage.goto('ad');              // Navigate to AD
await enginePage.goto('graph-explorer');  // Navigate to Graph Explorer
await enginePage.goto('ldap-explorer');   // Navigate to LDAP
await enginePage.goto('m365');            // Navigate to M365
await enginePage.waitForEmber();          // Wait for Ember to be ready
```

### `authHelpers`
Authentication utilities:
```javascript
await authHelpers.login(username, password);  // Login
await authHelpers.isLoggedIn();              // Check login status
```

### `waitHelpers`
Smart waiting utilities:
```javascript
await waitHelpers.waitForApiResponse('/api/users');  // Wait for API
await waitHelpers.waitForNoLoading();               // Wait for loading to finish
```

## Test Selectors

All selectors are centralized in `helpers/test-selectors.js`. Use them instead of hardcoding selectors:

```javascript
const selectors = require('../../helpers/test-selectors');

// Good - uses centralized selector
await page.click(selectors.ad.submitButton);

// Bad - hardcoded selector
await page.click('[data-test-submit-button]');
```

## Best Practices

1. **Test user workflows, not implementation details**
   - ✅ Test: "User can submit a prompt and see results"
   - ❌ Test: "SubmitButton component calls handleSubmit method"

2. **Use data-test attributes** in your components
   ```handlebars
   <button data-test-submit-button {{on "click" @onSubmit}}>
     Submit
   </button>
   ```

3. **Wait properly** - don't use arbitrary timeouts
   ```javascript
   // ✅ Good - wait for element
   await expect(page.locator('[data-test-result]')).toBeVisible();

   // ❌ Bad - arbitrary timeout
   await page.waitForTimeout(3000);
   ```

4. **Keep tests independent** - each test should work in isolation

5. **Use descriptive test names**
   ```javascript
   // ✅ Good
   test('should display error when API fails', async () => {});

   // ❌ Bad
   test('test1', async () => {});
   ```

## Documentation

For complete testing documentation, see:
- [../TESTING.md](../TESTING.md) - Complete testing guide
- [../TESTING_QUICKSTART.md](../TESTING_QUICKSTART.md) - 5-minute quick start
- [../tests/README.md](../tests/README.md) - Tests directory overview

## Need Help?

- Check example tests in `tests/` subdirectories
- Review `fixtures/base.js` for available helpers
- Check `helpers/test-selectors.js` for available selectors
- See [Playwright documentation](https://playwright.dev/)

---

Happy E2E Testing! 🧪✨
