const { test: base } = require('@playwright/test');

/**
 * Base Fixtures for MCP Tool Testing
 *
 * These fixtures provide reusable functionality across all tests
 */

const test = base.extend({
  /**
   * Navigate to a specific engine
   * Usage: await enginePage.goto('ad')
   */
  enginePage: async ({ page }, use) => {
    const engineHelpers = {
      /**
       * Navigate to specific engine
       * @param {string} engine - 'ad', 'graph-explorer', 'ldap-explorer', or 'm365'
       */
      async goto(engine) {
        const engineRoutes = {
          'ad': '/ad',
          'graph-explorer': '/graph-explorer',
          'ldap-explorer': '/ldap-explorer',
          'm365': '/m365',
        };

        const route = engineRoutes[engine];
        if (!route) {
          throw new Error(`Unknown engine: ${engine}. Valid engines: ${Object.keys(engineRoutes).join(', ')}`);
        }

        await page.goto(route);
        // Wait for engine to be fully loaded
        await page.waitForLoadState('networkidle');
      },

      /**
       * Wait for Ember to be ready
       */
      async waitForEmber() {
        // Wait for Ember to be available (optional - may not be exposed in production)
        try {
          await page.waitForFunction(() => {
            return window.Ember !== undefined;
          }, { timeout: 5000 });
        } catch (e) {
          // Ember might not be exposed globally, that's okay
          console.log('Note: window.Ember not detected, continuing anyway');
        }
        // Just wait for load state as backup
        await page.waitForLoadState('domcontentloaded');
      },

      /**
       * Get the page instance
       */
      get page() {
        return page;
      }
    };

    await use(engineHelpers);
  },

  /**
   * Authentication helpers
   */
  authHelpers: async ({ page }, use) => {
    const helpers = {
      /**
       * Login with credentials
       * Adjust this based on your authentication flow
       */
      async login(username, password) {
        // TODO: Implement your actual login flow
        // Example:
        // await page.fill('[data-test-username]', username);
        // await page.fill('[data-test-password]', password);
        // await page.click('[data-test-login-button]');
        // await page.waitForURL('**/dashboard');
        console.log('⚠️  Login helper needs to be implemented for your auth flow');
      },

      /**
       * Check if user is logged in
       */
      async isLoggedIn() {
        // TODO: Implement your actual login check
        // Example: return await page.locator('[data-test-user-menu]').isVisible();
        return false;
      }
    };

    await use(helpers);
  },

  /**
   * Wait helpers for async operations
   */
  waitHelpers: async ({ page }, use) => {
    const helpers = {
      /**
       * Wait for API response
       */
      async waitForApiResponse(urlPattern) {
        return await page.waitForResponse(response =>
          response.url().includes(urlPattern) && response.status() === 200
        );
      },

      /**
       * Wait for loading to complete
       */
      async waitForNoLoading() {
        await page.waitForSelector('[data-test-loading]', { state: 'hidden', timeout: 10000 }).catch(() => {
          // Loading indicator might not exist, that's okay
        });
      }
    };

    await use(helpers);
  }
});

module.exports = { test };
