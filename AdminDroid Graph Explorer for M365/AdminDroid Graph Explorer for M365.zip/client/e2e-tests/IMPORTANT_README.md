# IMPORTANT: E2E Tests Setup Required

## Current Status: Example Tests Only ⚠️

The Playwright E2E tests in this directory are **example tests** that demonstrate how to write end-to-end tests for your application.

**These tests will fail or skip until you add data-test attributes to your components.**

## Why Tests May Fail

The example tests look for `data-test-*` attributes that don't exist yet in your components:

```javascript
// Test looks for this:
await page.click('[data-test-submit-button]');

// But your component might have:
<button class="submit-btn">Submit</button>

// It should have:
<button data-test-submit-button class="submit-btn">Submit</button>
```

## How to Make Tests Work

### Step 1: Add data-test Attributes to Your Components

Update your components to include `data-test-*` attributes:

```handlebars
{{!-- Before --}}
<div class="prompt-box">
  <input class="prompt-input" />
  <button class="submit-button" {{on "click" @onSubmit}}>Submit</button>
  <div class="response-box">{{@response}}</div>
</div>

{{!-- After --}}
<div data-test-prompt-box class="prompt-box">
  <input data-test-prompt-input class="prompt-input" />
  <button data-test-submit-button class="submit-button" {{on "click" @onSubmit}}>
    Submit
  </button>
  <div data-test-response-box class="response-box">{{@response}}</div>
</div>
```

### Step 2: Update Test Selectors

Update `e2e-tests/helpers/test-selectors.js` to match your actual component structure.

### Step 3: Customize Tests

Modify the example tests to match your actual application behavior:
- Update URLs and routes
- Update expected text and elements
- Update workflows to match your features

## Running Tests Now

You can still run the tests to see the structure:

```bash
# View tests in UI (won't interact successfully but shows structure)
npm run test:playwright:ui

# Run tests (many will fail/skip)
npm run test:playwright
```

## Example: Adding data-test to AD Engine

Based on the git status showing changes to `lib/ad/addon/components/prompt-box/`, here's how to add data-test attributes:

```handlebars
{{!-- lib/ad/addon/components/prompt-box.hbs --}}
<div data-test-prompt-box>
  <div data-test-prompt-input-container>
    <textarea
      data-test-prompt-input
      name="tablePrompt"
      {{on "keydown" this.handleKeyDown}}
    >
    </textarea>
  </div>

  <button
    data-test-submit-button
    {{on "click" @handleSubmitChartGeneration}}
  >
    Submit
  </button>

  {{#if @response}}
    <div data-test-response-box>
      {{@response}}
    </div>
  {{/if}}
</div>
```

## What Works Right Now

The following tests should work without modifications:
- **Engine Navigation** - Basic navigation between engines (URLs only)
- **404 Handling** - Invalid route handling

These don't require specific data-test attributes.

## Next Steps

1. **Start small**: Add data-test attributes to one component
2. **Run one test**: Test that specific component with Playwright UI
3. **Iterate**: Gradually add attributes and tests

## Getting Help

- See main [TESTING.md](../TESTING.md) for complete guide
- Check [test-selectors.js](helpers/test-selectors.js) for expected selectors
- Review example tests to understand patterns

---

**Remember**: These are example tests to guide you. Customize them for your actual application!
