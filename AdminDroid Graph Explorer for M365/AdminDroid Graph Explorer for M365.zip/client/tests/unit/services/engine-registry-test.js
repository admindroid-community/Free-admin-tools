import { module, test } from 'qunit';
import { setupTest } from 'community-base-tool/tests/helpers';

module('Unit | Service | engine-registry', function (hooks) {
  setupTest(hooks);

  // TODO: Replace this with your real tests.
  test('it exists', function (assert) {
    let service = this.owner.lookup('service:engine-registry');
    assert.ok(service);
  });
});
