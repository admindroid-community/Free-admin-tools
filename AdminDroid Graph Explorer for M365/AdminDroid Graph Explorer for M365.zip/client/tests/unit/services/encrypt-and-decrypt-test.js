import { module, test } from 'qunit';
import { setupTest } from 'community-base-tool/tests/helpers';

/**
 * Unit Test Example: Testing a Service
 *
 * Service unit tests should:
 * - Test service methods in isolation
 * - Mock external dependencies
 * - Test both success and error cases
 * - Be fast and deterministic
 */

module('Unit | Service | encrypt-and-decrypt', function (hooks) {
  setupTest(hooks);

  test('it exists', function (assert) {
    let service = this.owner.lookup('service:encrypt-and-decrypt');
    assert.ok(service, 'service exists');
  });

  test('encryption method exists', function (assert) {
    let service = this.owner.lookup('service:encrypt-and-decrypt');
    assert.ok(typeof service.encryption === 'function', 'encryption method exists');
  });

  test('encrypts data', function (assert) {
    let service = this.owner.lookup('service:encrypt-and-decrypt');

    // Test data
    const originalData = 'sensitive-data-123';

    // Encrypt the data
    const encrypted = service.encryption(originalData);

    assert.ok(encrypted, 'encryption produces output');
    assert.notEqual(encrypted, originalData, 'encrypted data is different from original');
    assert.ok(encrypted.length > 0, 'encrypted data has content');
  });

  test('produces different output for different inputs', function (assert) {
    let service = this.owner.lookup('service:encrypt-and-decrypt');

    const data1 = 'test-data-1';
    const data2 = 'test-data-2';

    const encrypted1 = service.encryption(data1);
    const encrypted2 = service.encryption(data2);

    assert.notEqual(encrypted1, encrypted2, 'different inputs produce different encrypted outputs');
  });

  test('encrypted output has correct AES format', function (assert) {
    let service = this.owner.lookup('service:encrypt-and-decrypt');

    const data = 'test-data';
    const encrypted = service.encryption(data);

    // AES encryption with crypto-js produces base64 output starting with "U2FsdGVkX1" (base64 for "Salted__")
    // Note: Each encryption produces different output due to random salt (this is correct behavior)
    assert.ok(encrypted.startsWith('U2FsdGVkX1'), 'encrypted data has correct AES format');
    assert.ok(encrypted.length > data.length, 'encrypted data is longer than original');
  });

  test('handles empty string', function (assert) {
    let service = this.owner.lookup('service:encrypt-and-decrypt');

    const encrypted = service.encryption('');
    assert.ok(encrypted, 'handles empty string encryption');
  });
});
