# Quick Test Commands Reference

## Quick Start

```bash
# Run all tests (recommended before committing)
npm test

# Watch mode for Ember tests (TDD)
npm run test:ember:watch

# Debug Playwright tests visually
npm run test:playwright:ui
```

## Ember Tests (Fast - Unit & Integration)

```bash
# All Ember tests
npm run test:ember

# Watch mode (re-runs on file changes)
npm run test:ember:watch

# Only unit tests
npm run test:unit

# Only integration tests
npm run test:integration

# Run tests matching a pattern
ember test --filter="prompt-box"
```

## Playwright Tests (Acceptance/E2E)

### Basic Commands

```bash
# All Playwright tests (headless)
npm run test:playwright

# Show browser (watch tests run)
npm run test:playwright:headed

# Interactive UI mode (BEST for debugging)
npm run test:playwright:ui

# Debug mode (pause on failures)
npm run test:playwright:debug
```

### Engine-Specific Tests

```bash
# Test only AD engine
npm run test:playwright:ad

# Test only Graph Explorer
npm run test:playwright:graph

# Test only LDAP Explorer
npm run test:playwright:ldap

# Test only M365 engine
npm run test:playwright:m365

# Test only navigation/shared
playwright test e2e-tests/tests/shared
```

### Advanced Playwright

```bash
# Run specific test file
playwright test e2e-tests/tests/ad/prompt-workflow.spec.js

# Run tests matching name
playwright test -g "should display response"

# Run in specific browser
playwright test --project=chromium
playwright test --project=firefox
playwright test --project=webkit

# Run tests in parallel
playwright test --workers=4

# Update snapshots (visual regression)
playwright test --update-snapshots

# Show HTML report
npm run test:playwright:report

# Generate trace for debugging
playwright test --trace on
```

## Debugging

### Ember Tests

```bash
# Open browser for debugging
npm run test:ember:watch

# Then in browser console:
debugger; // Add to test code
```

### Playwright Tests

```bash
# Best option: UI mode
npm run test:playwright:ui

# Debug specific test
playwright test --debug e2e-tests/tests/ad/prompt-workflow.spec.js

# Step through with VSCode
# Add to launch.json:
{
  "type": "node",
  "request": "launch",
  "name": "Playwright Debug",
  "program": "${workspaceFolder}/node_modules/@playwright/test/cli.js",
  "args": ["test", "--debug"]
}
```

## Linting

```bash
# Run all linters
npm run lint

# Fix auto-fixable issues
npm run lint:fix

# Individual linters
npm run lint:js
npm run lint:hbs
npm run lint:css
```

## CI/CD Simulation

```bash
# Simulate what CI will run
npm run test:all
```

## Test File Patterns

```bash
# Unit tests
tests/unit/**/*-test.js

# Integration tests
tests/integration/**/*-test.js

# Playwright tests
e2e-tests/tests/**/*.spec.js
```

## Common Patterns

### Run tests before commit
```bash
npm test
```

### TDD workflow (Ember)
```bash
# Terminal 1: Watch tests
npm run test:ember:watch

# Terminal 2: Dev server
npm start
```

### TDD workflow (Playwright)
```bash
# Terminal 1: Dev server
npm start

# Terminal 2: Playwright UI
npm run test:playwright:ui
```

### Debug failing test
```bash
# Ember
npm run test:ember:watch
# Click on failing test in browser, add debugger

# Playwright
npm run test:playwright:ui
# Click on failing test, use time-travel debugging
```

## Environment Variables

```bash
# Run in CI mode
CI=true npm test

# Change test port
PORT=4200 npm start

# Playwright headed mode
HEADED=1 npm run test:playwright

# Playwright debug mode
PWDEBUG=1 npm run test:playwright
```

## Useful Aliases (add to ~/.bashrc or ~/.zshrc)

```bash
alias test="npm test"
alias test:watch="npm run test:ember:watch"
alias test:pw="npm run test:playwright:ui"
alias test:ad="npm run test:playwright:ad"
alias test:graph="npm run test:playwright:graph"
alias test:ldap="npm run test:playwright:ldap"
alias test:m365="npm run test:playwright:m365"
```

## Keyboard Shortcuts (Playwright UI)

- `F5` - Run all tests
- `F6` - Run single test
- `Ctrl+Shift+L` - Toggle watch mode
- `Ctrl+P` - Pick tests to run

## Test Selection Examples

```bash
# Run tests containing "login"
playwright test -g "login"

# Run tests in a specific file
playwright test prompt-workflow.spec.js

# Run tests matching pattern
playwright test e2e-tests/tests/*/navigation*.spec.js

# Run tests in multiple files
playwright test e2e-tests/tests/ad e2e-tests/tests/m365
```

## Reports

```bash
# View last Playwright test report
npm run test:playwright:report

# View trace
npx playwright show-trace trace.zip

# Reports are in:
# - playwright-report/ (HTML)
# - test-results/ (traces, videos, screenshots)
```

## Tips

1. **Use UI mode for Playwright** - It's amazing for debugging
2. **Keep Ember tests in watch mode** - Fast feedback loop
3. **Run unit tests first** - They're fastest
4. **Use specific engine commands** - Faster than running all tests
5. **Check reports after failures** - Playwright captures everything

## Common Issues

### Port already in use
```bash
# Kill process on port 4200
lsof -ti:4200 | xargs kill -9  # Mac/Linux
netstat -ano | findstr :4200   # Windows
```

### Tests timing out
```bash
# Increase timeout
TIMEOUT=60000 npm run test:playwright
```

### Browser not found (Playwright)
```bash
# Install browsers
npx playwright install chromium
```

### Ember test stuck
```bash
# Clear browser cache
# Or restart with: Ctrl+C then npm run test:ember:watch
```

---

**Pro Tip**: Bookmark this file! These commands will become your daily toolkit.
