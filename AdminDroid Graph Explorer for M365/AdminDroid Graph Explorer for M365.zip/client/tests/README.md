# Tests Directory

This directory contains all tests for the MCP Tool project.

## Quick Links

- **[Complete Testing Guide](../TESTING.md)** - Comprehensive guide on writing and running tests
- **[Quick Command Reference](TEST_COMMANDS_REFERENCE.md)** - Fast command lookup

## Directory Structure

```
tests/
├── acceptance/              # Playwright E2E/Acceptance Tests
│   ├── ad/                 # AD engine workflows
│   │   └── prompt-workflow.spec.js
│   ├── graph-explorer/     # Graph API explorer tests
│   │   └── api-requests.spec.js
│   ├── ldap-explorer/      # LDAP navigation tests
│   │   └── tree-navigation.spec.js
│   ├── m365/              # M365 engine tests
│   │   └── prompt-workflow.spec.js
│   └── shared/            # Cross-engine tests
│       └── navigation.spec.js
│
├── integration/            # Ember Integration Tests
│   └── components/
│       └── prompt-box-test.js
│
├── unit/                   # Ember Unit Tests
│   ├── helpers/
│   │   └── get-initials-test.js
│   └── services/
│       └── encrypt-and-decrypt-test.js
│
├── playwright-fixtures/    # Reusable Playwright fixtures
│   └── base.js            # Custom fixtures (enginePage, authHelpers, etc.)
│
├── playwright-helpers/     # Playwright utilities
│   └── test-selectors.js  # Centralized test selectors
│
├── helpers/               # Ember test helpers
├── playwright-setup.js    # Playwright global setup
├── test-helper.js        # Ember test setup
└── index.html            # Ember test runner HTML
```

## Test Types at a Glance

| Type | Tool | Speed | Use For | Example |
|------|------|-------|---------|---------|
| Unit | Ember/QUnit | ⚡ Fast (0.1s) | Pure logic, helpers, utils | Testing `getInitials()` function |
| Integration | Ember/QUnit | 🏃 Medium (1s) | Component rendering & interaction | Testing prompt box component |
| Acceptance | Playwright | 🐢 Slow (10s) | Full user workflows, E2E | Testing complete prompt submission flow |

## Quick Start

### Running Tests

```bash
# Everything (recommended before push)
npm test

# Fast feedback loop (TDD)
npm run test:ember:watch        # Ember tests
npm run test:playwright:ui      # Playwright tests with UI

# Specific test types
npm run test:unit              # Unit tests only
npm run test:integration       # Integration tests only
npm run test:playwright:ad     # AD engine only
```

### Writing Your First Test

#### 1. Unit Test (for functions/helpers)

```javascript
// tests/unit/helpers/my-helper-test.js
import { module, test } from 'qunit';
import { myHelper } from 'community-base-tool/helpers/my-helper';

module('Unit | Helper | my-helper', function () {
  test('it works', function (assert) {
    let result = myHelper(['input']);
    assert.strictEqual(result, 'expected');
  });
});
```

#### 2. Integration Test (for components)

```javascript
// tests/integration/components/my-component-test.js
import { module, test } from 'qunit';
import { setupRenderingTest } from 'community-base-tool/tests/helpers';
import { render } from '@ember/test-helpers';
import { hbs } from 'ember-cli-htmlbars';

module('Integration | Component | my-component', function (hooks) {
  setupRenderingTest(hooks);

  test('it renders', async function (assert) {
    await render(hbs`<MyComponent />`);
    assert.dom('[data-test-my-component]').exists();
  });
});
```

#### 3. Acceptance Test (for workflows)

```javascript
// e2e-tests/tests/ad/my-workflow.spec.js
const { test } = require('../../playwright-fixtures/base');
const { expect } = require('@playwright/test');

test.describe('My Workflow', () => {
  test('it works', async ({ enginePage, page }) => {
    await enginePage.goto('ad');
    await page.click('[data-test-button]');
    await expect(page.locator('[data-test-result]')).toBeVisible();
  });
});
```

## Key Files

### Playwright Configuration
- **[playwright.config.js](../playwright.config.js)** - Main Playwright configuration
- **[playwright-setup.js](playwright-setup.js)** - Global setup/teardown

### Playwright Utilities
- **[base.js](playwright-fixtures/base.js)** - Custom fixtures you can use:
  - `enginePage` - Navigate between engines
  - `authHelpers` - Authentication utilities
  - `waitHelpers` - Smart waiting utilities

- **[test-selectors.js](playwright-helpers/test-selectors.js)** - Centralized selectors for all engines

### Ember Configuration
- **[test-helper.js](test-helper.js)** - Ember test setup
- **[index.html](index.html)** - Test runner page

## Test Examples

We've created example tests for each engine to get you started:

### Ember Examples
- ✅ [Unit test: Helper function](unit/helpers/get-initials-test.js)
- ✅ [Unit test: Service](unit/services/encrypt-and-decrypt-test.js)
- ✅ [Integration test: Component](integration/components/prompt-box-test.js)

### Playwright Examples
- ✅ [Cross-engine navigation](acceptance/shared/navigation.spec.js)
- ✅ [AD engine workflow](acceptance/ad/prompt-workflow.spec.js)
- ✅ [Graph Explorer API requests](acceptance/graph-explorer/api-requests.spec.js)
- ✅ [LDAP tree navigation](acceptance/ldap-explorer/tree-navigation.spec.js)
- ✅ [M365 prompt workflow](acceptance/m365/prompt-workflow.spec.js)

## Best Practices

### 1. Use data-test Attributes

```html
<!-- Good -->
<button data-test-submit-button>Submit</button>

<!-- Bad -->
<button class="btn-primary">Submit</button>
```

### 2. Choose the Right Test Type

- **Unit**: Testing `calculateTotal(items)` ✅
- **Integration**: Testing `<ShoppingCart />` renders items ✅
- **Acceptance**: Testing checkout flow start to finish ✅

### 3. Keep Tests Independent

Each test should work regardless of execution order.

### 4. Use Fixtures and Helpers

```javascript
// Good - uses fixture
test('my test', async ({ enginePage }) => {
  await enginePage.goto('ad');
});

// Bad - duplicated code
test('my test', async ({ page }) => {
  await page.goto('/ad');
  await page.waitForLoadState('networkidle');
});
```

### 5. Test User Behavior, Not Implementation

```javascript
// Good - tests what user sees
assert.dom('[data-test-error]').hasText('Invalid email');

// Bad - tests internal state
assert.equal(this.component.errors.email, 'Invalid email');
```

## Common Patterns

### Waiting for Elements (Playwright)

```javascript
// ✅ Good - wait for visibility
await expect(page.locator('[data-test-result]')).toBeVisible();

// ❌ Bad - arbitrary timeout
await page.waitForTimeout(3000);
```

### Mocking Services (Ember)

```javascript
test('with mocked service', function (assert) {
  let authService = this.owner.lookup('service:auth');
  authService.set('currentUser', { name: 'Test User' });

  // Test with mocked service
});
```

### Using Custom Selectors (Playwright)

```javascript
const selectors = require('../../playwright-helpers/test-selectors');

// Good - use centralized selectors
await page.click(selectors.ad.submitButton);

// Bad - inline selectors
await page.click('[data-test-submit-button]');
```

## Debugging Tips

### Ember Tests

1. Open browser dev tools during `npm run test:ember:watch`
2. Add `debugger;` in your test
3. Check console for errors
4. Use QUnit UI to filter tests

### Playwright Tests

1. **Best**: Use `npm run test:playwright:ui` - time-travel debugging!
2. Use `await page.pause()` to pause execution
3. Check screenshots in `test-results/` after failures
4. View traces: `npx playwright show-trace trace.zip`

## Coverage

To check test coverage:

```bash
# Ember coverage (if configured)
COVERAGE=true npm run test:ember

# View coverage report
open coverage/index.html
```

## CI/CD

Tests run automatically on:
- Pull requests
- Commits to main/master
- Scheduled nightly builds

See `.github/workflows/test.yml` for configuration.

## Need Help?

1. **Check examples** - Look at existing test files
2. **Read guides**:
   - [Complete Testing Guide](../TESTING.md)
   - [Command Reference](TEST_COMMANDS_REFERENCE.md)
3. **Check documentation**:
   - [Ember Testing Guide](https://guides.emberjs.com/release/testing/)
   - [Playwright Docs](https://playwright.dev/)
4. **Ask the team** - We're here to help!

## Contributing

When adding new features:

1. ✅ Write unit tests for utilities/services
2. ✅ Write integration tests for components
3. ✅ Write acceptance tests for user workflows
4. ✅ Update selectors in `test-selectors.js`
5. ✅ Run all tests before submitting PR

---

**Happy Testing!** 🧪✨

Remember: Tests are documentation that never lies. Write them well, and they'll save you time debugging later.
