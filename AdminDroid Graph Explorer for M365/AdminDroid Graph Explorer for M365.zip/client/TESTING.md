# Testing Guide - MCP Tool

This guide explains the hybrid testing approach for the MCP Tool project with 4 Ember engines (AD, Graph Explorer, LDAP Explorer, and M365).

## Table of Contents

1. [Testing Philosophy](#testing-philosophy)
2. [Test Types](#test-types)
3. [Running Tests](#running-tests)
4. [Writing Tests](#writing-tests)
5. [Best Practices](#best-practices)
6. [CI/CD Integration](#cicd-integration)
7. [Troubleshooting](#troubleshooting)

## Testing Philosophy

We use a **hybrid testing approach** that combines:

- **Ember Testing (QUnit)** for unit and integration tests (fast, isolated)
- **Playwright** for acceptance/E2E tests (realistic, full-stack)

### Why Hybrid?

| Test Type | Tool | Why |
|-----------|------|-----|
| Unit Tests | Ember/QUnit | Fast, isolated, great for logic testing |
| Integration Tests | Ember/QUnit | Fast, good for component testing |
| Acceptance Tests | Playwright | Real browser, cross-engine flows, visual testing |

## Test Types

### 1. Unit Tests (Ember/QUnit)

**Purpose**: Test pure logic in isolation

**What to test**:
- Helpers
- Utilities
- Service methods
- Computed properties
- Actions without side effects

**Location**: `tests/unit/`

**Example**:
```javascript
// tests/unit/helpers/get-initials-test.js
test('it extracts initials from a full name', function (assert) {
  let result = getInitials(['John Doe']);
  assert.strictEqual(result, 'JD');
});
```

**Speed**: ~0.1s per test

### 2. Integration Tests (Ember/QUnit)

**Purpose**: Test component rendering and interactions

**What to test**:
- Component rendering
- User interactions (click, input)
- Component state changes
- Component integration with services (mocked)

**Location**: `tests/integration/`

**Example**:
```javascript
// tests/integration/components/prompt-box-test.js
test('it accepts text input', async function (assert) {
  await render(hbs`<PromptBox />`);
  await fillIn('[data-test-prompt-input]', 'Test text');
  assert.dom('[data-test-prompt-input]').hasValue('Test text');
});
```

**Speed**: ~0.5-2s per test

### 3. Acceptance Tests (Playwright)

**Purpose**: Test complete user workflows in real browser

**What to test**:
- Full user flows
- Cross-engine navigation
- Authentication flows
- Multi-step processes
- Visual regression
- Performance

**Location**: `e2e-tests/tests/`

**Example**:
```javascript
// e2e-tests/tests/ad/prompt-workflow.spec.js
test('should submit a prompt and display results', async ({ enginePage, page }) => {
  await enginePage.goto('ad');
  await page.fill('[data-test-prompt-input]', 'Get all users');
  await page.click('[data-test-submit-button]');
  await expect(page.locator('[data-test-response-box]')).toBeVisible();
});
```

**Speed**: ~5-15s per test

## Running Tests

### All Tests

```bash
# Run both Ember and Playwright tests
npm test

# Run all tests including linting
npm run test:all
```

### Ember Tests

```bash
# Run all Ember tests (unit + integration)
npm run test:ember

# Run Ember tests in watch mode (great for TDD)
npm run test:ember:watch

# Run only unit tests
npm run test:unit

# Run only integration tests
npm run test:integration
```

### Playwright Tests

```bash
# Run all Playwright tests (headless)
npm run test:playwright

# Run with visible browser
npm run test:playwright:headed

# Run with Playwright UI (best for debugging)
npm run test:playwright:ui

# Debug mode (pauses on failures)
npm run test:playwright:debug

# Run tests for specific engine
npm run test:playwright:ad
npm run test:playwright:graph
npm run test:playwright:ldap
npm run test:playwright:m365

# View test report
npm run test:playwright:report
```

## Writing Tests

### Unit Test Template

```javascript
import { module, test } from 'qunit';
import { setupTest } from 'community-base-tool/tests/helpers';

module('Unit | Service | my-service', function (hooks) {
  setupTest(hooks);

  test('it does something', function (assert) {
    let service = this.owner.lookup('service:my-service');
    let result = service.doSomething('input');
    assert.strictEqual(result, 'expected output');
  });
});
```

### Integration Test Template

```javascript
import { module, test } from 'qunit';
import { setupRenderingTest } from 'community-base-tool/tests/helpers';
import { render, click, fillIn } from '@ember/test-helpers';
import { hbs } from 'ember-cli-htmlbars';

module('Integration | Component | my-component', function (hooks) {
  setupRenderingTest(hooks);

  test('it renders', async function (assert) {
    await render(hbs`<MyComponent />`);
    assert.dom('[data-test-my-component]').exists();
  });
});
```

### Acceptance Test Template

```javascript
const { test } = require('../../playwright-fixtures/base');
const { expect } = require('@playwright/test');

test.describe('Feature Name', () => {
  test.beforeEach(async ({ enginePage }) => {
    await enginePage.goto('ad');
  });

  test('should do something', async ({ page }) => {
    await page.click('[data-test-button]');
    await expect(page.locator('[data-test-result]')).toBeVisible();
  });
});
```

## Best Practices

### General

1. **Use data-test attributes** for selectors
   ```html
   <button data-test-submit-button>Submit</button>
   ```

2. **Write descriptive test names**
   - Good: `'should display error message when API fails'`
   - Bad: `'test error'`

3. **Follow AAA pattern** (Arrange, Act, Assert)
   ```javascript
   // Arrange
   await page.goto('/ad');

   // Act
   await page.click('[data-test-button]');

   // Assert
   await expect(page.locator('[data-test-result]')).toBeVisible();
   ```

4. **Keep tests independent** - Each test should work in isolation

### Ember Tests

1. **Mock external dependencies**
   ```javascript
   let authService = this.owner.lookup('service:auth');
   authService.set('isLoggedIn', true);
   ```

2. **Use async/await** for all interactions
   ```javascript
   await click('[data-test-button]');
   await fillIn('[data-test-input]', 'value');
   ```

3. **Test user behavior, not implementation**
   - Good: Test that clicking a button shows a message
   - Bad: Test that a specific function was called

### Playwright Tests

1. **Use fixtures** for common functionality
   ```javascript
   test('my test', async ({ enginePage, waitHelpers }) => {
     await enginePage.goto('ad');
     await waitHelpers.waitForNoLoading();
   });
   ```

2. **Wait for elements properly**
   ```javascript
   // Good
   await expect(page.locator('[data-test-result]')).toBeVisible();

   // Bad
   await page.waitForTimeout(5000);
   ```

3. **Use page object pattern** for complex pages
   ```javascript
   // e2e-tests/helpers/pages/ad-page.js
   class AdPage {
     constructor(page) {
       this.page = page;
       this.promptInput = page.locator('[data-test-prompt-input]');
     }

     async submitPrompt(text) {
       await this.promptInput.fill(text);
       await this.page.click('[data-test-submit-button]');
     }
   }
   ```

## Project Structure

```
tests/
├── acceptance/              # Playwright E2E tests
│   ├── ad/                 # AD engine tests
│   ├── graph-explorer/     # Graph Explorer tests
│   ├── ldap-explorer/      # LDAP Explorer tests
│   ├── m365/              # M365 engine tests
│   └── shared/            # Cross-engine tests
├── integration/            # Ember component tests
│   └── components/
├── unit/                   # Ember unit tests
│   ├── helpers/
│   ├── services/
│   └── utils/
├── playwright-fixtures/    # Playwright fixtures
│   └── base.js
├── playwright-helpers/     # Playwright utilities
│   └── test-selectors.js
└── playwright-setup.js     # Playwright global setup
```

## Decision Matrix: Which Test Type?

| What are you testing? | Test Type | Tool |
|----------------------|-----------|------|
| Pure function/helper | Unit | Ember/QUnit |
| Service method | Unit | Ember/QUnit |
| Component rendering | Integration | Ember/QUnit |
| Component interactions | Integration | Ember/QUnit |
| Single page workflow | Integration | Ember/QUnit |
| Multi-page workflow | Acceptance | Playwright |
| Cross-engine navigation | Acceptance | Playwright |
| Authentication flow | Acceptance | Playwright |
| Visual regression | Acceptance | Playwright |
| Performance | Acceptance | Playwright |

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'

      # Run fast tests first
      - name: Install dependencies
        run: npm install

      - name: Lint
        run: npm run lint

      - name: Unit & Integration Tests
        run: npm run test:ember

      # Run slow tests only if fast tests pass
      - name: Install Playwright Browsers
        run: npx playwright install --with-deps chromium

      - name: Acceptance Tests
        run: npm run test:playwright

      - name: Upload test report
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: playwright-report
          path: playwright-report/
```

## Troubleshooting

### Ember Tests

**Problem**: Tests are slow
- **Solution**: Check for `waitForTimeout()` calls, replace with proper waiters

**Problem**: Tests are flaky
- **Solution**: Use `await` for all async operations, avoid timing assumptions

**Problem**: Component not rendering
- **Solution**: Check that you're using `await render()` and proper template syntax

### Playwright Tests

**Problem**: "Timeout waiting for element"
- **Solution**: Check selector, increase timeout, or ensure element actually appears
  ```javascript
  await expect(page.locator('[data-test]')).toBeVisible({ timeout: 10000 });
  ```

**Problem**: Tests fail in CI but pass locally
- **Solution**: Add `await page.waitForLoadState('networkidle')` before assertions

**Problem**: Authentication required
- **Solution**: Implement `authHelpers.login()` in fixtures or use Playwright's storage state

**Problem**: Server not starting
- **Solution**: Check port 4200 is free, or adjust `playwright.config.js`

## Tips for Success

1. **Start with unit tests** - They're fastest and easiest to write
2. **Use Playwright UI mode** - Great for debugging (`npm run test:playwright:ui`)
3. **Run tests often** - Don't wait until the end
4. **Keep tests simple** - One concept per test
5. **Review test coverage** - Aim for 70%+ on critical paths
6. **Mock external APIs** - Don't depend on external services
7. **Use fixtures** - Reuse common test setup

## Resources

- [Ember Testing Guide](https://guides.emberjs.com/release/testing/)
- [QUnit Documentation](https://qunitjs.com/)
- [Playwright Documentation](https://playwright.dev/)
- [Testing Best Practices](https://kentcdodds.com/blog/common-mistakes-with-react-testing-library)

## Need Help?

- Check test examples in `tests/` directories
- Review `e2e-tests/fixtures/base.js` for available helpers
- Check `e2e-tests/helpers/test-selectors.js` for available selectors
- Ask the team in Slack #testing channel

---

Happy Testing! Remember: Good tests save debugging time later.
