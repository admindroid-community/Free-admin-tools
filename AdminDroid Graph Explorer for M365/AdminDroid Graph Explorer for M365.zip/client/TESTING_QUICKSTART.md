# Testing Quick Start - 5 Minutes to Your First Test

## Step 1: Verify Setup (30 seconds)

```bash
# Check that Playwright is installed
npx playwright --version

# Should show: Version 1.xx.x
```

## Step 2: Run Example Tests (2 minutes)

### Option A: Ember Tests (Fastest)

```bash
# Terminal 1: Start dev server
npm start

# Terminal 2: Run Ember tests
npm run test:ember
```

You should see tests running in the console.

### Option B: Playwright Tests (Visual)

```bash
# This will start the dev server automatically and open Playwright UI
npm run test:playwright:ui
```

Click "Run all" to see tests execute in the browser.

## Step 3: Write Your First Test (2 minutes)

### Easiest: Unit Test

Create a simple helper function:

```javascript
// app/helpers/reverse-string.js
import { helper } from '@ember/component/helper';

export default helper(function reverseString([str]) {
  return str.split('').reverse().join('');
});
```

Create the test:

```javascript
// tests/unit/helpers/reverse-string-test.js
import { module, test } from 'qunit';
import { reverseString } from 'community-base-tool/helpers/reverse-string';

module('Unit | Helper | reverse-string', function () {
  test('it reverses a string', function (assert) {
    let result = reverseString(['hello']);
    assert.strictEqual(result, 'olleh');
  });

  test('it handles empty string', function (assert) {
    let result = reverseString(['']);
    assert.strictEqual(result, '');
  });
});
```

Run it:

```bash
npm run test:ember:watch
```

You should see your tests pass!

## Step 4: Add Test Selectors to Your Components

For components you want to test, add `data-test-*` attributes:

```handlebars
{{!-- app/components/my-button.hbs --}}
<button
  data-test-my-button
  {{on "click" @onClick}}
>
  {{@label}}
</button>
```

## Step 5: Next Steps

Now you're ready! Read the full guides:

1. **[TESTING.md](./TESTING.md)** - Complete testing guide
2. **[tests/README.md](./tests/README.md)** - Test directory overview
3. **[TEST_COMMANDS_REFERENCE.md](./tests/TEST_COMMANDS_REFERENCE.md)** - All commands

## Common Commands Cheat Sheet

```bash
# Development (TDD)
npm run test:ember:watch        # Ember tests, auto-reload
npm run test:playwright:ui      # Playwright with UI

# Run all tests
npm test                        # Ember + Playwright
npm run test:ember             # Ember only
npm run test:playwright        # Playwright only

# Run specific tests
npm run test:unit              # Unit tests only
npm run test:integration       # Integration tests only
npm run test:playwright:ad     # AD engine only
npm run test:playwright:m365   # M365 engine only

# Debugging
npm run test:playwright:headed # See browser
npm run test:playwright:debug  # Debug mode
npm run test:playwright:report # View last report
```

## Test Decision Tree

```
What are you testing?
│
├─ Pure function/calculation?
│  └─ Write UNIT test (Ember)
│     Location: tests/unit/
│
├─ Component rendering/behavior?
│  └─ Write INTEGRATION test (Ember)
│     Location: tests/integration/
│
└─ Complete user workflow?
   └─ Write ACCEPTANCE test (Playwright)
      Location: e2e-tests/tests/
```

## Troubleshooting

### Tests won't run
```bash
# Install dependencies
npm install

# Install Playwright browsers
npx playwright install chromium
```

### Port 4200 in use
```bash
# Find and kill the process
lsof -ti:4200 | xargs kill -9  # Mac/Linux
# Or manually stop the dev server
```

### Playwright tests timeout
```bash
# Make sure dev server is running
npm start

# In another terminal
npm run test:playwright
```

## Examples to Learn From

Check out these example tests:

1. **Unit Test**: [tests/unit/helpers/get-initials-test.js](./tests/unit/helpers/get-initials-test.js)
2. **Integration Test**: [tests/integration/components/prompt-box-test.js](./tests/integration/components/prompt-box-test.js)
3. **Acceptance Test**: [e2e-tests/tests/ad/prompt-workflow.spec.js](./e2e-tests/tests/ad/prompt-workflow.spec.js)

## That's It!

You're now set up and ready to write tests. Happy testing! 🚀

For detailed information, see [TESTING.md](./TESTING.md)
