let IconCollection = [
  {
    name: 'arrow-right-up',
    className: 'custom-icon-arrow-right-up',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'up',
        weight: 4,
      },
      {
        word: 'right',
        weight: 4,
      },
      {
        word: 'arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat',
    className: 'custom-icon-chat',
    keywords: [
      {
        word: 'conversation',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'chat',
        weight: 5,
      },
      {
        word: 'discussion',
        weight: 4,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'talk',
        weight: 4,
      },
      {
        word: 'bot',
        weight: 5,
      },
      {
        word: 'solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-setting',
    className: 'custom-icon-mail-setting',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'setting',
        weight: 4,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'gear',
        weight: 3,
      },
    ],
  },
  {
    name: 'server',
    className: 'custom-icon-server',
    keywords: [
      {
        word: 'host',
        weight: 5,
      },
      {
        word: 'backend',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'multi-tool',
    className: 'custom-icon-multi-tool',
    keywords: [
      {
        word: 'utility',
        weight: 5,
      },
      {
        word: 'configure',
        weight: 4,
      },
      {
        word: 'maintenance',
        weight: 4,
      },
      {
        word: 'tool',
        weight: 4,
      },
      {
        word: 'adjust',
        weight: 3,
      },
      {
        word: 'multi',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'easy-nav',
    className: 'custom-icon-easy-nav',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'interface',
        weight: 4,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'nav',
        weight: 3,
      },
      {
        word: 'easy',
        weight: 3,
      },
      {
        word: 'navigate',
        weight: 4,
      },
      {
        word: 'menu',
        weight: 3,
      },
    ],
  },
  {
    name: 'no-admin',
    className: 'custom-icon-no-admin',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'privilege',
        weight: 4,
      },
      {
        word: 'administrator',
        weight: 5,
      },
      {
        word: 'permission',
        weight: 4,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'admin',
        weight: 5,
      },
      {
        word: 'no',
        weight: 2,
      },
      {
        word: 'delegation',
        weight: 3,
      },
    ],
  },
  {
    name: 'time-manage',
    className: 'custom-icon-time-manage',
    keywords: [
      {
        word: 'arrange',
        weight: 4,
      },
      {
        word: 'manage',
        weight: 4,
      },
      {
        word: 'administration',
        weight: 3,
      },
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'control',
        weight: 3,
      },
      {
        word: 'time',
        weight: 5,
      },
      {
        word: 'planning',
        weight: 4,
      },
      {
        word: 'organize',
        weight: 3,
      },
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
    ],
  },
  {
    name: 'user-friendly',
    className: 'custom-icon-user-friendly',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'friendly',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'emoji',
        weight: 4,
      },
    ],
  },
  {
    name: 'support',
    className: 'custom-icon-support',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'assistance',
        weight: 5,
      },
      {
        word: 'support',
        weight: 5,
      },
      {
        word: 'service',
        weight: 4,
      },
      {
        word: 'help',
        weight: 4,
      },
      {
        word: 'contact',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-quote',
    className: 'custom-icon-get-quote',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'quote',
        weight: 5,
      },
      {
        word: 'dollar',
        weight: 3,
      },
    ],
  },
  {
    name: 'no-key',
    className: 'custom-icon-no-key',
    keywords: [
      {
        word: 'No',
        weight: 3,
      },
      {
        word: 'key',
        weight: 5,
      },
      {
        word: 'block',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-activities-icon',
    className: 'custom-icon-user-activities-icon',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'activities',
        weight: 3,
      },
      {
        word: 'icon',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'fingerprint',
        weight: 5,
      },
      {
        word: 'login',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-storage',
    className: 'custom-icon-cloud-storage',
    keywords: [
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'email',
    className: 'custom-icon-email',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-search',
    className: 'custom-icon-mail-search',
    keywords: [
      {
        word: 'search',
        weight: 5,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'audit',
        weight: 5,
      },
      {
        word: 'magnifying glass',
        weight: 5,
      },
      {
        word: 'lens',
        weight: 5,
      },
    ],
  },
  {
    name: 'queue',
    className: 'custom-icon-queue',
    keywords: [
      {
        word: 'queue',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-sent',
    className: 'custom-icon-mail-sent',
    keywords: [
      {
        word: 'sent',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'arrow up',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-received',
    className: 'custom-icon-mail-received',
    keywords: [
      {
        word: 'received',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'arrow down',
        weight: 5,
      },
    ],
  },
  {
    name: 'usage-icon',
    className: 'custom-icon-usage-icon',
    keywords: [
      {
        word: 'icon',
        weight: 3,
      },
      {
        word: 'usage',
        weight: 3,
      },
    ],
  },
  {
    name: 'insights-icon',
    className: 'custom-icon-insights-icon',
    keywords: [
      {
        word: 'insights',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
    ],
  },
  {
    name: 'bar-pie',
    className: 'custom-icon-bar-pie',
    keywords: [
      {
        word: 'bar',
        weight: 3,
      },
      {
        word: 'pie',
        weight: 3,
      },
    ],
  },
  {
    name: 'plus',
    className: 'custom-icon-plus',
    keywords: [
      {
        word: 'plus',
        weight: 3,
      },
    ],
  },
  {
    name: 'solid-bar',
    className: 'custom-icon-solid-bar',
    keywords: [
      {
        word: 'bar',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
    ],
  },
  {
    name: 'edit',
    className: 'custom-icon-edit',
    keywords: [
      {
        word: 'edit',
        weight: 3,
      },
    ],
  },
  {
    name: 'expand',
    className: 'custom-icon-expand',
    keywords: [
      {
        word: 'expand',
        weight: 3,
      },
    ],
  },
  {
    name: 'analytics-report1',
    className: 'custom-icon-analytics-report1',
    keywords: [
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'insights',
        weight: 3,
      },
      {
        word: 'stats',
        weight: 3,
      },
      {
        word: 'statistics',
        weight: 3,
      },
      {
        word: 'analytics',
        weight: 3,
      },
      {
        word: 'metrics',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'analytics-report2',
    className: 'custom-icon-analytics-report2',
    keywords: [
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'insights',
        weight: 3,
      },
      {
        word: 'stats',
        weight: 3,
      },
      {
        word: 'statistics',
        weight: 3,
      },
      {
        word: 'analytics',
        weight: 3,
      },
      {
        word: 'metrics',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'analytics-report3',
    className: 'custom-icon-analytics-report3',
    keywords: [
      {
        word: 'insights',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'report3',
        weight: 3,
      },
      {
        word: 'statistics',
        weight: 3,
      },
      {
        word: 'analytics',
        weight: 3,
      },
      {
        word: 'metrics',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'mail-protection',
    className: 'custom-icon-mail-protection',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-protection2',
    className: 'custom-icon-mail-protection2',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'protection2',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-protection3',
    className: 'custom-icon-mail-protection3',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'protection3',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'lock',
        weight: 5,
      },
    ],
  },
  {
    name: 'shared-mailbox',
    className: 'custom-icon-shared-mailbox',
    keywords: [
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'shared',
        weight: 3,
      },
      {
        word: 'share',
        weight: 3,
      },
      {
        word: 'forward',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'Transport-Rule-based-Statistics',
    className: 'custom-icon-Transport-Rule-based-Statistics',
    keywords: [
      {
        word: 'based',
        weight: 3,
      },
      {
        word: 'Rule',
        weight: 3,
      },
      {
        word: 'Statistics',
        weight: 3,
      },
      {
        word: 'Transport',
        weight: 3,
      },
    ],
  },
  {
    name: 'Transport-Rule-based-Statistics2',
    className: 'custom-icon-Transport-Rule-based-Statistics2',
    keywords: [
      {
        word: 'based',
        weight: 3,
      },
      {
        word: 'Rule',
        weight: 3,
      },
      {
        word: 'Transport',
        weight: 3,
      },
      {
        word: 'Statistics2',
        weight: 3,
      },
    ],
  },
  {
    name: 'Users-Mail-Protection-Statistics',
    className: 'custom-icon-Users-Mail-Protection-Statistics',
    keywords: [
      {
        word: 'Users',
        weight: 3,
      },
      {
        word: 'Mail',
        weight: 3,
      },
      {
        word: 'Protection',
        weight: 3,
      },
      {
        word: 'Statistics',
        weight: 3,
      },
    ],
  },
  {
    name: 'Users-Mail-Protection-Statistics2',
    className: 'custom-icon-Users-Mail-Protection-Statistics2',
    keywords: [
      {
        word: 'Users',
        weight: 3,
      },
      {
        word: 'Mail',
        weight: 3,
      },
      {
        word: 'Protection',
        weight: 3,
      },
      {
        word: 'Statistics2',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-protection-with-block-symbol',
    className: 'custom-icon-mail-protection-with-block-symbol',
    keywords: [
      {
        word: 'block',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'symbol',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'Users-Mail-Protection-Statistics-with-block-symbol',
    className: 'custom-icon-Users-Mail-Protection-Statistics-with-block-symbol',
    keywords: [
      {
        word: 'block',
        weight: 3,
      },
      {
        word: 'Mail',
        weight: 3,
      },
      {
        word: 'symbol',
        weight: 3,
      },
      {
        word: 'Statistics',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'Users',
        weight: 3,
      },
      {
        word: 'Protection',
        weight: 3,
      },
    ],
  },
  {
    name: 'analytics-report',
    className: 'custom-icon-analytics-report',
    keywords: [
      {
        word: 'report4',
        weight: 3,
      },
      {
        word: 'insights',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'statistics',
        weight: 3,
      },
      {
        word: 'analytics',
        weight: 3,
      },
      {
        word: 'metrics',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'admindroid',
    className: 'custom-icon-admindroid',
    keywords: [
      {
        word: 'admindroid',
        weight: 3,
      },
      {
        word: 'ad',
        weight: 1,
      },
    ],
  },
  {
    name: 'crown',
    className: 'custom-icon-crown',
    keywords: [
      {
        word: 'crown',
        weight: 3,
      },
    ],
  },
  {
    name: 'crown1',
    className: 'custom-icon-crown1',
    keywords: [
      {
        word: 'crown1',
        weight: 3,
      },
    ],
  },
  {
    name: 'Bank-dollar',
    className: 'custom-icon-Bank-dollar',
    keywords: [
      {
        word: 'Bank',
        weight: 3,
      },
      {
        word: 'dollar',
        weight: 3,
      },
    ],
  },
  {
    name: 'secure-credit-card',
    className: 'custom-icon-secure-credit-card',
    keywords: [
      {
        word: 'card',
        weight: 3,
      },
      {
        word: 'Credit',
        weight: 3,
      },
    ],
  },
  {
    name: 'shield-procession',
    className: 'custom-icon-shield-procession',
    keywords: [
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'processing',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
    ],
  },
  {
    name: 'secure-processing',
    className: 'custom-icon-secure-processing',
    keywords: [
      {
        word: 'GDPR',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'processing',
        weight: 3,
      },
    ],
  },
  {
    name: 'medical',
    className: 'custom-icon-medical',
    keywords: [
      {
        word: 'Medical',
        weight: 3,
      },
      {
        word: 'Symbol',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-activity',
    className: 'custom-icon-user-activity',
    keywords: [
      {
        word: 'Heart',
        weight: 3,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'Role',
    className: 'custom-icon-Role',
    keywords: [
      {
        word: 'Role',
        weight: 3,
      },
      {
        word: 'admin',
        weight: 3,
      },
    ],
  },
  {
    name: 'activity-chart',
    className: 'custom-icon-activity-chart',
    keywords: [
      {
        word: 'Antivirus',
        weight: 3,
      },
      {
        word: '',
        weight: 3,
      },
      {
        word: '512',
        weight: 3,
      },
      {
        word: 'Security',
        weight: 3,
      },
      {
        word: '38',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-chart',
    className: 'custom-icon-add-chart',
    keywords: [
      {
        word: 'symbol',
        weight: 3,
      },
      {
        word: 'Add',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'Chart',
        weight: 3,
      },
    ],
  },
  {
    name: 'bar-chart-horizontal',
    className: 'custom-icon-bar-chart-horizontal',
    keywords: [
      {
        word: 'view',
        weight: 3,
      },
      {
        word: 'horizontal',
        weight: 3,
      },
    ],
  },
  {
    name: 'bar-pie-chart',
    className: 'custom-icon-bar-pie-chart',
    keywords: [
      {
        word: 'chart',
        weight: 3,
      },
      {
        word: '14',
        weight: 3,
      },
    ],
  },
  {
    name: 'master-card',
    className: 'custom-icon-master-card',
    keywords: [
      {
        word: 'Master',
        weight: 3,
      },
      {
        word: 'card',
        weight: 3,
      },
    ],
  },
  {
    name: 'overview',
    className: 'custom-icon-overview',
    keywords: [
      {
        word: 'overview',
        weight: 3,
      },
    ],
  },
  {
    name: 'policy',
    className: 'custom-icon-policy',
    keywords: [
      {
        word: 'policy',
        weight: 3,
      },
    ],
  },
  {
    name: 'product-audit',
    className: 'custom-icon-product-audit',
    keywords: [
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'product',
        weight: 3,
      },
    ],
  },
  {
    name: 'report',
    className: 'custom-icon-report',
    keywords: [
      {
        word: 'report',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-settings1',
    className: 'custom-icon-user-settings1',
    keywords: [
      {
        word: 'semi-medium',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 3,
      },
      {
        word: 'user',
        weight: 3,
      },
      {
        word: 'pie-chart',
        weight: 3,
      },
      {
        word: 'usage',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-user',
    className: 'custom-icon-add-user',
    keywords: [
      {
        word: 'Role',
        weight: 3,
      },
    ],
  },
  {
    name: 'open-alerts',
    className: 'custom-icon-open-alerts',
    keywords: [
      {
        word: 'open',
        weight: 3,
      },
      {
        word: 'alerts',
        weight: 3,
      },
    ],
  },
  {
    name: 'investigating-alerts',
    className: 'custom-icon-investigating-alerts',
    keywords: [
      {
        word: 'investigating',
        weight: 3,
      },
      {
        word: 'alerts',
        weight: 3,
      },
    ],
  },
  {
    name: 'proxy',
    className: 'custom-icon-proxy',
    keywords: [
      {
        word: 'icon',
        weight: 3,
      },
      {
        word: 'Proxy',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-activity',
    className: 'custom-icon-mail-activity',
    keywords: [
      {
        word: 'Mail',
        weight: 3,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-Settings',
    className: 'custom-icon-mail-Settings',
    keywords: [
      {
        word: 'Settings',
        weight: 3,
      },
      {
        word: 'Mail',
        weight: 3,
      },
    ],
  },
  {
    name: 'performance',
    className: 'custom-icon-performance',
    keywords: [
      {
        word: 'performance',
        weight: 3,
      },
      {
        word: 'moniter',
        weight: 3,
      },
      {
        word: 'icon',
        weight: 3,
      },
    ],
  },
  {
    name: 'recovery',
    className: 'custom-icon-recovery',
    keywords: [
      {
        word: 'Monitor',
        weight: 3,
      },
      {
        word: 'recovery',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'maintance',
    className: 'custom-icon-maintance',
    keywords: [
      {
        word: 'implmentation',
        weight: 3,
      },
      {
        word: '',
        weight: 3,
      },
      {
        word: 'maintanance',
        weight: 3,
      },
      {
        word: 'O365',
        weight: 3,
      },
    ],
  },
  {
    name: 'pie-chart',
    className: 'custom-icon-pie-chart',
    keywords: [
      {
        word: 'chart',
        weight: 3,
      },
      {
        word: 'pie',
        weight: 3,
      },
    ],
  },
  {
    name: 'risk-identify',
    className: 'custom-icon-risk-identify',
    keywords: [
      {
        word: 'risk',
        weight: 3,
      },
      {
        word: 'identify',
        weight: 3,
      },
    ],
  },
  {
    name: 'risk-mgmt',
    className: 'custom-icon-risk-mgmt',
    keywords: [
      {
        word: 'mgmt',
        weight: 3,
      },
      {
        word: 'risk',
        weight: 3,
      },
    ],
  },
  {
    name: 'rules',
    className: 'custom-icon-rules',
    keywords: [
      {
        word: 'rules',
        weight: 3,
      },
    ],
  },
  {
    name: 'Shared-mailbox1',
    className: 'custom-icon-Shared-mailbox1',
    keywords: [
      {
        word: 'Shared',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'site-usage',
    className: 'custom-icon-site-usage',
    keywords: [
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'usage',
        weight: 3,
      },
    ],
  },
  {
    name: 'table',
    className: 'custom-icon-table',
    keywords: [
      {
        word: 'table',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-info',
    className: 'custom-icon-license-info',
    keywords: [
      {
        word: 'license',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-audit',
    className: 'custom-icon-user-audit',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'External',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-folder-activity',
    className: 'custom-icon-file-folder-activity',
    keywords: [
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-activity',
    className: 'custom-icon-group-activity',
    keywords: [
      {
        word: 'activity',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
    ],
  },
  {
    name: 'bird',
    className: 'custom-icon-bird',
    keywords: [
      {
        word: 'Bird',
        weight: 3,
      },
    ],
  },
  {
    name: 'changes-mgmt',
    className: 'custom-icon-changes-mgmt',
    keywords: [
      {
        word: 'changes',
        weight: 3,
      },
      {
        word: 'mgmt',
        weight: 3,
      },
    ],
  },
  {
    name: 'external-user-access',
    className: 'custom-icon-external-user-access',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'user',
        weight: 4,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 3,
      },
      {
        word: 'in',
        weight: 3,
      },
    ],
  },
  {
    name: 'admins-role-change',
    className: 'custom-icon-admins-role-change',
    keywords: [
      {
        word: 'role',
        weight: 3,
      },
      {
        word: 'admins',
        weight: 3,
      },
      {
        word: 'change',
        weight: 3,
      },
    ],
  },
  {
    name: 'assets',
    className: 'custom-icon-assets',
    keywords: [
      {
        word: 'assets',
        weight: 3,
      },
    ],
  },
  {
    name: 'bird-icon',
    className: 'custom-icon-bird-icon',
    keywords: [
      {
        word: 'icon',
        weight: 3,
      },
      {
        word: 'Bird',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-settings',
    className: 'custom-icon-user-settings',
    keywords: [
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'Admin',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-info',
    className: 'custom-icon-user-info',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'Admins',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-overview',
    className: 'custom-icon-user-overview',
    keywords: [
      {
        word: 'overview',
        weight: 3,
      },
      {
        word: 'Admins',
        weight: 3,
      },
      {
        word: 'user',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'acccess-Mgmt2',
    className: 'custom-icon-acccess-Mgmt2',
    keywords: [
      {
        word: 'Mgmt2',
        weight: 3,
      },
      {
        word: 'Access',
        weight: 3,
      },
    ],
  },
  {
    name: 'access-restriction',
    className: 'custom-icon-access-restriction',
    keywords: [
      {
        word: 'restriction',
        weight: 3,
      },
      {
        word: 'access',
        weight: 3,
      },
    ],
  },
  {
    name: 'activation',
    className: 'custom-icon-activation',
    keywords: [
      {
        word: 'summary',
        weight: 3,
      },
      {
        word: 'Activation',
        weight: 3,
      },
    ],
  },
  {
    name: 'Access-Mgmt-with-keyhole',
    className: 'custom-icon-Access-Mgmt-with-keyhole',
    keywords: [
      {
        word: 'keyhole',
        weight: 3,
      },
      {
        word: 'Mgmt',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'Access',
        weight: 3,
      },
    ],
  },
  {
    name: 'Mailbox-barchart',
    className: 'custom-icon-Mailbox-barchart',
    keywords: [
      {
        word: 'MailboxChart',
        weight: 3,
      },
      {
        word: 'redborder',
        weight: 3,
      },
      {
        word: 'till',
        weight: 3,
      },
    ],
  },
  {
    name: 'ReportChart',
    className: 'custom-icon-ReportChart',
    keywords: [
      {
        word: 'ReportChart',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-settings-change',
    className: 'custom-icon-user-settings-change',
    keywords: [
      {
        word: 'Role',
        weight: 3,
      },
      {
        word: 'Settings',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'Thin',
        weight: 3,
      },
      {
        word: 'changes',
        weight: 3,
      },
    ],
  },
  {
    name: 'Failed-logins',
    className: 'custom-icon-Failed-logins',
    keywords: [
      {
        word: 'Failed',
        weight: 3,
      },
      {
        word: 'logins',
        weight: 3,
      },
    ],
  },
  {
    name: 'Group-Mailbox-Active-Hours',
    className: 'custom-icon-Group-Mailbox-Active-Hours',
    keywords: [
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'Hours',
        weight: 3,
      },
      {
        word: 'Active',
        weight: 3,
      },
      {
        word: 'Group',
        weight: 3,
      },
    ],
  },
  {
    name: 'Group-Mailbox-Traffic-Stats',
    className: 'custom-icon-Group-Mailbox-Traffic-Stats',
    keywords: [
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'Stats',
        weight: 3,
      },
      {
        word: 'Traffic',
        weight: 3,
      },
      {
        word: 'Group',
        weight: 3,
      },
    ],
  },
  {
    name: 'Group-Mailbox-Peak-Hours',
    className: 'custom-icon-Group-Mailbox-Peak-Hours',
    keywords: [
      {
        word: 'Peak',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'Hours',
        weight: 3,
      },
      {
        word: 'Group',
        weight: 3,
      },
    ],
  },
  {
    name: 'Group-Mailbox-Slack-Days',
    className: 'custom-icon-Group-Mailbox-Slack-Days',
    keywords: [
      {
        word: 'Days',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'Slack',
        weight: 3,
      },
      {
        word: 'Group',
        weight: 3,
      },
    ],
  },
  {
    name: 'Group-Total-Mailssvg',
    className: 'custom-icon-Group-Total-Mailssvg',
    keywords: [
      {
        word: 'Total',
        weight: 3,
      },
      {
        word: 'Mailssvg',
        weight: 3,
      },
      {
        word: 'Group',
        weight: 3,
      },
    ],
  },
  {
    name: 'Inactive-Groups',
    className: 'custom-icon-Inactive-Groups',
    keywords: [
      {
        word: 'Inactive',
        weight: 3,
      },
      {
        word: 'Groups',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-increasing',
    className: 'custom-icon-mailbox-increasing',
    keywords: [
      {
        word: 'increasing',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'Organization-peak-hours',
    className: 'custom-icon-Organization-peak-hours',
    keywords: [
      {
        word: 'peak',
        weight: 3,
      },
      {
        word: 'hours',
        weight: 3,
      },
      {
        word: 'Organization',
        weight: 3,
      },
    ],
  },
  {
    name: 'Organization-slack-hours',
    className: 'custom-icon-Organization-slack-hours',
    keywords: [
      {
        word: 'hours',
        weight: 3,
      },
      {
        word: 'slack',
        weight: 3,
      },
      {
        word: 'Organization',
        weight: 3,
      },
    ],
  },
  {
    name: 'Shared-Mailbox-Peak-Hours',
    className: 'custom-icon-Shared-Mailbox-Peak-Hours',
    keywords: [
      {
        word: 'Peak',
        weight: 3,
      },
      {
        word: 'Shared',
        weight: 3,
      },
      {
        word: 'Hours',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'Shared-Mailbox-Peak-Days',
    className: 'custom-icon-Shared-Mailbox-Peak-Days',
    keywords: [
      {
        word: 'Peak',
        weight: 3,
      },
      {
        word: 'Shared',
        weight: 3,
      },
      {
        word: 'Days',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'Shared-Mailbox-Slack-Days',
    className: 'custom-icon-Shared-Mailbox-Slack-Days',
    keywords: [
      {
        word: 'Days',
        weight: 3,
      },
      {
        word: 'Shared',
        weight: 3,
      },
      {
        word: 'Slack',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'Shared-Mailbox-Slack-Hours',
    className: 'custom-icon-Shared-Mailbox-Slack-Hours',
    keywords: [
      {
        word: 'Shared',
        weight: 3,
      },
      {
        word: 'Hours',
        weight: 3,
      },
      {
        word: 'Slack',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'Shared-Mailbox-Total-Mails',
    className: 'custom-icon-Shared-Mailbox-Total-Mails',
    keywords: [
      {
        word: 'Total',
        weight: 3,
      },
      {
        word: 'Shared',
        weight: 3,
      },
      {
        word: 'Mails',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'shared-mailbox-traffic-stat',
    className: 'custom-icon-shared-mailbox-traffic-stat',
    keywords: [
      {
        word: 'stat',
        weight: 3,
      },
      {
        word: 'traffic',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'shared',
        weight: 3,
      },
    ],
  },
  {
    name: 'top-grp',
    className: 'custom-icon-top-grp',
    keywords: [
      {
        word: 'grp',
        weight: 3,
      },
      {
        word: 'top',
        weight: 3,
      },
    ],
  },
  {
    name: 'top-grp2',
    className: 'custom-icon-top-grp2',
    keywords: [
      {
        word: 'grp2',
        weight: 3,
      },
      {
        word: 'top',
        weight: 3,
      },
    ],
  },
  {
    name: 'top-user',
    className: 'custom-icon-top-user',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'top',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'Total-Mails',
    className: 'custom-icon-Total-Mails',
    keywords: [
      {
        word: 'Total',
        weight: 3,
      },
      {
        word: 'Mails',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-email-traffic-stat',
    className: 'custom-icon-user-email-traffic-stat',
    keywords: [
      {
        word: 'bar chart',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'stat',
        weight: 3,
      },
      {
        word: 'traffic',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'User-Mailbox-Peak-Days',
    className: 'custom-icon-User-Mailbox-Peak-Days',
    keywords: [
      {
        word: 'Peak',
        weight: 3,
      },
      {
        word: 'User',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'Days',
        weight: 3,
      },
    ],
  },
  {
    name: 'User-Mailbox-Slack-Days',
    className: 'custom-icon-User-Mailbox-Slack-Days',
    keywords: [
      {
        word: 'Days',
        weight: 3,
      },
      {
        word: 'User',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'Slack',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-tie',
    className: 'custom-icon-user-tie',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'tie',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-peak-hours',
    className: 'custom-icon-user-peak-hours',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'peak',
        weight: 3,
      },
      {
        word: 'hours',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'user-slack-hours',
    className: 'custom-icon-user-slack-hours',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'slack',
        weight: 3,
      },
      {
        word: 'hours',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'Group-Mailbox-Slack-Hours',
    className: 'custom-icon-Group-Mailbox-Slack-Hours',
    keywords: [
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'Hours',
        weight: 3,
      },
      {
        word: 'Slack',
        weight: 3,
      },
      {
        word: 'Group',
        weight: 3,
      },
    ],
  },
  {
    name: 'spinner',
    className: 'custom-icon-spinner',
    keywords: [
      {
        word: 'spinner',
        weight: 3,
      },
    ],
  },
  {
    name: 'spinner1',
    className: 'custom-icon-spinner1',
    keywords: [
      {
        word: 'spinner1',
        weight: 3,
      },
    ],
  },
  {
    name: 'spinner5',
    className: 'custom-icon-spinner5',
    keywords: [
      {
        word: 'spinner5',
        weight: 3,
      },
    ],
  },
  {
    name: 'Group-Mailbox-Peak-Days',
    className: 'custom-icon-Group-Mailbox-Peak-Days',
    keywords: [
      {
        word: 'Peak',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'Days',
        weight: 3,
      },
      {
        word: 'Group',
        weight: 3,
      },
    ],
  },
  {
    name: 'spinner51',
    className: 'custom-icon-spinner51',
    keywords: [
      {
        word: 'spinner51',
        weight: 3,
      },
    ],
  },
  {
    name: 'spinner4',
    className: 'custom-icon-spinner4',
    keywords: [
      {
        word: 'spinner4',
        weight: 3,
      },
    ],
  },
  {
    name: 'Access-Icon',
    className: 'custom-icon-Access-Icon',
    keywords: [
      {
        word: 'Icon',
        weight: 3,
      },
      {
        word: 'Access',
        weight: 3,
      },
    ],
  },
  {
    name: 'spinner2',
    className: 'custom-icon-spinner2',
    keywords: [
      {
        word: 'spinner2',
        weight: 3,
      },
    ],
  },
  {
    name: 'spinner3',
    className: 'custom-icon-spinner3',
    keywords: [
      {
        word: 'spinner3',
        weight: 3,
      },
    ],
  },
  {
    name: 'spinner10',
    className: 'custom-icon-spinner10',
    keywords: [
      {
        word: 'spinner10',
        weight: 3,
      },
    ],
  },
  {
    name: 'Limited-Access-4_1_2',
    className: 'custom-icon-Limited-Access-4_1_2',
    keywords: [
      {
        word: 'Access',
        weight: 3,
      },
      {
        word: '4',
        weight: 3,
      },
      {
        word: 'Limited',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'Lock-with-keyhole',
    className: 'custom-icon-Lock-with-keyhole',
    keywords: [
      {
        word: 'Lock',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'keyhole',
        weight: 3,
      },
    ],
  },
  {
    name: 'No-Access---1',
    className: 'custom-icon-No-Access---1',
    keywords: [
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'No',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'Access',
        weight: 3,
      },
      {
        word: 'exclamation',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'No-Access',
    className: 'custom-icon-No-Access',
    keywords: [
      {
        word: 'No',
        weight: 3,
      },
      {
        word: 'Access',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'block',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'Policy-template-custom-icon',
    className: 'custom-icon-Policy-template-custom-icon',
    keywords: [
      {
        word: 'icon',
        weight: 3,
      },
      {
        word: 'template',
        weight: 3,
      },
      {
        word: 'Policy',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-stats',
    className: 'custom-icon-report-stats',
    keywords: [
      {
        word: 'avaiable',
        weight: 3,
      },
      {
        word: 'chart',
        weight: 3,
      },
      {
        word: 'Reports',
        weight: 3,
      },
      {
        word: 'icon',
        weight: 3,
      },
      {
        word: 'no',
        weight: 2,
      },
    ],
  },
  {
    name: 'Completed-Alerts',
    className: 'custom-icon-Completed-Alerts',
    keywords: [
      {
        word: 'Alerts',
        weight: 3,
      },
      {
        word: 'Completed',
        weight: 3,
      },
    ],
  },
  {
    name: 'External-User-icon',
    className: 'custom-icon-External-User-icon',
    keywords: [
      {
        word: 'User',
        weight: 3,
      },
      {
        word: 'icon',
        weight: 3,
      },
      {
        word: 'External',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 3,
      },
      {
        word: 'semi-medium',
        weight: 3,
      },
      {
        word: 'out',
        weight: 3,
      },
    ],
  },
  {
    name: 'Inactive-devices',
    className: 'custom-icon-Inactive-devices',
    keywords: [
      {
        word: 'devices',
        weight: 3,
      },
      {
        word: 'Inactive',
        weight: 3,
      },
    ],
  },
  {
    name: 'reload',
    className: 'custom-icon-reload',
    keywords: [
      {
        word: 'reload',
        weight: 3,
      },
    ],
  },
  {
    name: 'reload-1',
    className: 'custom-icon-reload-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'reload',
        weight: 3,
      },
    ],
  },
  {
    name: 'reload-2',
    className: 'custom-icon-reload-2',
    keywords: [
      {
        word: 'reload',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'shield-security-puzzle',
    className: 'custom-icon-shield-security-puzzle',
    keywords: [
      {
        word: 'puzzle',
        weight: 3,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'privacy',
        weight: 3,
      },
      {
        word: 'defense',
        weight: 3,
      },
      {
        word: 'elements',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'Shield',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'safety',
        weight: 3,
      },
      {
        word: 'modal',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-chart',
    className: 'custom-icon-upgrade-chart',
    keywords: [
      {
        word: 'bigPieChart',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-chart-data',
    className: 'custom-icon-update-chart-data',
    keywords: [
      {
        word: 'bigChartData',
        weight: 3,
      },
    ],
  },
  {
    name: 'conditional-access-policy',
    className: 'custom-icon-conditional-access-policy',
    keywords: [
      {
        word: 'Conditional',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'Policy',
        weight: 3,
      },
      {
        word: 'Access',
        weight: 3,
      },
    ],
  },
  {
    name: 'chart-recycle',
    className: 'custom-icon-chart-recycle',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'recycle',
        weight: 3,
      },
      {
        word: 'Chart',
        weight: 3,
      },
    ],
  },
  {
    name: 'inactive-mailbox-usage',
    className: 'custom-icon-inactive-mailbox-usage',
    keywords: [
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'inactive',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'inactive-o365-users',
    className: 'custom-icon-inactive-o365-users',
    keywords: [
      {
        word: 'inactive',
        weight: 3,
      },
      {
        word: 'o365',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'inactive-oneDrive-users',
    className: 'custom-icon-inactive-oneDrive-users',
    keywords: [
      {
        word: 'OneDrive',
        weight: 3,
      },
      {
        word: 'inactive',
        weight: 3,
      },
      {
        word: 'Users',
        weight: 3,
      },
    ],
  },
  {
    name: 'inactive-user-account',
    className: 'custom-icon-inactive-user-account',
    keywords: [
      {
        word: 'inactive',
        weight: 3,
      },
      {
        word: 'user',
        weight: 3,
      },
      {
        word: 'account',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 3,
      },
      {
        word: 'out',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'world-plus-inactive',
    className: 'custom-icon-world-plus-inactive',
    keywords: [
      {
        word: 'world',
        weight: 3,
      },
      {
        word: 'inactive',
        weight: 3,
      },
      {
        word: 'plus',
        weight: 3,
      },
    ],
  },
  {
    name: 'inactive-yammer',
    className: 'custom-icon-inactive-yammer',
    keywords: [
      {
        word: 'inactive',
        weight: 3,
      },
      {
        word: 'yammer',
        weight: 3,
      },
    ],
  },
  {
    name: 'alarm-clock-solid',
    className: 'custom-icon-alarm-clock-solid',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'alarm',
        weight: 3,
      },
    ],
  },
  {
    name: 'raw',
    className: 'custom-icon-raw',
    keywords: [
      {
        word: 'raw',
        weight: 3,
      },
    ],
  },
  {
    name: 'csv',
    className: 'custom-icon-csv',
    keywords: [
      {
        word: 'csv1',
        weight: 3,
      },
    ],
  },
  {
    name: 'xlsx',
    className: 'custom-icon-xlsx',
    keywords: [
      {
        word: 'xlsx',
        weight: 3,
      },
    ],
  },
  {
    name: 'xls',
    className: 'custom-icon-xls',
    keywords: [
      {
        word: 'xls',
        weight: 3,
      },
    ],
  },
  {
    name: 'progress1',
    className: 'custom-icon-progress1',
    keywords: [
      {
        word: 'progress1',
        weight: 3,
      },
    ],
  },
  {
    name: 'progress2',
    className: 'custom-icon-progress2',
    keywords: [
      {
        word: 'progress2',
        weight: 3,
      },
    ],
  },
  {
    name: 'pdf-file',
    className: 'custom-icon-pdf-file',
    keywords: [
      {
        word: 'pdf',
        weight: 3,
      },
    ],
  },
  {
    name: 'html-file',
    className: 'custom-icon-html-file',
    keywords: [
      {
        word: 'html',
        weight: 3,
      },
    ],
  },
  {
    name: 'azure-ad',
    className: 'custom-icon-azure-ad',
    keywords: [
      {
        word: 'aad',
        weight: 3,
      },
    ],
  },
  {
    name: 'exchange',
    className: 'custom-icon-exchange',
    keywords: [
      {
        word: 'exchange',
        weight: 3,
      },
    ],
  },
  {
    name: 'onedrive',
    className: 'custom-icon-onedrive',
    keywords: [
      {
        word: 'onedrive',
        weight: 3,
      },
    ],
  },
  {
    name: 'power-bi',
    className: 'custom-icon-power-bi',
    keywords: [
      {
        word: 'powerBI',
        weight: 3,
      },
    ],
  },
  {
    name: 'sharepoint',
    className: 'custom-icon-sharepoint',
    keywords: [
      {
        word: 'sharepoint',
        weight: 3,
      },
    ],
  },
  {
    name: 'stream',
    className: 'custom-icon-stream',
    keywords: [
      {
        word: 'stream',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams',
    className: 'custom-icon-teams',
    keywords: [
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'yammer',
    className: 'custom-icon-yammer',
    keywords: [
      {
        word: 'yammer',
        weight: 3,
      },
    ],
  },
  {
    name: 'module',
    className: 'custom-icon-module',
    keywords: [
      {
        word: 'module',
        weight: 3,
      },
    ],
  },
  {
    name: 'header-right',
    className: 'custom-icon-header-right',
    keywords: [
      {
        word: 'header',
        weight: 3,
      },
      {
        word: 'right',
        weight: 4,
      },
    ],
  },
  {
    name: 'header-left',
    className: 'custom-icon-header-left',
    keywords: [
      {
        word: 'header',
        weight: 3,
      },
      {
        word: 'left',
        weight: 3,
      },
    ],
  },
  {
    name: 'vertical-move',
    className: 'custom-icon-vertical-move',
    keywords: [
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'vertical',
        weight: 3,
      },
    ],
  },
  {
    name: 'apps-count',
    className: 'custom-icon-apps-count',
    keywords: [
      {
        word: 'apps',
        weight: 3,
      },
      {
        word: 'count',
        weight: 3,
      },
    ],
  },
  {
    name: 'archive',
    className: 'custom-icon-archive',
    keywords: [
      {
        word: 'archive',
        weight: 3,
      },
    ],
  },
  {
    name: 'classification',
    className: 'custom-icon-classification',
    keywords: [
      {
        word: 'classification',
        weight: 3,
      },
    ],
  },
  {
    name: 'company-name',
    className: 'custom-icon-company-name',
    keywords: [
      {
        word: 'name',
        weight: 3,
      },
      {
        word: 'company',
        weight: 3,
      },
    ],
  },
  {
    name: 'country',
    className: 'custom-icon-country',
    keywords: [
      {
        word: 'country',
        weight: 3,
      },
    ],
  },
  {
    name: 'created-time',
    className: 'custom-icon-created-time',
    keywords: [
      {
        word: 'time',
        weight: 3,
      },
      {
        word: 'created',
        weight: 3,
      },
    ],
  },
  {
    name: 'deleted-timee',
    className: 'custom-icon-deleted-timee',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'time',
        weight: 5,
      },
      {
        word: 'planning',
        weight: 4,
      },
      {
        word: 'Deleted',
        weight: 3,
      },
      {
        word: 'organize',
        weight: 3,
      },
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
    ],
  },
  {
    name: 'department',
    className: 'custom-icon-department',
    keywords: [
      {
        word: 'department',
        weight: 3,
      },
    ],
  },
  {
    name: 'description',
    className: 'custom-icon-description',
    keywords: [
      {
        word: 'description',
        weight: 3,
      },
    ],
  },
  {
    name: 'direct-reports',
    className: 'custom-icon-direct-reports',
    keywords: [
      {
        word: 'direct',
        weight: 3,
      },
      {
        word: 'reports',
        weight: 3,
      },
    ],
  },
  {
    name: 'disabled-license',
    className: 'custom-icon-disabled-license',
    keywords: [
      {
        word: 'license',
        weight: 3,
      },
      {
        word: 'disabled',
        weight: 3,
      },
    ],
  },
  {
    name: 'deleted-time',
    className: 'custom-icon-deleted-time',
    keywords: [
      {
        word: 'deleted',
        weight: 3,
      },
      {
        word: 'time',
        weight: 3,
      },
    ],
  },
  {
    name: 'external-domain',
    className: 'custom-icon-external-domain',
    keywords: [
      {
        word: 'domain',
        weight: 3,
      },
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'question',
        weight: 3,
      },
      {
        word: 'semi-medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'favorite-channel',
    className: 'custom-icon-favorite-channel',
    keywords: [
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'favorite',
        weight: 3,
      },
      {
        word: 'star',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'guest-count',
    className: 'custom-icon-guest-count',
    keywords: [
      {
        word: 'guest',
        weight: 3,
      },
      {
        word: 'count',
        weight: 3,
      },
    ],
  },
  {
    name: 'immutable',
    className: 'custom-icon-immutable',
    keywords: [
      {
        word: 'immutable',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-status',
    className: 'custom-icon-license-status',
    keywords: [
      {
        word: 'license',
        weight: 3,
      },
      {
        word: 'status',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-assigned',
    className: 'custom-icon-license-assigned',
    keywords: [
      {
        word: 'assigned',
        weight: 3,
      },
      {
        word: 'licensed',
        weight: 3,
      },
    ],
  },
  {
    name: 'location-building',
    className: 'custom-icon-location-building',
    keywords: [
      {
        word: 'custom-icon-location-building',
        weight: 3,
      },
    ],
  },
  {
    name: 'management-roles',
    className: 'custom-icon-management-roles',
    keywords: [
      {
        word: 'roles',
        weight: 3,
      },
      {
        word: 'management',
        weight: 3,
      },
    ],
  },
  {
    name: 'membercount',
    className: 'custom-icon-membercount',
    keywords: [
      {
        word: 'count',
        weight: 3,
      },
      {
        word: 'Member',
        weight: 3,
      },
    ],
  },
  {
    name: 'member-mail',
    className: 'custom-icon-member-mail',
    keywords: [
      {
        word: 'mail',
        weight: 3,
      },
      {
        word: 'Member',
        weight: 3,
      },
    ],
  },
  {
    name: 'member-of',
    className: 'custom-icon-member-of',
    keywords: [
      {
        word: 'member',
        weight: 3,
      },
      {
        word: 'of',
        weight: 3,
      },
    ],
  },
  {
    name: 'modified-settings',
    className: 'custom-icon-modified-settings',
    keywords: [
      {
        word: 'Modified',
        weight: 3,
      },
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
    ],
  },
  {
    name: 'no-of-license-applied',
    className: 'custom-icon-no-of-license-applied',
    keywords: [
      {
        word: 'applied',
        weight: 3,
      },
      {
        word: 'No',
        weight: 3,
      },
      {
        word: 'license',
        weight: 3,
      },
      {
        word: 'of',
        weight: 3,
      },
    ],
  },
  {
    name: 'object-id',
    className: 'custom-icon-object-id',
    keywords: [
      {
        word: 'id',
        weight: 3,
      },
      {
        word: 'object',
        weight: 3,
      },
    ],
  },
  {
    name: 'object-type',
    className: 'custom-icon-object-type',
    keywords: [
      {
        word: 'object',
        weight: 3,
      },
      {
        word: 'type',
        weight: 3,
      },
      {
        word: 'user',
        weight: 3,
      },
      {
        word: 'chat',
        weight: 3,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'semi bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'last-sync',
    className: 'custom-icon-last-sync',
    keywords: [
      {
        word: 'sync',
        weight: 3,
      },
      {
        word: 'last',
        weight: 3,
      },
      {
        word: 'On',
        weight: 3,
      },
      {
        word: 'Premises',
        weight: 3,
      },
    ],
  },
  {
    name: 'onpremise-security-identifier',
    className: 'custom-icon-onpremise-security-identifier',
    keywords: [
      {
        word: 'premises',
        weight: 3,
      },
      {
        word: 'On',
        weight: 3,
      },
      {
        word: 'identifier',
        weight: 3,
      },
      {
        word: 'Security',
        weight: 3,
      },
    ],
  },
  {
    name: 'sync-enabled',
    className: 'custom-icon-sync-enabled',
    keywords: [
      {
        word: 'sync',
        weight: 3,
      },
      {
        word: 'premises',
        weight: 3,
      },
      {
        word: 'On',
        weight: 3,
      },
      {
        word: 'enabled',
        weight: 3,
      },
    ],
  },
  {
    name: 'onpremise-domain-name',
    className: 'custom-icon-onpremise-domain-name',
    keywords: [
      {
        word: 'name',
        weight: 3,
      },
      {
        word: 'domain',
        weight: 3,
      },
      {
        word: 'Onpremises',
        weight: 3,
      },
    ],
  },
  {
    name: 'onpremise-netbios-name',
    className: 'custom-icon-onpremise-netbios-name',
    keywords: [
      {
        word: 'net-bios',
        weight: 3,
      },
      {
        word: 'name',
        weight: 3,
      },
      {
        word: 'domain',
        weight: 3,
      },
      {
        word: 'Onpremises',
        weight: 3,
      },
    ],
  },
  {
    name: 'onpremise-samaccount-name',
    className: 'custom-icon-onpremise-samaccount-name',
    keywords: [
      {
        word: 'name',
        weight: 3,
      },
      {
        word: 'sam-account',
        weight: 3,
      },
      {
        word: 'domain',
        weight: 3,
      },
      {
        word: 'Onpremises',
        weight: 3,
      },
    ],
  },
  {
    name: 'On-premises-Provisioning-errors',
    className: 'custom-icon-On-premises-Provisioning-errors',
    keywords: [
      {
        word: 'provisioning',
        weight: 3,
      },
      {
        word: 'name',
        weight: 3,
      },
      {
        word: 'domain',
        weight: 3,
      },
      {
        word: 'Onpremises',
        weight: 3,
      },
    ],
  },
  {
    name: 'other-mails',
    className: 'custom-icon-other-mails',
    keywords: [
      {
        word: 'mails',
        weight: 3,
      },
      {
        word: 'other',
        weight: 3,
      },
    ],
  },
  {
    name: 'postal-code',
    className: 'custom-icon-postal-code',
    keywords: [
      {
        word: 'code',
        weight: 3,
      },
      {
        word: 'postal',
        weight: 3,
      },
    ],
  },
  {
    name: 'data-location',
    className: 'custom-icon-data-location',
    keywords: [
      {
        word: 'Preferred',
        weight: 3,
      },
      {
        word: 'location',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'preferred-language',
    className: 'custom-icon-preferred-language',
    keywords: [
      {
        word: 'language',
        weight: 3,
      },
      {
        word: 'Preferred',
        weight: 3,
      },
    ],
  },
  {
    name: 'private-channels',
    className: 'custom-icon-private-channels',
    keywords: [
      {
        word: 'Private',
        weight: 3,
      },
      {
        word: 'channels',
        weight: 3,
      },
    ],
  },
  {
    name: 'proxy-address',
    className: 'custom-icon-proxy-address',
    keywords: [
      {
        word: 'Address',
        weight: 3,
      },
      {
        word: 'Proxy',
        weight: 3,
      },
    ],
  },
  {
    name: 'renewed-date-time',
    className: 'custom-icon-renewed-date-time',
    keywords: [
      {
        word: 'Renewed',
        weight: 3,
      },
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'time',
        weight: 5,
      },
      {
        word: 'planning',
        weight: 4,
      },
      {
        word: 'organize',
        weight: 3,
      },
      {
        word: 'date',
        weight: 3,
      },
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
    ],
  },
  {
    name: 'security-enabled',
    className: 'custom-icon-security-enabled',
    keywords: [
      {
        word: 'enabled',
        weight: 3,
      },
      {
        word: 'Security',
        weight: 3,
      },
    ],
  },
  {
    name: 'security-identifier',
    className: 'custom-icon-security-identifier',
    keywords: [
      {
        word: 'Identifier',
        weight: 3,
      },
      {
        word: 'Security',
        weight: 3,
      },
    ],
  },
  {
    name: 'standard-channels',
    className: 'custom-icon-standard-channels',
    keywords: [
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'Standard',
        weight: 3,
      },
      {
        word: 'chat',
        weight: 3,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'state-location',
    className: 'custom-icon-state-location',
    keywords: [
      {
        word: 'Location',
        weight: 1,
      },
      {
        word: 'state',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-membership-solid',
    className: 'custom-icon-teams-membership-solid',
    keywords: [
      {
        word: 'custom-icon-teams-membership-solid',
        weight: 3,
      },
    ],
  },
  {
    name: 'thumbnail-photo',
    className: 'custom-icon-thumbnail-photo',
    keywords: [
      {
        word: 'Thumbnail',
        weight: 3,
      },
      {
        word: 'photo',
        weight: 3,
      },
    ],
  },
  {
    name: 'total-channels',
    className: 'custom-icon-total-channels',
    keywords: [
      {
        word: 'Total',
        weight: 3,
      },
      {
        word: 'channels',
        weight: 3,
      },
      {
        word: 'pulse',
        weight: 3,
      },
      {
        word: 'activity',
        weight: 3,
      },
      {
        word: 'wave',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'totalmember-count',
    className: 'custom-icon-totalmember-count',
    keywords: [
      {
        word: 'Total',
        weight: 3,
      },
      {
        word: 'Participants',
        weight: 3,
      },
    ],
  },
  {
    name: 'cjis',
    className: 'custom-icon-cjis',
    keywords: [
      {
        word: 'CJIS1',
        weight: 1,
      },
      {
        word: 'solid',
        weight: 5,
      },
      {
        word: 'balance',
        weight: 2,
      },
    ],
  },
  {
    name: 'customize-filter',
    className: 'custom-icon-customize-filter',
    keywords: [
      {
        word: 'filter',
        weight: 3,
      },
      {
        word: 'custom',
        weight: 3,
      },
      {
        word: 'funnel',
        weight: 3,
      },
    ],
  },
  {
    name: 'customize',
    className: 'custom-icon-customize',
    keywords: [
      {
        word: 'customize',
        weight: 3,
      },
    ],
  },
  {
    name: 'font-bg',
    className: 'custom-icon-font-bg',
    keywords: [
      {
        word: 'font',
        weight: 3,
      },
      {
        word: 'bg',
        weight: 3,
      },
    ],
  },
  {
    name: 'font-color',
    className: 'custom-icon-font-color',
    keywords: [
      {
        word: 'color',
        weight: 3,
      },
      {
        word: 'font',
        weight: 3,
      },
    ],
  },
  {
    name: 'font-family',
    className: 'custom-icon-font-family',
    keywords: [
      {
        word: 'Family',
        weight: 3,
      },
      {
        word: 'font',
        weight: 3,
      },
    ],
  },
  {
    name: 'font-size',
    className: 'custom-icon-font-size',
    keywords: [
      {
        word: 'Size',
        weight: 3,
      },
      {
        word: 'font',
        weight: 3,
      },
    ],
  },
  {
    name: 'Frame-2',
    className: 'custom-icon-frame-2',
    keywords: [
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'Frame',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-format',
    className: 'custom-icon-remove-format',
    keywords: [
      {
        word: 'format',
        weight: 3,
      },
      {
        word: 'Remove',
        weight: 3,
      },
    ],
  },
  {
    name: 'active',
    className: 'custom-icon-active',
    keywords: [
      {
        word: 'Active',
        weight: 3,
      },
    ],
  },
  {
    name: 'authoritative',
    className: 'custom-icon-authoritative',
    keywords: [
      {
        word: 'Authoritative',
        weight: 3,
      },
    ],
  },
  {
    name: 'common-user-activity-alerts',
    className: 'custom-icon-common-user-activity-alerts',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'alerts',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'Common',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'conditional-access',
    className: 'custom-icon-conditional-access',
    keywords: [
      {
        word: 'conditional',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
    ],
  },
  {
    name: 'external-relay',
    className: 'custom-icon-external-relay',
    keywords: [
      {
        word: 'relay',
        weight: 3,
      },
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'mail',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-and-folder-activities-alerts',
    className: 'custom-icon-file-and-folder-activities-alerts',
    keywords: [
      {
        word: 'File',
        weight: 3,
      },
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'alerts',
        weight: 3,
      },
      {
        word: 'activities',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-sharing-activity-alerts',
    className: 'custom-icon-file-sharing-activity-alerts',
    keywords: [
      {
        word: 'sharing',
        weight: 3,
      },
      {
        word: 'File',
        weight: 3,
      },
      {
        word: 'Activity',
        weight: 3,
      },
      {
        word: 'alerts',
        weight: 3,
      },
    ],
  },
  {
    name: 'day-sun',
    className: 'custom-icon-day-sun',
    keywords: [
      {
        word: 'Day',
        weight: 3,
      },
      {
        word: 'Sun',
        weight: 3,
      },
    ],
  },
  {
    name: 'day-tue',
    className: 'custom-icon-day-tue',
    keywords: [
      {
        word: 'Day',
        weight: 3,
      },
      {
        word: 'Tue',
        weight: 3,
      },
    ],
  },
  {
    name: 'day-wed',
    className: 'custom-icon-day-wed',
    keywords: [
      {
        word: 'Day',
        weight: 3,
      },
      {
        word: 'Wed',
        weight: 3,
      },
    ],
  },
  {
    name: 'day-mon',
    className: 'custom-icon-day-mon',
    keywords: [
      {
        word: 'Day',
        weight: 3,
      },
      {
        word: 'Mon',
        weight: 3,
      },
    ],
  },
  {
    name: 'day-thu',
    className: 'custom-icon-day-thu',
    keywords: [
      {
        word: 'Day',
        weight: 3,
      },
      {
        word: 'Thu',
        weight: 3,
      },
    ],
  },
  {
    name: 'day-fri',
    className: 'custom-icon-day-fri',
    keywords: [
      {
        word: 'Day',
        weight: 3,
      },
      {
        word: 'Fri',
        weight: 3,
      },
    ],
  },
  {
    name: 'day-sat',
    className: 'custom-icon-day-sat',
    keywords: [
      {
        word: 'Day',
        weight: 3,
      },
      {
        word: 'Sat',
        weight: 3,
      },
    ],
  },
  {
    name: 'minutes',
    className: 'custom-icon-minutes',
    keywords: [
      {
        word: 'Minutes',
        weight: 3,
      },
    ],
  },
  {
    name: 'hours',
    className: 'custom-icon-hours',
    keywords: [
      {
        word: 'Hours',
        weight: 3,
      },
    ],
  },
  {
    name: 'days-week',
    className: 'custom-icon-days-week',
    keywords: [
      {
        word: 'Days',
        weight: 3,
      },
      {
        word: 'Week',
        weight: 3,
      },
    ],
  },
  {
    name: 'days-month',
    className: 'custom-icon-days-month',
    keywords: [
      {
        word: 'Days',
        weight: 3,
      },
      {
        word: 'Month',
        weight: 3,
      },
    ],
  },
  {
    name: 'days-year',
    className: 'custom-icon-days-year',
    keywords: [
      {
        word: 'Days',
        weight: 3,
      },
      {
        word: 'Year',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-jan',
    className: 'custom-icon-month-jan',
    keywords: [
      {
        word: 'Jan',
        weight: 3,
      },
      {
        word: 'Month',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-feb',
    className: 'custom-icon-month-feb',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Feb',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-mar',
    className: 'custom-icon-month-mar',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Mar',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-apr',
    className: 'custom-icon-month-apr',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Apr',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-may',
    className: 'custom-icon-month-may',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'May',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-jun',
    className: 'custom-icon-month-jun',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Jun',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-jul',
    className: 'custom-icon-month-jul',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Jul',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-aug',
    className: 'custom-icon-month-aug',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Aug',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-sep',
    className: 'custom-icon-month-sep',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Sep',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-oct',
    className: 'custom-icon-month-oct',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Oct',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-nov',
    className: 'custom-icon-month-nov',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Nov',
        weight: 3,
      },
    ],
  },
  {
    name: 'month-dec',
    className: 'custom-icon-month-dec',
    keywords: [
      {
        word: 'Month',
        weight: 3,
      },
      {
        word: 'Dec',
        weight: 3,
      },
    ],
  },
  {
    name: 'null-set',
    className: 'custom-icon-null-set',
    keywords: [
      {
        word: 'Null',
        weight: 3,
      },
      {
        word: 'set',
        weight: 3,
      },
    ],
  },
  {
    name: 'seconds',
    className: 'custom-icon-seconds',
    keywords: [
      {
        word: 'seconds',
        weight: 3,
      },
    ],
  },
  {
    name: 'cron',
    className: 'custom-icon-cron',
    keywords: [
      {
        word: 'cron',
        weight: 3,
      },
    ],
  },
  {
    name: 'open',
    className: 'custom-icon-open',
    keywords: [
      {
        word: 'open',
        weight: 3,
      },
    ],
  },
  {
    name: 'threshold',
    className: 'custom-icon-threshold',
    keywords: [
      {
        word: 'Threshold',
        weight: 3,
      },
    ],
  },
  {
    name: 'compare',
    className: 'custom-icon-compare',
    keywords: [
      {
        word: 'compare',
        weight: 3,
      },
    ],
  },
  {
    name: 'new-events',
    className: 'custom-icon-new-events',
    keywords: [
      {
        word: 'New',
        weight: 3,
      },
      {
        word: 'events',
        weight: 3,
      },
    ],
  },
  {
    name: 'filter-private',
    className: 'custom-icon-filter-private',
    keywords: [
      {
        word: 'filter',
        weight: 3,
      },
      {
        word: 'private',
        weight: 3,
      },
    ],
  },
  {
    name: 'filter-public',
    className: 'custom-icon-filter-public',
    keywords: [
      {
        word: 'public',
        weight: 3,
      },
      {
        word: 'filter',
        weight: 3,
      },
    ],
  },
  {
    name: 'Hosted-pending',
    className: 'custom-icon-hosted-pending',
    keywords: [
      {
        word: 'pending',
        weight: 3,
      },
      {
        word: 'Hosted',
        weight: 3,
      },
    ],
  },
  {
    name: 'Hosted-Provisioned',
    className: 'custom-icon-hosted-provisioned',
    keywords: [
      {
        word: 'Provisioned',
        weight: 3,
      },
      {
        word: 'Hosted',
        weight: 3,
      },
    ],
  },
  {
    name: 'identify-protection',
    className: 'custom-icon-identify-protection',
    keywords: [
      {
        word: 'Identify',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
    ],
  },
  {
    name: 'ios',
    className: 'custom-icon-ios',
    keywords: [
      {
        word: 'iOs',
        weight: 3,
      },
    ],
  },
  {
    name: 'Linux',
    className: 'custom-icon-linux',
    keywords: [
      {
        word: 'Linux',
        weight: 3,
      },
    ],
  },
  {
    name: 'Local',
    className: 'custom-icon-local',
    keywords: [
      {
        word: 'Local',
        weight: 3,
      },
    ],
  },
  {
    name: 'macos',
    className: 'custom-icon-macos',
    keywords: [
      {
        word: 'MacOs',
        weight: 3,
      },
    ],
  },
  {
    name: 'None',
    className: 'custom-icon-none',
    keywords: [
      {
        word: 'None',
        weight: 3,
      },
    ],
  },
  {
    name: 'on-premise',
    className: 'custom-icon-on-premise',
    keywords: [
      {
        word: 'premise',
        weight: 3,
      },
      {
        word: 'On',
        weight: 3,
      },
    ],
  },
  {
    name: 'per-user-mfa',
    className: 'custom-icon-per-user-mfa',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'per',
        weight: 3,
      },
      {
        word: 'mfa',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'security-defaults',
    className: 'custom-icon-security-defaults',
    keywords: [
      {
        word: 'Defaults',
        weight: 3,
      },
      {
        word: 'Security',
        weight: 3,
      },
    ],
  },
  {
    name: 'synchronization-event-alerts',
    className: 'custom-icon-synchronization-event-alerts',
    keywords: [
      {
        word: 'Synchronization',
        weight: 3,
      },
      {
        word: 'Event',
        weight: 3,
      },
      {
        word: 'alerts',
        weight: 3,
      },
    ],
  },
  {
    name: 'unknown',
    className: 'custom-icon-unknown',
    keywords: [
      {
        word: 'UNKNOWN',
        weight: 3,
      },
    ],
  },
  {
    name: 'update',
    className: 'custom-icon-update',
    keywords: [
      {
        word: 'Update',
        weight: 3,
      },
    ],
  },
  {
    name: 'creations-options-flag',
    className: 'custom-icon-creations-options-flag',
    keywords: [
      {
        word: 'Options',
        weight: 3,
      },
      {
        word: 'Flag',
        weight: 3,
      },
      {
        word: 'Creations',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-type',
    className: 'custom-icon-user-type',
    keywords: [
      {
        word: 'User',
        weight: 3,
      },
      {
        word: 'Type',
        weight: 3,
      },
    ],
  },
  {
    name: 'child-classification',
    className: 'custom-icon-child-classification',
    keywords: [
      {
        word: 'Child',
        weight: 3,
      },
      {
        word: 'classification',
        weight: 3,
      },
    ],
  },
  {
    name: 'house-address',
    className: 'custom-icon-house-address',
    keywords: [
      {
        word: 'House',
        weight: 3,
      },
      {
        word: 'address',
        weight: 3,
      },
    ],
  },
  {
    name: 'owner-settings',
    className: 'custom-icon-owner-settings',
    keywords: [
      {
        word: 'Owner',
        weight: 3,
      },
      {
        word: 'User',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'User',
        weight: 3,
      },
      {
        word: 'checkmark',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'owner2',
    className: 'custom-icon-owner2',
    keywords: [
      {
        word: 'owner2',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-create-declarative-workflow',
    className: 'custom-icon-allow-create-declarative-workflow',
    keywords: [
      {
        word: 'workflow',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'declarative',
        weight: 3,
      },
      {
        word: 'Allow',
        weight: 3,
      },
    ],
  },
  {
    name: 'can-upgrade',
    className: 'custom-icon-can-upgrade',
    keywords: [
      {
        word: 'Can',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-users',
    className: 'custom-icon-add-users',
    keywords: [
      {
        word: 'Guest',
        weight: 3,
      },
      {
        word: 'Users',
        weight: 3,
      },
    ],
  },
  {
    name: 'max-items-per-throttled-operation',
    className: 'custom-icon-max-items-per-throttled-operation',
    keywords: [
      {
        word: 'throttled',
        weight: 3,
      },
      {
        word: 'items',
        weight: 3,
      },
      {
        word: 'per',
        weight: 3,
      },
      {
        word: 'Max',
        weight: 3,
      },
      {
        word: 'operation',
        weight: 3,
      },
    ],
  },
  {
    name: 'share-by-mail-enabled',
    className: 'custom-icon-share-by-mail-enabled',
    keywords: [
      {
        word: 'enabled',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'by',
        weight: 3,
      },
      {
        word: 'Share',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'sharing-allowed-domain-list',
    className: 'custom-icon-sharing-allowed-domain-list',
    keywords: [
      {
        word: 'Domain',
        weight: 3,
      },
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'Allowed',
        weight: 3,
      },
      {
        word: 'Sharing',
        weight: 3,
      },
    ],
  },
  {
    name: 'sharing-allowed-domain-list-1',
    className: 'custom-icon-sharing-allowed-domain-list-1',
    keywords: [
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'Allowed',
        weight: 3,
      },
      {
        word: 'Domain',
        weight: 3,
      },
      {
        word: 'Sharing',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'sharing-blocked-domain-list',
    className: 'custom-icon-sharing-blocked-domain-list',
    keywords: [
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'blocked',
        weight: 3,
      },
      {
        word: 'Sharing',
        weight: 3,
      },
      {
        word: 'domain',
        weight: 3,
      },
    ],
  },
  {
    name: 'sharing-capability',
    className: 'custom-icon-sharing-capability',
    keywords: [
      {
        word: 'capability',
        weight: 3,
      },
      {
        word: 'Sharing',
        weight: 3,
      },
    ],
  },
  {
    name: 'storage-used',
    className: 'custom-icon-storage-used',
    keywords: [
      {
        word: '',
        weight: 3,
      },
      {
        word: 'used',
        weight: 3,
      },
      {
        word: 'Storage',
        weight: 3,
      },
    ],
  },
  {
    name: 'storage-max-level',
    className: 'custom-icon-storage-max-level',
    keywords: [
      {
        word: 'max',
        weight: 3,
      },
      {
        word: 'level',
        weight: 3,
      },
      {
        word: 'Storage',
        weight: 3,
      },
    ],
  },
  {
    name: 'storage-quota-type',
    className: 'custom-icon-storage-quota-type',
    keywords: [
      {
        word: 'Quota',
        weight: 3,
      },
      {
        word: 'Type',
        weight: 3,
      },
      {
        word: 'Storage',
        weight: 3,
      },
    ],
  },
  {
    name: 'storage-usage',
    className: 'custom-icon-storage-usage',
    keywords: [
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'Storage',
        weight: 3,
      },
    ],
  },
  {
    name: 'storage-warning-level',
    className: 'custom-icon-storage-warning-level',
    keywords: [
      {
        word: 'warning',
        weight: 3,
      },
      {
        word: 'level',
        weight: 3,
      },
      {
        word: 'Storage',
        weight: 3,
      },
    ],
  },
  {
    name: 'storage',
    className: 'custom-icon-storage',
    keywords: [
      {
        word: 'Storage',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-errors',
    className: 'custom-icon-upgrade-errors',
    keywords: [
      {
        word: 'Upgrade',
        weight: 3,
      },
      {
        word: 'Errors',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-file-text',
    className: 'custom-icon-upgrade-file-text',
    keywords: [
      {
        word: 'text',
        weight: 3,
      },
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'upgrade-info',
    className: 'custom-icon-upgrade-info',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-reminder-date',
    className: 'custom-icon-upgrade-reminder-date',
    keywords: [
      {
        word: 'date',
        weight: 3,
      },
      {
        word: 'reminder',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-retry',
    className: 'custom-icon-upgrade-retry',
    keywords: [
      {
        word: 'retry',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-start-time',
    className: 'custom-icon-upgrade-start-time',
    keywords: [
      {
        word: 'start',
        weight: 3,
      },
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'time',
        weight: 5,
      },
      {
        word: 'planning',
        weight: 4,
      },
      {
        word: 'organize',
        weight: 3,
      },
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
    ],
  },
  {
    name: 'upgrade-timer',
    className: 'custom-icon-upgrade-timer',
    keywords: [
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-type',
    className: 'custom-icon-upgrade-type',
    keywords: [
      {
        word: 'Upgrade',
        weight: 3,
      },
      {
        word: 'type',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-warnings',
    className: 'custom-icon-upgrade-warnings',
    keywords: [
      {
        word: 'warnings',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrading',
    className: 'custom-icon-upgrading',
    keywords: [
      {
        word: 'Upgrading',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-master-page-editing',
    className: 'custom-icon-allow-master-page-editing',
    keywords: [
      {
        word: 'master',
        weight: 3,
      },
      {
        word: 'page',
        weight: 3,
      },
      {
        word: 'Allow',
        weight: 3,
      },
      {
        word: 'editing',
        weight: 3,
      },
    ],
  },
  {
    name: 'bandwidth',
    className: 'custom-icon-bandwidth',
    keywords: [
      {
        word: 'Bandwidth',
        weight: 3,
      },
    ],
  },
  {
    name: 'child',
    className: 'custom-icon-child',
    keywords: [
      {
        word: 'Child',
        weight: 3,
      },
    ],
  },
  {
    name: 'deny-add-customize-pages',
    className: 'custom-icon-deny-add-customize-pages',
    keywords: [
      {
        word: '',
        weight: 3,
      },
      {
        word: 'Deny',
        weight: 3,
      },
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'pages',
        weight: 3,
      },
      {
        word: 'customize',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-app-views',
    className: 'custom-icon-disable-app-views',
    keywords: [
      {
        word: 'views',
        weight: 3,
      },
      {
        word: 'Disable',
        weight: 3,
      },
      {
        word: 'app',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-company-wide-sharing-links',
    className: 'custom-icon-disable-company-wide-sharing-links',
    keywords: [
      {
        word: 'wide',
        weight: 3,
      },
      {
        word: 'company',
        weight: 3,
      },
      {
        word: 'sharing',
        weight: 3,
      },
      {
        word: 'links',
        weight: 3,
      },
      {
        word: 'Disable',
        weight: 3,
      },
    ],
  },
  {
    name: 'quote-first',
    className: 'custom-icon-quote-first',
    keywords: [
      {
        word: 'Quote1',
        weight: 3,
      },
    ],
  },
  {
    name: 'immediate-child',
    className: 'custom-icon-immediate-child',
    keywords: [
      {
        word: 'Immediate',
        weight: 3,
      },
      {
        word: 'child',
        weight: 3,
      },
    ],
  },
  {
    name: 'quote-second',
    className: 'custom-icon-quote-second',
    keywords: [
      {
        word: 'Quote2',
        weight: 3,
      },
    ],
  },
  {
    name: 'link-enabled',
    className: 'custom-icon-link-enabled',
    keywords: [
      {
        word: 'enabled',
        weight: 3,
      },
      {
        word: 'Link',
        weight: 3,
      },
    ],
  },
  {
    name: 'lock-issue',
    className: 'custom-icon-lock-issue',
    keywords: [
      {
        word: 'Lock',
        weight: 3,
      },
      {
        word: 'Issue',
        weight: 3,
      },
    ],
  },
  {
    name: 'lock-state',
    className: 'custom-icon-lock-state',
    keywords: [
      {
        word: 'state',
        weight: 3,
      },
      {
        word: 'Lock',
        weight: 3,
      },
    ],
  },
  {
    name: 'icon-needs-b2b-upgrade',
    className: 'custom-icon-needs-b2b-upgrade',
    keywords: [
      {
        word: 'Needs',
        weight: 3,
      },
      {
        word: 'B2B',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
    ],
  },
  {
    name: 'primary-uri',
    className: 'custom-icon-primary-uri',
    keywords: [
      {
        word: 'Primary',
        weight: 3,
      },
      {
        word: 'URL',
        weight: 3,
      },
    ],
  },
  {
    name: 'status',
    className: 'custom-icon-status',
    keywords: [
      {
        word: 'user',
        weight: 3,
      },
      {
        word: 'status',
        weight: 3,
      },
    ],
  },
  {
    name: 'trim-audit-log',
    className: 'custom-icon-trim-audit-log',
    keywords: [
      {
        word: 'Audit',
        weight: 3,
      },
      {
        word: 'Trim',
        weight: 3,
      },
      {
        word: 'log',
        weight: 3,
      },
    ],
  },
  {
    name: 'ui-version-configuration',
    className: 'custom-icon-ui-version-configuration',
    keywords: [
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'version',
        weight: 3,
      },
      {
        word: 'UI',
        weight: 3,
      },
    ],
  },
  {
    name: 'usercode-maximum-level',
    className: 'custom-icon-usercode-maximum-level',
    keywords: [
      {
        word: 'maximum',
        weight: 3,
      },
      {
        word: 'level',
        weight: 3,
      },
      {
        word: 'Usercode',
        weight: 3,
      },
    ],
  },
  {
    name: 'usercode-minimum-level',
    className: 'custom-icon-usercode-minimum-level',
    keywords: [
      {
        word: 'minimum',
        weight: 3,
      },
      {
        word: 'level',
        weight: 3,
      },
      {
        word: 'Usercode',
        weight: 3,
      },
    ],
  },
  {
    name: 'empty-template',
    className: 'custom-icon-empty-template',
    keywords: [
      {
        word: 'Empty',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
    ],
  },
  {
    name: 'invite-template',
    className: 'custom-icon-invite-template',
    keywords: [
      {
        word: 'Invite',
        weight: 3,
      },
    ],
  },
  {
    name: 'retention-template',
    className: 'custom-icon-retention-template',
    keywords: [
      {
        word: 'Retention',
        weight: 3,
      },
    ],
  },
  {
    name: 'spoof1',
    className: 'custom-icon-spoof1',
    keywords: [
      {
        word: 'spoof1',
        weight: 3,
      },
    ],
  },
  {
    name: 'spoof2',
    className: 'custom-icon-spoof2',
    keywords: [
      {
        word: 'spoof2',
        weight: 3,
      },
    ],
  },
  {
    name: 'malware',
    className: 'custom-icon-malware',
    keywords: [
      {
        word: 'malware',
        weight: 3,
      },
    ],
  },
  {
    name: 'spam',
    className: 'custom-icon-spam',
    keywords: [
      {
        word: 'spam',
        weight: 3,
      },
    ],
  },
  {
    name: 'phish',
    className: 'custom-icon-phish',
    keywords: [
      {
        word: 'phish',
        weight: 3,
      },
    ],
  },
  {
    name: 'malware_stat1',
    className: 'custom-icon-malware_stat1',
    keywords: [
      {
        word: 'stat1',
        weight: 3,
      },
      {
        word: 'malware',
        weight: 3,
      },
    ],
  },
  {
    name: 'malware_stat2',
    className: 'custom-icon-malware_stat2',
    keywords: [
      {
        word: '28',
        weight: 3,
      },
      {
        word: 'Frame',
        weight: 3,
      },
    ],
  },
  {
    name: 'Phishing',
    className: 'custom-icon-Phishing',
    keywords: [
      {
        word: 'Phishing',
        weight: 3,
      },
    ],
  },
  {
    name: 'malware_bug',
    className: 'custom-icon-malware_bug',
    keywords: [
      {
        word: 'bug',
        weight: 3,
      },
      {
        word: 'malware',
        weight: 3,
      },
    ],
  },
  {
    name: 'spoofing',
    className: 'custom-icon-spoofing',
    keywords: [
      {
        word: 'spoofing',
        weight: 3,
      },
    ],
  },
  {
    name: 'spoof',
    className: 'custom-icon-spoof',
    keywords: [
      {
        word: 'spoof',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-channels',
    className: 'custom-icon-create-channels',
    keywords: [
      {
        word: 'channels',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'warning-quota',
    className: 'custom-icon-warning-quota',
    keywords: [
      {
        word: 'quota',
        weight: 3,
      },
      {
        word: 'warning',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-edit-channels',
    className: 'custom-icon-user-edit-channels',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'channels',
        weight: 3,
      },
      {
        word: 'edit',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'Yammer-post-count',
    className: 'custom-icon-yammer-post-count',
    keywords: [
      {
        word: 'count',
        weight: 3,
      },
      {
        word: 'post',
        weight: 3,
      },
      {
        word: 'Yammer',
        weight: 3,
      },
    ],
  },
  {
    name: 'Active-files',
    className: 'custom-icon-active-files',
    keywords: [
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'Active',
        weight: 3,
      },
    ],
  },
  {
    name: 'read-count',
    className: 'custom-icon-read-count',
    keywords: [
      {
        word: 'count',
        weight: 3,
      },
      {
        word: 'Read',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-status',
    className: 'custom-icon-subscription-status',
    keywords: [
      {
        word: 'status',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'circle-trash',
    className: 'custom-icon-circle-trash',
    keywords: [
      {
        word: 'circle',
        weight: 3,
      },
      {
        word: 'trash',
        weight: 3,
      },
    ],
  },
  {
    name: 'public',
    className: 'custom-icon-public',
    keywords: [
      {
        word: 'public',
        weight: 3,
      },
    ],
  },
  {
    name: 'public-icon',
    className: 'custom-icon-public-icon',
    keywords: [
      {
        word: 'public',
        weight: 3,
      },
      {
        word: 'icon',
        weight: 3,
      },
    ],
  },
  {
    name: 'MFA-enabled',
    className: 'custom-icon-MFA-enabled',
    keywords: [
      {
        word: 'enabled',
        weight: 3,
      },
      {
        word: 'MFA',
        weight: 3,
      },
    ],
  },
  {
    name: 'delete-xmark',
    className: 'custom-icon-delete-xmark',
    keywords: [
      {
        word: 'delete',
        weight: 3,
      },
      {
        word: 'xmark',
        weight: 3,
      },
    ],
  },
  {
    name: 'MFA-disabled',
    className: 'custom-icon-MFA-disabled',
    keywords: [
      {
        word: 'disabled',
        weight: 3,
      },
      {
        word: 'MFA',
        weight: 3,
      },
    ],
  },
  {
    name: 'MFA-enforced',
    className: 'custom-icon-MFA-enforced',
    keywords: [
      {
        word: 'enforced',
        weight: 3,
      },
      {
        word: 'MFA',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-key',
    className: 'custom-icon-user-key',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'key',
        weight: 5,
      },
    ],
  },
  {
    name: 'bells',
    className: 'custom-icon-bells',
    keywords: [
      {
        word: 'bells',
        weight: 3,
      },
    ],
  },
  {
    name: 'ipad-usage',
    className: 'custom-icon-ipad-usage',
    keywords: [
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'ipad',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-storage',
    className: 'custom-icon-mailbox-storage',
    keywords: [
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'rectangle-terminal',
    className: 'custom-icon-rectangle-terminal',
    keywords: [
      {
        word: 'terminal',
        weight: 3,
      },
      {
        word: 'rectangle',
        weight: 3,
      },
    ],
  },
  {
    name: 'phone-office',
    className: 'custom-icon-phone-office',
    keywords: [
      {
        word: 'phone',
        weight: 3,
      },
      {
        word: 'office',
        weight: 3,
      },
    ],
  },
  {
    name: 'shared-channel',
    className: 'custom-icon-shared-channel',
    keywords: [
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'shared',
        weight: 3,
      },
    ],
  },
  {
    name: 'phone-app-notification',
    className: 'custom-icon-phone-app-notification',
    keywords: [
      {
        word: 'phone',
        weight: 3,
      },
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'app',
        weight: 3,
      },
    ],
  },
  {
    name: 'weak-password',
    className: 'custom-icon-weak-password',
    keywords: [
      {
        word: 'custom-icon-weak-password',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-threat-solid',
    className: 'custom-icon-mail-threat-solid',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'threat',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-threat-protection',
    className: 'custom-icon-mail-threat-protection',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'threat',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-income-outgoing',
    className: 'custom-icon-mail-income-outgoing',
    keywords: [
      {
        word: 'income',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'outgoing',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-lines',
    className: 'custom-icon-message-lines',
    keywords: [
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'lines',
        weight: 3,
      },
    ],
  },
  {
    name: 'messages',
    className: 'custom-icon-messages',
    keywords: [
      {
        word: 'messages',
        weight: 3,
      },
    ],
  },
  {
    name: 'trash-clock',
    className: 'custom-icon-trash-clock',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'trash',
        weight: 3,
      },
    ],
  },
  {
    name: 'trash-arrow-up',
    className: 'custom-icon-trash-arrow-up',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'up',
        weight: 4,
      },
      {
        word: 'trash',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'nfc-trash',
    className: 'custom-icon-nfc-trash',
    keywords: [
      {
        word: '8',
        weight: 3,
      },
      {
        word: 'trash',
        weight: 3,
      },
      {
        word: 'nfc',
        weight: 3,
      },
    ],
  },
  {
    name: 'calendar-lines',
    className: 'custom-icon-calendar-lines',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'lines',
        weight: 3,
      },
      {
        word: 'calendar',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-post',
    className: 'custom-icon-mailbox-post',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'booth-curtain',
    className: 'custom-icon-booth-curtain',
    keywords: [
      {
        word: 'booth',
        weight: 3,
      },
      {
        word: 'curtain',
        weight: 3,
      },
    ],
  },
  {
    name: 'sign-in-alt',
    className: 'custom-icon-sign-in-alt',
    keywords: [
      {
        word: 'sign',
        weight: 3,
      },
      {
        word: 'in',
        weight: 3,
      },
      {
        word: 'alt',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-pen',
    className: 'custom-icon-file-pen',
    keywords: [
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'edit',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'folder-open',
    className: 'custom-icon-folder-open',
    keywords: [
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'open',
        weight: 3,
      },
    ],
  },
  {
    name: 'code',
    className: 'custom-icon-code',
    keywords: [
      {
        word: 'code',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-bulk',
    className: 'custom-icon-mail-bulk',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'bulk',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'empty-set',
    className: 'custom-icon-empty-set',
    keywords: [
      {
        word: 'set',
        weight: 3,
      },
      {
        word: 'empty',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-alt',
    className: 'custom-icon-file-alt',
    keywords: [
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'alt',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'distribution-group',
    className: 'custom-icon-distribution-group',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'distribution',
        weight: 3,
      },
    ],
  },
  {
    name: 'private-channel-member',
    className: 'custom-icon-private-channel-member',
    keywords: [
      {
        word: 'private',
        weight: 3,
      },
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'all-mfa-methods',
    className: 'custom-icon-all-mfa-methods',
    keywords: [
      {
        word: 'custom-icon-all-mfa-methods',
        weight: 5,
      },
    ],
  },
  {
    name: 'mfa-device-auth-types',
    className: 'custom-icon-mfa-device-auth-types',
    keywords: [
      {
        word: 'mfa',
        weight: 3,
      },
      {
        word: 'device',
        weight: 3,
      },
      {
        word: 'types',
        weight: 3,
      },
      {
        word: 'auth',
        weight: 3,
      },
    ],
  },
  {
    name: 'security-group',
    className: 'custom-icon-security-group',
    keywords: [
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'privacy',
        weight: 3,
      },
      {
        word: 'defense',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'safety',
        weight: 3,
      },
    ],
  },
  {
    name: 'private-lock',
    className: 'custom-icon-private-lock',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
      {
        word: 'private',
        weight: 3,
      },
    ],
  },
  {
    name: 'public-teams',
    className: 'custom-icon-public-teams',
    keywords: [
      {
        word: 'public',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'detailed-provisioning',
    className: 'custom-icon-detailed-provisioning',
    keywords: [
      {
        word: 'detailed',
        weight: 3,
      },
      {
        word: 'provisioning',
        weight: 3,
      },
    ],
  },
  {
    name: 'managed',
    className: 'custom-icon-managed',
    keywords: [
      {
        word: 'managed',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-extension',
    className: 'custom-icon-file-extension',
    keywords: [
      {
        word: 'extension',
        weight: 3,
      },
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'file-url',
    className: 'custom-icon-file-url',
    keywords: [
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'url',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'private-chat',
    className: 'custom-icon-private-chat',
    keywords: [
      {
        word: 'conversation',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'chat',
        weight: 5,
      },
      {
        word: 'discussion',
        weight: 4,
      },
      {
        word: 'private',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'talk',
        weight: 4,
      },
    ],
  },
  {
    name: 'wave-pulse',
    className: 'custom-icon-wave-pulse',
    keywords: [
      {
        word: 'wave',
        weight: 3,
      },
      {
        word: 'pulse',
        weight: 3,
      },
    ],
  },
  {
    name: 'onedrive-adoption',
    className: 'custom-icon-onedrive-adoption',
    keywords: [
      {
        word: 'onedrive',
        weight: 3,
      },
      {
        word: 'adoption',
        weight: 3,
      },
    ],
  },
  {
    name: 'accessed-files',
    className: 'custom-icon-accessed-files',
    keywords: [
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'accessed',
        weight: 3,
      },
    ],
  },
  {
    name: 'anonymous-link-accessed',
    className: 'custom-icon-anonymous-link-accessed',
    keywords: [
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'accessed',
        weight: 3,
      },
      {
        word: 'anonymous',
        weight: 3,
      },
    ],
  },
  {
    name: 'anonymous-link-created',
    className: 'custom-icon-anonymous-link-created',
    keywords: [
      {
        word: 'created',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'anonymous',
        weight: 3,
      },
    ],
  },
  {
    name: 'anonymous-link-created-1',
    className: 'custom-icon-anonymous-link-created-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'created',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'anonymous',
        weight: 3,
      },
    ],
  },
  {
    name: 'anonymous-link-removed',
    className: 'custom-icon-anonymous-link-removed',
    keywords: [
      {
        word: 'removed',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'anonymous',
        weight: 3,
      },
    ],
  },
  {
    name: 'company-link-created',
    className: 'custom-icon-company-link-created',
    keywords: [
      {
        word: 'created',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'company',
        weight: 3,
      },
    ],
  },
  {
    name: 'company-link-removed',
    className: 'custom-icon-company-link-removed',
    keywords: [
      {
        word: 'removed',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'company',
        weight: 3,
      },
    ],
  },
  {
    name: 'company-links',
    className: 'custom-icon-company-links',
    keywords: [
      {
        word: 'links',
        weight: 3,
      },
      {
        word: 'company',
        weight: 3,
      },
    ],
  },
  {
    name: 'copied-files',
    className: 'custom-icon-copied-files',
    keywords: [
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'copied',
        weight: 3,
      },
    ],
  },
  {
    name: 'copied-folders',
    className: 'custom-icon-copied-folders',
    keywords: [
      {
        word: 'folders',
        weight: 3,
      },
      {
        word: 'copied',
        weight: 3,
      },
    ],
  },
  {
    name: 'folder-create',
    className: 'custom-icon-folder-create',
    keywords: [
      {
        word: 'folders',
        weight: 3,
      },
      {
        word: 'created',
        weight: 3,
      },
    ],
  },
  {
    name: 'deleted-files',
    className: 'custom-icon-deleted-files',
    keywords: [
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'deleted',
        weight: 3,
      },
    ],
  },
  {
    name: 'deleted-folders',
    className: 'custom-icon-deleted-folders',
    keywords: [
      {
        word: 'folders',
        weight: 3,
      },
      {
        word: 'deleted',
        weight: 3,
      },
    ],
  },
  {
    name: 'modified-files',
    className: 'custom-icon-modified-files',
    keywords: [
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'modified',
        weight: 3,
      },
    ],
  },
  {
    name: 'modified-folders',
    className: 'custom-icon-modified-folders',
    keywords: [
      {
        word: 'folders',
        weight: 3,
      },
      {
        word: 'modified',
        weight: 3,
      },
    ],
  },
  {
    name: 'moved-files',
    className: 'custom-icon-moved-files',
    keywords: [
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'moved',
        weight: 3,
      },
    ],
  },
  {
    name: 'moved-folders',
    className: 'custom-icon-moved-folders',
    keywords: [
      {
        word: 'folders',
        weight: 3,
      },
      {
        word: 'moved',
        weight: 3,
      },
    ],
  },
  {
    name: 'renamed-files',
    className: 'custom-icon-renamed-files',
    keywords: [
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'renamed',
        weight: 3,
      },
    ],
  },
  {
    name: 'renamed-folders',
    className: 'custom-icon-renamed-folders',
    keywords: [
      {
        word: 'folders',
        weight: 3,
      },
      {
        word: 'renamed',
        weight: 3,
      },
    ],
  },
  {
    name: 'restored-files',
    className: 'custom-icon-restored-files',
    keywords: [
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'restored',
        weight: 3,
      },
    ],
  },
  {
    name: 'restored-folders',
    className: 'custom-icon-restored-folders',
    keywords: [
      {
        word: 'folders',
        weight: 3,
      },
      {
        word: 'restored',
        weight: 3,
      },
    ],
  },
  {
    name: 'uploaded-files',
    className: 'custom-icon-uploaded-files',
    keywords: [
      {
        word: 'uploaded',
        weight: 3,
      },
      {
        word: 'files',
        weight: 3,
      },
    ],
  },
  {
    name: 'discover-risky-sign-ins',
    className: 'custom-icon-discover-risky-sign-ins',
    keywords: [
      {
        word: 'risky',
        weight: 3,
      },
      {
        word: 'discover',
        weight: 3,
      },
      {
        word: 'sign',
        weight: 3,
      },
      {
        word: 'ins',
        weight: 3,
      },
    ],
  },
  {
    name: 'examine-user-access',
    className: 'custom-icon-examine-user-access',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'examine',
        weight: 3,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'monitor-access-rights-to-user-files',
    className: 'custom-icon-monitor-access-rights-to-user-files',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'monitor',
        weight: 3,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'rights',
        weight: 3,
      },
      {
        word: 'to',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'monitor-admin-access',
    className: 'custom-icon-monitor-admin-access',
    keywords: [
      {
        word: 'monitor',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'privilege',
        weight: 4,
      },
      {
        word: 'administrator',
        weight: 5,
      },
      {
        word: 'permission',
        weight: 4,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'admin',
        weight: 5,
      },
    ],
  },
  {
    name: 'monitor-anti-malware',
    className: 'custom-icon-monitor-anti-malware',
    keywords: [
      {
        word: 'anti',
        weight: 3,
      },
      {
        word: 'monitor',
        weight: 3,
      },
      {
        word: 'malware',
        weight: 3,
      },
    ],
  },
  {
    name: 'monitor-user-roles-access-rights',
    className: 'custom-icon-monitor-user-roles-access-rights',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'monitor',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'rights',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'roles',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'review-score-trends',
    className: 'custom-icon-review-score-trends',
    keywords: [
      {
        word: 'trends',
        weight: 3,
      },
      {
        word: 'review',
        weight: 3,
      },
      {
        word: 'score',
        weight: 3,
      },
    ],
  },
  {
    name: 'risk-identification',
    className: 'custom-icon-risk-identification',
    keywords: [
      {
        word: 'identification',
        weight: 3,
      },
      {
        word: 'risk',
        weight: 3,
      },
    ],
  },
  {
    name: 'track-configuration-changes',
    className: 'custom-icon-track-configuration-changes',
    keywords: [
      {
        word: 'track',
        weight: 3,
      },
      {
        word: 'changes',
        weight: 3,
      },
      {
        word: 'configuration',
        weight: 3,
      },
    ],
  },
  {
    name: 'track-login-attempts',
    className: 'custom-icon-track-login-attempts',
    keywords: [
      {
        word: 'track',
        weight: 3,
      },
      {
        word: 'attempts',
        weight: 3,
      },
      {
        word: 'login',
        weight: 3,
      },
    ],
  },
  {
    name: 'track-login-attempts-1',
    className: 'custom-icon-track-login-attempts-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'track',
        weight: 3,
      },
      {
        word: 'attempts',
        weight: 3,
      },
      {
        word: 'login',
        weight: 3,
      },
    ],
  },
  {
    name: 'verify-downloaded-files',
    className: 'custom-icon-verify-downloaded-files',
    keywords: [
      {
        word: 'verify',
        weight: 3,
      },
      {
        word: 'files',
        weight: 3,
      },
      {
        word: 'downloaded',
        weight: 3,
      },
    ],
  },
  {
    name: 'verify-policy-details',
    className: 'custom-icon-verify-policy-details',
    keywords: [
      {
        word: 'verify',
        weight: 3,
      },
      {
        word: 'policy',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
    ],
  },
  {
    name: 'verify-user-identity',
    className: 'custom-icon-verify-user-identity',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'verify',
        weight: 3,
      },
      {
        word: 'identity',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'theme-switch',
    className: 'custom-icon-theme-switch',
    keywords: [
      {
        word: 'switch',
        weight: 3,
      },
      {
        word: 'theme',
        weight: 3,
      },
    ],
  },
  {
    name: 'concealed-data',
    className: 'custom-icon-concealed-data',
    keywords: [
      {
        word: 'concealed',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'exo-upgrade',
    className: 'custom-icon-exo-upgrade',
    keywords: [
      {
        word: 'upgrade',
        weight: 3,
      },
      {
        word: 'exo',
        weight: 3,
      },
    ],
  },
  {
    name: 'inportal-updates',
    className: 'custom-icon-inportal-updates',
    keywords: [
      {
        word: 'inportal',
        weight: 3,
      },
      {
        word: 'updates',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-info1',
    className: 'custom-icon-mail-info1',
    keywords: [
      {
        word: 'custom-icon-mail-info1',
        weight: 5,
      },
    ],
  },
  {
    name: 'new-reports',
    className: 'custom-icon-new-reports',
    keywords: [
      {
        word: 'new',
        weight: 3,
      },
      {
        word: 'reports',
        weight: 3,
      },
    ],
  },
  {
    name: 'swap',
    className: 'custom-icon-swap',
    keywords: [
      {
        word: 'Swap',
        weight: 3,
      },
    ],
  },
  {
    name: 'audit-user-activity',
    className: 'custom-icon-audit-user-activity',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'investigate-on-breach-activity',
    className: 'custom-icon-investigate-on-breach-activity',
    keywords: [
      {
        word: 'breach',
        weight: 3,
      },
      {
        word: 'on',
        weight: 3,
      },
      {
        word: 'investigate',
        weight: 3,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-info',
    className: 'custom-icon-mail-info',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'monitor-user-logins',
    className: 'custom-icon-monitor-user-logins',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'monitor',
        weight: 3,
      },
      {
        word: 'logins',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'review-database-activity',
    className: 'custom-icon-review-database-activity',
    keywords: [
      {
        word: 'review',
        weight: 3,
      },
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'users-having-special-permissions',
    className: 'custom-icon-users-having-special-permissions',
    keywords: [
      {
        word: 'permissions',
        weight: 3,
      },
      {
        word: 'having',
        weight: 3,
      },
      {
        word: 'special',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'password-change',
    className: 'custom-icon-password-change',
    keywords: [
      {
        word: 'password',
        weight: 3,
      },
      {
        word: 'change',
        weight: 3,
      },
    ],
  },
  {
    name: 'dashboard-delegation',
    className: 'custom-icon-dashboard-delegation',
    keywords: [
      {
        word: 'delegation',
        weight: 3,
      },
      {
        word: 'dashboard',
        weight: 3,
      },
    ],
  },
  {
    name: 'delegated-access-inspection',
    className: 'custom-icon-delegated-access-inspection',
    keywords: [
      {
        word: 'delegated',
        weight: 3,
      },
      {
        word: 'inspection',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
    ],
  },
  {
    name: 'granular-roles',
    className: 'custom-icon-granular-roles',
    keywords: [
      {
        word: 'roles',
        weight: 3,
      },
      {
        word: 'granular',
        weight: 3,
      },
    ],
  },
  {
    name: 'review-admin-activity-logs',
    className: 'custom-icon-review-admin-activity-logs',
    keywords: [
      {
        word: 'review',
        weight: 3,
      },
      {
        word: 'logs',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'privilege',
        weight: 4,
      },
      {
        word: 'administrator',
        weight: 5,
      },
      {
        word: 'permission',
        weight: 4,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'admin',
        weight: 5,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'folder-file',
    className: 'custom-icon-folder-file',
    keywords: [
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'file-activities-by-admins',
    className: 'custom-icon-file-activities-by-admins',
    keywords: [
      {
        word: 'admins',
        weight: 3,
      },
      {
        word: 'by',
        weight: 3,
      },
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'activities',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'hub-site-activities',
    className: 'custom-icon-hub-site-activities',
    keywords: [
      {
        word: 'activities',
        weight: 3,
      },
      {
        word: 'hub',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'senstivity-labels',
    className: 'custom-icon-senstivity-labels',
    keywords: [
      {
        word: 'senstivity',
        weight: 3,
      },
      {
        word: 'labels',
        weight: 3,
      },
    ],
  },
  {
    name: 'site-collection-configuration',
    className: 'custom-icon-site-collection-configuration',
    keywords: [
      {
        word: 'collection',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'configuration',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-shares',
    className: 'custom-icon-user-shares',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'shares',
        weight: 3,
      },
    ],
  },
  {
    name: 'youtube',
    className: 'custom-icon-youtube',
    keywords: [
      {
        word: 'youtube',
        weight: 3,
      },
    ],
  },
  {
    name: 'reddit',
    className: 'custom-icon-reddit',
    keywords: [
      {
        word: 'reddit',
        weight: 3,
      },
    ],
  },
  {
    name: 'reddit-box',
    className: 'custom-icon-reddit-box',
    keywords: [
      {
        word: 'box',
        weight: 3,
      },
      {
        word: 'reddit',
        weight: 3,
      },
    ],
  },
  {
    name: 'facebook-box',
    className: 'custom-icon-facebook-box',
    keywords: [
      {
        word: 'facebook',
        weight: 3,
      },
      {
        word: 'box',
        weight: 3,
      },
    ],
  },
  {
    name: 'merging-reports',
    className: 'custom-icon-merging-reports',
    keywords: [
      {
        word: 'merging',
        weight: 3,
      },
      {
        word: 'reports',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-https',
    className: 'custom-icon-enable-https',
    keywords: [
      {
        word: 'webpage',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'youtube-box',
    className: 'custom-icon-youtube-box',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'box',
        weight: 3,
      },
      {
        word: 'youtube',
        weight: 3,
      },
    ],
  },
  {
    name: 'advanced-alerting',
    className: 'custom-icon-advanced-alerting',
    keywords: [
      {
        word: 'alerting',
        weight: 3,
      },
      {
        word: 'advanced',
        weight: 3,
      },
    ],
  },
  {
    name: 'explore-reports',
    className: 'custom-icon-explore-reports',
    keywords: [
      {
        word: 'reports',
        weight: 3,
      },
      {
        word: 'explore',
        weight: 3,
      },
    ],
  },
  {
    name: 'granular-delegation',
    className: 'custom-icon-granular-delegation',
    keywords: [
      {
        word: 'delegation',
        weight: 3,
      },
      {
        word: 'granular',
        weight: 3,
      },
    ],
  },
  {
    name: 'schedule-reports',
    className: 'custom-icon-schedule-reports',
    keywords: [
      {
        word: 'reports',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
    ],
  },
  {
    name: 'access-anywhere-users',
    className: 'custom-icon-access-anywhere-users',
    keywords: [
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'manage-multiple-tenants',
    className: 'custom-icon-manage-multiple-tenants',
    keywords: [
      {
        word: 'arrange',
        weight: 4,
      },
      {
        word: 'administration',
        weight: 3,
      },
      {
        word: 'manage',
        weight: 4,
      },
      {
        word: 'multiple',
        weight: 3,
      },
      {
        word: 'control',
        weight: 3,
      },
      {
        word: 'organize',
        weight: 3,
      },
      {
        word: 'tenants',
        weight: 3,
      },
    ],
  },
  {
    name: 'others-access-this-portal',
    className: 'custom-icon-others-access-this-portal',
    keywords: [
      {
        word: 'this',
        weight: 3,
      },
      {
        word: 'others',
        weight: 3,
      },
      {
        word: 'portal',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
    ],
  },
  {
    name: 'AdminDroid-text',
    className: 'custom-icon-AdminDroid-text',
    keywords: [
      {
        word: 'text',
        weight: 3,
      },
      {
        word: 'AdminDroid',
        weight: 3,
      },
    ],
  },
  {
    name: 'audit-admin-details',
    className: 'custom-icon-audit-admin-details',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'Audit',
        weight: 3,
      },
      {
        word: 'administrator',
        weight: 5,
      },
      {
        word: 'privilege',
        weight: 4,
      },
      {
        word: 'permission',
        weight: 4,
      },
      {
        word: 'Details',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'admin',
        weight: 5,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'dudit-delegate-details',
    className: 'custom-icon-audit-delegate-details',
    keywords: [
      {
        word: 'Delegate',
        weight: 3,
      },
      {
        word: 'Audit',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'audit-owner-details',
    className: 'custom-icon-audit-owner-details',
    keywords: [
      {
        word: 'Audit',
        weight: 3,
      },
      {
        word: 'owner',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-audit',
    className: 'custom-icon-mailbox-audit',
    keywords: [
      {
        word: 'Audit',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-usage',
    className: 'custom-icon-mail-usage',
    keywords: [
      {
        word: 'Mail',
        weight: 3,
      },
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-connections',
    className: 'custom-icon-mailbox-connections',
    keywords: [
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'connections',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-settings-2',
    className: 'custom-icon-mailbox-settings-2',
    keywords: [
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-settings',
    className: 'custom-icon-mailbox-settings',
    keywords: [
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-types',
    className: 'custom-icon-mailbox-types',
    keywords: [
      {
        word: 'types',
        weight: 3,
      },
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox',
    className: 'custom-icon-mailbox',
    keywords: [
      {
        word: 'Mailbox',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-overall',
    className: 'custom-icon-mailbox-overall',
    keywords: [
      {
        word: 'Overall',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-quota-and-size',
    className: 'custom-icon-mailbox-quota-and-size',
    keywords: [
      {
        word: 'Quota',
        weight: 3,
      },
      {
        word: 'Size',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mfa-authentication-method',
    className: 'custom-icon-mfa-authentication-method',
    keywords: [
      {
        word: 'method',
        weight: 3,
      },
      {
        word: 'MFA',
        weight: 3,
      },
      {
        word: 'Authentication',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'azure-ad-overall',
    className: 'custom-icon-azure-ad-overall',
    keywords: [
      {
        word: 'Azure',
        weight: 3,
      },
      {
        word: 'AD',
        weight: 3,
      },
      {
        word: 'Overall',
        weight: 3,
      },
      {
        word: '',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'group',
    className: 'custom-icon-group',
    keywords: [
      {
        word: 'Group',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'iso',
    className: 'custom-icon-iso',
    keywords: [
      {
        word: 'iso',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-light',
    className: 'custom-icon-license-light',
    keywords: [
      {
        word: 'License',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'security-light',
    className: 'custom-icon-security-light',
    keywords: [
      {
        word: 'Security',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription',
    className: 'custom-icon-subscription',
    keywords: [
      {
        word: 'Subscription',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'user',
    className: 'custom-icon-user',
    keywords: [
      {
        word: 'User',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'admin',
    className: 'custom-icon-admin',
    keywords: [
      {
        word: 'Admin',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'expired',
    className: 'custom-icon-expired',
    keywords: [
      {
        word: 'Expired',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'caution',
        weight: 3,
      },
      {
        word: 'alert',
        weight: 3,
      },
      {
        word: 'warning',
        weight: 3,
      },
      {
        word: 'alert',
        weight: 3,
      },
    ],
  },
  {
    name: 'expiry-status',
    className: 'custom-icon-expiry-status',
    keywords: [
      {
        word: 'Expiry',
        weight: 3,
      },
      {
        word: 'status',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mfa-overview',
    className: 'custom-icon-mfa-overview',
    keywords: [
      {
        word: 'overview',
        weight: 3,
      },
      {
        word: 'MFA',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mfa',
    className: 'custom-icon-mfa',
    keywords: [
      {
        word: 'MFA',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'never-changed',
    className: 'custom-icon-never-changed',
    keywords: [
      {
        word: 'Changed',
        weight: 3,
      },
      {
        word: 'Never',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'never-expires',
    className: 'custom-icon-never-expires',
    keywords: [
      {
        word: 'Expires',
        weight: 3,
      },
      {
        word: 'Never',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'password',
    className: 'custom-icon-password',
    keywords: [
      {
        word: 'Password',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'soon-to-expire',
    className: 'custom-icon-soon-to-expire',
    keywords: [
      {
        word: 'to',
        weight: 3,
      },
      {
        word: 'Soon',
        weight: 3,
      },
      {
        word: 'expire',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-without-mfa',
    className: 'custom-icon-user-without-mfa',
    keywords: [
      {
        word: 'User',
        weight: 3,
      },
      {
        word: 'without',
        weight: 3,
      },
      {
        word: 'MFA',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'video-cc',
    className: 'custom-icon-video-cc',
    keywords: [
      {
        word: 'cc',
        weight: 3,
      },
      {
        word: 'video',
        weight: 3,
      },
    ],
  },
  {
    name: 'calls',
    className: 'custom-icon-calls',
    keywords: [
      {
        word: 'calls',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'channel-statistics',
    className: 'custom-icon-channel-statistics',
    keywords: [
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'statistics',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'chats',
    className: 'custom-icon-chats',
    keywords: [
      {
        word: 'chats',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-libs',
    className: 'custom-icon-doc-libs',
    keywords: [
      {
        word: 'libs',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'hidden',
    className: 'custom-icon-hidden',
    keywords: [
      {
        word: 'hidden',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'incoming-traffic',
    className: 'custom-icon-incoming-traffic',
    keywords: [
      {
        word: 'incoming',
        weight: 3,
      },
      {
        word: 'traffic',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'list',
    className: 'custom-icon-list',
    keywords: [
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mails-read',
    className: 'custom-icon-mails-read',
    keywords: [
      {
        word: 'Read',
        weight: 3,
      },
      {
        word: 'Mails',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mails-received',
    className: 'custom-icon-mails-received',
    keywords: [
      {
        word: 'mails',
        weight: 3,
      },
      {
        word: 'received',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'mails-sent',
    className: 'custom-icon-mails-sent',
    keywords: [
      {
        word: 'mails',
        weight: 3,
      },
      {
        word: 'sent',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'malware-received',
    className: 'custom-icon-malware-received',
    keywords: [
      {
        word: 'received',
        weight: 3,
      },
      {
        word: 'malware',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'meetings',
    className: 'custom-icon-meetings',
    keywords: [
      {
        word: 'meetings',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-membership-light',
    className: 'custom-icon-teams-membership-light',
    keywords: [
      {
        word: 'Membership',
        weight: 3,
      },
      {
        word: 'Teams',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'outgoing-traffic',
    className: 'custom-icon-outgoing-traffic',
    keywords: [
      {
        word: 'traffic',
        weight: 3,
      },
      {
        word: 'Outgoing',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'overall-traffic-2',
    className: 'custom-icon-overall-traffic-2',
    keywords: [
      {
        word: 'overall',
        weight: 3,
      },
      {
        word: 'traffic',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'overall-traffic',
    className: 'custom-icon-overall-traffic',
    keywords: [
      {
        word: 'overall',
        weight: 3,
      },
      {
        word: 'traffic',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'phish-received',
    className: 'custom-icon-phish-received',
    keywords: [
      {
        word: 'received',
        weight: 3,
      },
      {
        word: 'phish',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'private-channels1',
    className: 'custom-icon-private-channels1',
    keywords: [
      {
        word: 'private',
        weight: 3,
      },
      {
        word: 'channels',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'private-chat-2',
    className: 'custom-icon-private-chat-2',
    keywords: [
      {
        word: 'Private',
        weight: 3,
      },
      {
        word: 'conversation',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'chat',
        weight: 5,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'discussion',
        weight: 4,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'talk',
        weight: 4,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'private-chats',
    className: 'custom-icon-private-chats',
    keywords: [
      {
        word: 'chats',
        weight: 3,
      },
      {
        word: 'private',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'sharepoint-overall',
    className: 'custom-icon-sharepoint-overall',
    keywords: [
      {
        word: 'overall',
        weight: 3,
      },
      {
        word: 'SharePoint',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'site-collection',
    className: 'custom-icon-site-collection',
    keywords: [
      {
        word: 'Site',
        weight: 3,
      },
      {
        word: 'collection',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'sites',
    className: 'custom-icon-sites',
    keywords: [
      {
        word: 'sites',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'spam-received',
    className: 'custom-icon-spam-received',
    keywords: [
      {
        word: 'spam',
        weight: 3,
      },
      {
        word: 'received',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'spoof-received',
    className: 'custom-icon-spoof-received',
    keywords: [
      {
        word: 'received',
        weight: 3,
      },
      {
        word: 'spoof',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'storage-light',
    className: 'custom-icon-storage-light',
    keywords: [
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-overall',
    className: 'custom-icon-teams-overall',
    keywords: [
      {
        word: 'overall',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-usage',
    className: 'custom-icon-teams-usage',
    keywords: [
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-mail-stats',
    className: 'custom-icon-user-mail-stats',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'stats',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'top-failures',
    className: 'custom-icon-top-failures',
    keywords: [
      {
        word: 'Top',
        weight: 3,
      },
      {
        word: 'failures',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'usage-and-adoption-overview',
    className: 'custom-icon-usage-and-adoption-overview',
    keywords: [
      {
        word: 'Usage',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'overview',
        weight: 3,
      },
      {
        word: 'adoption',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'by-admins',
    className: 'custom-icon-by-admins',
    keywords: [
      {
        word: 'By',
        weight: 3,
      },
      {
        word: 'admins',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'by-city',
    className: 'custom-icon-by-city',
    keywords: [
      {
        word: 'city',
        weight: 3,
      },
      {
        word: 'By',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'by-company-name',
    className: 'custom-icon-by-company-name',
    keywords: [
      {
        word: 'By',
        weight: 3,
      },
      {
        word: 'name',
        weight: 3,
      },
      {
        word: 'company',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'by-country',
    className: 'custom-icon-by-country',
    keywords: [
      {
        word: 'By',
        weight: 3,
      },
      {
        word: 'country',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'by-external-users',
    className: 'custom-icon-by-external-users',
    keywords: [
      {
        word: 'By',
        weight: 3,
      },
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'by-job-title',
    className: 'custom-icon-by-job-title',
    keywords: [
      {
        word: 'By',
        weight: 3,
      },
      {
        word: 'title',
        weight: 3,
      },
      {
        word: 'job',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'by-state',
    className: 'custom-icon-by-state',
    keywords: [
      {
        word: 'By',
        weight: 3,
      },
      {
        word: 'state',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'cjis-light',
    className: 'custom-icon-cjis-light',
    keywords: [
      {
        word: 'CJIS',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'balance',
        weight: 3,
      },
    ],
  },
  {
    name: 'fisma-light',
    className: 'custom-icon-fisma-light',
    keywords: [
      {
        word: 'fisma',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'gdpr-light',
    className: 'custom-icon-gdpr-light',
    keywords: [
      {
        word: 'GDPR',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'glba-light',
    className: 'custom-icon-glba-light',
    keywords: [
      {
        word: 'GLBA',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'hippa-light',
    className: 'custom-icon-hippa-light',
    keywords: [
      {
        word: 'HIPAA',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'pci-dss-light',
    className: 'custom-icon-pci-dss-light',
    keywords: [
      {
        word: 'DSS',
        weight: 3,
      },
      {
        word: 'PCI',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'sox-light',
    className: 'custom-icon-sox-light',
    keywords: [
      {
        word: 'SOX',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'top-activities',
    className: 'custom-icon-top-activities',
    keywords: [
      {
        word: 'activities',
        weight: 3,
      },
      {
        word: 'top',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'alert-reports',
    className: 'custom-icon-alert-reports',
    keywords: [
      {
        word: 'caution',
        weight: 3,
      },
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'signal',
        weight: 3,
      },
      {
        word: 'reports',
        weight: 3,
      },
      {
        word: 'alarm',
        weight: 3,
      },
      {
        word: 'alert',
        weight: 3,
      },
      {
        word: 'warning',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'alerts',
    className: 'custom-icon-alerts',
    keywords: [
      {
        word: 'alerts',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'm365-birds-eye-view',
    className: 'custom-icon-m365-birds-eye-view',
    keywords: [
      {
        word: 'm365',
        weight: 3,
      },
      {
        word: 'eye',
        weight: 3,
      },
      {
        word: 'view',
        weight: 3,
      },
      {
        word: 'birds',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'm365-inactive-users',
    className: 'custom-icon-m365-inactive-users',
    keywords: [
      {
        word: 'm365',
        weight: 3,
      },
      {
        word: 'inactive',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'new-role',
    className: 'custom-icon-new-role',
    keywords: [
      {
        word: 'new',
        weight: 3,
      },
      {
        word: 'role',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'policies',
    className: 'custom-icon-policies',
    keywords: [
      {
        word: 'policies',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'policy-template',
    className: 'custom-icon-policy-template',
    keywords: [
      {
        word: 'template',
        weight: 3,
      },
      {
        word: 'policy',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'roles-overview',
    className: 'custom-icon-roles-overview',
    keywords: [
      {
        word: 'overview',
        weight: 3,
      },
      {
        word: 'roles',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'activity-reports',
    className: 'custom-icon-activity-reports',
    keywords: [
      {
        word: 'reports',
        weight: 3,
      },
      {
        word: 'activity',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'admin-overview',
    className: 'custom-icon-admin-overview',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'privilege',
        weight: 4,
      },
      {
        word: 'administrator',
        weight: 5,
      },
      {
        word: 'permission',
        weight: 4,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'admin',
        weight: 5,
      },
      {
        word: 'overview',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'alert-dashboard',
    className: 'custom-icon-alert-dashboard',
    keywords: [
      {
        word: 'caution',
        weight: 3,
      },
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'signal',
        weight: 3,
      },
      {
        word: 'dashboard',
        weight: 3,
      },
      {
        word: 'alarm',
        weight: 3,
      },
      {
        word: 'alert',
        weight: 3,
      },
      {
        word: 'warning',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'new-twitter-logo',
    className: 'custom-icon-new-twitter-logo',
    keywords: [
      {
        word: 'logo',
        weight: 3,
      },
      {
        word: 'New',
        weight: 3,
      },
      {
        word: 'twitter',
        weight: 3,
      },
    ],
  },
  {
    name: 'notification-icon',
    className: 'custom-icon-notification-icon',
    keywords: [
      {
        word: 'Notification',
        weight: 3,
      },
    ],
  },
  {
    name: 'SSL-Certificate',
    className: 'custom-icon-SSL-certificate',
    keywords: [
      {
        word: 'SSL',
        weight: 3,
      },
      {
        word: 'Certificate',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-column',
    className: 'custom-icon-add-column',
    keywords: [
      {
        word: 'column',
        weight: 3,
      },
      {
        word: 'add',
        weight: 3,
      },
    ],
  },
  {
    name: 'delete-column',
    className: 'custom-icon-delete-column',
    keywords: [
      {
        word: 'column',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
    ],
  },
  {
    name: 'run-time-user',
    className: 'custom-icon-run-time-user',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'time',
        weight: 5,
      },
      {
        word: 'planning',
        weight: 4,
      },
      {
        word: 'organize',
        weight: 3,
      },
      {
        word: 'run',
        weight: 3,
      },
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'add-member-mgmt',
    className: 'custom-icon-add-member-mgmt',
    keywords: [
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'add-owner-mgmt',
    className: 'custom-icon-add-owner-mgmt',
    keywords: [
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'owner',
        weight: 3,
      },
    ],
  },
  {
    name: 'assign-manager-mgmt',
    className: 'custom-icon-assign-manager-mgmt',
    keywords: [
      {
        word: 'manager',
        weight: 3,
      },
      {
        word: 'assign',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-group-mgmt',
    className: 'custom-icon-create-group-mgmt',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-users-mgmt',
    className: 'custom-icon-create-users-mgmt',
    keywords: [
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'delete-group-mgmt',
    className: 'custom-icon-delete-group-mgmt',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
    ],
  },
  {
    name: 'delete-user-mgmt',
    className: 'custom-icon-delete-user-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'delete',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'disable-mfa-mgmt',
    className: 'custom-icon-disable-mfa-mgmt',
    keywords: [
      {
        word: 'mfa',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-users-mgmt',
    className: 'custom-icon-disable-users-mgmt',
    keywords: [
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'disconnect-existing-session-mgmt',
    className: 'custom-icon-disconnect-existing-session-mgmt',
    keywords: [
      {
        word: 'existing',
        weight: 3,
      },
      {
        word: 'session',
        weight: 3,
      },
      {
        word: 'disconnect',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-mfa-mgmt',
    className: 'custom-icon-enable-mfa-mgmt',
    keywords: [
      {
        word: 'mfa',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-users-mgmt',
    className: 'custom-icon-enable-users-mgmt',
    keywords: [
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'enforce-mfa-mgmt',
    className: 'custom-icon-enforce-mfa-mgmt',
    keywords: [
      {
        word: 'mfa',
        weight: 3,
      },
      {
        word: 'enforce',
        weight: 3,
      },
    ],
  },
  {
    name: 'drag-and-drop',
    className: 'custom-icon-drag-and-drop',
    keywords: [
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'drop',
        weight: 3,
      },
      {
        word: 'drag',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-application-owned-mgmt',
    className: 'custom-icon-get-application-owned-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'application',
        weight: 3,
      },
      {
        word: 'owned',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-direct-reports-mgmt',
    className: 'custom-icon-get-direct-reports-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'direct',
        weight: 3,
      },
      {
        word: 'reports',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-group-memberof-mgmt',
    className: 'custom-icon-get-group-memberof-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'memberof',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-group-owned-mgmt',
    className: 'custom-icon-get-group-owned-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'owned',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-group-mgmt',
    className: 'custom-icon-get-group-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-joined-teams-mgmt',
    className: 'custom-icon-get-joined-teams-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
      {
        word: 'joined',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-manager-mgmt',
    className: 'custom-icon-get-manager-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'manager',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-user-mgmt',
    className: 'custom-icon-get-user-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'is-user-available-mgmt',
    className: 'custom-icon-is-user-available-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'available',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'is',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'license-update-mgmt',
    className: 'custom-icon-license-update-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'license',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-mgmt',
    className: 'custom-icon-license-mgmt',
    keywords: [
      {
        word: 'license',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-license-mgmt',
    className: 'custom-icon-remove-license-mgmt',
    keywords: [
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'license',
        weight: 3,
      },
    ],
  },
  {
    name: 'membership-mgmt',
    className: 'custom-icon-membership-mgmt',
    keywords: [
      {
        word: 'membership',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-manager-mgmt',
    className: 'custom-icon-remove-manager-mgmt',
    keywords: [
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'manager',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-member-mgmt',
    className: 'custom-icon-remove-member-mgmt',
    keywords: [
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'mail-tip-mgmt',
    className: 'custom-icon-mail-tip-mgmt',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'tip',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'remove-user-from-all-groups-mgmt',
    className: 'custom-icon-remove-user-from-all-groups-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'groups',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'all',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-user-membership-from-all-teams-mgmt',
    className: 'custom-icon-remove-user-membership-from-all-teams-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'membership',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'all',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-user-ownership-from-all-groups-mgmt',
    className: 'custom-icon-remove-user-ownership-from-all-groups-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'groups',
        weight: 3,
      },
      {
        word: 'ownership',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'all',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-user-ownership-from-all-teams-mgmt',
    className: 'custom-icon-remove-user-ownership-from-all-teams-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'ownership',
        weight: 3,
      },
      {
        word: 'Teams',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'all',
        weight: 3,
      },
    ],
  },
  {
    name: 'replace-ownership-mgmt',
    className: 'custom-icon-replace-ownership-mgmt',
    keywords: [
      {
        word: 'replace',
        weight: 3,
      },
      {
        word: 'ownership',
        weight: 3,
      },
    ],
  },
  {
    name: 'restore-deleted-group-mgmt',
    className: 'custom-icon-restore-deleted-group-mgmt',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'deleted',
        weight: 3,
      },
      {
        word: 'restore',
        weight: 3,
      },
    ],
  },
  {
    name: 'restore-user-mgmt',
    className: 'custom-icon-restore-user-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'restore',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'retrieve-details-mgmt',
    className: 'custom-icon-retrieve-details-mgmt',
    keywords: [
      {
        word: 'retrieve',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-password-policy-mgmt',
    className: 'custom-icon-update-password-policy-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'password',
        weight: 3,
      },
      {
        word: 'policy',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-password-mgmt',
    className: 'custom-icon-update-password-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'password',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-properties-mgmt',
    className: 'custom-icon-update-properties-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'properties',
        weight: 3,
      },
    ],
  },
  {
    name: 'security-mgmt',
    className: 'custom-icon-security-mgmt',
    keywords: [
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'privacy',
        weight: 3,
      },
      {
        word: 'defense',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'safety',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-user-from-all-teams-mgmt',
    className: 'custom-icon-remove-user-from-all-teams-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'teams',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'all',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-user-membership-from-all-groups-mgmt',
    className: 'custom-icon-remove-user-membership-from-all-groups-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'groups',
        weight: 3,
      },
      {
        word: 'membership',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'all',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-custom-memes-mgmt',
    className: 'custom-icon-allow-custom-memes-mgmt',
    keywords: [
      {
        word: 'memes',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'custom',
        weight: 3,
      },
    ],
  },
  {
    name: 'block-message-from-none-mgmt',
    className: 'custom-icon-block-message-from-none-mgmt',
    keywords: [
      {
        word: 'none',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'block',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
    ],
  },
  {
    name: 'create-user-mailbox-mgmt',
    className: 'custom-icon-create-user-mailbox-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'update-message-size-mgmt',
    className: 'custom-icon-update-message-size-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'size',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
    ],
  },
  {
    name: 'accept-meessage-from-all-mgmt',
    className: 'custom-icon-accept-meessage-from-all-mgmt',
    keywords: [
      {
        word: 'accept',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'meessage',
        weight: 3,
      },
      {
        word: 'all',
        weight: 3,
      },
    ],
  },
  {
    name: 'accept-message-from-selected-mgmt',
    className: 'custom-icon-accept-message-from-selected-mgmt',
    keywords: [
      {
        word: 'accept',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'selected',
        weight: 3,
      },
    ],
  },
  {
    name: 'set-recipient-limit-mgmt',
    className: 'custom-icon-set-recipient-limit-mgmt',
    keywords: [
      {
        word: 'recipient',
        weight: 3,
      },
      {
        word: 'set',
        weight: 3,
      },
      {
        word: 'limit',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-owner-delete-messages-mgmt',
    className: 'custom-icon-allow-owner-delete-messages-mgmt',
    keywords: [
      {
        word: 'messages',
        weight: 3,
      },
      {
        word: 'owner',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-custom-attributes-mgmt',
    className: 'custom-icon-add-custom-attributes-mgmt',
    keywords: [
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'attributes',
        weight: 3,
      },
      {
        word: 'custom',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-email-to-mailbox-mgmt',
    className: 'custom-icon-add-email-to-mailbox-mgmt',
    keywords: [
      {
        word: 'to',
        weight: 3,
      },
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
    ],
  },
  {
    name: 'allow-add-remove-apps-mgmt',
    className: 'custom-icon-allow-add-remove-apps-mgmt',
    keywords: [
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'apps',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-channel-mentions-mgmt',
    className: 'custom-icon-allow-channel-mentions-mgmt',
    keywords: [
      {
        word: 'mentions',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'channel',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-create-private-channels-mgmt',
    className: 'custom-icon-allow-create-private-channels-mgmt',
    keywords: [
      {
        word: 'channels',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'private',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-create-update-channels-mgmt',
    className: 'custom-icon-allow-create-update-channels-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'channels',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-create-update-remove-connectors-mgmt',
    className: 'custom-icon-allow-create-update-remove-connectors-mgmt',
    keywords: [
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'connectors',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-create-update-remove-tabs-mgmt',
    className: 'custom-icon-allow-create-update-remove-tabs-mgmt',
    keywords: [
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'tabs',
        weight: 3,
      },
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-delete-channels-mgmt',
    className: 'custom-icon-allow-delete-channels-mgmt',
    keywords: [
      {
        word: 'channels',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-giphy-mgmt',
    className: 'custom-icon-allow-giphy-mgmt',
    keywords: [
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'giphy',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-guest-create-update-channels-mgmt',
    className: 'custom-icon-allow-guest-create-update-channels-mgmt',
    keywords: [
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'channels',
        weight: 3,
      },
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'guest',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-stickers-and-memes-mgmt',
    className: 'custom-icon-allow-stickers-and-memes-mgmt',
    keywords: [
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'stickers',
        weight: 3,
      },
      {
        word: 'memes',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-team-mentions-mgmt',
    className: 'custom-icon-allow-team-mentions-mgmt',
    keywords: [
      {
        word: 'team',
        weight: 3,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'mentions',
        weight: 3,
      },
    ],
  },
  {
    name: 'allow-user-delete-messages-mgmt',
    className: 'custom-icon-allow-user-delete-messages-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'delete',
        weight: 3,
      },
      {
        word: 'messages',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'allow-user-edit-messages-mgmt',
    className: 'custom-icon-allow-user-edit-messages-mgmt',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'allow',
        weight: 3,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'edit',
        weight: 3,
      },
      {
        word: 'messages',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'archive-mgmt',
    className: 'custom-icon-archive-mgmt',
    keywords: [
      {
        word: 'archive',
        weight: 3,
      },
    ],
  },
  {
    name: 'clone-teams-mgmt',
    className: 'custom-icon-clone-teams-mgmt',
    keywords: [
      {
        word: 'clone',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-equipment-mailbox-mgmt',
    className: 'custom-icon-create-equipment-mailbox-mgmt',
    keywords: [
      {
        word: 'equipment',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'mail',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-shared-mailbox-mgmt',
    className: 'custom-icon-create-shared-mailbox-mgmt',
    keywords: [
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'shared',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-team-from-group-mgmt',
    className: 'custom-icon-create-team-from-group-mgmt',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'team',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-team-mgmt',
    className: 'custom-icon-create-team-mgmt',
    keywords: [
      {
        word: 'team',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'delete-team-mgmt',
    className: 'custom-icon-delete-team-mgmt',
    keywords: [
      {
        word: 'team',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-mailbox-archive-mgmt',
    className: 'custom-icon-disable-mailbox-archive-mgmt',
    keywords: [
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'archive',
        weight: 3,
      },
    ],
  },
  {
    name: 'email-forwarding-mgmt',
    className: 'custom-icon-email-forwarding-mgmt',
    keywords: [
      {
        word: 'forwarding',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
    ],
  },
  {
    name: 'get-team-mgmt',
    className: 'custom-icon-get-team-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'team',
        weight: 3,
      },
    ],
  },
  {
    name: 'giphy-content-rating-mgmt',
    className: 'custom-icon-giphy-content-rating-mgmt',
    keywords: [
      {
        word: 'content',
        weight: 3,
      },
      {
        word: 'rating',
        weight: 3,
      },
      {
        word: 'giphy',
        weight: 3,
      },
    ],
  },
  {
    name: 'hide-mailbox-mgmt',
    className: 'custom-icon-hide-mailbox-mgmt',
    keywords: [
      {
        word: 'hide',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'litigation-hold-mgmt',
    className: 'custom-icon-litigation-hold-mgmt',
    keywords: [
      {
        word: 'litigation',
        weight: 3,
      },
      {
        word: 'hold',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-email-from-mailbox-mgmt',
    className: 'custom-icon-remove-email-from-mailbox-mgmt',
    keywords: [
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
    ],
  },
  {
    name: 'unarchive-mgmt',
    className: 'custom-icon-unarchive-mgmt',
    keywords: [
      {
        word: 'unarchive',
        weight: 3,
      },
    ],
  },
  {
    name: 'unhide-mailbox-mgmt',
    className: 'custom-icon-unhide-mailbox-mgmt',
    keywords: [
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'unhide',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-teams-mgmt',
    className: 'custom-icon-update-teams-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-mailbox-mgmt',
    className: 'custom-icon-enable-mailbox-mgmt',
    keywords: [
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-audit-owner-mgmt',
    className: 'custom-icon-add-audit-owner-mgmt',
    keywords: [
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'owner',
        weight: 3,
      },
      {
        word: 'audit',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-full-access-mgmt',
    className: 'custom-icon-add-full-access-mgmt',
    keywords: [
      {
        word: 'full',
        weight: 3,
      },
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
    ],
  },
  {
    name: 'get-mailbox-mgmt',
    className: 'custom-icon-get-mailbox-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-active-sync-mgmt',
    className: 'custom-icon-disable-active-sync-mgmt',
    keywords: [
      {
        word: 'active',
        weight: 3,
      },
      {
        word: 'sync',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-bypass-for-mailbox-audit-mgmt',
    className: 'custom-icon-disable-bypass-for-mailbox-audit-mgmt',
    keywords: [
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'bypass',
        weight: 3,
      },
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-ews-mgmt',
    className: 'custom-icon-disable-ews-mgmt',
    keywords: [
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'ews',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-mailbox-audit-mgmt',
    className: 'custom-icon-disable-mailbox-audit-mgmt',
    keywords: [
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-mapi-mgmt',
    className: 'custom-icon-disable-mapi-mgmt',
    keywords: [
      {
        word: 'mapi',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-message-copy-for-send-on-behalf-mgmt',
    className: 'custom-icon-disable-message-copy-for-send-on-behalf-mgmt',
    keywords: [
      {
        word: 'on',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'behalf',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'copy',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-org-audit-mgmt',
    className: 'custom-icon-disable-org-audit-mgmt',
    keywords: [
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'org',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-pop3-mgmt',
    className: 'custom-icon-disable-pop3-mgmt',
    keywords: [
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'pop3',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-bypass-for-mailbox-audit-mgmt',
    className: 'custom-icon-enable-bypass-for-mailbox-audit-mgmt',
    keywords: [
      {
        word: 'mailbox',
        weight: 3,
      },
      {
        word: 'bypass',
        weight: 3,
      },
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-ews-mgmt',
    className: 'custom-icon-enable-ews-mgmt',
    keywords: [
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'ews',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-imap-mgmt',
    className: 'custom-icon-disable-imap-mgmt',
    keywords: [
      {
        word: 'imap',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-mailbox-audit-mgmt',
    className: 'custom-icon-enable-mailbox-audit-mgmt',
    keywords: [
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-mapi-mgmt',
    className: 'custom-icon-enable-mapi-mgmt',
    keywords: [
      {
        word: 'mapi',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-message-copy-for-send-on-behalf-mgmt',
    className: 'custom-icon-enable-message-copy-for-send-on-behalf-mgmt',
    keywords: [
      {
        word: 'on',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'behalf',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'copy',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-org-audit-mgmt',
    className: 'custom-icon-enable-org-audit-mgmt',
    keywords: [
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'org',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-pop3-mgmt',
    className: 'custom-icon-enable-pop3-mgmt',
    keywords: [
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'pop3',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-audit-owner-mgmt',
    className: 'custom-icon-remove-audit-owner-mgmt',
    keywords: [
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'owner',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-automatic-reply-for-inside-mgmt',
    className: 'custom-icon-disable-automatic-reply-for-inside-mgmt',
    keywords: [
      {
        word: 'reply',
        weight: 3,
      },
      {
        word: 'automatic',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'inside',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-automatic-reply-for-outside-mgmt',
    className: 'custom-icon-disable-automatic-reply-for-outside-mgmt',
    keywords: [
      {
        word: 'reply',
        weight: 3,
      },
      {
        word: 'automatic',
        weight: 3,
      },
      {
        word: 'outside',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-automatic-reply-mgmt',
    className: 'custom-icon-disable-automatic-reply-mgmt',
    keywords: [
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'reply',
        weight: 3,
      },
      {
        word: 'automatic',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-message-copy-for-send-as-mgmt',
    className: 'custom-icon-disable-message-copy-for-send-as-mgmt',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'as',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'copy',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-owa-mgmt',
    className: 'custom-icon-disable-owa-mgmt',
    keywords: [
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'owa',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-senders-are-authenticated-mgmt',
    className: 'custom-icon-disable-senders-are-authenticated-mgmt',
    keywords: [
      {
        word: 'senders',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'are',
        weight: 3,
      },
      {
        word: 'authenticated',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-automatic-reply-for-inside-mgmt',
    className: 'custom-icon-enable-automatic-reply-for-inside-mgmt',
    keywords: [
      {
        word: 'reply',
        weight: 3,
      },
      {
        word: 'automatic',
        weight: 3,
      },
      {
        word: 'inside',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-automatic-reply-mgmt',
    className: 'custom-icon-enable-automatic-reply-mgmt',
    keywords: [
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'reply',
        weight: 3,
      },
      {
        word: 'automatic',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-message-copy-for-send-as-mgmt',
    className: 'custom-icon-enable-message-copy-for-send-as-mgmt',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'as',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'copy',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-owa-mgmt',
    className: 'custom-icon-enable-owa-mgmt',
    keywords: [
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'owa',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-senders-are-authenticated-mgmt',
    className: 'custom-icon-enable-senders-are-authenticated-mgmt',
    keywords: [
      {
        word: 'senders',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'are',
        weight: 3,
      },
      {
        word: 'authenticated',
        weight: 3,
      },
    ],
  },
  {
    name: 'schedule-automatic-reply-for-inside-mgmt',
    className: 'custom-icon-schedule-automatic-reply-for-inside-mgmt',
    keywords: [
      {
        word: 'reply',
        weight: 3,
      },
      {
        word: 'automatic',
        weight: 3,
      },
      {
        word: 'inside',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
      {
        word: 'for',
        weight: 3,
      },
    ],
  },
  {
    name: 'schedule-automatic-reply-for-outside-mgmt',
    className: 'custom-icon-schedule-automatic-reply-for-outside-mgmt',
    keywords: [
      {
        word: 'reply',
        weight: 3,
      },
      {
        word: 'automatic',
        weight: 3,
      },
      {
        word: 'outside',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
      {
        word: 'for',
        weight: 3,
      },
    ],
  },
  {
    name: 'schedule-automatic-reply-mgmt',
    className: 'custom-icon-schedule-automatic-reply-mgmt',
    keywords: [
      {
        word: 'reply',
        weight: 3,
      },
      {
        word: 'automatic',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
    ],
  },
  {
    name: 'soft-delete-messages-mgmt',
    className: 'custom-icon-soft-delete-messages-mgmt',
    keywords: [
      {
        word: 'soft',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
      {
        word: 'messages',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-distribution-list-mgmt',
    className: 'custom-icon-create-distribution-list-mgmt',
    keywords: [
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'distribution',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-distribution-list-mgmt',
    className: 'custom-icon-get-distribution-list-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'distribution',
        weight: 3,
      },
    ],
  },
  {
    name: 'delete-distribution-list-mgmt',
    className: 'custom-icon-delete-distribution-list-mgmt',
    keywords: [
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
      {
        word: 'distribution',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-inbox-rule-mgmt',
    className: 'custom-icon-create-inbox-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-inbox-rule-mgmt',
    className: 'custom-icon-disable-inbox-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
    ],
  },
  {
    name: 'enable-inbox-rule-mgmt',
    className: 'custom-icon-enable-inbox-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
    ],
  },
  {
    name: 'get-inbox-rule-mgmt',
    className: 'custom-icon-get-inbox-rule-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'rule',
        weight: 3,
      },
    ],
  },
  {
    name: 'modify-inbox-rule-mgmt',
    className: 'custom-icon-modify-inbox-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'modify',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-inbox-rule-mgmt',
    className: 'custom-icon-remove-inbox-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
    ],
  },
  {
    name: 'create-transport-rule-mgmt',
    className: 'custom-icon-create-transport-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
      {
        word: 'transport',
        weight: 3,
      },
    ],
  },
  {
    name: 'disable-transport-rule-mgmt',
    className: 'custom-icon-disable-transport-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'disable',
        weight: 3,
      },
      {
        word: 'transport',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-transport-rule-mgmt',
    className: 'custom-icon-enable-transport-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
      {
        word: 'transport',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-transport-rule-mgmt',
    className: 'custom-icon-get-transport-rule-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'transport',
        weight: 3,
      },
    ],
  },
  {
    name: 'modify-transport-rule-mgmt',
    className: 'custom-icon-modify-transport-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'modify',
        weight: 3,
      },
      {
        word: 'transport',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-transport-rule-mgmt',
    className: 'custom-icon-remove-transport-rule-mgmt',
    keywords: [
      {
        word: 'rule',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
      {
        word: 'transport',
        weight: 3,
      },
    ],
  },
  {
    name: 'recover-soft-deleted-mailbox-mgmt',
    className: 'custom-icon-recover-soft-deleted-mailbox-mgmt',
    keywords: [
      {
        word: 'soft',
        weight: 3,
      },
      {
        word: 'deleted',
        weight: 3,
      },
      {
        word: 'recover',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'send-as-mgmt',
    className: 'custom-icon-send-as-mgmt',
    keywords: [
      {
        word: 'as',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
    ],
  },
  {
    name: 'send-on-behalf-mgmt',
    className: 'custom-icon-send-on-behalf-mgmt',
    keywords: [
      {
        word: 'on',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'behalf',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-recipient-type-mgmt',
    className: 'custom-icon-update-recipient-type-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'type',
        weight: 3,
      },
      {
        word: 'recipient',
        weight: 3,
      },
    ],
  },
  {
    name: 'enable-imap-mgmt',
    className: 'custom-icon-enable-imap-mgmt',
    keywords: [
      {
        word: 'imap',
        weight: 3,
      },
      {
        word: 'enable',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-allowed-domain-mgmt',
    className: 'custom-icon-add-allowed-domain-mgmt',
    keywords: [
      {
        word: 'allowed',
        weight: 3,
      },
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'domain',
        weight: 3,
      },
    ],
  },
  {
    name: 'add-blocked-domain-mgmt',
    className: 'custom-icon-add-blocked-domain-mgmt',
    keywords: [
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'blocked',
        weight: 3,
      },
      {
        word: 'domain',
        weight: 3,
      },
    ],
  },
  {
    name: 'create-spo-group-mgmt',
    className: 'custom-icon-create-spo-group-mgmt',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'spo',
        weight: 3,
      },
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'delete-permission-mgmt',
    className: 'custom-icon-delete-permission-mgmt',
    keywords: [
      {
        word: 'delete',
        weight: 3,
      },
      {
        word: 'permission',
        weight: 4,
      },
    ],
  },
  {
    name: 'delete-site-from-recyclebin-mgmt',
    className: 'custom-icon-delete-site-from-recyclebin-mgmt',
    keywords: [
      {
        word: 'recyclebin',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'delete-spo-group-mgmt',
    className: 'custom-icon-delete-spo-group-mgmt',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'spo',
        weight: 3,
      },
      {
        word: 'delete',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-anonymous-link-expiration-in-days-for-org-mgmt',
    className: 'custom-icon-get-anonymous-link-expiration-in-days-for-org-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'in',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'anonymous',
        weight: 3,
      },
      {
        word: 'org',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'days',
        weight: 3,
      },
      {
        word: 'expiration',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-external-sharing-by-domain-mgmt',
    className: 'custom-icon-get-external-sharing-by-domain-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'domain',
        weight: 3,
      },
      {
        word: 'by',
        weight: 3,
      },
      {
        word: 'sharing',
        weight: 3,
      },
    ],
  },
  {
    name: 'get-external-sharing-settings-for-site-mgmt',
    className: 'custom-icon-get-external-sharing-settings-for-site-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'sharing',
        weight: 3,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
    ],
  },
  {
    name: 'get-spo-site-guid-mgmt',
    className: 'custom-icon-get-spo-site-guid-mgmt',
    keywords: [
      {
        word: 'get',
        weight: 3,
      },
      {
        word: 'spo',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'guid',
        weight: 3,
      },
    ],
  },
  {
    name: 'grant-access-to-sharing-link-mgmt',
    className: 'custom-icon-grant-access-to-sharing-link-mgmt',
    keywords: [
      {
        word: 'sharing',
        weight: 3,
      },
      {
        word: 'grant',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'to',
        weight: 3,
      },
    ],
  },
  {
    name: 'restore-deleted-site-mgmt',
    className: 'custom-icon-restore-deleted-site-mgmt',
    keywords: [
      {
        word: 'deleted',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'restore',
        weight: 3,
      },
    ],
  },
  {
    name: 'revoke-access-to-sharing-links-mgmt',
    className: 'custom-icon-revoke-access-to-sharing-links-mgmt',
    keywords: [
      {
        word: 'sharing',
        weight: 3,
      },
      {
        word: 'revoke',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'to',
        weight: 3,
      },
      {
        word: 'links',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-anonymous-access-links-mgmt',
    className: 'custom-icon-update-anonymous-access-links-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'links',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'anonymous',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-anonymous-link-expire-date-time-mgmt',
    className: 'custom-icon-update-anonymous-link-expire-date-time-mgmt',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'time',
        weight: 5,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'planning',
        weight: 4,
      },
      {
        word: 'anonymous',
        weight: 3,
      },
      {
        word: 'organize',
        weight: 3,
      },
      {
        word: 'date',
        weight: 3,
      },
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'schedule',
        weight: 4,
      },
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'expire',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-default-sharing-link-type-mgmt',
    className: 'custom-icon-update-default-sharing-link-type-mgmt',
    keywords: [
      {
        word: 'sharing',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'default',
        weight: 3,
      },
      {
        word: 'type',
        weight: 3,
      },
      {
        word: 'update',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-prevent-external-users-from-resharing-mgmt',
    className: 'custom-icon-update-prevent-external-users-from-resharing-mgmt',
    keywords: [
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'prevent',
        weight: 3,
      },
      {
        word: 'resharing',
        weight: 3,
      },
      {
        word: 'from',
        weight: 3,
      },
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-site-description-mgmt',
    className: 'custom-icon-update-site-description-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'description',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-site-external-sharing-settings-mgmt',
    className: 'custom-icon-update-site-external-sharing-settings-mgmt',
    keywords: [
      {
        word: 'sharing',
        weight: 3,
      },
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
    ],
  },
  {
    name: 'update-site-group-owner-mgmt',
    className: 'custom-icon-update-site-group-owner-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'owner',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-site-logo-description-mgmt',
    className: 'custom-icon-update-site-logo-description-mgmt',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'description',
        weight: 3,
      },
      {
        word: 'logo',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'update-tenant-external-sharing-settings-mgmt',
    className: 'custom-icon-update-tenant-external-sharing-settings-mgmt',
    keywords: [
      {
        word: 'sharing',
        weight: 3,
      },
      {
        word: 'external',
        weight: 3,
      },
      {
        word: 'tenant',
        weight: 3,
      },
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
    ],
  },
  {
    name: 'anonymous-link-expiration-in-days-for-site',
    className: 'custom-icon-anonymous-link-expiration-in-days-for-site',
    keywords: [
      {
        word: 'in',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'anonymous',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'for',
        weight: 3,
      },
      {
        word: 'days',
        weight: 3,
      },
      {
        word: 'expiration',
        weight: 3,
      },
    ],
  },
  {
    name: 'css',
    className: 'custom-icon-css',
    keywords: [
      {
        word: 'css',
        weight: 3,
      },
    ],
  },
  {
    name: 'json',
    className: 'custom-icon-json',
    keywords: [
      {
        word: 'json',
        weight: 3,
      },
    ],
  },
  {
    name: 'image',
    className: 'custom-icon-image',
    keywords: [
      {
        word: 'image',
        weight: 3,
      },
    ],
  },
  {
    name: 'text',
    className: 'custom-icon-text',
    keywords: [
      {
        word: 'text',
        weight: 3,
      },
    ],
  },
  {
    name: 'video',
    className: 'custom-icon-video',
    keywords: [
      {
        word: 'video',
        weight: 3,
      },
    ],
  },
  {
    name: 'audio',
    className: 'custom-icon-audio',
    keywords: [
      {
        word: 'audio',
        weight: 3,
      },
    ],
  },
  {
    name: 'audio-1',
    className: 'custom-icon-audio-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'audio',
        weight: 3,
      },
    ],
  },
  {
    name: 'video-1',
    className: 'custom-icon-video-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'video',
        weight: 3,
      },
    ],
  },
  {
    name: 'boolean',
    className: 'custom-icon-boolean',
    keywords: [
      {
        word: 'Boolean',
        weight: 3,
      },
    ],
  },
  {
    name: 'datetime',
    className: 'custom-icon-datetime',
    keywords: [
      {
        word: 'DateTime',
        weight: 3,
      },
    ],
  },
  {
    name: 'fileuploader',
    className: 'custom-icon-fileuploader',
    keywords: [
      {
        word: 'FileUploader',
        weight: 3,
      },
    ],
  },
  {
    name: 'imageuploader',
    className: 'custom-icon-imageuploader',
    keywords: [
      {
        word: 'ImageUploader',
        weight: 3,
      },
    ],
  },
  {
    name: 'integer',
    className: 'custom-icon-integer',
    keywords: [
      {
        word: 'integer',
        weight: 3,
      },
    ],
  },
  {
    name: 'multioptions',
    className: 'custom-icon-multioptions',
    keywords: [
      {
        word: 'MultiOptions',
        weight: 3,
      },
    ],
  },
  {
    name: 'randompassword',
    className: 'custom-icon-randompassword',
    keywords: [
      {
        word: 'RandomPassword',
        weight: 3,
      },
    ],
  },
  {
    name: 'textbox',
    className: 'custom-icon-textbox',
    keywords: [
      {
        word: 'Textbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'loop-component-filled',
    className: 'custom-icon-loop-component-filled',
    keywords: [
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'component',
        weight: 3,
      },
      {
        word: 'loop',
        weight: 3,
      },
    ],
  },
  {
    name: 'loop-component-stroke',
    className: 'custom-icon-loop-component-stroke',
    keywords: [
      {
        word: 'component',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'loop',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-id',
    className: 'custom-icon-user-id',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'id',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'location-marker-stroke',
    className: 'custom-icon-location-marker-stroke',
    keywords: [
      {
        word: 'marker',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'location',
        weight: 3,
      },
    ],
  },
  {
    name: 'contact-info',
    className: 'custom-icon-contact-info',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'contact',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe',
    className: 'custom-icon-globe',
    keywords: [
      {
        word: 'globe',
        weight: 3,
      },
    ],
  },
  {
    name: 'mfa-filled-and-stroke',
    className: 'custom-icon-mfa-filled-and-stroke',
    keywords: [
      {
        word: 'mfa',
        weight: 3,
      },
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
    ],
  },
  {
    name: 'mfa-filled',
    className: 'custom-icon-mfa-filled',
    keywords: [
      {
        word: 'mfa',
        weight: 3,
      },
      {
        word: 'filled',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-details',
    className: 'custom-icon-subscription-details',
    keywords: [
      {
        word: 'subscription',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-status-1',
    className: 'custom-icon-subscription-status-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'status',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'recovery',
    className: 'custom-icon-recovery',
    keywords: [
      {
        word: 'recovery',
        weight: 3,
      },
    ],
  },
  {
    name: 'alternate-contact-filled',
    className: 'custom-icon-alternate-contact-filled',
    keywords: [
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'alternate',
        weight: 3,
      },
      {
        word: 'contact',
        weight: 3,
      },
    ],
  },
  {
    name: 'alternate-contact-stroke',
    className: 'custom-icon-alternate-contact-stroke',
    keywords: [
      {
        word: 'alternate',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'contact',
        weight: 3,
      },
    ],
  },
  {
    name: 'error',
    className: 'custom-icon-error',
    keywords: [
      {
        word: 'error',
        weight: 3,
      },
    ],
  },
  {
    name: 'on-premise-config',
    className: 'custom-icon-on-premise-config',
    keywords: [
      {
        word: 'premise',
        weight: 3,
      },
      {
        word: 'config',
        weight: 3,
      },
      {
        word: 'on',
        weight: 3,
      },
    ],
  },
  {
    name: 'collection',
    className: 'custom-icon-collection',
    keywords: [
      {
        word: 'collection',
        weight: 3,
      },
    ],
  },
  {
    name: 'collection-stroke',
    className: 'custom-icon-collection-stroke',
    keywords: [
      {
        word: 'collection',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
    ],
  },
  {
    name: 'database-filled',
    className: 'custom-icon-database-filled',
    keywords: [
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'database',
        weight: 4,
      },
    ],
  },
  {
    name: 'database-stroke',
    className: 'custom-icon-database-stroke',
    keywords: [
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'stroke',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe-with-usage',
    className: 'custom-icon-globe-with-usage',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'usage',
        weight: 3,
      },
    ],
  },
  {
    name: 'spo-permission',
    className: 'custom-icon-spo-permission',
    keywords: [
      {
        word: 'spo',
        weight: 3,
      },
      {
        word: 'permission',
        weight: 4,
      },
    ],
  },
  {
    name: 'globe-with-checkmark',
    className: 'custom-icon-globe-with-checkmark',
    keywords: [
      {
        word: 'checkmark',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe-with-gear',
    className: 'custom-icon-globe-with-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
    ],
  },
  {
    name: 'toolkit-with-gear',
    className: 'custom-icon-toolkit-with-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'toolkit',
        weight: 3,
      },
    ],
  },
  {
    name: 'audit-and-list',
    className: 'custom-icon-audit-and-list',
    keywords: [
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'list',
        weight: 3,
      },
    ],
  },
  {
    name: 'site-collection-status',
    className: 'custom-icon-site-collection-status',
    keywords: [
      {
        word: 'collection',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'status',
        weight: 3,
      },
    ],
  },
  {
    name: 'upgrade-conditions',
    className: 'custom-icon-upgrade-conditions',
    keywords: [
      {
        word: 'conditions',
        weight: 3,
      },
      {
        word: 'Upgrade',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-stroke',
    className: 'custom-icon-teams-stroke',
    keywords: [
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'channel-filled',
    className: 'custom-icon-channel-filled',
    keywords: [
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'channel',
        weight: 3,
      },
    ],
  },
  {
    name: 'channel-stroke',
    className: 'custom-icon-channel-stroke',
    keywords: [
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'channel',
        weight: 3,
      },
    ],
  },
  {
    name: 'team-status',
    className: 'custom-icon-team-status',
    keywords: [
      {
        word: 'team',
        weight: 3,
      },
      {
        word: 'status',
        weight: 3,
      },
    ],
  },
  {
    name: 'team-mem-settings',
    className: 'custom-icon-team-mem-settings',
    keywords: [
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'mem',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'team',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
    ],
  },
  {
    name: 'fun-settings',
    className: 'custom-icon-fun-settings',
    keywords: [
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'fun',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-1',
    className: 'custom-icon-group-1',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-with-gear-head',
    className: 'custom-icon-user-with-gear-head',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'head',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'globe-with-lock',
    className: 'custom-icon-globe-with-lock',
    keywords: [
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe-with-share',
    className: 'custom-icon-globe-with-share',
    keywords: [
      {
        word: 'share',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-with-badge',
    className: 'custom-icon-user-with-badge',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'badge',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'doc-with-gear',
    className: 'custom-icon-doc-with-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-gear-icon',
    className: 'custom-icon-group-with-gear-icon',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'icon',
        weight: 3,
      },
    ],
  },
  {
    name: 'uppercase',
    className: 'custom-icon-uppercase',
    keywords: [
      {
        word: 'uppercase',
        weight: 3,
      },
    ],
  },
  {
    name: 'lowercase',
    className: 'custom-icon-lowercase',
    keywords: [
      {
        word: 'lowercase',
        weight: 3,
      },
    ],
  },
  {
    name: 'replace',
    className: 'custom-icon-replace',
    keywords: [
      {
        word: 'replace',
        weight: 3,
      },
    ],
  },
  {
    name: 'capitalize',
    className: 'custom-icon-capitalize',
    keywords: [
      {
        word: 'capitalize',
        weight: 3,
      },
    ],
  },
  {
    name: 'first',
    className: 'custom-icon-first',
    keywords: [
      {
        word: 'first',
        weight: 3,
      },
    ],
  },
  {
    name: 'last',
    className: 'custom-icon-last',
    keywords: [
      {
        word: 'last',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove',
    className: 'custom-icon-remove',
    keywords: [
      {
        word: 'remove',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-1',
    className: 'custom-icon-remove-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
    ],
  },
  {
    name: 'append',
    className: 'custom-icon-append',
    keywords: [
      {
        word: 'append',
        weight: 3,
      },
    ],
  },
  {
    name: 'append-1',
    className: 'custom-icon-append-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'append',
        weight: 3,
      },
    ],
  },
  {
    name: 'select-1',
    className: 'custom-icon-select-1',
    keywords: [
      {
        word: 'select',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'select',
    className: 'custom-icon-select',
    keywords: [
      {
        word: 'select',
        weight: 3,
      },
    ],
  },
  {
    name: 'ceil',
    className: 'custom-icon-ceil',
    keywords: [
      {
        word: 'ceil',
        weight: 3,
      },
    ],
  },
  {
    name: 'floor',
    className: 'custom-icon-floor',
    keywords: [
      {
        word: 'floor',
        weight: 3,
      },
    ],
  },
  {
    name: 'round-off',
    className: 'custom-icon-round-off',
    keywords: [
      {
        word: 'round',
        weight: 3,
      },
      {
        word: 'off',
        weight: 3,
      },
    ],
  },
  {
    name: 'date',
    className: 'custom-icon-date',
    keywords: [
      {
        word: 'date',
        weight: 3,
      },
    ],
  },
  {
    name: 'day',
    className: 'custom-icon-day',
    keywords: [
      {
        word: 'day',
        weight: 3,
      },
    ],
  },
  {
    name: 'month',
    className: 'custom-icon-month',
    keywords: [
      {
        word: 'month',
        weight: 3,
      },
    ],
  },
  {
    name: 'format',
    className: 'custom-icon-format',
    keywords: [
      {
        word: 'format',
        weight: 3,
      },
    ],
  },
  {
    name: 'default',
    className: 'custom-icon-default',
    keywords: [
      {
        word: 'default',
        weight: 3,
      },
    ],
  },
  {
    name: 'clock',
    className: 'custom-icon-clock',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
    ],
  },
  {
    name: 'flag',
    className: 'custom-icon-flag',
    keywords: [
      {
        word: 'flag',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-overview-stroke',
    className: 'custom-icon-mailbox-overview-stroke',
    keywords: [
      {
        word: 'overview',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-overview',
    className: 'custom-icon-mailbox-overview',
    keywords: [
      {
        word: 'overview',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-with-info',
    className: 'custom-icon-user-with-info',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'mail-with-question',
    className: 'custom-icon-mail-with-question',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'question',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'contact',
    className: 'custom-icon-contact',
    keywords: [
      {
        word: 'contact',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-magnifying-glass',
    className: 'custom-icon-subscription-with-magnifying-glass',
    keywords: [
      {
        word: 'glass',
        weight: 3,
      },
      {
        word: 'magnifying',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-clock',
    className: 'custom-icon-subscription-with-clock',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-checkmark',
    className: 'custom-icon-subscription-with-checkmark',
    keywords: [
      {
        word: 'checkmark',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-with-at',
    className: 'custom-icon-mail-with-at',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'at',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-with-at',
    className: 'custom-icon-globe-with-at',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'at',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-edit',
    className: 'custom-icon-doc-with-edit',
    keywords: [
      {
        word: 'edit',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
    ],
  },
  {
    name: 'password-analytics-stroke',
    className: 'custom-icon-password-analytics-stroke',
    keywords: [
      {
        word: 'Password',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'insights',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'statistics',
        weight: 3,
      },
      {
        word: 'analytics',
        weight: 3,
      },
      {
        word: 'metrics',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'password-analytics',
    className: 'custom-icon-password-analytics',
    keywords: [
      {
        word: 'Password',
        weight: 3,
      },
      {
        word: 'insights',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'statistics',
        weight: 3,
      },
      {
        word: 'analytics',
        weight: 3,
      },
      {
        word: 'metrics',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'table-stroke',
    className: 'custom-icon-table-stroke',
    keywords: [
      {
        word: 'table',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
    ],
  },
  {
    name: 'table2',
    className: 'custom-icon-table2',
    keywords: [
      {
        word: 'table',
        weight: 3,
      },
    ],
  },
  {
    name: 'message-stroke',
    className: 'custom-icon-message-stroke',
    keywords: [
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'stroke',
        weight: 3,
      },
    ],
  },
  {
    name: 'message-fill',
    className: 'custom-icon-message-fill',
    keywords: [
      {
        word: 'fill',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
    ],
  },
  {
    name: 'mail-with-cloud',
    className: 'custom-icon-mail-with-cloud',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'trash-with-info',
    className: 'custom-icon-trash-with-info',
    keywords: [
      {
        word: 'trash',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-with-key',
    className: 'custom-icon-mail-with-key',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'key',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-magnifying-glass',
    className: 'custom-icon-mail-with-magnifying-glass',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'glass',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'magnifying',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-wrench',
    className: 'custom-icon-mail-with-wrench',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'wrench',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-box',
    className: 'custom-icon-mail-with-box',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'box',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-box-stroke',
    className: 'custom-icon-mail-with-box-stroke',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'box',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-tag',
    className: 'custom-icon-mail-with-tag',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'tag',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-with-plus',
    className: 'custom-icon-gear-with-plus',
    keywords: [
      {
        word: 'plus',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-with-plus',
    className: 'custom-icon-file-with-plus',
    keywords: [
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'plus',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'mail-with-location-marker',
    className: 'custom-icon-mail-with-location-marker',
    keywords: [
      {
        word: 'marker',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'location',
        weight: 3,
      },
    ],
  },
  {
    name: 'messaging-status',
    className: 'custom-icon-messaging-status',
    keywords: [
      {
        word: 'messaging',
        weight: 3,
      },
      {
        word: 'status',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-with-spam',
    className: 'custom-icon-mail-with-spam',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'spam',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-swap-arrows',
    className: 'custom-icon-mail-with-swap-arrows',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'swap',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'arrows',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-clock',
    className: 'custom-icon-mail-with-clock',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-lock',
    className: 'custom-icon-mail-with-lock',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'archive-with-mail',
    className: 'custom-icon-archive-with-mail',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'archive',
        weight: 3,
      },
    ],
  },
  {
    name: 'archive-with-at',
    className: 'custom-icon-archive-with-at',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'at',
        weight: 3,
      },
      {
        word: 'archive',
        weight: 3,
      },
    ],
  },
  {
    name: 'archive-with-downward-arrow',
    className: 'custom-icon-archive-with-downward-arrow',
    keywords: [
      {
        word: 'downward',
        weight: 3,
      },
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'arrow',
        weight: 5,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'archive',
        weight: 3,
      },
    ],
  },
  {
    name: 'archive-with-cross',
    className: 'custom-icon-archive-with-cross',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'archive',
        weight: 3,
      },
      {
        word: 'cross',
        weight: 3,
      },
    ],
  },
  {
    name: 'archive-with-info',
    className: 'custom-icon-archive-with-info',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'archive',
        weight: 3,
      },
    ],
  },
  {
    name: 'server-with-info',
    className: 'custom-icon-server-with-info',
    keywords: [
      {
        word: 'host',
        weight: 5,
      },
      {
        word: 'backend',
        weight: 4,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'server',
        weight: 5,
      },
    ],
  },
  {
    name: 'info-fill',
    className: 'custom-icon-info-fill',
    keywords: [
      {
        word: 'fill',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'info-stroke',
    className: 'custom-icon-info-stroke',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-with-info',
    className: 'custom-icon-mail-with-info',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'system-activity',
    className: 'custom-icon-system-activity',
    keywords: [
      {
        word: 'system',
        weight: 3,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-with-bar-chart',
    className: 'custom-icon-mail-with-bar-chart',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'chart',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'bar',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-filled',
    className: 'custom-icon-gear-filled',
    keywords: [
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 2,
      },
    ],
  },
  {
    name: 'gear-stroke',
    className: 'custom-icon-gear-stroke',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 2,
      },
    ],
  },
  {
    name: 'globe-with-wrench',
    className: 'custom-icon-globe-with-wrench',
    keywords: [
      {
        word: 'wrench',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-pencil',
    className: 'custom-icon-doc-with-pencil',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'pencil',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-with-gear',
    className: 'custom-icon-mail-with-gear',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-with-group',
    className: 'custom-icon-folder-with-group',
    keywords: [
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-badge',
    className: 'custom-icon-group-with-badge',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'badge',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-info',
    className: 'custom-icon-group-with-info',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-timer',
    className: 'custom-icon-group-with-timer',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'timer',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-link',
    className: 'custom-icon-group-with-link',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-with-eye',
    className: 'custom-icon-mail-with-eye',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'eye',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'attribute-with-group',
    className: 'custom-icon-attribute-with-group',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'attribute',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'calendar-with-gear',
    className: 'custom-icon-calendar-with-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'calendar',
        weight: 3,
      },
    ],
  },
  {
    name: 'call-with-info',
    className: 'custom-icon-call-with-info',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'call',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'category-actions',
    className: 'custom-icon-category-actions',
    keywords: [
      {
        word: 'actions',
        weight: 3,
      },
      {
        word: 'category',
        weight: 3,
      },
    ],
  },
  {
    name: 'classification-3-stroke',
    className: 'custom-icon-classification-3-stroke',
    keywords: [
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'classification',
        weight: 3,
      },
    ],
  },
  {
    name: 'classification-3',
    className: 'custom-icon-classification-3',
    keywords: [
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'classification',
        weight: 3,
      },
    ],
  },
  {
    name: 'conditional-attributes',
    className: 'custom-icon-conditional-attributes',
    keywords: [
      {
        word: 'conditional',
        weight: 3,
      },
      {
        word: 'attributes',
        weight: 3,
      },
    ],
  },
  {
    name: 'data-doc-with-gear',
    className: 'custom-icon-data-doc-with-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'database-with-ques',
    className: 'custom-icon-database-with-ques',
    keywords: [
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'ques',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-attach',
    className: 'custom-icon-doc-with-attach',
    keywords: [
      {
        word: 'attach',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-classification',
    className: 'custom-icon-doc-with-classification',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'classification',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-exclamation',
    className: 'custom-icon-doc-with-exclamation',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'exclamation',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-hide',
    className: 'custom-icon-doc-with-hide',
    keywords: [
      {
        word: 'hide',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-location',
    className: 'custom-icon-doc-with-location',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'location',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-size-arrow',
    className: 'custom-icon-doc-with-size-arrow',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'size',
        weight: 3,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'arrow',
        weight: 5,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-user',
    className: 'custom-icon-doc-with-user',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'ews-gear',
    className: 'custom-icon-ews-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'EWS',
        weight: 3,
      },
    ],
  },
  {
    name: 'extenstion-custom-attributes',
    className: 'custom-icon-extenstion-custom-attributes',
    keywords: [
      {
        word: 'Extenstion',
        weight: 3,
      },
      {
        word: 'attributes',
        weight: 3,
      },
      {
        word: 'custom',
        weight: 3,
      },
    ],
  },
  {
    name: 'folder-with-user',
    className: 'custom-icon-folder-with-user',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'gear-head-user-with-key',
    className: 'custom-icon-gear-head-user-with-key',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'head',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'key',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-head-user-with-location',
    className: 'custom-icon-gear-head-user-with-location',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'head',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'location',
        weight: 3,
      },
    ],
  },
  {
    name: 'gear-head-user-with-ques',
    className: 'custom-icon-gear-head-user-with-ques',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'ques',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'head',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'globe-with-group',
    className: 'custom-icon-globe-with-group',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe-with-user',
    className: 'custom-icon-globe-with-user',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'group-details',
    className: 'custom-icon-group-details',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-clock',
    className: 'custom-icon-group-with-clock',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-lock',
    className: 'custom-icon-group-with-lock',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-ques',
    className: 'custom-icon-group-with-ques',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'ques',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-statistics',
    className: 'custom-icon-group-with-statistics',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'statistics',
        weight: 3,
      },
    ],
  },
  {
    name: 'hierarchy',
    className: 'custom-icon-hierarchy',
    keywords: [
      {
        word: 'Hierarchy',
        weight: 3,
      },
    ],
  },
  {
    name: 'imap-gear',
    className: 'custom-icon-imap-gear',
    keywords: [
      {
        word: 'IMAP',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
    ],
  },
  {
    name: 'inbox-with-arrow',
    className: 'custom-icon-inbox-with-arrow',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'arrow',
        weight: 5,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
    ],
  },
  {
    name: 'inbox-with-info',
    className: 'custom-icon-inbox-with-info',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-details',
    className: 'custom-icon-license-details',
    keywords: [
      {
        word: 'license',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-with-info',
    className: 'custom-icon-license-with-info',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'license',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-details',
    className: 'custom-icon-mail-details',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'details',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-history',
    className: 'custom-icon-mail-history',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'history',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-sync',
    className: 'custom-icon-mail-with-sync',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'sync',
        weight: 3,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-with-usage-1',
    className: 'custom-icon-mail-with-usage-1',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mapi-gear',
    className: 'custom-icon-mapi-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'MAPI',
        weight: 3,
      },
    ],
  },
  {
    name: 'message-with-filter',
    className: 'custom-icon-message-with-filter',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'filter',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
    ],
  },
  {
    name: 'message-with-lock',
    className: 'custom-icon-message-with-lock',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'mobile-details',
    className: 'custom-icon-mobile-details',
    keywords: [
      {
        word: 'details',
        weight: 3,
      },
      {
        word: 'mobile',
        weight: 3,
      },
    ],
  },
  {
    name: 'mobile-info',
    className: 'custom-icon-mobile-info',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'mobile',
        weight: 3,
      },
    ],
  },
  {
    name: 'mobile-with-brush',
    className: 'custom-icon-mobile-with-brush',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'mobile',
        weight: 3,
      },
      {
        word: 'brush',
        weight: 3,
      },
    ],
  },
  {
    name: 'mobile-with-ques',
    className: 'custom-icon-mobile-with-ques',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'ques',
        weight: 3,
      },
      {
        word: 'mobile',
        weight: 3,
      },
    ],
  },
  {
    name: 'owa-gear',
    className: 'custom-icon-owa-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'owa',
        weight: 3,
      },
    ],
  },
  {
    name: 'padlock-with-info',
    className: 'custom-icon-padlock-with-info',
    keywords: [
      {
        word: 'padlock',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'policy-with-gear',
    className: 'custom-icon-policy-with-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'policy',
        weight: 3,
      },
    ],
  },
  {
    name: 'policy-with-group',
    className: 'custom-icon-policy-with-group',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'policy',
        weight: 3,
      },
    ],
  },
  {
    name: 'policy-with-info',
    className: 'custom-icon-policy-with-info',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'policy',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'policy-with-star',
    className: 'custom-icon-policy-with-star',
    keywords: [
      {
        word: 'star',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'policy',
        weight: 3,
      },
    ],
  },
  {
    name: 'pop-gear',
    className: 'custom-icon-pop-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'POP',
        weight: 3,
      },
    ],
  },
  {
    name: 'server-with-clock',
    className: 'custom-icon-server-with-clock',
    keywords: [
      {
        word: 'host',
        weight: 5,
      },
      {
        word: 'backend',
        weight: 4,
      },
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'server',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-content-with-gear',
    className: 'custom-icon-site-content-with-gear',
    keywords: [
      {
        word: 'content',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'site-with-edit',
    className: 'custom-icon-site-with-edit',
    keywords: [
      {
        word: 'edit',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'site-with-text',
    className: 'custom-icon-site-with-text',
    keywords: [
      {
        word: 'text',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'site-with-wrench',
    className: 'custom-icon-site-with-wrench',
    keywords: [
      {
        word: 'wrench',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'smtp-gear',
    className: 'custom-icon-smtp-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'SMTP',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-gear',
    className: 'custom-icon-subscription-with-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'sync-with-info',
    className: 'custom-icon-sync-with-info',
    keywords: [
      {
        word: 'sync',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-details',
    className: 'custom-icon-user-details',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'details',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'user-with-key',
    className: 'custom-icon-user-with-key',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'key',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-with-location',
    className: 'custom-icon-user-with-location',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'location',
        weight: 3,
      },
    ],
  },
  {
    name: 'Workflow-1',
    className: 'custom-icon-workflow-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'Workflow',
        weight: 3,
      },
    ],
  },
  {
    name: 'Workflow-stroke-1',
    className: 'custom-icon-Workflow-stroke-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'Workflow',
        weight: 3,
      },
    ],
  },
  {
    name: 'Workflow-stroke',
    className: 'custom-icon-workflow-stroke',
    keywords: [
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'Workflow',
        weight: 3,
      },
    ],
  },
  {
    name: 'Workflow',
    className: 'custom-icon-workflow',
    keywords: [
      {
        word: 'Workflow',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-info',
    className: 'custom-icon-doc-with-info',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'gear-head-user-with-details',
    className: 'custom-icon-gear-head-user-with-details',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
      {
        word: 'head',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'gear-head-user-with-info',
    className: 'custom-icon-gear-head-user-with-info',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'head',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'globe-with-info',
    className: 'custom-icon-globe-with-info',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'padlock-with-details',
    className: 'custom-icon-padlock-with-details',
    keywords: [
      {
        word: 'padlock',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'details',
        weight: 3,
      },
    ],
  },
  {
    name: 'team-with-info',
    className: 'custom-icon-team-with-info',
    keywords: [
      {
        word: 'team',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'number-to-text',
    className: 'custom-icon-number-to-text',
    keywords: [
      {
        word: 'to',
        weight: 3,
      },
      {
        word: 'number',
        weight: 3,
      },
      {
        word: 'text',
        weight: 3,
      },
    ],
  },
  {
    name: 'text-to-number',
    className: 'custom-icon-text-to-number',
    keywords: [
      {
        word: 'to',
        weight: 3,
      },
      {
        word: 'number',
        weight: 3,
      },
      {
        word: 'text',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-security',
    className: 'custom-icon-group-security',
    keywords: [
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'privacy',
        weight: 3,
      },
      {
        word: 'defense',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'safety',
        weight: 3,
      },
    ],
  },
  {
    name: 'create',
    className: 'custom-icon-create',
    keywords: [
      {
        word: 'create',
        weight: 3,
      },
    ],
  },
  {
    name: 'device',
    className: 'custom-icon-device',
    keywords: [
      {
        word: 'device',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-with-checkmark',
    className: 'custom-icon-doc-with-checkmark',
    keywords: [
      {
        word: 'checkmark',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-add',
    className: 'custom-icon-license-add',
    keywords: [
      {
        word: 'add',
        weight: 3,
      },
      {
        word: 'license',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-with-checkmark',
    className: 'custom-icon-license-with-checkmark',
    keywords: [
      {
        word: 'checkmark',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'license',
        weight: 3,
      },
    ],
  },
  {
    name: 'mobile-with-checkmark',
    className: 'custom-icon-mobile-with-checkmark',
    keywords: [
      {
        word: 'checkmark',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'mobile',
        weight: 3,
      },
    ],
  },
  {
    name: 'profile-photo-fill',
    className: 'custom-icon-profile-photo-fill',
    keywords: [
      {
        word: 'fill',
        weight: 3,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'photo',
        weight: 3,
      },
    ],
  },
  {
    name: 'profile-photo-update-fill',
    className: 'custom-icon-profile-photo-update-fill',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'fill',
        weight: 3,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'photo',
        weight: 3,
      },
    ],
  },
  {
    name: 'profile-photo-update',
    className: 'custom-icon-profile-photo-update',
    keywords: [
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'photo',
        weight: 3,
      },
    ],
  },
  {
    name: 'profile-photo',
    className: 'custom-icon-profile-photo',
    keywords: [
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'photo',
        weight: 3,
      },
    ],
  },
  {
    name: 'remove-licenses',
    className: 'custom-icon-remove-licenses',
    keywords: [
      {
        word: 'licenses',
        weight: 3,
      },
      {
        word: 'remove',
        weight: 3,
      },
    ],
  },
  {
    name: 'team-with-downward-arrow',
    className: 'custom-icon-team-with-downward-arrow',
    keywords: [
      {
        word: 'downward',
        weight: 3,
      },
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'team',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-with-crown',
    className: 'custom-icon-teams-with-crown',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'crown',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-with-filled-crown',
    className: 'custom-icon-teams-with-filled-crown',
    keywords: [
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'crown',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-with-tag',
    className: 'custom-icon-user-with-tag',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'tag',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'chevron-down',
    className: 'custom-icon-chevron-down',
    keywords: [
      {
        word: 'down',
        weight: 3,
      },
      {
        word: 'chevron',
        weight: 3,
      },
    ],
  },
  {
    name: 'chevron-left',
    className: 'custom-icon-chevron-left',
    keywords: [
      {
        word: 'left',
        weight: 3,
      },
      {
        word: 'chevron',
        weight: 3,
      },
    ],
  },
  {
    name: 'chevron-right',
    className: 'custom-icon-chevron-right',
    keywords: [
      {
        word: 'right',
        weight: 4,
      },
      {
        word: 'chevron',
        weight: 3,
      },
    ],
  },
  {
    name: 'chevron-up',
    className: 'custom-icon-chevron-up',
    keywords: [
      {
        word: 'up',
        weight: 4,
      },
      {
        word: 'chevron',
        weight: 3,
      },
    ],
  },
  {
    name: 'clipboard-sync',
    className: 'custom-icon-clipboard-sync',
    keywords: [
      {
        word: 'sync',
        weight: 3,
      },
      {
        word: 'clipboard',
        weight: 3,
      },
    ],
  },
  {
    name: 'copy',
    className: 'custom-icon-copy',
    keywords: [
      {
        word: 'copy',
        weight: 3,
      },
    ],
  },
  {
    name: 'desktop',
    className: 'custom-icon-desktop',
    keywords: [
      {
        word: 'desktop',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail',
    className: 'custom-icon-mail',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'mute',
    className: 'custom-icon-mute',
    keywords: [
      {
        word: 'mute',
        weight: 3,
      },
    ],
  },
  {
    name: 'mute-1',
    className: 'custom-icon-mute-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'mute',
        weight: 3,
      },
    ],
  },
  {
    name: 'paste',
    className: 'custom-icon-paste',
    keywords: [
      {
        word: 'paste',
        weight: 3,
      },
    ],
  },
  {
    name: 'remote-desktop',
    className: 'custom-icon-remote-desktop',
    keywords: [
      {
        word: 'remote',
        weight: 3,
      },
      {
        word: 'desktop',
        weight: 3,
      },
    ],
  },
  {
    name: 'screenshot-1',
    className: 'custom-icon-screenshot-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'screenshot',
        weight: 3,
      },
    ],
  },
  {
    name: 'screenshot',
    className: 'custom-icon-screenshot',
    keywords: [
      {
        word: 'screenshot',
        weight: 3,
      },
    ],
  },
  {
    name: 'unmute',
    className: 'custom-icon-unmute',
    keywords: [
      {
        word: 'unmute',
        weight: 3,
      },
    ],
  },
  {
    name: 'zoom-in',
    className: 'custom-icon-zoom-in',
    keywords: [
      {
        word: 'zoom',
        weight: 3,
      },
      {
        word: 'in',
        weight: 3,
      },
    ],
  },
  {
    name: 'zoom-out',
    className: 'custom-icon-zoom-out',
    keywords: [
      {
        word: 'zoom',
        weight: 3,
      },
      {
        word: 'out',
        weight: 3,
      },
    ],
  },
  {
    name: 'zoom-reset',
    className: 'custom-icon-zoom-reset',
    keywords: [
      {
        word: 'zoom',
        weight: 3,
      },
      {
        word: 'reset',
        weight: 3,
      },
    ],
  },
  {
    name: 'sparkle',
    className: 'custom-icon-sparkle',
    keywords: [
      {
        word: 'sparkle',
        weight: 3,
      },
    ],
  },
  {
    name: 'active-directory-filled',
    className: 'custom-icon-active-directory-filled',
    keywords: [
      {
        word: 'active',
        weight: 3,
      },
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'directory',
        weight: 3,
      },
    ],
  },
  {
    name: 'active-directory',
    className: 'custom-icon-active-directory',
    keywords: [
      {
        word: 'active',
        weight: 3,
      },
      {
        word: 'directory',
        weight: 3,
      },
    ],
  },
  {
    name: 'cloud-groups',
    className: 'custom-icon-cloud-groups',
    keywords: [
      {
        word: 'groups',
        weight: 3,
      },
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'cloud-user',
    className: 'custom-icon-cloud-user',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'doc-with-gear-head-user',
    className: 'custom-icon-doc-with-gear-head-user',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'head',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'empty-group',
    className: 'custom-icon-empty-group',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'empty',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-and-shield-with-checkmark',
    className: 'custom-icon-group-and-shield-with-checkmark',
    keywords: [
      {
        word: 'checkmark',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-distribution',
    className: 'custom-icon-group-distribution',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'distribution',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-size',
    className: 'custom-icon-group-size',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'size',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-with-star',
    className: 'custom-icon-group-with-star',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'star',
        weight: 3,
      },
    ],
  },
  {
    name: 'license-with-cross',
    className: 'custom-icon-license-with-cross',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'license',
        weight: 3,
      },
      {
        word: 'cross',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-1',
    className: 'custom-icon-subscription-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'licensed-users',
    className: 'custom-icon-licensed-users',
    keywords: [
      {
        word: 'licensed',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-with-groups',
    className: 'custom-icon-mail-with-groups',
    keywords: [
      {
        word: 'groups',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'nested-groups',
    className: 'custom-icon-nested-groups',
    keywords: [
      {
        word: 'groups',
        weight: 3,
      },
      {
        word: 'nested',
        weight: 3,
      },
    ],
  },
  {
    name: 'provisioning',
    className: 'custom-icon-provisioning',
    keywords: [
      {
        word: 'provisioning',
        weight: 3,
      },
    ],
  },
  {
    name: 'regain-licenses',
    className: 'custom-icon-regain-licenses',
    keywords: [
      {
        word: 'licenses',
        weight: 3,
      },
      {
        word: 'regain',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-inactivity',
    className: 'custom-icon-subscription-inactivity',
    keywords: [
      {
        word: 'inactivity',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-trial',
    className: 'custom-icon-subscription-trial',
    keywords: [
      {
        word: 'trial',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-usage',
    className: 'custom-icon-subscription-usage',
    keywords: [
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-alert',
    className: 'custom-icon-subscription-with-alert',
    keywords: [
      {
        word: 'caution',
        weight: 3,
      },
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
      {
        word: 'signal',
        weight: 3,
      },
      {
        word: 'alarm',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'alert',
        weight: 3,
      },
      {
        word: 'warning',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-cross',
    className: 'custom-icon-subscription-with-cross',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
      {
        word: 'cross',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-pause',
    className: 'custom-icon-subscription-with-pause',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'pause',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-star',
    className: 'custom-icon-subscription-with-star',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'star',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'synced-group',
    className: 'custom-icon-synced-group',
    keywords: [
      {
        word: 'synced',
        weight: 3,
      },
      {
        word: 'group',
        weight: 3,
      },
    ],
  },
  {
    name: 'trial-users',
    className: 'custom-icon-trial-users',
    keywords: [
      {
        word: 'trial',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-with-star',
    className: 'custom-icon-user-with-star',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'star',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'user-subscription',
    className: 'custom-icon-user-subscription',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'subscription',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'users-with-errors',
    className: 'custom-icon-users-with-errors',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'errors',
        weight: 3,
      },
      {
        word: 'users',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-with-idle-bar',
    className: 'custom-icon-subscription-with-idle-bar',
    keywords: [
      {
        word: 'idle',
        weight: 3,
      },
      {
        word: 'bar',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
    ],
  },
  {
    name: 'new-twitter-filled',
    className: 'custom-icon-new-twitter-filled',
    keywords: [
      {
        word: 'new',
        weight: 3,
      },
      {
        word: 'filled',
        weight: 3,
      },
      {
        word: 'twitter',
        weight: 3,
      },
    ],
  },
  {
    name: 'above',
    className: 'custom-icon-above',
    keywords: [
      {
        word: 'above',
        weight: 3,
      },
    ],
  },
  {
    name: 'beside',
    className: 'custom-icon-beside',
    keywords: [
      {
        word: 'beside',
        weight: 3,
      },
    ],
  },
  {
    name: 'floating',
    className: 'custom-icon-floating',
    keywords: [
      {
        word: 'floating',
        weight: 3,
      },
    ],
  },
  {
    name: 'dashboard-1',
    className: 'custom-icon-dashboard-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'dashboard',
        weight: 3,
      },
    ],
  },
  {
    name: 'dashboard-2',
    className: 'custom-icon-dashboard-2',
    keywords: [
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'dashboard',
        weight: 3,
      },
    ],
  },
  {
    name: 'reportboard',
    className: 'custom-icon-reportboard',
    keywords: [
      {
        word: 'reportboard',
        weight: 3,
      },
    ],
  },
  {
    name: 'copy-text-1',
    className: 'custom-icon-copy-text-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'text',
        weight: 3,
      },
      {
        word: 'copy',
        weight: 3,
      },
    ],
  },
  {
    name: 'copy-text-2',
    className: 'custom-icon-copy-text-2',
    keywords: [
      {
        word: 'text',
        weight: 3,
      },
      {
        word: 'copy',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'copy-text-3',
    className: 'custom-icon-copy-text-3',
    keywords: [
      {
        word: 'text',
        weight: 3,
      },
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'copy',
        weight: 3,
      },
    ],
  },
  {
    name: 'filter-2',
    className: 'custom-icon-filter-2',
    keywords: [
      {
        word: 'filter',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'fitler-1',
    className: 'custom-icon-fitler-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'fitler',
        weight: 3,
      },
    ],
  },
  {
    name: 'filter-3',
    className: 'custom-icon-filter-3',
    keywords: [
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'filter',
        weight: 3,
      },
    ],
  },
  {
    name: 'video-solid',
    className: 'custom-icon-video-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'video',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-call-1',
    className: 'custom-icon-group-call-1',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'call',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'chat-stroke',
    className: 'custom-icon-chat-stroke',
    keywords: [
      {
        word: 'conversation',
        weight: 5,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'chat',
        weight: 5,
      },
      {
        word: 'discussion',
        weight: 4,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'talk',
        weight: 4,
      },
    ],
  },
  {
    name: 'group-call-2',
    className: 'custom-icon-group-call-2',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'call',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'messesnger',
    className: 'custom-icon-messesnger',
    keywords: [
      {
        word: 'messesnger',
        weight: 3,
      },
    ],
  },
  {
    name: 'emoji-stroke',
    className: 'custom-icon-emoji-stroke',
    keywords: [
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'emoji',
        weight: 3,
      },
    ],
  },
  {
    name: 'reaction-1',
    className: 'custom-icon-reaction-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'reaction',
        weight: 3,
      },
    ],
  },
  {
    name: 'thumbs-up',
    className: 'custom-icon-thumbs-up',
    keywords: [
      {
        word: 'up',
        weight: 4,
      },
      {
        word: 'thumbs',
        weight: 3,
      },
    ],
  },
  {
    name: 'call',
    className: 'custom-icon-call',
    keywords: [
      {
        word: 'call',
        weight: 3,
      },
    ],
  },
  {
    name: 'message',
    className: 'custom-icon-message',
    keywords: [
      {
        word: 'message',
        weight: 4,
      },
    ],
  },
  {
    name: 'receive',
    className: 'custom-icon-receive',
    keywords: [
      {
        word: 'receive',
        weight: 5,
      },
    ],
  },
  {
    name: 'sent',
    className: 'custom-icon-sent',
    keywords: [
      {
        word: 'sent',
        weight: 3,
      },
    ],
  },
  {
    name: 'messenger-solid',
    className: 'custom-icon-messenger-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'messenger',
        weight: 3,
      },
    ],
  },
  {
    name: 'messenger-stroke',
    className: 'custom-icon-messenger-stroke',
    keywords: [
      {
        word: 'messenger',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
    ],
  },
  {
    name: 'meetings-organized',
    className: 'custom-icon-meetings-organized',
    keywords: [
      {
        word: 'organized',
        weight: 3,
      },
      {
        word: 'meetings',
        weight: 3,
      },
    ],
  },
  {
    name: 'meetings-organized-3',
    className: 'custom-icon-meetings-organized-3',
    keywords: [
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'organized',
        weight: 3,
      },
      {
        word: 'meetings',
        weight: 3,
      },
    ],
  },
  {
    name: 'emoji-solid',
    className: 'custom-icon-emoji-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'emoji',
        weight: 3,
      },
    ],
  },
  {
    name: 'download',
    className: 'custom-icon-download',
    keywords: [
      {
        word: 'download',
        weight: 3,
      },
    ],
  },
  {
    name: 'lightning-solid',
    className: 'custom-icon-lightning-solid',
    keywords: [
      {
        word: 'lightning',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
    ],
  },
  {
    name: 'lightning-stroke',
    className: 'custom-icon-lightning-stroke',
    keywords: [
      {
        word: 'lightning',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
    ],
  },
  {
    name: 'meetings-organized-1',
    className: 'custom-icon-meetings-organized-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'organized',
        weight: 3,
      },
      {
        word: 'meetings',
        weight: 3,
      },
    ],
  },
  {
    name: 'meetings-organized-2',
    className: 'custom-icon-meetings-organized-2',
    keywords: [
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'organized',
        weight: 3,
      },
      {
        word: 'meetings',
        weight: 3,
      },
    ],
  },
  {
    name: 'rocket-with-clock-2',
    className: 'custom-icon-rocket-with-clock-2',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'rocket',
        weight: 3,
      },
    ],
  },
  {
    name: 'rocket-with-clock',
    className: 'custom-icon-rocket-with-clock',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'rocket',
        weight: 3,
      },
    ],
  },
  {
    name: 'rocket',
    className: 'custom-icon-rocket',
    keywords: [
      {
        word: 'rocket',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-channel-2',
    className: 'custom-icon-teams-channel-2',
    keywords: [
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-channel',
    className: 'custom-icon-teams-channel',
    keywords: [
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'received',
    className: 'custom-icon-received',
    keywords: [
      {
        word: 'received',
        weight: 3,
      },
    ],
  },
  {
    name: 'sent-1',
    className: 'custom-icon-sent-1',
    keywords: [
      {
        word: 'sent',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'external',
    className: 'custom-icon-external',
    keywords: [
      {
        word: 'external',
        weight: 3,
      },
    ],
  },
  {
    name: 'mention-stroke-2',
    className: 'custom-icon-mention-stroke-2',
    keywords: [
      {
        word: 'mention',
        weight: 3,
      },
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'call-solid',
    className: 'custom-icon-call-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'call',
        weight: 3,
      },
    ],
  },
  {
    name: 'chat-solid',
    className: 'custom-icon-chat-solid',
    keywords: [
      {
        word: 'conversation',
        weight: 5,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'chat',
        weight: 5,
      },
      {
        word: 'discussion',
        weight: 4,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'talk',
        weight: 4,
      },
    ],
  },
  {
    name: 'newspaper',
    className: 'custom-icon-newspaper',
    keywords: [
      {
        word: 'newspaper',
        weight: 3,
      },
    ],
  },
  {
    name: 'vertical-dots',
    className: 'custom-icon-vertical-dots',
    keywords: [
      {
        word: 'dots',
        weight: 3,
      },
      {
        word: 'vertical',
        weight: 3,
      },
    ],
  },
  {
    name: 'cloud-storage-1',
    className: 'custom-icon-cloud-storage-1',
    keywords: [
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'cloud-storage-2',
    className: 'custom-icon-cloud-storage-2',
    keywords: [
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'exchange-1',
    className: 'custom-icon-exchange-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'exchange',
        weight: 3,
      },
    ],
  },
  {
    name: 'exclamation',
    className: 'custom-icon-exclamation',
    keywords: [
      {
        word: 'exclamation',
        weight: 3,
      },
    ],
  },
  {
    name: 'eye-slash',
    className: 'custom-icon-eye-slash',
    keywords: [
      {
        word: 'eye',
        weight: 3,
      },
      {
        word: 'slash',
        weight: 3,
      },
    ],
  },
  {
    name: 'info-i',
    className: 'custom-icon-info-i',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'i',
        weight: 3,
      },
    ],
  },
  {
    name: 'plus-sign',
    className: 'custom-icon-plus-sign',
    keywords: [
      {
        word: 'plus',
        weight: 3,
      },
      {
        word: 'sign',
        weight: 3,
      },
    ],
  },
  {
    name: 'question-sign',
    className: 'custom-icon-question-sign',
    keywords: [
      {
        word: 'sign',
        weight: 3,
      },
      {
        word: 'question',
        weight: 3,
      },
    ],
  },
  {
    name: 'trashcan-stroke',
    className: 'custom-icon-trashcan-stroke',
    keywords: [
      {
        word: 'stroke',
        weight: 3,
      },
      {
        word: 'trashcan',
        weight: 3,
      },
    ],
  },
  {
    name: 'trashcan-filed',
    className: 'custom-icon-trashcan-filled',
    keywords: [
      {
        word: 'filed',
        weight: 3,
      },
      {
        word: 'trashcan',
        weight: 3,
      },
    ],
  },
  {
    name: 'cloud-storage-3',
    className: 'custom-icon-cloud-storage-3',
    keywords: [
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'cloud-storage-4',
    className: 'custom-icon-cloud-storage-4',
    keywords: [
      {
        word: 'online',
        weight: 4,
      },
      {
        word: '4',
        weight: 3,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'speedometer',
    className: 'custom-icon-speedometer',
    keywords: [
      {
        word: 'speedometer',
        weight: 3,
      },
    ],
  },
  {
    name: 'key',
    className: 'custom-icon-key',
    keywords: [
      {
        word: 'key',
        weight: 5,
      },
    ],
  },
  {
    name: 'db-backup-1',
    className: 'custom-icon-db-backup-1',
    keywords: [
      {
        word: 'backup',
        weight: 3,
      },
      {
        word: 'db',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'db-backup-2',
    className: 'custom-icon-db-backup-2',
    keywords: [
      {
        word: 'backup',
        weight: 3,
      },
      {
        word: 'db',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'db-upgrade-1',
    className: 'custom-icon-db-upgrade-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'upgrade',
        weight: 3,
      },
      {
        word: 'db',
        weight: 3,
      },
    ],
  },
  {
    name: 'db-upgrade',
    className: 'custom-icon-db-upgrade',
    keywords: [
      {
        word: 'upgrade',
        weight: 3,
      },
      {
        word: 'db',
        weight: 3,
      },
    ],
  },
  {
    name: 'portal-settings',
    className: 'custom-icon-portal-settings',
    keywords: [
      {
        word: 'configuration',
        weight: 3,
      },
      {
        word: 'options',
        weight: 3,
      },
      {
        word: 'portal',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 4,
      },
      {
        word: 'adjustment',
        weight: 3,
      },
      {
        word: 'preferences',
        weight: 3,
      },
    ],
  },
  {
    name: 'sorting-1',
    className: 'custom-icon-sorting-1',
    keywords: [
      {
        word: 'sorting',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'sorting-2',
    className: 'custom-icon-sorting-2',
    keywords: [
      {
        word: 'sorting',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'backup-1-light',
    className: 'custom-icon-backup-1-light',
    keywords: [
      {
        word: 'backup',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'backup-2-light',
    className: 'custom-icon-backup-2-light',
    keywords: [
      {
        word: 'backup',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'restore-1-light',
    className: 'custom-icon-restore-1-light',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'restore',
        weight: 3,
      },
    ],
  },
  {
    name: 'restore-2-light',
    className: 'custom-icon-restore-2-light',
    keywords: [
      {
        word: 'light',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'restore',
        weight: 3,
      },
    ],
  },
  {
    name: 'pause-bold',
    className: 'custom-icon-pause-bold',
    keywords: [
      {
        word: 'pause',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'pause-solid',
    className: 'custom-icon-pause-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'pause',
        weight: 3,
      },
    ],
  },
  {
    name: 'resume-bold',
    className: 'custom-icon-resume-bold',
    keywords: [
      {
        word: 'resume',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'resume-solid',
    className: 'custom-icon-resume-solid',
    keywords: [
      {
        word: 'resume',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
    ],
  },
  {
    name: 'bell-solid-1-notification-medium',
    className: 'custom-icon-bell-solid-1-notification-medium',
    keywords: [
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'bell',
        weight: 3,
      },
    ],
  },
  {
    name: 'sharepoint-medium',
    className: 'custom-icon-sharepoint-medium',
    keywords: [
      {
        word: 'sharepoint',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'sharepoint-light',
    className: 'custom-icon-sharepoint-light',
    keywords: [
      {
        word: 'sharepoint',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'stream-medium',
    className: 'custom-icon-stream-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'stream',
        weight: 3,
      },
    ],
  },
  {
    name: 'stream-light',
    className: 'custom-icon-stream-light',
    keywords: [
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'stream',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-medium',
    className: 'custom-icon-teams-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'teams-light',
    className: 'custom-icon-teams-light',
    keywords: [
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'yammer-bold',
    className: 'custom-icon-yammer-bold',
    keywords: [
      {
        word: 'yammer',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'yammer-medium',
    className: 'custom-icon-yammer-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'yammer',
        weight: 3,
      },
    ],
  },
  {
    name: 'yammer-light',
    className: 'custom-icon-yammer-light',
    keywords: [
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'yammer',
        weight: 3,
      },
    ],
  },
  {
    name: 'share',
    className: 'custom-icon-share',
    keywords: [
      {
        word: 'share',
        weight: 3,
      },
    ],
  },
  {
    name: 'power-automate-medium',
    className: 'custom-icon-power-automate-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'automate',
        weight: 3,
      },
      {
        word: 'power',
        weight: 3,
      },
    ],
  },
  {
    name: 'onenote-bold',
    className: 'custom-icon-onenote-bold',
    keywords: [
      {
        word: 'onenote',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'onenote-medium',
    className: 'custom-icon-onenote-medium',
    keywords: [
      {
        word: 'onenote',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'onenote-light',
    className: 'custom-icon-onenote-light',
    keywords: [
      {
        word: 'onenote',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'link-with-gear',
    className: 'custom-icon-link-with-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-with-lock-bold',
    className: 'custom-icon-file-with-lock-bold',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'bell-1-notification-medium',
    className: 'custom-icon-bell-1-notification-medium',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'bell',
        weight: 3,
      },
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'bell-alert-medium',
    className: 'custom-icon-bell-alert-medium',
    keywords: [
      {
        word: 'caution',
        weight: 3,
      },
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'signal',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'alarm',
        weight: 3,
      },
      {
        word: 'bell',
        weight: 3,
      },
      {
        word: 'alert',
        weight: 3,
      },
      {
        word: 'warning',
        weight: 3,
      },
    ],
  },
  {
    name: 'bell-solid-notification-medium',
    className: 'custom-icon-bell-solid-notification-medium',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'bell',
        weight: 3,
      },
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'newspaper-medium',
    className: 'custom-icon-newspaper-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'newspaper',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe-with-location-1',
    className: 'custom-icon-globe-with-location-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'location',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe-with-location',
    className: 'custom-icon-globe-with-location',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'location',
        weight: 3,
      },
    ],
  },
  {
    name: 'multiple-obj-table',
    className: 'custom-icon-multiple-obj-table',
    keywords: [
      {
        word: 'obj',
        weight: 3,
      },
      {
        word: 'table',
        weight: 3,
      },
      {
        word: 'multiple',
        weight: 3,
      },
    ],
  },
  {
    name: 'single-obj-table',
    className: 'custom-icon-single-obj-table',
    keywords: [
      {
        word: 'obj',
        weight: 3,
      },
      {
        word: 'table',
        weight: 3,
      },
      {
        word: 'single',
        weight: 3,
      },
    ],
  },
  {
    name: 'approval-1-medium',
    className: 'custom-icon-approval-1-medium',
    keywords: [
      {
        word: 'approval',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
    ],
  },
  {
    name: 'approval-2-medium',
    className: 'custom-icon-approval-2-medium',
    keywords: [
      {
        word: 'approval',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'azure-medium',
    className: 'custom-icon-azure-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'azure',
        weight: 3,
      },
    ],
  },
  {
    name: 'azure-light',
    className: 'custom-icon-azure-light',
    keywords: [
      {
        word: 'azure',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'bot',
    className: 'custom-icon-bot',
    keywords: [
      {
        word: 'bot',
        weight: 3,
      },
    ],
  },
  {
    name: 'broken-link-1-bold',
    className: 'custom-icon-broken-link-1-bold',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'broken',
        weight: 3,
      },
    ],
  },
  {
    name: 'broken-link-bold',
    className: 'custom-icon-broken-link-bold',
    keywords: [
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'broken',
        weight: 3,
      },
    ],
  },
  {
    name: 'channel-light',
    className: 'custom-icon-channel-light',
    keywords: [
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'channel',
        weight: 3,
      },
    ],
  },
  {
    name: 'document-with-share',
    className: 'custom-icon-document-with-share',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'share',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
    ],
  },
  {
    name: 'double-gear',
    className: 'custom-icon-double-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'double',
        weight: 3,
      },
    ],
  },
  {
    name: 'exchange-light',
    className: 'custom-icon-exchange-light',
    keywords: [
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'exchange',
        weight: 3,
      },
    ],
  },
  {
    name: 'exchange-medium',
    className: 'custom-icon-exchange-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'exchange',
        weight: 3,
      },
    ],
  },
  {
    name: 'exclamation-solid',
    className: 'custom-icon-exclamation-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'exclamation',
        weight: 3,
      },
    ],
  },
  {
    name: 'explorer-medium',
    className: 'custom-icon-explorer-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'explorer',
        weight: 3,
      },
    ],
  },
  {
    name: 'file-and-folder-bold',
    className: 'custom-icon-file-and-folder-bold',
    keywords: [
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'file-with-key-bold',
    className: 'custom-icon-file-with-key-bold',
    keywords: [
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'key',
        weight: 5,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'file-with-share',
    className: 'custom-icon-file-with-share',
    keywords: [
      {
        word: 'share',
        weight: 3,
      },
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'folder-bold',
    className: 'custom-icon-folder-bold',
    keywords: [
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'intune',
    className: 'custom-icon-intune',
    keywords: [
      {
        word: 'intune',
        weight: 3,
      },
    ],
  },
  {
    name: 'open-email',
    className: 'custom-icon-open-email',
    keywords: [
      {
        word: 'open',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-bold',
    className: 'custom-icon-link-bold',
    keywords: [
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'link-forward-semisolid',
    className: 'custom-icon-link-forward-semisolid',
    keywords: [
      {
        word: 'semisolid',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
      {
        word: 'forward',
        weight: 3,
      },
    ],
  },
  {
    name: 'link-share-semisolid',
    className: 'custom-icon-link-share-semisolid',
    keywords: [
      {
        word: 'semisolid',
        weight: 3,
      },
      {
        word: 'share',
        weight: 3,
      },
      {
        word: 'link',
        weight: 3,
      },
    ],
  },
  {
    name: 'mailbox-solid',
    className: 'custom-icon-mailbox-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'mailbox',
        weight: 3,
      },
    ],
  },
  {
    name: 'new-chat-1-bold',
    className: 'custom-icon-new-chat-1-bold',
    keywords: [
      {
        word: 'new',
        weight: 3,
      },
      {
        word: 'conversation',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'chat',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'discussion',
        weight: 4,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'talk',
        weight: 4,
      },
    ],
  },
  {
    name: 'new-chat-2-bold',
    className: 'custom-icon-new-chat-2-bold',
    keywords: [
      {
        word: 'new',
        weight: 3,
      },
      {
        word: 'conversation',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'chat',
        weight: 5,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'discussion',
        weight: 4,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'talk',
        weight: 4,
      },
    ],
  },
  {
    name: 'new-chat-bold',
    className: 'custom-icon-new-chat-bold',
    keywords: [
      {
        word: 'new',
        weight: 3,
      },
      {
        word: 'conversation',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'chat',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'discussion',
        weight: 4,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bubble',
        weight: 3,
      },
      {
        word: 'talk',
        weight: 4,
      },
    ],
  },
  {
    name: 'not-set-1-bold',
    className: 'custom-icon-not-set-1-bold',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'set',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'not',
        weight: 3,
      },
    ],
  },
  {
    name: 'not-set-solid-2-bold',
    className: 'custom-icon-not-set-solid-2-bold',
    keywords: [
      {
        word: 'set',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'not',
        weight: 3,
      },
    ],
  },
  {
    name: 'office-configuaration-medium',
    className: 'custom-icon-office-configuaration-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'office',
        weight: 3,
      },
      {
        word: 'configuaration',
        weight: 3,
      },
    ],
  },
  {
    name: 'office-configuration-light',
    className: 'custom-icon-office-configuration-light',
    keywords: [
      {
        word: 'office',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'configuration',
        weight: 3,
      },
    ],
  },
  {
    name: 'one-drive-light',
    className: 'custom-icon-one-drive-light',
    keywords: [
      {
        word: 'drive',
        weight: 3,
      },
      {
        word: 'one',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'onedrive',
        weight: 3,
      },
    ],
  },
  {
    name: 'one-drive-medium',
    className: 'custom-icon-one-drive-medium',
    keywords: [
      {
        word: 'drive',
        weight: 3,
      },
      {
        word: 'one',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'onedrive',
        weight: 3,
      },
    ],
  },
  {
    name: 'power-automate-light',
    className: 'custom-icon-power-automate-light',
    keywords: [
      {
        word: 'automate',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'power',
        weight: 3,
      },
    ],
  },
  {
    name: 'power-bi-light',
    className: 'custom-icon-power-bi-light',
    keywords: [
      {
        word: 'bi',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'power',
        weight: 3,
      },
    ],
  },
  {
    name: 'power-bi-medium',
    className: 'custom-icon-power-bi-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'bi',
        weight: 3,
      },
      {
        word: 'power',
        weight: 3,
      },
    ],
  },
  {
    name: 'recent-activity',
    className: 'custom-icon-recent-activity',
    keywords: [
      {
        word: 'recent',
        weight: 3,
      },
      {
        word: 'activity',
        weight: 3,
      },
    ],
  },
  {
    name: 'bullet-list-bold',
    className: 'custom-icon-bullet-list-bold',
    keywords: [
      {
        word: 'bullet',
        weight: 3,
      },
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'circle-list-bold',
    className: 'custom-icon-circle-list-bold',
    keywords: [
      {
        word: 'circle',
        weight: 3,
      },
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'number-list-bold',
    className: 'custom-icon-number-list-bold',
    keywords: [
      {
        word: 'number',
        weight: 3,
      },
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'alphabet-list-bold',
    className: 'custom-icon-alphabet-list-bold',
    keywords: [
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'alphabet',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'square-list-bold',
    className: 'custom-icon-square-list-bold',
    keywords: [
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'square',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'square-list-1-bold',
    className: 'custom-icon-square-list-1-bold',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'list',
        weight: 3,
      },
      {
        word: 'square',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-bold',
    className: 'custom-icon-user-bold',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'warning-bold',
    className: 'custom-icon-warning-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'alert',
        weight: 2,
      },
      {
        word: 'warning',
        weight: 3,
      },
    ],
  },
  {
    name: 'warning-medium',
    className: 'custom-icon-warning-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'warning',
        weight: 3,
      },
      {
        word: 'alert',
        weight: 2,
      },
    ],
  },
  {
    name: 'newspaper-solid',
    className: 'custom-icon-newspaper-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'newspaper',
        weight: 3,
      },
    ],
  },
  {
    name: 'notepad-solid-background',
    className: 'custom-icon-notepad-solid-background',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'notepad',
        weight: 3,
      },
      {
        word: 'background',
        weight: 3,
      },
    ],
  },
  {
    name: 'notepad-solid',
    className: 'custom-icon-notepad-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'notepad',
        weight: 3,
      },
    ],
  },
  {
    name: 'option-1-bold',
    className: 'custom-icon-option-1-bold',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'option',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'alt-tab',
    className: 'custom-icon-alt-tab',
    keywords: [
      {
        word: 'tab',
        weight: 3,
      },
      {
        word: 'alt',
        weight: 3,
      },
    ],
  },
  {
    name: 'audio-2-bold',
    className: 'custom-icon-audio-2-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'audio',
        weight: 3,
      },
    ],
  },
  {
    name: 'pad1-solid-down-arrow-bold',
    className: 'custom-icon-pad1-solid-down-arrow-bold',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'down',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
      {
        word: 'pad1',
        weight: 3,
      },
    ],
  },
  {
    name: 'pad1-solid-right-arrow-bold',
    className: 'custom-icon-pad1-solid-right-arrow-bold',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'right',
        weight: 4,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
      {
        word: 'pad1',
        weight: 3,
      },
    ],
  },
  {
    name: 'pad-solid-up-arrow-bold',
    className: 'custom-icon-pad-solid-up-arrow-bold',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'up',
        weight: 4,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'pad-solid-down-arrow-bold',
    className: 'custom-icon-pad-solid-down-arrow-bold',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'down',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'pad-solid-right-arrow-bold',
    className: 'custom-icon-pad-solid-right-arrow-bold',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'right',
        weight: 4,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'pad1-solid-up-arrow-bold',
    className: 'custom-icon-pad1-solid-up-arrow-bold',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'up',
        weight: 4,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
      {
        word: 'pad1',
        weight: 3,
      },
    ],
  },
  {
    name: 'pad-solid-camera-bold',
    className: 'custom-icon-pad-solid-camera-bold',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'camera',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
    ],
  },
  {
    name: 'pad1-solid-camera-bold',
    className: 'custom-icon-pad1-solid-camera-bold',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'camera',
        weight: 3,
      },
      {
        word: 'pad1',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'ctrl-alt-tab',
    className: 'custom-icon-ctrl-alt-tab',
    keywords: [
      {
        word: 'tab',
        weight: 3,
      },
      {
        word: 'ctrl',
        weight: 3,
      },
      {
        word: 'alt',
        weight: 3,
      },
    ],
  },
  {
    name: 'end-session-bold',
    className: 'custom-icon-end-session-bold',
    keywords: [
      {
        word: 'session',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'end',
        weight: 3,
      },
    ],
  },
  {
    name: 'full-screen-1-bold',
    className: 'custom-icon-full-screen-1-bold',
    keywords: [
      {
        word: 'full',
        weight: 3,
      },
      {
        word: 'screen',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'frames-1-bold',
    className: 'custom-icon-frames-1-bold',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'frames',
        weight: 3,
      },
    ],
  },
  {
    name: 'frames-1-with-gear-bold',
    className: 'custom-icon-frames-1-with-gear-bold',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'frames',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'frames-bold',
    className: 'custom-icon-frames-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'frames',
        weight: 3,
      },
    ],
  },
  {
    name: 'frames-with-gear-bold',
    className: 'custom-icon-frames-with-gear-bold',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'frames',
        weight: 3,
      },
    ],
  },
  {
    name: 'full-screen-2-bold',
    className: 'custom-icon-full-screen-2-bold',
    keywords: [
      {
        word: 'full',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'screen',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'full-screen-bold',
    className: 'custom-icon-full-screen-bold',
    keywords: [
      {
        word: 'full',
        weight: 3,
      },
      {
        word: 'screen',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'keyboard-1',
    className: 'custom-icon-keyboard-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'keyboard',
        weight: 3,
      },
    ],
  },
  {
    name: 'keyboard',
    className: 'custom-icon-keyboard',
    keywords: [
      {
        word: 'keyboard',
        weight: 3,
      },
    ],
  },
  {
    name: 'logoff-bold',
    className: 'custom-icon-logoff-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'logoff',
        weight: 3,
      },
    ],
  },
  {
    name: 'monitor-logoff-bold',
    className: 'custom-icon-monitor-logoff-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'monitor',
        weight: 3,
      },
      {
        word: 'logoff',
        weight: 3,
      },
    ],
  },
  {
    name: 'monitor-power-button-bold',
    className: 'custom-icon-monitor-power-button-bold',
    keywords: [
      {
        word: 'button',
        weight: 3,
      },
      {
        word: 'monitor',
        weight: 3,
      },
      {
        word: 'power',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'mouse',
    className: 'custom-icon-mouse',
    keywords: [
      {
        word: 'mouse',
        weight: 3,
      },
    ],
  },
  {
    name: 'solid-pause-bold',
    className: 'custom-icon-solid-pause-bold',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'pause',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'pause-semi-solid',
    className: 'custom-icon-pause-semi-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'pause',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
    ],
  },
  {
    name: 'play-bold',
    className: 'custom-icon-play-bold',
    keywords: [
      {
        word: 'play',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'solid-play-bold',
    className: 'custom-icon-solid-play-bold',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'play',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'play-semi-solid',
    className: 'custom-icon-play-semi-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'play',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
    ],
  },
  {
    name: 'play-solid',
    className: 'custom-icon-play-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'play',
        weight: 3,
      },
    ],
  },
  {
    name: 'power-button-1-bold',
    className: 'custom-icon-power-button-1-bold',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'button',
        weight: 3,
      },
      {
        word: 'power',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'power-button-bold',
    className: 'custom-icon-power-button-bold',
    keywords: [
      {
        word: 'button',
        weight: 3,
      },
      {
        word: 'power',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'solid-record-bold',
    className: 'custom-icon-solid-record-bold',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'record-bold',
    className: 'custom-icon-record-bold',
    keywords: [
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'screen-capture-bold',
    className: 'custom-icon-screen-capture-bold',
    keywords: [
      {
        word: 'screen',
        weight: 3,
      },
      {
        word: 'capture',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'capture-bold',
    className: 'custom-icon-capture-bold',
    keywords: [
      {
        word: 'capture',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'search-bold',
    className: 'custom-icon-search-bold',
    keywords: [
      {
        word: 'search',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'send-1-bold',
    className: 'custom-icon-send-1-bold',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'send-2-bold',
    className: 'custom-icon-send-2-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: '2',
        weight: 3,
      },
    ],
  },
  {
    name: 'stop-bold',
    className: 'custom-icon-stop-bold',
    keywords: [
      {
        word: 'stop',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'solid-stop-bold',
    className: 'custom-icon-solid-stop-bold',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'stop',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'stop-semi-solid',
    className: 'custom-icon-stop-semi-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'stop',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
    ],
  },
  {
    name: 'stop-solid',
    className: 'custom-icon-stop-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'stop',
        weight: 3,
      },
    ],
  },
  {
    name: 'technician-gear',
    className: 'custom-icon-technician-gear',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'technician',
        weight: 3,
      },
    ],
  },
  {
    name: 'technician-star',
    className: 'custom-icon-technician-star',
    keywords: [
      {
        word: 'star',
        weight: 3,
      },
      {
        word: 'technician',
        weight: 3,
      },
    ],
  },
  {
    name: 'technician',
    className: 'custom-icon-technician',
    keywords: [
      {
        word: 'technician',
        weight: 3,
      },
    ],
  },
  {
    name: 'video1-solid-edit-bold',
    className: 'custom-icon-video1-solid-edit-bold',
    keywords: [
      {
        word: 'video1',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'edit',
        weight: 3,
      },
    ],
  },
  {
    name: 'video-solid-edit-bold',
    className: 'custom-icon-video-solid-edit-bold',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'video',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'edit',
        weight: 3,
      },
    ],
  },
  {
    name: 'video-solid-gear-bold',
    className: 'custom-icon-video-solid-gear-bold',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'video',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'search-focus-bold',
    className: 'custom-icon-search-focus-bold',
    keywords: [
      {
        word: 'focus',
        weight: 3,
      },
      {
        word: 'search',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'move-bold',
    className: 'custom-icon-move-bold',
    keywords: [
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'expand-bold',
    className: 'custom-icon-expand-bold',
    keywords: [
      {
        word: 'expand',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'app-and-3-dots-semi-bold',
    className: 'custom-icon-app-and-3-dots-semi-bold',
    keywords: [
      {
        word: 'app',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'dots',
        weight: 3,
      },
    ],
  },
  {
    name: 'app-and-gear-info-semi-bold',
    className: 'custom-icon-app-and-gear-info-semi-bold',
    keywords: [
      {
        word: 'app',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'app-and-gear-semi-bold',
    className: 'custom-icon-app-and-gear-semi-bold',
    keywords: [
      {
        word: 'app',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'app-and-shield-semi-bold',
    className: 'custom-icon-app-and-shield-semi-bold',
    keywords: [
      {
        word: 'app',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'bold-folder-solid-message',
    className: 'custom-icon-bold-folder-solid-message',
    keywords: [
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'bold-mail-solid-message',
    className: 'custom-icon-bold-mail-solid-message',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'bold-message-solid-key',
    className: 'custom-icon-bold-message-solid-key',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'key',
        weight: 5,
      },
    ],
  },
  {
    name: 'book-bold',
    className: 'custom-icon-book-bold',
    keywords: [
      {
        word: 'book',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'book-line-bold',
    className: 'custom-icon-book-line-bold',
    keywords: [
      {
        word: 'book',
        weight: 3,
      },
      {
        word: 'line',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'calendar-and-3-dots-semi-bold',
    className: 'custom-icon-calendar-and-3-dots-semi-bold',
    keywords: [
      {
        word: 'and',
        weight: 3,
      },
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'dots',
        weight: 3,
      },
      {
        word: 'calendar',
        weight: 3,
      },
    ],
  },
  {
    name: 'channel-gear-bold',
    className: 'custom-icon-channel-gear-bold',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'channel-info-bold',
    className: 'custom-icon-channel-info-bold',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'channel-site-bold',
    className: 'custom-icon-channel-site-bold',
    keywords: [
      {
        word: 'site',
        weight: 3,
      },
      {
        word: 'channel',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'cloud-and-azure-ad-semi-bold',
    className: 'custom-icon-cloud-and-azure-ad-semi-bold',
    keywords: [
      {
        word: 'ad',
        weight: 3,
      },
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'azure',
        weight: 3,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'compliance-info',
    className: 'custom-icon-compliance-info',
    keywords: [
      {
        word: 'compliance',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
    ],
  },
  {
    name: 'copilot-bold',
    className: 'custom-icon-copilot-bold',
    keywords: [
      {
        word: 'copilot',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'desktop-pulse-bold',
    className: 'custom-icon-desktop-pulse-bold',
    keywords: [
      {
        word: 'desktop',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'pulse',
        weight: 3,
      },
    ],
  },
  {
    name: 'device-gear-bold',
    className: 'custom-icon-device-gear-bold',
    keywords: [
      {
        word: 'device',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'device-info-bold',
    className: 'custom-icon-device-info-bold',
    keywords: [
      {
        word: 'device',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'device-pulse-bold',
    className: 'custom-icon-device-pulse-bold',
    keywords: [
      {
        word: 'device',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'pulse',
        weight: 3,
      },
    ],
  },
  {
    name: 'device-ques-bold',
    className: 'custom-icon-device-ques-bold',
    keywords: [
      {
        word: 'device',
        weight: 3,
      },
      {
        word: 'ques',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'device-tag-bold',
    className: 'custom-icon-device-tag-bold',
    keywords: [
      {
        word: 'device',
        weight: 3,
      },
      {
        word: 'tag',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-and-lock-bold',
    className: 'custom-icon-doc-and-lock-bold',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
    ],
  },
  {
    name: 'doc-and-mail-bold',
    className: 'custom-icon-doc-and-mail-bold',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-and-server-bold',
    className: 'custom-icon-doc-and-server-bold',
    keywords: [
      {
        word: 'host',
        weight: 5,
      },
      {
        word: 'backend',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'server',
        weight: 5,
      },
    ],
  },
  {
    name: 'dollar-subscription-bold',
    className: 'custom-icon-dollar-subscription-bold',
    keywords: [
      {
        word: 'subscription',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'dollar',
        weight: 3,
      },
    ],
  },
  {
    name: 'emoji-1-bold',
    className: 'custom-icon-emoji-1-bold',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'emoji',
        weight: 3,
      },
    ],
  },
  {
    name: 'emoji-2-bold',
    className: 'custom-icon-emoji-2-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'emoji',
        weight: 3,
      },
    ],
  },
  {
    name: 'emoji-3-bold',
    className: 'custom-icon-emoji-3-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'emoji',
        weight: 3,
      },
    ],
  },
  {
    name: 'folder-bold-solid-3-dots',
    className: 'custom-icon-folder-bold-solid-3-dots',
    keywords: [
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'dots',
        weight: 3,
      },
    ],
  },
  {
    name: 'folder-message-semi-bold',
    className: 'custom-icon-folder-message-semi-bold',
    keywords: [
      {
        word: 'folder',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'laptop-gear-data-mixed',
    className: 'custom-icon-laptop-gear-data-mixed',
    keywords: [
      {
        word: 'laptop',
        weight: 3,
      },
      {
        word: 'mixed',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'laptop-gear-mixed',
    className: 'custom-icon-laptop-gear-mixed',
    keywords: [
      {
        word: 'laptop',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'mixed',
        weight: 3,
      },
    ],
  },
  {
    name: 'legacy-doc-bold',
    className: 'custom-icon-legacy-doc-bold',
    keywords: [
      {
        word: 'legacy',
        weight: 3,
      },
      {
        word: 'doc',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'lock-and-3-dots-semi-bold',
    className: 'custom-icon-lock-and-3-dots-semi-bold',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'dots',
        weight: 3,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: '3',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
    ],
  },
  {
    name: 'lock-and-ques-semi-bold',
    className: 'custom-icon-lock-and-ques-semi-bold',
    keywords: [
      {
        word: 'ques',
        weight: 3,
      },
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
    ],
  },
  {
    name: 'lock-and-shield-semi-bold',
    className: 'custom-icon-lock-and-shield-semi-bold',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
    ],
  },
  {
    name: 'lock-and-update-semi-bold',
    className: 'custom-icon-lock-and-update-semi-bold',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'update',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-and-archive-semi-bold',
    className: 'custom-icon-mail-and-archive-semi-bold',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'archive',
        weight: 3,
      },
    ],
  },
  {
    name: 'mail-bold-solid-pause',
    className: 'custom-icon-mail-bold-solid-pause',
    keywords: [
      {
        word: 'pause',
        weight: 3,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'microsoft-365-solid',
    className: 'custom-icon-microsoft-365-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'microsoft',
        weight: 3,
      },
      {
        word: '365',
        weight: 3,
      },
    ],
  },
  {
    name: 'microsoft_365_bold',
    className: 'custom-icon-microsoft_365_bold',
    keywords: [
      {
        word: 'microsoft',
        weight: 3,
      },
      {
        word: '365',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'mobile-gear-bold',
    className: 'custom-icon-mobile-gear-bold',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'mobile',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'mobile-pulse-bold',
    className: 'custom-icon-mobile-pulse-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'mobile',
        weight: 3,
      },
      {
        word: 'pulse',
        weight: 3,
      },
    ],
  },
  {
    name: 'mobile-tag-bold',
    className: 'custom-icon-mobile-tag-bold',
    keywords: [
      {
        word: 'tag',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'mobile',
        weight: 3,
      },
    ],
  },
  {
    name: 'old-exchange-semi-bold',
    className: 'custom-icon-old-exchange-semi-bold',
    keywords: [
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'old',
        weight: 3,
      },
      {
        word: 'exchange',
        weight: 3,
      },
    ],
  },
  {
    name: 'on-premise-info',
    className: 'custom-icon-on-premise-info',
    keywords: [
      {
        word: 'premise',
        weight: 3,
      },
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'on',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-bold-solid-gear',
    className: 'custom-icon-report-bold-solid-gear',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-bold-solid-pause',
    className: 'custom-icon-report-bold-solid-pause',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pause',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-app-bold',
    className: 'custom-icon-report-pad-app-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'app',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-badge-bold',
    className: 'custom-icon-report-pad-badge-bold',
    keywords: [
      {
        word: 'badge',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-cube-semibold',
    className: 'custom-icon-report-pad-cube-semibold',
    keywords: [
      {
        word: 'cube',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'semibold',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-gear-bold',
    className: 'custom-icon-report-pad-gear-bold',
    keywords: [
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-group-bold',
    className: 'custom-icon-report-pad-group-bold',
    keywords: [
      {
        word: 'group',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-info-bold',
    className: 'custom-icon-report-pad-info-bold',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-location-bold',
    className: 'custom-icon-report-pad-location-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'location',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-platform-bold',
    className: 'custom-icon-report-pad-platform-bold',
    keywords: [
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'platform',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-pad-user-bold',
    className: 'custom-icon-report-pad-user-bold',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'report-shield-bold',
    className: 'custom-icon-report-shield-bold',
    keywords: [
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'report-subscription-semi-bold',
    className: 'custom-icon-report-subscription-semi-bold',
    keywords: [
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'report',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'sspr-solid',
    className: 'custom-icon-sspr-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'sspr',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscription-info-semibold',
    className: 'custom-icon-subscription-info-semibold',
    keywords: [
      {
        word: 'info',
        weight: 3,
      },
      {
        word: 'subscription',
        weight: 3,
      },
      {
        word: 'semibold',
        weight: 3,
      },
    ],
  },
  {
    name: 'subscriptions',
    className: 'custom-icon-subscriptions',
    keywords: [
      {
        word: 'subscriptions',
        weight: 3,
      },
    ],
  },
  {
    name: 'trial-bold',
    className: 'custom-icon-trial-bold',
    keywords: [
      {
        word: 'trial',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'automation-2-solid',
    className: 'custom-icon-automation-2-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'automation',
        weight: 3,
      },
    ],
  },
  {
    name: 'automation-solid',
    className: 'custom-icon-automation-solid',
    keywords: [
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'automation',
        weight: 3,
      },
    ],
  },
  {
    name: 'calendar-usage',
    className: 'custom-icon-calendar-usage',
    keywords: [
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'calendar',
        weight: 3,
      },
    ],
  },
  {
    name: 'calendar-with-clock',
    className: 'custom-icon-calendar-with-clock',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'calendar',
        weight: 3,
      },
    ],
  },
  {
    name: 'calendar-with-solid-clock',
    className: 'custom-icon-calendar-with-solid-clock',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'calendar',
        weight: 3,
      },
    ],
  },
  {
    name: 'database-usage-semi-bold',
    className: 'custom-icon-database-usage-semi-bold',
    keywords: [
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'usage',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'up',
    className: 'custom-icon-up',
    keywords: [
      {
        word: 'up',
        weight: 4,
      },
    ],
  },
  {
    name: 'down',
    className: 'custom-icon-down',
    keywords: [
      {
        word: 'down',
        weight: 3,
      },
    ],
  },
  {
    name: 'pad-with-bell-light',
    className: 'custom-icon-pad-with-bell-light',
    keywords: [
      {
        word: 'bell',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'pad',
        weight: 3,
      },
    ],
  },
  {
    name: 'rules-with-bell-light',
    className: 'custom-icon-rules-with-bell-light',
    keywords: [
      {
        word: 'bell',
        weight: 3,
      },
      {
        word: 'rules',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
    ],
  },
  {
    name: 'bell-with-notification-light',
    className: 'custom-icon-bell-with-notification-light',
    keywords: [
      {
        word: 'bell',
        weight: 3,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'notification',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'pdf-plus',
    className: 'custom-icon-pdf-plus',
    keywords: [
      {
        word: 'plus',
        weight: 3,
      },
      {
        word: 'pdf',
        weight: 3,
      },
    ],
  },
  {
    name: 'phone-ring-bold',
    className: 'custom-icon-phone-ring-bold',
    keywords: [
      {
        word: 'ring',
        weight: 3,
      },
      {
        word: 'phone',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
    ],
  },
  {
    name: 'switch-medium',
    className: 'custom-icon-switch-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'switch',
        weight: 3,
      },
    ],
  },
  {
    name: 'switch-semi-medium',
    className: 'custom-icon-switch-semi-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'switch',
        weight: 3,
      },
      {
        word: 'semi',
        weight: 3,
      },
    ],
  },
  {
    name: 'user-2-bold',
    className: 'custom-icon-user-2-bold',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: '2',
        weight: 3,
      },
      {
        word: 'bold',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'entity-tracking-1',
    className: 'custom-icon-entity-tracking-1',
    keywords: [
      {
        word: '1',
        weight: 3,
      },
      {
        word: 'entity',
        weight: 3,
      },
      {
        word: 'tracking',
        weight: 3,
      },
    ],
  },
  {
    name: 'data-analysis',
    className: 'custom-icon-data-analysis',
    keywords: [
      {
        word: 'analysis',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'arrow-light',
    className: 'custom-icon-arrow-light',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-storage-light',
    className: 'custom-icon-cloud-storage-light',
    keywords: [
      {
        word: 'online',
        weight: 4,
      },
      {
        word: 'cloud',
        weight: 4,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'network',
        weight: 4,
      },
      {
        word: 'storage',
        weight: 5,
      },
      {
        word: 'server',
        weight: 5,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'database-light',
    className: 'custom-icon-database-light',
    keywords: [
      {
        word: 'database',
        weight: 4,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'db-backup-light',
    className: 'custom-icon-db-backup-light',
    keywords: [
      {
        word: 'backup',
        weight: 3,
      },
      {
        word: 'db',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'db-restore-light',
    className: 'custom-icon-db-restore-light',
    keywords: [
      {
        word: 'db',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'restore',
        weight: 3,
      },
    ],
  },
  {
    name: 'notepad-with-clock-light',
    className: 'custom-icon-notepad-with-clock-light',
    keywords: [
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'notepad',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'notepad-with-ques-light',
    className: 'custom-icon-notepad-with-ques-light',
    keywords: [
      {
        word: 'with',
        weight: 3,
      },
      {
        word: 'ques',
        weight: 3,
      },
      {
        word: 'notepad',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'personalisation-light',
    className: 'custom-icon-personalisation-light',
    keywords: [
      {
        word: 'personalisation',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'site-edit-light',
    className: 'custom-icon-site-edit-light',
    keywords: [
      {
        word: 'edit',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
      {
        word: 'site',
        weight: 3,
      },
    ],
  },
  {
    name: 'tag-light',
    className: 'custom-icon-tag-light',
    keywords: [
      {
        word: 'tag',
        weight: 3,
      },
      {
        word: 'light',
        weight: 3,
      },
    ],
  },
  {
    name: 'explorer-medium-1',
    className: 'custom-icon-explorer-medium-1',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'explorer',
        weight: 3,
      },
      {
        word: '1',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe-medium',
    className: 'custom-icon-globe-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'globe',
        weight: 3,
      },
    ],
  },
  {
    name: 'lock-medium',
    className: 'custom-icon-lock-medium',
    keywords: [
      {
        word: 'access',
        weight: 5,
      },
      {
        word: 'security',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'safe',
        weight: 3,
      },
      {
        word: 'restricted',
        weight: 3,
      },
      {
        word: 'protection',
        weight: 3,
      },
      {
        word: 'lock',
        weight: 3,
      },
    ],
  },
  {
    name: 'clock-and-expire-medium',
    className: 'custom-icon-clock-and-expire-medium',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'clock',
        weight: 4,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'expire',
        weight: 3,
      },
    ],
  },
  {
    name: 'medium-calendar-solid-timer',
    className: 'custom-icon-medium-calendar-solid-timer',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'calendar',
        weight: 3,
      },
    ],
  },
  {
    name: 'medium-file-solid-share',
    className: 'custom-icon-medium-file-solid-share',
    keywords: [
      {
        word: 'share',
        weight: 3,
      },
      {
        word: 'record',
        weight: 3,
      },
      {
        word: 'upload',
        weight: 3,
      },
      {
        word: 'document',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'download',
        weight: 3,
      },
      {
        word: 'file',
        weight: 3,
      },
      {
        word: 'save',
        weight: 3,
      },
      {
        word: 'data',
        weight: 4,
      },
    ],
  },
  {
    name: 'medium-folder-solid-gear',
    className: 'custom-icon-medium-folder-solid-gear',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'folder',
        weight: 3,
      },
    ],
  },
  {
    name: 'medium-folder-solid-shield',
    className: 'custom-icon-medium-folder-solid-shield',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'folder',
        weight: 3,
      },
    ],
  },
  {
    name: 'medium-globe-and-solid-arrow',
    className: 'custom-icon-medium-globe-and-solid-arrow',
    keywords: [
      {
        word: 'globe',
        weight: 3,
      },
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'and',
        weight: 3,
      },
      {
        word: 'arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'medium-mail-solid-arrow',
    className: 'custom-icon-medium-mail-solid-arrow',
    keywords: [
      {
        word: 'direction',
        weight: 5,
      },
      {
        word: 'pointer',
        weight: 2,
      },
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'move',
        weight: 3,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'navigation',
        weight: 4,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'arrow',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'medium-mail-solid-plus',
    className: 'custom-icon-medium-mail-solid-plus',
    keywords: [
      {
        word: 'send',
        weight: 5,
      },
      {
        word: 'receive',
        weight: 5,
      },
      {
        word: 'inbox',
        weight: 4,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'plus',
        weight: 3,
      },
      {
        word: 'email',
        weight: 5,
      },
      {
        word: 'communication',
        weight: 5,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'mail',
        weight: 5,
      },
    ],
  },
  {
    name: 'medium-message-solid-exclamation',
    className: 'custom-icon-medium-message-solid-exclamation',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'exclamation',
        weight: 3,
      },
    ],
  },
  {
    name: 'medium-message-solid-reply',
    className: 'custom-icon-medium-message-solid-reply',
    keywords: [
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'message',
        weight: 4,
      },
      {
        word: 'reply',
        weight: 3,
      },
    ],
  },
  {
    name: 'medium-user-mention',
    className: 'custom-icon-medium-user-mention',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'mention',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'medium-user-solid-shield',
    className: 'custom-icon-medium-user-solid-shield',
    keywords: [
      {
        word: 'customer',
        weight: 4,
      },
      {
        word: 'person',
        weight: 4,
      },
      {
        word: 'user',
        weight: 5,
      },
      {
        word: 'profile',
        weight: 4,
      },
      {
        word: 'medium',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 3,
      },
      {
        word: 'shield',
        weight: 3,
      },
      {
        word: 'account',
        weight: 4,
      },
      {
        word: 'member',
        weight: 4,
      },
    ],
  },
  {
    name: 'clock-lock-bold',
    className: 'custom-icon-clock-lock-bold',
    keywords: [
      {
        word: 'custom-icon-clock-lock-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'open-lock-timer-bold',
    className: 'custom-icon-open-lock-timer-bold',
    keywords: [
      {
        word: 'custom-icon-open-lock-timer-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'block-bold',
    className: 'custom-icon-block-bold',
    keywords: [
      {
        word: 'custom-icon-block-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'building-cross-semi-bold',
    className: 'custom-icon-building-cross-semi-bold',
    keywords: [
      {
        word: 'custom-icon-building-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-cross-semi-bold',
    className: 'custom-icon-call-cross-semi-bold',
    keywords: [
      {
        word: 'custom-icon-call-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-download-block-bold',
    className: 'custom-icon-cloud-download-block-bold',
    keywords: [
      {
        word: 'custom-icon-cloud-download-block-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-download-block-semi-solid',
    className: 'custom-icon-cloud-download-block-semi-solid',
    keywords: [
      {
        word: 'custom-icon-cloud-download-block-semi-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-lens-bold',
    className: 'custom-icon-cloud-lens-bold',
    keywords: [
      {
        word: 'custom-icon-cloud-lens-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-lens-semi-solid',
    className: 'custom-icon-cloud-lens-semi-solid',
    keywords: [
      {
        word: 'custom-icon-cloud-lens-semi-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-lock-bold',
    className: 'custom-icon-cloud-lock-bold',
    keywords: [
      {
        word: 'custom-icon-cloud-lock-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-question',
    className: 'custom-icon-lens-question',
    keywords: [
      {
        word: 'custom-icon-lens-question',
        weight: 5,
      },
    ],
  },
  {
    name: 'question-sign-bold',
    className: 'custom-icon-question-sign-bold',
    keywords: [
      {
        word: 'custom-icon-question-sign-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mobile-add-semi-bold',
    className: 'custom-icon-mobile-add-semi-bold',
    keywords: [
      {
        word: 'custom-icon-mobile-add-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mobile-remove-semi-bold',
    className: 'custom-icon-mobile-remove-semi-bold',
    keywords: [
      {
        word: 'custom-icon-mobile-remove-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'none-bold',
    className: 'custom-icon-none-bold',
    keywords: [
      {
        word: 'custom-icon-none-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'location-cross-semibold',
    className: 'custom-icon-location-cross-semibold',
    keywords: [
      {
        word: 'custom-icon-location-cross-semibold',
        weight: 5,
      },
    ],
  },
  {
    name: 'plus-location-semi-bold-2',
    className: 'custom-icon-plus-location-semi-bold-2',
    keywords: [
      {
        word: 'custom-icon-plus-location-semi-bold-2',
        weight: 5,
      },
    ],
  },
  {
    name: 'plus-location-semi-bold',
    className: 'custom-icon-plus-location-semi-bold',
    keywords: [
      {
        word: 'custom-icon-plus-location-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'star-location-semi-bold-2',
    className: 'custom-icon-star-location-semi-bold-2',
    keywords: [
      {
        word: 'custom-icon-star-location-semi-bold-2',
        weight: 5,
      },
    ],
  },
  {
    name: 'star-location-semi-bold',
    className: 'custom-icon-star-location-semi-bold',
    keywords: [
      {
        word: 'custom-icon-star-location-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-bold',
    className: 'custom-icon-reportpad-bold',
    keywords: [
      {
        word: 'custom-icon-reportpad-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-checkmark-shield-semi-bold',
    className: 'custom-icon-reportpad-checkmark-shield-semi-bold',
    keywords: [
      {
        word: 'custom-icon-reportpad-checkmark-shield-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-cross-shield-semi-bold',
    className: 'custom-icon-reportpad-cross-shield-semi-bold',
    keywords: [
      {
        word: 'custom-icon-reportpad-cross-shield-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-lock-bold',
    className: 'custom-icon-site-lock-bold',
    keywords: [
      {
        word: 'custom-icon-site-lock-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-id-cross-semi-bold',
    className: 'custom-icon-user-id-cross-semi-bold',
    keywords: [
      {
        word: 'custom-icon-user-id-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'shrink',
    className: 'custom-icon-shrink',
    keywords: [
      {
        word: 'custom-icon-shrink',
        weight: 5,
      },
    ],
  },
  {
    name: 'shrink-2',
    className: 'custom-icon-shrink-2',
    keywords: [
      {
        word: 'custom-icon-shrink-2',
        weight: 5,
      },
    ],
  },
  {
    name: 'stack-documents-solid',
    className: 'custom-icon-stack-documents-solid',
    keywords: [
      {
        word: 'custom-icon-stack-documents-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'share-solid',
    className: 'custom-icon-share-solid',
    keywords: [
      {
        word: 'custom-icon-share-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'in-progress',
    className: 'custom-icon-in-progress',
    keywords: [
      {
        word: 'custom-icon-in-progress',
        weight: 5,
      },
    ],
  },
  {
    name: 'checkmark-bold',
    className: 'custom-icon-checkmark-bold',
    keywords: [
      {
        word: 'custom-icon-checkmark-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'checkmark-solid',
    className: 'custom-icon-checkmark-solid',
    keywords: [
      {
        word: 'custom-icon-checkmark-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'cross-bold',
    className: 'custom-icon-cross-bold',
    keywords: [
      {
        word: 'custom-icon-cross-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cross-solid',
    className: 'custom-icon-cross-solid',
    keywords: [
      {
        word: 'custom-icon-cross-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'pause-and-cursor',
    className: 'custom-icon-pause-and-cursor',
    keywords: [
      {
        word: 'custom-icon-pause-and-cursor',
        weight: 5,
      },
    ],
  },
  {
    name: 'sync-solid',
    className: 'custom-icon-sync-solid',
    keywords: [
      {
        word: 'custom-icon-sync-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'time',
    className: 'custom-icon-time',
    keywords: [
      {
        word: 'custom-icon-time',
        weight: 5,
      },
    ],
  },
  {
    name: 'warning-solid',
    className: 'custom-icon-warning-solid',
    keywords: [
      {
        word: 'solid',
        weight: 5,
      },
      {
        word: 'alert',
        weight: 2,
      },
      {
        word: 'warning',
        weight: 2,
      },
    ],
  },
  {
    name: 'screenshare-bold',
    className: 'custom-icon-screenshare-bold',
    keywords: [
      {
        word: 'custom-icon-screenshare-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'screenshare-solid',
    className: 'custom-icon-screenshare-solid',
    keywords: [
      {
        word: 'custom-icon-screenshare-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'microphone-audio-bold',
    className: 'custom-icon-microphone-audio-bold',
    keywords: [
      {
        word: 'custom-icon-microphone-audio-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'microphone-audio-solid',
    className: 'custom-icon-microphone-audio-solid',
    keywords: [
      {
        word: 'custom-icon-microphone-audio-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'screenshare-bold-1',
    className: 'custom-icon-screenshare-bold-1',
    keywords: [
      {
        word: 'custom-icon-screenshare-bold-1',
        weight: 5,
      },
    ],
  },
  {
    name: 'building-medium',
    className: 'custom-icon-building-medium',
    keywords: [
      {
        word: 'building',
        weight: 5,
      },
      {
        word: 'Organization',
        weight: 5,
      },
      {
        word: 'Office',
        weight: 5,
      },
      {
        word: 'Company',
        weight: 5,
      },
      {
        word: 'medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-lens-medium',
    className: 'custom-icon-calendar-lens-medium',
    keywords: [
      {
        word: 'calendar lens',
        weight: 5,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'calendar',
        weight: 5,
      },
      {
        word: 'search',
        weight: 5,
      },
      {
        word: 'magnifying glass',
        weight: 5,
      },
      {
        word: 'date',
        weight: 5,
      },
    ],
  },
  {
    name: 'certificate-badge-medium',
    className: 'custom-icon-certificate-badge-medium',
    keywords: [
      {
        word: 'certificate badge',
        weight: 5,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'certificate',
        weight: 1,
      },
      {
        word: 'badge',
        weight: 2,
      },
      {
        word: 'award',
        weight: 4,
      },
      {
        word: 'achivement',
        weight: 4,
      },
    ],
  },
  {
    name: 'channel-add-semi-bold',
    className: 'custom-icon-channel-add-semi-bold',
    keywords: [
      {
        word: 'create channel',
        weight: 5,
      },
      {
        word: 'semi bold',
        weight: 5,
      },
      {
        word: 'channel',
        weight: 1,
      },
      {
        word: 'add',
        weight: 2,
      },
    ],
  },
  {
    name: 'clock-checkmark-semi-medium',
    className: 'custom-icon-clock-checkmark-semi-medium',
    keywords: [
      {
        word: 'clock checkmark',
        weight: 5,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'clock',
        weight: 1,
      },
      {
        word: 'checkmark',
        weight: 2,
      },
      {
        word: 'Confirmed Schedule',
        weight: 2,
      },
    ],
  },
  {
    name: 'cloud-medium',
    className: 'custom-icon-cloud-medium',
    keywords: [
      {
        word: 'cloud',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'storage',
        weight: 1,
      },
      {
        word: 'cloud services',
        weight: 2,
      },
    ],
  },
  {
    name: 'cloud-on-premise-medium',
    className: 'custom-icon-cloud-on-premise-medium',
    keywords: [
      {
        word: 'cloud',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'on premise',
        weight: 1,
      },
      {
        word: 'hybrid',
        weight: 2,
      },
    ],
  },
  {
    name: 'cloud-on-premise-semi-medium',
    className: 'custom-icon-cloud-on-premise-semi-medium',
    keywords: [
      {
        word: 'cloud',
        weight: 1,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'on premise',
        weight: 1,
      },
      {
        word: 'hybrid',
        weight: 2,
      },
    ],
  },
  {
    name: 'cloud-solid',
    className: 'custom-icon-cloud-solid',
    keywords: [
      {
        word: 'cloud',
        weight: 1,
      },
      {
        word: 'solid',
        weight: 5,
      },
      {
        word: 'storage',
        weight: 1,
      },
      {
        word: 'cloud services',
        weight: 2,
      },
    ],
  },
  {
    name: 'desktop-gear-medium',
    className: 'custom-icon-desktop-gear-medium',
    keywords: [
      {
        word: 'desktop',
        weight: 1,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 2,
      },
      {
        word: 'system',
        weight: 2,
      },
      {
        word: 'device',
        weight: 2,
      },
      {
        word: 'Desktop Settings',
        weight: 2,
      },
      {
        word: 'system management',
        weight: 2,
      },
      {
        word: 'monitor',
        weight: 2,
      },
    ],
  },
  {
    name: 'desktop-user-semi-medium',
    className: 'custom-icon-desktop-user-semi-medium',
    keywords: [
      {
        word: 'desktop',
        weight: 1,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'login',
        weight: 2,
      },
      {
        word: 'user login',
        weight: 2,
      },
      {
        word: 'system',
        weight: 2,
      },
      {
        word: 'device',
        weight: 2,
      },
      {
        word: 'User Desktop',
        weight: 2,
      },
      {
        word: 'profile',
        weight: 2,
      },
    ],
  },
  {
    name: 'gear-refresh-arrow-medium',
    className: 'custom-icon-gear-refresh-arrow-medium',
    keywords: [
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 2,
      },
      {
        word: 'refresh',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'changes management',
        weight: 3,
      },
      {
        word: 'update preferences',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-gear-semi-medium',
    className: 'custom-icon-group-gear-semi-medium',
    keywords: [
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 2,
      },
      {
        word: 'group',
        weight: 1,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'security group',
        weight: 3,
      },
      {
        word: 'group administration',
        weight: 5,
      },
      {
        word: 'group settings',
        weight: 5,
      },
    ],
  },
  {
    name: 'horizontal-dots',
    className: 'custom-icon-horizontal-dots',
    keywords: [
      {
        word: 'dots',
        weight: 1,
      },
      {
        word: 'horizontal',
        weight: 2,
      },
      {
        word: 'more options',
        weight: 1,
      },
      {
        word: 'solid',
        weight: 5,
      },
      {
        word: 'more',
        weight: 3,
      },
      {
        word: 'menu',
        weight: 5,
      },
    ],
  },
  {
    name: 'kerberos-medium',
    className: 'custom-icon-kerberos-medium',
    keywords: [
      {
        word: 'kerberos',
        weight: 1,
      },
      {
        word: '3 headed dog',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'key-lock-medium',
    className: 'custom-icon-key-lock-medium',
    keywords: [
      {
        word: 'lock and key',
        weight: 1,
      },
      {
        word: 'lock',
        weight: 1,
      },
      {
        word: 'key',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'password protection',
        weight: 3,
      },
      {
        word: 'access control',
        weight: 2,
      },
    ],
  },
  {
    name: 'lens-exclamation-medium',
    className: 'custom-icon-lens-exclamation-medium',
    keywords: [
      {
        word: 'magnifying glass',
        weight: 1,
      },
      {
        word: 'exclamation',
        weight: 1,
      },
      {
        word: 'alert',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'spam',
        weight: 3,
      },
      {
        word: 'warning',
        weight: 2,
      },
      {
        word: 'suspicious',
        weight: 2,
      },
    ],
  },
  {
    name: 'lens-gear-semi-medium-2',
    className: 'custom-icon-lens-gear-semi-medium-2',
    keywords: [
      {
        word: 'magnifying glass',
        weight: 1,
      },
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 1,
      },
      {
        word: 'audit',
        weight: 1,
      },
      {
        word: 'search',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: '2',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-gear-semi-medium',
    className: 'custom-icon-lens-gear-semi-medium',
    keywords: [
      {
        word: 'magnifying glass',
        weight: 1,
      },
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 1,
      },
      {
        word: 'audit',
        weight: 1,
      },
      {
        word: 'search',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'lens',
        weight: 1,
      },
    ],
  },
  {
    name: 'lock-edit-semi-medium',
    className: 'custom-icon-lock-edit-semi-medium',
    keywords: [
      {
        word: 'lock',
        weight: 1,
      },
      {
        word: 'edit',
        weight: 1,
      },
      {
        word: 'changes',
        weight: 1,
      },
      {
        word: 'password',
        weight: 1,
      },
      {
        word: 'pencil',
        weight: 3,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-gear-semi-medium',
    className: 'custom-icon-lock-gear-semi-medium',
    keywords: [
      {
        word: 'lock',
        weight: 1,
      },
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'management',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 1,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-link-medium',
    className: 'custom-icon-lock-link-medium',
    keywords: [
      {
        word: 'lock',
        weight: 1,
      },
      {
        word: 'link',
        weight: 1,
      },
      {
        word: 'url',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-warning-semi-medium',
    className: 'custom-icon-lock-warning-semi-medium',
    keywords: [
      {
        word: 'lock',
        weight: 1,
      },
      {
        word: 'warning',
        weight: 1,
      },
      {
        word: 'alert',
        weight: 1,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'risk',
        weight: 2,
      },
      {
        word: 'security warning',
        weight: 3,
      },
      {
        word: 'lockout',
        weight: 5,
      },
      {
        word: 'password',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-with-infinity-bold',
    className: 'custom-icon-lock-with-infinity-bold',
    keywords: [
      {
        word: 'lock',
        weight: 1,
      },
      {
        word: 'infinity',
        weight: 1,
      },
      {
        word: 'never expires',
        weight: 1,
      },
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'password',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-gear-semi-medium',
    className: 'custom-icon-notepad-gear-semi-medium',
    keywords: [
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 1,
      },
      {
        word: 'notepad',
        weight: 1,
      },
      {
        word: 'reportpad',
        weight: 2,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-lens',
    className: 'custom-icon-notepad-lens',
    keywords: [
      {
        word: 'notepad',
        weight: 1,
      },
      {
        word: 'reportpad',
        weight: 1,
      },
      {
        word: 'magnifying glass',
        weight: 1,
      },
      {
        word: 'search',
        weight: 2,
      },
      {
        word: 'audit',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'os',
    className: 'custom-icon-os',
    keywords: [
      {
        word: 'os',
        weight: 1,
      },
      {
        word: 'operating system',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-pad-lens-medium',
    className: 'custom-icon-report-pad-lens-medium',
    keywords: [
      {
        word: 'report',
        weight: 1,
      },
      {
        word: 'policy',
        weight: 2,
      },
      {
        word: 'checklist',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'magnifying glass',
        weight: 1,
      },
      {
        word: 'lens',
        weight: 2,
      },
      {
        word: 'search',
        weight: 2,
      },
    ],
  },
  {
    name: 'report-pad-timer-medium',
    className: 'custom-icon-report-pad-timer-medium',
    keywords: [
      {
        word: 'report',
        weight: 1,
      },
      {
        word: 'policy',
        weight: 2,
      },
      {
        word: 'checklist',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'timer',
        weight: 1,
      },
      {
        word: 'countdown',
        weight: 2,
      },
    ],
  },
  {
    name: 'reportpad-globe-semi-medium',
    className: 'custom-icon-reportpad-globe-semi-medium',
    keywords: [
      {
        word: 'report',
        weight: 1,
      },
      {
        word: 'policy',
        weight: 2,
      },
      {
        word: 'checklist',
        weight: 2,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'globe',
        weight: 1,
      },
      {
        word: 'site',
        weight: 2,
      },
    ],
  },
  {
    name: 'shield-checkmark-medium',
    className: 'custom-icon-shield-checkmark-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'checkmark',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'verified',
        weight: 1,
      },
      {
        word: 'protection',
        weight: 2,
      },
    ],
  },
  {
    name: 'shield-exclamation',
    className: 'custom-icon-shield-exclamation',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'exclamation',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'warning',
        weight: 1,
      },
      {
        word: 'risk detected',
        weight: 2,
      },
      {
        word: 'alert',
        weight: 2,
      },
    ],
  },
  {
    name: 'shield-gear-semi-medium',
    className: 'custom-icon-shield-gear-semi-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'gear',
        weight: 2,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'settings',
        weight: 1,
      },
    ],
  },
  {
    name: 'shield-key-medium',
    className: 'custom-icon-shield-key-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'key',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'access',
        weight: 1,
      },
      {
        word: 'login',
        weight: 1,
      },
    ],
  },
  {
    name: 'shield-link-semi-medium',
    className: 'custom-icon-shield-link-semi-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'link',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'url',
        weight: 1,
      },
      {
        word: 'secure link',
        weight: 1,
      },
    ],
  },
  {
    name: 'shield-pulse-medium',
    className: 'custom-icon-shield-pulse-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'pulse',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'wave',
        weight: 1,
      },
      {
        word: 'activity',
        weight: 1,
      },
    ],
  },
  {
    name: 'shield-refresh-arrow-medium',
    className: 'custom-icon-shield-refresh-arrow-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'refresh',
        weight: 2,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'update',
        weight: 1,
      },
      {
        word: 'arrow',
        weight: 1,
      },
    ],
  },
  {
    name: 'shield-star-semi-medium',
    className: 'custom-icon-shield-star-semi-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'star',
        weight: 2,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'trust',
        weight: 1,
      },
    ],
  },
  {
    name: 'shield-wrench-medium',
    className: 'custom-icon-shield-wrench-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 2,
      },
      {
        word: 'spanner',
        weight: 2,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'wrench',
        weight: 1,
      },
      {
        word: 'configuration',
        weight: 1,
      },
    ],
  },
  {
    name: 'shield-semi-medium',
    className: 'custom-icon-shield-semi-medium',
    keywords: [
      {
        word: 'shield',
        weight: 1,
      },
      {
        word: 'security',
        weight: 1,
      },
      {
        word: 'Protection',
        weight: 1,
      },
      {
        word: 'Firewall',
        weight: 1,
      },
      {
        word: 'secure',
        weight: 1,
      },
      {
        word: 'semi medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'support-medium',
    className: 'custom-icon-support-medium',
    keywords: [
      {
        word: 'Support',
        weight: 1,
      },
      {
        word: 'Technician',
        weight: 1,
      },
      {
        word: 'Customer support',
        weight: 2,
      },
      {
        word: 'Help',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'tab-semibold',
    className: 'custom-icon-tab-semibold',
    keywords: [
      {
        word: 'semibold',
        weight: 5,
      },
      {
        word: 'tab',
        weight: 1,
      },
      {
        word: 'browser',
        weight: 2,
      },
    ],
  },
  {
    name: 'user-clock-semi-medium',
    className: 'custom-icon-user-clock-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'time',
        weight: 1,
      },
      {
        word: 'clock',
        weight: 2,
      },
      {
        word: 'User',
        weight: 2,
      },
      {
        word: 'activity',
        weight: 2,
      },
    ],
  },
  {
    name: 'user-key-medium',
    className: 'custom-icon-user-key-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'key',
        weight: 1,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'credentials',
        weight: 2,
      },
      {
        word: 'password',
        weight: 2,
      },
    ],
  },
  {
    name: 'user-lock-semi-medium',
    className: 'custom-icon-user-lock-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'lock',
        weight: 1,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'Private profile',
        weight: 5,
      },
      {
        word: 'authentication',
        weight: 1,
      },
      {
        word: 'Password',
        weight: 1,
      },
    ],
  },
  {
    name: 'user-ques-semi-medium',
    className: 'custom-icon-user-ques-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'question',
        weight: 2,
      },
      {
        word: 'status',
        weight: 2,
      },
    ],
  },
  {
    name: 'user-warning-semi-medium',
    className: 'custom-icon-user-warning-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'warning',
        weight: 1,
      },
      {
        word: 'alert',
        weight: 2,
      },
      {
        word: 'Caution',
        weight: 2,
      },
      {
        word: 'User',
        weight: 2,
      },
      {
        word: 'issue',
        weight: 2,
      },
    ],
  },
  {
    name: 'windows-medium',
    className: 'custom-icon-windows-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'windows',
        weight: 1,
      },
      {
        word: 'microsoft',
        weight: 2,
      },
      {
        word: 'os',
        weight: 2,
      },
    ],
  },
  {
    name: 'windows-solid',
    className: 'custom-icon-windows-solid',
    keywords: [
      {
        word: 'solid',
        weight: 5,
      },
      {
        word: 'windows',
        weight: 1,
      },
      {
        word: 'microsoft',
        weight: 2,
      },
      {
        word: 'os',
        weight: 2,
      },
    ],
  },
  {
    name: 'desktop-pulse-lens-medium',
    className: 'custom-icon-desktop-pulse-lens-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'explorer',
        weight: 1,
      },
      {
        word: 'monitoring',
        weight: 2,
      },
      {
        word: 'analysis',
        weight: 2,
      },
      {
        word: 'activity',
        weight: 2,
      },
      {
        word: 'desktop',
        weight: 2,
      },
      {
        word: 'pulse',
        weight: 2,
      },
      {
        word: 'lens',
        weight: 2,
      },
    ],
  },
  {
    name: 'active-directory-medium',
    className: 'custom-icon-active-directory-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'active directory',
        weight: 1,
      },
      {
        word: 'ad',
        weight: 2,
      },
      {
        word: 'service',
        weight: 2,
      },
    ],
  },
  {
    name: 'bar-chart-medium',
    className: 'custom-icon-bar-chart-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'bar chart',
        weight: 1,
      },
      {
        word: 'data visualization',
        weight: 2,
      },
      {
        word: 'dashboard',
        weight: 2,
      },
      {
        word: 'Analytics',
        weight: 2,
      },
    ],
  },
  {
    name: 'data-base-medium',
    className: 'custom-icon-data-base-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'Database',
        weight: 1,
      },
      {
        word: 'Storage',
        weight: 2,
      },
      {
        word: 'server',
        weight: 2,
      },
      {
        word: 'repository',
        weight: 2,
      },
    ],
  },
  {
    name: 'desktop-eye-semi-medium',
    className: 'custom-icon-desktop-eye-semi-medium',
    keywords: [
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'desktop',
        weight: 1,
      },
      {
        word: 'eye',
        weight: 2,
      },
      {
        word: 'monitoring',
        weight: 2,
      },
      {
        word: 'insights',
        weight: 2,
      },
    ],
  },
  {
    name: 'gear-head-user-medium',
    className: 'custom-icon-gear-head-user-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'admin',
        weight: 2,
      },
      {
        word: 'manager',
        weight: 2,
      },
      {
        word: 'owner',
        weight: 2,
      },
    ],
  },
  {
    name: 'gear-medium',
    className: 'custom-icon-gear-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'gear',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 2,
      },
      {
        word: 'configurations',
        weight: 2,
      },
      {
        word: 'preferences',
        weight: 2,
      },
      {
        word: 'setup',
        weight: 2,
      },
    ],
  },
  {
    name: 'lens-eye-1-semi-medium',
    className: 'custom-icon-lens-eye-1-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'lens',
        weight: 1,
      },
      {
        word: 'search',
        weight: 2,
      },
      {
        word: 'vision',
        weight: 2,
      },
      {
        word: 'insight',
        weight: 2,
      },
      {
        word: 'explore',
        weight: 2,
      },
    ],
  },
  {
    name: 'lens-eye-semi-medium',
    className: 'custom-icon-lens-eye-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'lens',
        weight: 1,
      },
      {
        word: 'search',
        weight: 2,
      },
      {
        word: 'vision',
        weight: 2,
      },
      {
        word: 'insight',
        weight: 2,
      },
      {
        word: 'explore',
        weight: 2,
      },
    ],
  },
  {
    name: 'user-badge-semi-medium',
    className: 'custom-icon-user-badge-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'badge',
        weight: 1,
      },
      {
        word: 'user',
        weight: 2,
      },
      {
        word: 'role',
        weight: 2,
      },
      {
        word: 'credentials',
        weight: 2,
      },
    ],
  },
  {
    name: 'workflow-medium',
    className: 'custom-icon-workflow-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'workflow',
        weight: 1,
      },
      {
        word: 'flow',
        weight: 2,
      },
      {
        word: 'Automation',
        weight: 2,
      },
      {
        word: 'Power Automate',
        weight: 2,
      },
      {
        word: 'Data Flow',
        weight: 2,
      },
    ],
  },
  {
    name: 'bird-medium',
    className: 'custom-icon-bird-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'bird',
        weight: 5,
      },
      {
        word: 'view',
        weight: 5,
      },
    ],
  },
  {
    name: 'bulb-bolt-semi-medium',
    className: 'custom-icon-bulb-bolt-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'insights',
        weight: 1,
      },
      {
        word: 'idea',
        weight: 2,
      },
      {
        word: 'innovation',
        weight: 5,
      },
      {
        word: 'bulb',
        weight: 5,
      },
      {
        word: 'bolt',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-with-m365-semi-medium',
    className: 'custom-icon-lens-with-m365-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'm365',
        weight: 1,
      },
      {
        word: 'o365',
        weight: 1,
      },
      {
        word: 'governance',
        weight: 3,
      },
      {
        word: 'monitoring',
        weight: 5,
      },
      {
        word: 'lens',
        weight: 3,
      },
      {
        word: 'magnifying glass',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-medium',
    className: 'custom-icon-mail-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'mail',
        weight: 1,
      },
      {
        word: 'email',
        weight: 1,
      },
      {
        word: 'mailbox',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-with-gear-semi-medium',
    className: 'custom-icon-report-with-gear-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'management',
        weight: 1,
      },
      {
        word: 'report',
        weight: 1,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'settings',
        weight: 5,
      },
    ],
  },
  {
    name: 'growth-analysis-medium',
    className: 'custom-icon-growth-analysis-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'Growth',
        weight: 4,
      },
      {
        word: 'usage',
        weight: 2,
      },
      {
        word: 'Upward Trend',
        weight: 3,
      },
      {
        word: 'Analysis',
        weight: 1,
      },
      {
        word: 'Progress',
        weight: 2,
      },
    ],
  },
  {
    name: 'bar-chart-semi-medium',
    className: 'custom-icon-bar-chart-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'bar chart',
        weight: 1,
      },
      {
        word: 'analytics',
        weight: 1,
      },
      {
        word: 'data refresh',
        weight: 2,
      },
      {
        word: 'usage',
        weight: 3,
      },
    ],
  },
  {
    name: 'bell-gear-semi-medium',
    className: 'custom-icon-bell-gear-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'Notification Settings',
        weight: 1,
      },
      {
        word: 'Alert Configuration',
        weight: 2,
      },
      {
        word: 'notification setup',
        weight: 1,
      },
      {
        word: 'gear',
        weight: 3,
      },
      {
        word: 'bell',
        weight: 2,
      },
    ],
  },
  {
    name: 'channel-medium',
    className: 'custom-icon-channel-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'channel',
        weight: 1,
      },
      {
        word: 'teams',
        weight: 3,
      },
    ],
  },
  {
    name: 'cloud-gear-semi-medium',
    className: 'custom-icon-cloud-gear-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'Cloud Settings',
        weight: 1,
      },
      {
        word: 'permission',
        weight: 3,
      },
      {
        word: 'onedrive',
        weight: 1,
      },
      {
        word: 'settings',
        weight: 5,
      },
      {
        word: 'cloud storage',
        weight: 2,
      },
    ],
  },
  {
    name: 'entra-bold',
    className: 'custom-icon-entra-bold',
    keywords: [
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'Microsoft Entra',
        weight: 2,
      },
      {
        word: 'entra',
        weight: 1,
      },
      {
        word: 'azure',
        weight: 1,
      },
    ],
  },
  {
    name: 'entra-medium',
    className: 'custom-icon-entra-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'Microsoft Entra',
        weight: 1,
      },
      {
        word: 'entra',
        weight: 1,
      },
      {
        word: 'azure',
        weight: 1,
      },
    ],
  },
  {
    name: 'entra-solid',
    className: 'custom-icon-entra-solid',
    keywords: [
      {
        word: 'solid',
        weight: 5,
      },
      {
        word: 'Microsoft Entra',
        weight: 1,
      },
      {
        word: 'entra',
        weight: 1,
      },
      {
        word: 'azure',
        weight: 1,
      },
    ],
  },
  {
    name: 'exchange-bold',
    className: 'custom-icon-exchange-bold',
    keywords: [
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'Microsoft Exchange',
        weight: 1,
      },
      {
        word: 'Email',
        weight: 4,
      },
      {
        word: 'Mail Server',
        weight: 1,
      },
      {
        word: 'Messaging Platform',
        weight: 4,
      },
    ],
  },
  {
    name: 'file-lens-medium',
    className: 'custom-icon-file-lens-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'file audit',
        weight: 1,
      },
      {
        word: 'search',
        weight: 2,
      },
      {
        word: 'magnifying glass',
        weight: 5,
      },
      {
        word: 'file',
        weight: 5,
      },
      {
        word: 'audit',
        weight: 2,
      },
    ],
  },
  {
    name: 'group-call-medium',
    className: 'custom-icon-group-call-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'group',
        weight: 1,
      },
      {
        word: 'call',
        weight: 2,
      },
      {
        word: 'meeting',
        weight: 1,
      },
      {
        word: 'calls and meetings',
        weight: 5,
      },
      {
        word: 'group discussion',
        weight: 2,
      },
    ],
  },
  {
    name: 'license-medium',
    className: 'custom-icon-license-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'license',
        weight: 5,
      },
    ],
  },
  {
    name: 'lightning-bolt-medium',
    className: 'custom-icon-lightning-bolt-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'lightning',
        weight: 2,
      },
      {
        word: 'action',
        weight: 3,
      },
      {
        word: 'start',
        weight: 2,
      },
    ],
  },
  {
    name: 'lightning-bolt-semi-medium',
    className: 'custom-icon-lightning-bolt-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'lightning',
        weight: 2,
      },
      {
        word: 'action',
        weight: 3,
      },
      {
        word: 'start',
        weight: 2,
      },
    ],
  },
  {
    name: 'mail-gear-semi-medium',
    className: 'custom-icon-mail-gear-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'mail',
        weight: 5,
      },
      {
        word: 'settings',
        weight: 5,
      },
      {
        word: 'mailbox settings',
        weight: 5,
      },
      {
        word: 'permission',
        weight: 5,
      },
    ],
  },
  {
    name: 'one-drive-bold',
    className: 'custom-icon-one-drive-bold',
    keywords: [
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'cloud',
        weight: 1,
      },
      {
        word: 'cloud storage',
        weight: 2,
      },
      {
        word: 'OneDrive',
        weight: 5,
      },
    ],
  },
  {
    name: 'power-bi-bold',
    className: 'custom-icon-power-bi-bold',
    keywords: [
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'Power Bi',
        weight: 2,
      },
      {
        word: 'data analytics',
        weight: 2,
      },
      {
        word: 'data visualization',
        weight: 1,
      },
    ],
  },
  {
    name: 'reportpad-checkmark-semi-medium',
    className: 'custom-icon-reportpad-checkmark-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'Compliance Check',
        weight: 2,
      },
      {
        word: 'Security Check',
        weight: 2,
      },
      {
        word: 'Shield',
        weight: 1,
      },
      {
        word: 'reportpad',
        weight: 1,
      },
    ],
  },
  {
    name: 'reportpad-medium',
    className: 'custom-icon-reportpad-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'reportpad',
        weight: 1,
      },
      {
        word: 'checklist',
        weight: 2,
      },
    ],
  },
  {
    name: 'right-arrow-medium',
    className: 'custom-icon-right-arrow-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'right arrow',
        weight: 1,
      },
      {
        word: 'start',
        weight: 2,
      },
    ],
  },
  {
    name: 'rocket-medium',
    className: 'custom-icon-rocket-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'start',
        weight: 2,
      },
      {
        word: 'rocket',
        weight: 1,
      },
    ],
  },
  {
    name: 'sharepoint-bold',
    className: 'custom-icon-sharepoint-bold',
    keywords: [
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'sharepoint',
        weight: 1,
      },
      {
        word: 'file',
        weight: 5,
      },
      {
        word: 'document',
        weight: 5,
      },
      {
        word: 'site',
        weight: 2,
      },
    ],
  },
  {
    name: 'site-cloud-semi-mudium',
    className: 'custom-icon-site-cloud-semi-mudium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'site',
        weight: 2,
      },
      {
        word: 'cloud',
        weight: 5,
      },
      {
        word: 'onedrive',
        weight: 5,
      },
      {
        word: 'onedrive sites',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-gear-semi-medium',
    className: 'custom-icon-site-gear-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'site',
        weight: 2,
      },
      {
        word: 'gear',
        weight: 5,
      },
      {
        word: 'site settings',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-globe-semi-medium',
    className: 'custom-icon-site-globe-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'site',
        weight: 2,
      },
      {
        word: 'globe',
        weight: 5,
      },
      {
        word: 'sharepoint sites',
        weight: 5,
      },
    ],
  },
  {
    name: 'stream-bold',
    className: 'custom-icon-stream-bold',
    keywords: [
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'stream',
        weight: 2,
      },
      {
        word: 'video stream',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-bold',
    className: 'custom-icon-teams-bold',
    keywords: [
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'teams',
        weight: 2,
      },
      {
        word: 'group chat',
        weight: 5,
      },
      {
        word: 'Message Platform',
        weight: 2,
      },
    ],
  },
  {
    name: 'teams-users-medium',
    className: 'custom-icon-teams-users-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'teams',
        weight: 2,
      },
      {
        word: 'users',
        weight: 2,
      },
      {
        word: 'Microsoft teams',
        weight: 5,
      },
    ],
  },
  {
    name: 'upward-rising-arrow-medium',
    className: 'custom-icon-upward-rising-arrow-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'upward',
        weight: 2,
      },
      {
        word: 'trend',
        weight: 2,
      },
      {
        word: 'growth',
        weight: 2,
      },
      {
        word: 'usage',
        weight: 2,
      },
    ],
  },
  {
    name: 'usage-medium',
    className: 'custom-icon-usage-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'usage',
        weight: 2,
      },
      {
        word: 'pie chart',
        weight: 2,
      },
    ],
  },
  {
    name: 'usage-semi-medium',
    className: 'custom-icon-usage-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'usage',
        weight: 2,
      },
      {
        word: 'pie chart',
        weight: 2,
      },
    ],
  },
  {
    name: 'user-gear-semi-medium',
    className: 'custom-icon-user-gear-semi-medium',
    keywords: [
      {
        word: 'semi medium',
        weight: 5,
      },
      {
        word: 'user',
        weight: 2,
      },
      {
        word: 'settings',
        weight: 2,
      },
      {
        word: 'gear',
        weight: 2,
      },
      {
        word: 'admin settings',
        weight: 2,
      },
    ],
  },
  {
    name: 'user-lens-medium',
    className: 'custom-icon-user-lens-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'user audit',
        weight: 2,
      },
      {
        word: 'user',
        weight: 2,
      },
      {
        word: 'search',
        weight: 2,
      },
      {
        word: 'lens',
        weight: 2,
      },
    ],
  },
  {
    name: 'viva-engage-bold',
    className: 'custom-icon-viva-engage-bold',
    keywords: [
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'viva engage',
        weight: 2,
      },
      {
        word: 'collaboration',
        weight: 2,
      },
      {
        word: 'Employee Engagement',
        weight: 2,
      },
    ],
  },
  {
    name: 'viva-engage-medium',
    className: 'custom-icon-viva-engage-medium',
    keywords: [
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'viva engage',
        weight: 2,
      },
      {
        word: 'collaboration',
        weight: 2,
      },
      {
        word: 'Employee Engagement',
        weight: 2,
      },
    ],
  },
  {
    name: 'admin-wave-semi-medium',
    className: 'custom-icon-admin-wave-semi-medium',
    keywords: [
      {
        word: 'custom-icon-admin-wave-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'arrow-right-solid',
    className: 'custom-icon-arrow-right-solid',
    keywords: [
      {
        word: 'custom-icon-arrow-right-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'arrow-up-solid',
    className: 'custom-icon-arrow-up-solid',
    keywords: [
      {
        word: 'custom-icon-arrow-up-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'audio-1-medium',
    className: 'custom-icon-audio-1-medium',
    keywords: [
      {
        word: 'custom-icon-audio-1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'audio-2-medium',
    className: 'custom-icon-audio-2-medium',
    keywords: [
      {
        word: 'custom-icon-audio-2-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'automation-2-semi-medium',
    className: 'custom-icon-automation-2-semi-medium',
    keywords: [
      {
        word: 'custom-icon-automation-2-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'barchart1-medium',
    className: 'custom-icon-barchart1-medium',
    keywords: [
      {
        word: 'custom-icon-barchart1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-clock-semi-bold',
    className: 'custom-icon-calendar-clock-semi-bold',
    keywords: [
      {
        word: 'custom-icon-calendar-clock-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-cross-bold',
    className: 'custom-icon-calendar-cross-bold',
    keywords: [
      {
        word: 'custom-icon-calendar-cross-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-cross',
    className: 'custom-icon-calendar-cross',
    keywords: [
      {
        word: 'custom-icon-calendar-cross',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-plus-semi-bold',
    className: 'custom-icon-calendar-plus-semi-bold',
    keywords: [
      {
        word: 'custom-icon-calendar-plus-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-user-semi-bold',
    className: 'custom-icon-calendar-user-semi-bold',
    keywords: [
      {
        word: 'custom-icon-calendar-user-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-lock-semi-medium',
    className: 'custom-icon-channel-lock-semi-medium',
    keywords: [
      {
        word: 'custom-icon-channel-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-database-semi-solid',
    className: 'custom-icon-cloud-database-semi-solid',
    keywords: [
      {
        word: 'custom-icon-cloud-database-semi-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-group-semi-medium',
    className: 'custom-icon-cloud-group-semi-medium',
    keywords: [
      {
        word: 'custom-icon-cloud-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-high-measure-semi-medium',
    className: 'custom-icon-cloud-high-measure-semi-medium',
    keywords: [
      {
        word: 'custom-icon-cloud-high-measure-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-low-measure-semi-medium',
    className: 'custom-icon-cloud-low-measure-semi-medium',
    keywords: [
      {
        word: 'custom-icon-cloud-low-measure-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-pie-chart-semi-medium',
    className: 'custom-icon-cloud-pie-chart-semi-medium',
    keywords: [
      {
        word: 'custom-icon-cloud-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-user-semi-medium',
    className: 'custom-icon-cloud-user-semi-medium',
    keywords: [
      {
        word: 'custom-icon-cloud-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-wave',
    className: 'custom-icon-cloud-wave',
    keywords: [
      {
        word: 'custom-icon-cloud-wave',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-with-gear-head-user-semi-medium',
    className: 'custom-icon-cloud-with-gear-head-user-semi-medium',
    keywords: [
      {
        word: 'custom-icon-cloud-with-gear-head-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-with-upward-arrow',
    className: 'custom-icon-cloud-with-upward-arrow',
    keywords: [
      {
        word: 'custom-icon-cloud-with-upward-arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'dashboard-1-medium',
    className: 'custom-icon-dashboard-1-medium',
    keywords: [
      {
        word: 'custom-icon-dashboard-1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'dashboard-2-medium',
    className: 'custom-icon-dashboard-2-medium',
    keywords: [
      {
        word: 'custom-icon-dashboard-2-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'delete-contact',
    className: 'custom-icon-delete-contact',
    keywords: [
      {
        word: 'custom-icon-delete-contact',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-arrows-bold',
    className: 'custom-icon-desktop-arrows-bold',
    keywords: [
      {
        word: 'custom-icon-desktop-arrows-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-checkmark-bold',
    className: 'custom-icon-desktop-checkmark-bold',
    keywords: [
      {
        word: 'custom-icon-desktop-checkmark-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-gear-bold',
    className: 'custom-icon-desktop-gear-bold',
    keywords: [
      {
        word: 'custom-icon-desktop-gear-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-lock-semi-medium',
    className: 'custom-icon-desktop-lock-semi-medium',
    keywords: [
      {
        word: 'custom-icon-desktop-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-os-medium',
    className: 'custom-icon-desktop-os-medium',
    keywords: [
      {
        word: 'custom-icon-desktop-os-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-plus-bold',
    className: 'custom-icon-desktop-plus-bold',
    keywords: [
      {
        word: 'custom-icon-desktop-plus-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-refresh-bold',
    className: 'custom-icon-desktop-refresh-bold',
    keywords: [
      {
        word: 'custom-icon-desktop-refresh-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-shield-semi-medium',
    className: 'custom-icon-desktop-shield-semi-medium',
    keywords: [
      {
        word: 'custom-icon-desktop-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-libs-medium',
    className: 'custom-icon-doc-libs-medium',
    keywords: [
      {
        word: 'custom-icon-doc-libs-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-libs1-medium',
    className: 'custom-icon-doc-libs1-medium',
    keywords: [
      {
        word: 'custom-icon-doc-libs1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'document-1-medium',
    className: 'custom-icon-document-1-medium',
    keywords: [
      {
        word: 'custom-icon-document-1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'shield-wrench-semi-bold',
    className: 'custom-icon-shield-wrench-semi-bold',
    keywords: [
      {
        word: 'custom-icon-shield-wrench-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'external-file-semi-medium',
    className: 'custom-icon-external-file-semi-medium',
    keywords: [
      {
        word: 'custom-icon-external-file-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-lens2-medium',
    className: 'custom-icon-file-lens2-medium',
    keywords: [
      {
        word: 'custom-icon-file-lens2-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-medium',
    className: 'custom-icon-file-medium',
    keywords: [
      {
        word: 'custom-icon-file-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-share-semi-medium',
    className: 'custom-icon-file-share-semi-medium',
    keywords: [
      {
        word: 'custom-icon-file-share-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-lock-semi-bold',
    className: 'custom-icon-folder-lock-semi-bold',
    keywords: [
      {
        word: 'custom-icon-folder-lock-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-arrows-semi-bold',
    className: 'custom-icon-globe-arrows-semi-bold',
    keywords: [
      {
        word: 'custom-icon-globe-arrows-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-cross-semi-medium',
    className: 'custom-icon-globe-cross-semi-medium',
    keywords: [
      {
        word: 'custom-icon-globe-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-medium',
    className: 'custom-icon-group-medium',
    keywords: [
      {
        word: 'custom-icon-group-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'hierarchy-medium',
    className: 'custom-icon-hierarchy-medium',
    keywords: [
      {
        word: 'custom-icon-hierarchy-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'hierarchy1-medium',
    className: 'custom-icon-hierarchy1-medium',
    keywords: [
      {
        word: 'custom-icon-hierarchy1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'image-medium',
    className: 'custom-icon-image-medium',
    keywords: [
      {
        word: 'custom-icon-image-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'image-semi-medium',
    className: 'custom-icon-image-semi-medium',
    keywords: [
      {
        word: 'custom-icon-image-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'insights-semi-bold',
    className: 'custom-icon-insights-semi-bold',
    keywords: [
      {
        word: 'custom-icon-insights-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'internal-file-semi-medium',
    className: 'custom-icon-internal-file-semi-medium',
    keywords: [
      {
        word: 'custom-icon-internal-file-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'key-cross-semi-medium',
    className: 'custom-icon-key-cross-semi-medium',
    keywords: [
      {
        word: 'custom-icon-key-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-medium',
    className: 'custom-icon-lens-medium',
    keywords: [
      {
        word: 'custom-icon-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'license-user-semi-medium',
    className: 'custom-icon-license-user-semi-medium',
    keywords: [
      {
        word: 'custom-icon-license-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-group-semi-medium',
    className: 'custom-icon-list-group-semi-medium',
    keywords: [
      {
        word: 'custom-icon-list-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-light',
    className: 'custom-icon-list-light',
    keywords: [
      {
        word: 'custom-icon-list-light',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-medium',
    className: 'custom-icon-list-medium',
    keywords: [
      {
        word: 'custom-icon-list-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-checkmark-semi-medium',
    className: 'custom-icon-lock-checkmark-semi-medium',
    keywords: [
      {
        word: 'custom-icon-lock-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-user-semi-medium',
    className: 'custom-icon-lock-user-semi-medium',
    keywords: [
      {
        word: 'custom-icon-lock-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-arrow-in-semi-medium',
    className: 'custom-icon-mail-arrow-in-semi-medium',
    keywords: [
      {
        word: 'custom-icon-mail-arrow-in-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-arrow-out-semi-medium',
    className: 'custom-icon-mail-arrow-out-semi-medium',
    keywords: [
      {
        word: 'custom-icon-mail-arrow-out-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-arrows-1-medium',
    className: 'custom-icon-mail-arrows-1-medium',
    keywords: [
      {
        word: 'custom-icon-mail-arrows-1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-arrows-2-medium',
    className: 'custom-icon-mail-arrows-2-medium',
    keywords: [
      {
        word: 'custom-icon-mail-arrows-2-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-eye-semi-medium',
    className: 'custom-icon-mail-eye-semi-medium',
    keywords: [
      {
        word: 'custom-icon-mail-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mailboxes-medium',
    className: 'custom-icon-mailboxes-medium',
    keywords: [
      {
        word: 'custom-icon-mailboxes-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mask-user-semi-medium',
    className: 'custom-icon-mask-user-semi-medium',
    keywords: [
      {
        word: 'custom-icon-mask-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'merged-reports-1-semi-medium',
    className: 'custom-icon-merged-reports-1-semi-medium',
    keywords: [
      {
        word: 'custom-icon-merged-reports-1-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'merged-reports-medium',
    className: 'custom-icon-merged-reports-medium',
    keywords: [
      {
        word: 'custom-icon-merged-reports-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'microsoft-365-medium',
    className: 'custom-icon-microsoft-365-medium',
    keywords: [
      {
        word: 'custom-icon-microsoft-365-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'move-desktop-bold',
    className: 'custom-icon-move-desktop-bold',
    keywords: [
      {
        word: 'custom-icon-move-desktop-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'oepned-email-medium',
    className: 'custom-icon-oepned-email-medium',
    keywords: [
      {
        word: 'custom-icon-oepned-email-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'remove-desktop-bold',
    className: 'custom-icon-remove-desktop-bold',
    keywords: [
      {
        word: 'custom-icon-remove-desktop-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'remove-group-semi-medium',
    className: 'custom-icon-remove-group-semi-medium',
    keywords: [
      {
        word: 'custom-icon-remove-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'remove-list-semi-medium',
    className: 'custom-icon-remove-list-semi-medium',
    keywords: [
      {
        word: 'custom-icon-remove-list-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'rename-bold',
    className: 'custom-icon-rename-bold',
    keywords: [
      {
        word: 'custom-icon-rename-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-pad-checkmark-semi-medium',
    className: 'custom-icon-report-pad-checkmark-semi-medium',
    keywords: [
      {
        word: 'custom-icon-report-pad-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-stack1-medium',
    className: 'custom-icon-report-stack1-medium',
    keywords: [
      {
        word: 'custom-icon-report-stack1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-stack-medium',
    className: 'custom-icon-report-stack-medium',
    keywords: [
      {
        word: 'custom-icon-report-stack-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'restore-bold',
    className: 'custom-icon-restore-bold',
    keywords: [
      {
        word: 'custom-icon-restore-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'send-1-medium',
    className: 'custom-icon-send-1-medium',
    keywords: [
      {
        word: 'custom-icon-send-1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'send-2-medium',
    className: 'custom-icon-send-2-medium',
    keywords: [
      {
        word: 'custom-icon-send-2-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-link-semi-bold',
    className: 'custom-icon-site-link-semi-bold',
    keywords: [
      {
        word: 'custom-icon-site-link-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'subscription-medium',
    className: 'custom-icon-subscription-medium',
    keywords: [
      {
        word: 'custom-icon-subscription-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'sun-medium',
    className: 'custom-icon-sun-medium',
    keywords: [
      {
        word: 'custom-icon-sun-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'sun-solid',
    className: 'custom-icon-sun-solid',
    keywords: [
      {
        word: 'custom-icon-sun-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'tab-cross-semi-medium',
    className: 'custom-icon-tab-cross-semi-medium',
    keywords: [
      {
        word: 'custom-icon-tab-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'tab-light',
    className: 'custom-icon-tab-light',
    keywords: [
      {
        word: 'custom-icon-tab-light',
        weight: 5,
      },
    ],
  },
  {
    name: 'tab-medium',
    className: 'custom-icon-tab-medium',
    keywords: [
      {
        word: 'custom-icon-tab-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'tab-stack-medium',
    className: 'custom-icon-tab-stack-medium',
    keywords: [
      {
        word: 'custom-icon-tab-stack-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'toolkit-arrows-bold',
    className: 'custom-icon-toolkit-arrows-bold',
    keywords: [
      {
        word: 'custom-icon-toolkit-arrows-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'usage-1-medium',
    className: 'custom-icon-usage-1-medium',
    keywords: [
      {
        word: 'custom-icon-usage-1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'usage-1-semi-medium',
    className: 'custom-icon-usage-1-semi-medium',
    keywords: [
      {
        word: 'custom-icon-usage-1-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-arrow-in-semi-bold',
    className: 'custom-icon-user-arrow-in-semi-bold',
    keywords: [
      {
        word: 'custom-icon-user-arrow-in-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-badge1-semi-medium',
    className: 'custom-icon-user-badge1-semi-medium',
    keywords: [
      {
        word: 'custom-icon-user-badge1-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-bug-semi-medium',
    className: 'custom-icon-user-bug-semi-medium',
    keywords: [
      {
        word: 'custom-icon-user-bug-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-clock-semi-bold',
    className: 'custom-icon-user-clock-semi-bold',
    keywords: [
      {
        word: 'custom-icon-user-clock-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-cross-semi-medium',
    className: 'custom-icon-user-cross-semi-medium',
    keywords: [
      {
        word: 'custom-icon-user-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-exclamation-semi-medium',
    className: 'custom-icon-user-exclamation-semi-medium',
    keywords: [
      {
        word: 'custom-icon-user-exclamation-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-mail-semi-medium',
    className: 'custom-icon-user-mail-semi-medium',
    keywords: [
      {
        word: 'custom-icon-user-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-management-semi-bold',
    className: 'custom-icon-user-management-semi-bold',
    keywords: [
      {
        word: 'custom-icon-user-management-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-medium',
    className: 'custom-icon-user-medium',
    keywords: [
      {
        word: 'custom-icon-user-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-phish-hook-medium',
    className: 'custom-icon-user-phish-hook-medium',
    keywords: [
      {
        word: 'custom-icon-user-phish-hook-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'video-medium',
    className: 'custom-icon-video-medium',
    keywords: [
      {
        word: 'custom-icon-video-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'video-semi-medium',
    className: 'custom-icon-video-semi-medium',
    keywords: [
      {
        word: 'custom-icon-video-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-access-bold',
    className: 'custom-icon-ms-access-bold',
    keywords: [
      {
        word: 'custom-icon-ms-access-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'add-group-semi-bold',
    className: 'custom-icon-add-group-semi-bold',
    keywords: [
      {
        word: 'custom-icon-add-group-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-bold',
    className: 'custom-icon-calendar-bold',
    keywords: [
      {
        word: 'custom-icon-calendar-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-block-bold',
    className: 'custom-icon-desktop-block-bold',
    keywords: [
      {
        word: 'custom-icon-desktop-block-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-lock-bold',
    className: 'custom-icon-desktop-lock-bold',
    keywords: [
      {
        word: 'custom-icon-desktop-lock-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'device-checkmark-medium',
    className: 'custom-icon-device-checkmark-medium',
    keywords: [
      {
        word: 'custom-icon-device-checkmark-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'device-link-medium',
    className: 'custom-icon-device-link-medium',
    keywords: [
      {
        word: 'custom-icon-device-link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'device-medium',
    className: 'custom-icon-device-medium',
    keywords: [
      {
        word: 'custom-icon-device-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'excel-bold',
    className: 'custom-icon-excel-bold',
    keywords: [
      {
        word: 'custom-icon-excel-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'filter-gear-semi-bold',
    className: 'custom-icon-filter-gear-semi-bold',
    keywords: [
      {
        word: 'custom-icon-filter-gear-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-checkmark-bold',
    className: 'custom-icon-group-checkmark-bold',
    keywords: [
      {
        word: 'custom-icon-group-checkmark-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-checkmark-semi-bold',
    className: 'custom-icon-group-checkmark-semi-bold',
    keywords: [
      {
        word: 'custom-icon-group-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-cross-semi-bold',
    className: 'custom-icon-group-cross-semi-bold',
    keywords: [
      {
        word: 'custom-icon-group-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'custom-icon-active-directory1-medium',
    className: 'custom-icon-active-directory1-medium',
    keywords: [
      {
        word: 'custom-icon-active-directory1-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mails-medium',
    className: 'custom-icon-mails-medium',
    keywords: [
      {
        word: 'custom-icon-mails-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'moon-medium',
    className: 'custom-icon-moon-medium',
    keywords: [
      {
        word: 'custom-icon-moon-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'moon-solid',
    className: 'custom-icon-moon-solid',
    keywords: [
      {
        word: 'custom-icon-moon-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-publish-bold',
    className: 'custom-icon-ms-publish-bold',
    keywords: [
      {
        word: 'custom-icon-ms-publish-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-visio-bold',
    className: 'custom-icon-ms-visio-bold',
    keywords: [
      {
        word: 'custom-icon-ms-visio-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-word-bold',
    className: 'custom-icon-ms-word-bold',
    keywords: [
      {
        word: 'custom-icon-ms-word-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'powerpoint-bold',
    className: 'custom-icon-powerpoint-bold',
    keywords: [
      {
        word: 'custom-icon-powerpoint-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-semi-medium',
    className: 'custom-icon-gear-semi-medium',
    keywords: [
      {
        word: 'gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-filled',
    className: 'custom-icon-calendar-filled',
    keywords: [
      {
        word: 'calendar-filled',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-medium',
    className: 'custom-icon-calendar-medium',
    keywords: [
      {
        word: 'calendar-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'computer-medium',
    className: 'custom-icon-computer-medium',
    keywords: [
      {
        word: 'computer-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'arrow-in-bold',
    className: 'custom-icon-arrow-in-bold',
    keywords: [
      {
        word: 'arrow-in-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'circle-bold',
    className: 'custom-icon-circle-bold',
    keywords: [
      {
        word: 'circle-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'circle-solid',
    className: 'custom-icon-circle-solid',
    keywords: [
      {
        word: 'circle-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-download',
    className: 'custom-icon-file-download',
    keywords: [
      {
        word: 'file-download',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-bolt-semi-medium',
    className: 'custom-icon-gear-bolt-semi-medium',
    keywords: [
      {
        word: 'gear-bolt-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'restored-files-bold',
    className: 'custom-icon-restored-files-bold',
    keywords: [
      {
        word: 'restored-files-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'attach-medium',
    className: 'custom-icon-attach-medium',
    keywords: [
      {
        word: 'attach-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-classification-medium',
    className: 'custom-icon-user-classification-medium',
    keywords: [
      {
        word: 'user-classification-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-division-medium',
    className: 'custom-icon-user-division-medium',
    keywords: [
      {
        word: 'user-division-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-arrow-down-semi-medium',
    className: 'custom-icon-globe-arrow-down-semi-medium',
    keywords: [
      {
        word: 'globe-arrow-down-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-arrow-in-semi-medium',
    className: 'custom-icon-globe-arrow-in-semi-medium',
    keywords: [
      {
        word: 'globe-arrow-in-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-arrow-out-semi-medium',
    className: 'custom-icon-globe-arrow-out-semi-medium',
    keywords: [
      {
        word: 'globe-arrow-out-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-arrow-up-semi-medium',
    className: 'custom-icon-globe-arrow-up-semi-medium',
    keywords: [
      {
        word: 'globe-arrow-up-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-group-semi-medium',
    className: 'custom-icon-globe-group-semi-medium',
    keywords: [
      {
        word: 'globe-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-lens-medium',
    className: 'custom-icon-globe-lens-medium',
    keywords: [
      {
        word: 'globe-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-user-semi-medium',
    className: 'custom-icon-globe-user-semi-medium',
    keywords: [
      {
        word: 'globe-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'inbox-right-arrow-semi-medium',
    className: 'custom-icon-inbox-right-arrow-semi-medium',
    keywords: [
      {
        word: 'inbox-right-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-arrow-in-semi-medium',
    className: 'custom-icon-link-arrow-in-semi-medium',
    keywords: [
      {
        word: 'link-arrow-in-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-arrow-out-medum',
    className: 'custom-icon-link-arrow-out-medum',
    keywords: [
      {
        word: 'link-arrow-out-medum',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-mail-semi-medium',
    className: 'custom-icon-link-mail-semi-medium',
    keywords: [
      {
        word: 'link-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-question-semi-medium',
    className: 'custom-icon-link-question-semi-medium',
    keywords: [
      {
        word: 'link-question-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-archive-semi-medium',
    className: 'custom-icon-mail-archive-semi-medium',
    keywords: [
      {
        word: 'mail-archive-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-arrow-left-semi-medium',
    className: 'custom-icon-mail-arrow-left-semi-medium',
    keywords: [
      {
        word: 'mail-arrow-left-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-arrow-right-semi-medium',
    className: 'custom-icon-mail-arrow-right-semi-medium',
    keywords: [
      {
        word: 'mail-arrow-right-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-attach-medium',
    className: 'custom-icon-mail-attach-medium',
    keywords: [
      {
        word: 'mail-attach-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-block-medium',
    className: 'custom-icon-mail-block-medium',
    keywords: [
      {
        word: 'mail-block-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-checkmark-shield-semi-medium',
    className: 'custom-icon-mail-checkmark-shield-semi-medium',
    keywords: [
      {
        word: 'mail-checkmark-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-connection-2-medium',
    className: 'custom-icon-mail-connection-2-medium',
    keywords: [
      {
        word: 'mail-connection-2-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-cross-semi-medium',
    className: 'custom-icon-mail-cross-semi-medium',
    keywords: [
      {
        word: 'mail-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-cross-shield-semi-medium',
    className: 'custom-icon-mail-cross-shield-semi-medium',
    keywords: [
      {
        word: 'mail-cross-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-double-side-arrow-medium',
    className: 'custom-icon-mail-double-side-arrow-medium',
    keywords: [
      {
        word: 'mail-double-side-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-down-arrow-semi-medium',
    className: 'custom-icon-mail-down-arrow-semi-medium',
    keywords: [
      {
        word: 'mail-down-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-history-medium',
    className: 'custom-icon-mail-history-medium',
    keywords: [
      {
        word: 'mail-history-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-key-medium',
    className: 'custom-icon-mail-key-medium',
    keywords: [
      {
        word: 'mail-key-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-link-medium',
    className: 'custom-icon-mail-link-medium',
    keywords: [
      {
        word: 'mail-link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-percentage-medium',
    className: 'custom-icon-mail-percentage-medium',
    keywords: [
      {
        word: 'mail-percentage-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-pie-chart-semi-medium',
    className: 'custom-icon-mail-pie-chart-semi-medium',
    keywords: [
      {
        word: 'mail-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-right-arrow-semi-medium',
    className: 'custom-icon-mail-right-arrow-semi-medium',
    keywords: [
      {
        word: 'mail-right-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-star-semi-medium',
    className: 'custom-icon-mail-star-semi-medium',
    keywords: [
      {
        word: 'mail-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-storage-semi-medium',
    className: 'custom-icon-mail-storage-semi-medium',
    keywords: [
      {
        word: 'mail-storage-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-tag-semi-medium',
    className: 'custom-icon-mail-tag-semi-medium',
    keywords: [
      {
        word: 'mail-tag-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-up-arrow-semi-medium',
    className: 'custom-icon-mail-up-arrow-semi-medium',
    keywords: [
      {
        word: 'mail-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-wave-medium',
    className: 'custom-icon-mail-wave-medium',
    keywords: [
      {
        word: 'mail-wave-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mailbox-right-arrow-semi-medium',
    className: 'custom-icon-mailbox-right-arrow-semi-medium',
    keywords: [
      {
        word: 'mailbox-right-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-globe-semi-medium',
    className: 'custom-icon-user-globe-semi-medium',
    keywords: [
      {
        word: 'user-globe-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-send-rocket-semi-medium',
    className: 'custom-icon-user-send-rocket-semi-medium',
    keywords: [
      {
        word: 'user-send-rocket-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-trend-wave-semi-medium',
    className: 'custom-icon-user-trend-wave-semi-medium',
    keywords: [
      {
        word: 'user-trend-wave-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-up-arrow-semi-medium',
    className: 'custom-icon-user-up-arrow-semi-medium',
    keywords: [
      {
        word: 'user-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'users-presence',
    className: 'custom-icon-users-presence',
    keywords: [
      {
        word: 'users-presence',
        weight: 5,
      },
    ],
  },
  {
    name: 'angry-1-bold',
    className: 'custom-icon-angry-1-bold',
    keywords: [
      {
        word: 'angry-1-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'angry-2-bold',
    className: 'custom-icon-angry-2-bold',
    keywords: [
      {
        word: 'angry-2-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'surprised-semi-bold',
    className: 'custom-icon-surprised-semi-bold',
    keywords: [
      {
        word: 'surprised-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'laugh-bold',
    className: 'custom-icon-laugh-bold',
    keywords: [
      {
        word: 'laugh-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'contact-medium',
    className: 'custom-icon-contact-medium',
    keywords: [
      {
        word: 'contact-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'entra-admin-solid',
    className: 'custom-icon-entra-admin-solid',
    keywords: [
      {
        word: 'entra-admin-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'entra-admin-bold',
    className: 'custom-icon-entra-admin-bold',
    keywords: [
      {
        word: 'entra-admin-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'entra-admin-medium',
    className: 'custom-icon-entra-admin-medium',
    keywords: [
      {
        word: 'entra-admin-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-solid',
    className: 'custom-icon-user-solid',
    keywords: [
      {
        word: 'user-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-solid',
    className: 'custom-icon-group-solid',
    keywords: [
      {
        word: 'group-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-bold',
    className: 'custom-icon-heart-bold',
    keywords: [
      {
        word: 'heart-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-solid',
    className: 'custom-icon-heart-solid',
    keywords: [
      {
        word: 'heart-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-reply-solid',
    className: 'custom-icon-mail-reply-solid',
    keywords: [
      {
        word: 'mail-reply-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'measure-1-semi-medium',
    className: 'custom-icon-measure-1-semi-medium',
    keywords: [
      {
        word: 'measure-1-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'measure-2-semi-medium',
    className: 'custom-icon-measure-2-semi-medium',
    keywords: [
      {
        word: 'measure-2-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'measure-3-semi-medium',
    className: 'custom-icon-measure-3-semi-medium',
    keywords: [
      {
        word: 'measure-3-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'measure-4-solid',
    className: 'custom-icon-measure-4-solid',
    keywords: [
      {
        word: 'measure-4-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-info-semi-medium',
    className: 'custom-icon-teams-info-semi-medium',
    keywords: [
      {
        word: 'teams-info-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-user-semi-medium',
    className: 'custom-icon-calendar-user-semi-medium',
    keywords: [
      {
        word: 'calendar-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-bolt-semi-medium',
    className: 'custom-icon-chat-bolt-semi-medium',
    keywords: [
      {
        word: 'chat-bolt-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-checkmark-semi-medium',
    className: 'custom-icon-chat-checkmark-semi-medium',
    keywords: [
      {
        word: 'chat-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-checkmark-semi-medium-1',
    className: 'custom-icon-chat-checkmark-semi-medium-1',
    keywords: [
      {
        word: 'chat-checkmark-semi-medium-1',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-external-arrow-medium',
    className: 'custom-icon-user-external-arrow-medium',
    keywords: [
      {
        word: 'user-external-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-call-semi-medium',
    className: 'custom-icon-globe-call-semi-medium',
    keywords: [
      {
        word: 'globe-call-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-double-side-arrow-medium',
    className: 'custom-icon-user-double-side-arrow-medium',
    keywords: [
      {
        word: 'user-double-side-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-shield-semi-medium',
    className: 'custom-icon-user-shield-semi-medium',
    keywords: [
      {
        word: 'user-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-bar-chart-semi-medium',
    className: 'custom-icon-calendar-bar-chart-semi-medium',
    keywords: [
      {
        word: 'calendar-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'autoresponded',
    className: 'custom-icon-autoresponded',
    keywords: [
      {
        word: 'autoresponded',
        weight: 5,
      },
    ],
  },
  {
    name: 'bot-bold',
    className: 'custom-icon-bot-bold',
    keywords: [
      {
        word: 'bot-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-chat-semi-medium',
    className: 'custom-icon-calendar-chat-semi-medium',
    keywords: [
      {
        word: 'calendar-chat-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-group-semi-medium',
    className: 'custom-icon-call-group-semi-medium',
    keywords: [
      {
        word: 'call-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-medium',
    className: 'custom-icon-call-medium',
    keywords: [
      {
        word: 'call-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-video-semi-medium',
    className: 'custom-icon-call-video-semi-medium',
    keywords: [
      {
        word: 'call-video-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-gear-semi-medium',
    className: 'custom-icon-channel-gear-semi-medium',
    keywords: [
      {
        word: 'channel-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-user-semi-medium',
    className: 'custom-icon-channel-user-semi-medium',
    keywords: [
      {
        word: 'channel-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-video-semi-medium',
    className: 'custom-icon-channel-video-semi-medium',
    keywords: [
      {
        word: 'channel-video-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-bar-chart-semi-medium',
    className: 'custom-icon-chat-bar-chart-semi-medium',
    keywords: [
      {
        word: 'chat-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-lens-semi-medium',
    className: 'custom-icon-chat-lens-semi-medium',
    keywords: [
      {
        word: 'chat-lens-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-medium',
    className: 'custom-icon-chat-medium',
    keywords: [
      {
        word: 'chat-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-star-semi-medium',
    className: 'custom-icon-chat-star-semi-medium',
    keywords: [
      {
        word: 'chat-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-trend-arrow-medium',
    className: 'custom-icon-chat-trend-arrow-medium',
    keywords: [
      {
        word: 'chat-trend-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-user-semi-medium',
    className: 'custom-icon-chat-user-semi-medium',
    keywords: [
      {
        word: 'chat-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-with-gear-semi-medium',
    className: 'custom-icon-chat-with-gear-semi-medium',
    keywords: [
      {
        word: 'chat-with-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-with-star-semi-medium',
    className: 'custom-icon-chat-with-star-semi-medium',
    keywords: [
      {
        word: 'chat-with-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-with-trend-arrow-medium',
    className: 'custom-icon-chat-with-trend-arrow-medium',
    keywords: [
      {
        word: 'chat-with-trend-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-settings-semi-medium',
    className: 'custom-icon-cloud-settings-semi-medium',
    keywords: [
      {
        word: 'cloud-settings-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'email-sent',
    className: 'custom-icon-email-sent',
    keywords: [
      {
        word: 'email-sent',
        weight: 5,
      },
    ],
  },
  {
    name: 'eye-bold',
    className: 'custom-icon-eye-bold',
    keywords: [
      {
        word: 'eye-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-bar-chart-semi-medium',
    className: 'custom-icon-file-bar-chart-semi-medium',
    keywords: [
      {
        word: 'file-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-cloud-semi-medium',
    className: 'custom-icon-file-cloud-semi-medium',
    keywords: [
      {
        word: 'file-cloud-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-cross-semi-medium',
    className: 'custom-icon-file-cross-semi-medium',
    keywords: [
      {
        word: 'file-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-history-medium',
    className: 'custom-icon-file-history-medium',
    keywords: [
      {
        word: 'file-history-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-malware-semi-medium',
    className: 'custom-icon-file-malware-semi-medium',
    keywords: [
      {
        word: 'file-malware-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'plain-file-medium',
    className: 'custom-icon-plain-file-medium',
    keywords: [
      {
        word: 'plain-file-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-pulse-semi-medium',
    className: 'custom-icon-file-pulse-semi-medium',
    keywords: [
      {
        word: 'file-pulse-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-user-semi-medium',
    className: 'custom-icon-file-user-semi-medium',
    keywords: [
      {
        word: 'file-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'filewith-malware-semi-medium',
    className: 'custom-icon-filewith-malware-semi-medium',
    keywords: [
      {
        word: 'filewith-malware-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-bar-graph-semi-medium',
    className: 'custom-icon-folder-bar-graph-semi-medium',
    keywords: [
      {
        word: 'folder-bar-graph-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-cloud-semi-medium',
    className: 'custom-icon-folder-cloud-semi-medium',
    keywords: [
      {
        word: 'folder-cloud-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-cross-semi-medium',
    className: 'custom-icon-folder-cross-semi-medium',
    keywords: [
      {
        word: 'folder-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-lens-medium',
    className: 'custom-icon-folder-lens-medium',
    keywords: [
      {
        word: 'folder-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-medium',
    className: 'custom-icon-folder-medium',
    keywords: [
      {
        word: 'folder-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-user-semi-medium',
    className: 'custom-icon-folder-user-semi-medium',
    keywords: [
      {
        word: 'folder-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-wave-semi-medium',
    className: 'custom-icon-folder-wave-semi-medium',
    keywords: [
      {
        word: 'folder-wave-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-lens-medium',
    className: 'custom-icon-group-lens-medium',
    keywords: [
      {
        word: 'group-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-double-side-arrow-medium',
    className: 'custom-icon-group-double-side-arrow-medium',
    keywords: [
      {
        word: 'group-double-side-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-checkmark-semi-medium',
    className: 'custom-icon-group-checkmark-semi-medium',
    keywords: [
      {
        word: 'group-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-clock-semi-medium',
    className: 'custom-icon-globe-clock-semi-medium',
    keywords: [
      {
        word: 'globe-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-pie-chart-semi-medium',
    className: 'custom-icon-globe-pie-chart-semi-medium',
    keywords: [
      {
        word: 'globe-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-chat-semi-medium',
    className: 'custom-icon-group-chat-semi-medium',
    keywords: [
      {
        word: 'group-chat-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-eye-semi-medium',
    className: 'custom-icon-group-eye-semi-medium',
    keywords: [
      {
        word: 'group-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-star-semi-medium',
    className: 'custom-icon-group-star-semi-medium',
    keywords: [
      {
        word: 'group-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-right-arrow-bold',
    className: 'custom-icon-group-right-arrow-bold',
    keywords: [
      {
        word: 'group-right-arrow-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-checkmark-semi-medium',
    className: 'custom-icon-message-checkmark-semi-medium',
    keywords: [
      {
        word: 'message-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-paper-plane-semi-medium',
    className: 'custom-icon-message-paper-plane-semi-medium',
    keywords: [
      {
        word: 'message-paper-plane-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-pie-chart-semi-medium',
    className: 'custom-icon-message-pie-chart-semi-medium',
    keywords: [
      {
        word: 'message-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-semi-medium',
    className: 'custom-icon-message-semi-medium',
    keywords: [
      {
        word: 'message-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-star-semi-medium',
    className: 'custom-icon-message-star-semi-medium',
    keywords: [
      {
        word: 'message-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-wave-semi-medium',
    className: 'custom-icon-message-wave-semi-medium',
    keywords: [
      {
        word: 'message-wave-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'received-externally',
    className: 'custom-icon-received-externally',
    keywords: [
      {
        word: 'received-externally',
        weight: 5,
      },
    ],
  },
  {
    name: 'received-internally',
    className: 'custom-icon-received-internally',
    keywords: [
      {
        word: 'received-internally',
        weight: 5,
      },
    ],
  },
  {
    name: 'rss-feed',
    className: 'custom-icon-rss-feed',
    keywords: [
      {
        word: 'rss-feed',
        weight: 5,
      },
    ],
  },
  {
    name: 'sent-internally',
    className: 'custom-icon-sent-internally',
    keywords: [
      {
        word: 'sent-internally',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-tab-gear-semi-medium',
    className: 'custom-icon-site-tab-gear-semi-medium',
    keywords: [
      {
        word: 'site-tab-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'subscribed-email',
    className: 'custom-icon-subscribed-email',
    keywords: [
      {
        word: 'subscribed-email',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-clock-semi-medium',
    className: 'custom-icon-teams-clock-semi-medium',
    keywords: [
      {
        word: 'teams-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-eye-semi-medium',
    className: 'custom-icon-teams-eye-semi-medium',
    keywords: [
      {
        word: 'teams-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-settings-semi-medium',
    className: 'custom-icon-teams-settings-semi-medium',
    keywords: [
      {
        word: 'teams-settings-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-wave-semi-medium',
    className: 'custom-icon-teams-wave-semi-medium',
    keywords: [
      {
        word: 'teams-wave-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-right-arrow-semi-bold',
    className: 'custom-icon-user-right-arrow-semi-bold',
    keywords: [
      {
        word: 'user-right-arrow-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-up-arrow-semi-bold',
    className: 'custom-icon-user-up-arrow-semi-bold',
    keywords: [
      {
        word: 'user-up-arrow-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-warning-semi-bold',
    className: 'custom-icon-user-warning-semi-bold',
    keywords: [
      {
        word: 'user-warning-semi-bold',
        weight: 5,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'warning',
        weight: 2,
      },
      {
        word: 'spam',
        weight: 1,
      },
      {
        word: 'alert',
        weight: 1,
      },
      {
        word: 'semi bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-with-lock-open-bold',
    className: 'custom-icon-user-with-lock-open-bold',
    keywords: [
      {
        word: 'user-with-lock-open-bold',
        weight: 5,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'open lock',
        weight: 2,
      },
      {
        word: 'lock',
        weight: 1,
      },
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'open',
        weight: 5,
      },
    ],
  },
  {
    name: 'video-bar-chart-semi-medium',
    className: 'custom-icon-video-bar-chart-semi-medium',
    keywords: [
      {
        word: 'video-bar-chart-semi-medium',
        weight: 5,
      },
      {
        word: 'video',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'bar',
        weight: 1,
      },
      {
        word: 'chart',
        weight: 1,
      },
    ],
  },
  {
    name: 'video-call-semi-medium',
    className: 'custom-icon-video-call-semi-medium',
    keywords: [
      {
        word: 'video-call-semi-medium',
        weight: 5,
      },
      {
        word: 'video',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'call',
        weight: 1,
      },
    ],
  },
  {
    name: 'video-group-semi-medium',
    className: 'custom-icon-video-group-semi-medium',
    keywords: [
      {
        word: 'video-group-semi-medium',
        weight: 5,
      },
      {
        word: 'video',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'group',
        weight: 1,
      },
    ],
  },
  {
    name: 'video-user-semi-medium',
    className: 'custom-icon-video-user-semi-medium',
    keywords: [
      {
        word: 'video-user-semi-medium',
        weight: 5,
      },
      {
        word: 'video',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'user',
        weight: 1,
      },
    ],
  },
  {
    name: 'app-user-cross-medium',
    className: 'custom-icon-app-user-cross-medium',
    keywords: [
      {
        word: 'app-user-cross-medium',
        weight: 5,
      },
      {
        word: 'app',
        weight: 1,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'cross',
        weight: 5,
      },
      {
        word: 'medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'bell-alert-semi-medium',
    className: 'custom-icon-bell-alert-semi-medium',
    keywords: [
      {
        word: 'bell-alert-semi-medium',
        weight: 5,
      },
      {
        word: 'bell',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'alert',
        weight: 1,
      },
      {
        word: 'notification',
        weight: 2,
      },
      {
        word: 'warning',
        weight: 2,
      },
    ],
  },
  {
    name: 'bell-spark-semi-medium',
    className: 'custom-icon-bell-spark-semi-medium',
    keywords: [
      {
        word: 'bell-spark-semi-medium',
        weight: 5,
      },
      {
        word: 'bell',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'spark',
        weight: 1,
      },
      {
        word: 'notification',
        weight: 2,
      },
      {
        word: 'bolt',
        weight: 2,
      },
    ],
  },
  {
    name: 'calendar-checkmark-semi-medium',
    className: 'custom-icon-calendar-checkmark-semi-medium',
    keywords: [
      {
        word: 'calendar-checkmark-semi-medium',
        weight: 5,
      },
      {
        word: 'Calendar',
        weight: 1,
      },
      {
        word: 'checkmark',
        weight: 2,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-folder-semi-medium',
    className: 'custom-icon-calendar-folder-semi-medium',
    keywords: [
      {
        word: 'calendar-folder-semi-medium',
        weight: 5,
      },
      {
        word: 'calendar',
        weight: 1,
      },
      {
        word: 'folder',
        weight: 2,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-mail-semi-medium',
    className: 'custom-icon-calendar-mail-semi-medium',
    keywords: [
      {
        word: 'calendar-mail-semi-medium',
        weight: 5,
      },
      {
        word: 'calendar',
        weight: 1,
      },
      {
        word: 'mail',
        weight: 2,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-click-semi-medium',
    className: 'custom-icon-doc-click-semi-medium',
    keywords: [
      {
        word: 'doc-click-semi-medium',
        weight: 5,
      },
      {
        word: 'document',
        weight: 1,
      },
      {
        word: 'click',
        weight: 2,
      },
      {
        word: 'cursor',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-clock-semi-medium',
    className: 'custom-icon-doc-clock-semi-medium',
    keywords: [
      {
        word: 'doc-clock-semi-medium',
        weight: 5,
      },
      {
        word: 'document',
        weight: 1,
      },
      {
        word: 'clock',
        weight: 2,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-spark-semi-medium',
    className: 'custom-icon-doc-spark-semi-medium',
    keywords: [
      {
        word: 'doc-spark-semi-medium',
        weight: 5,
      },
      {
        word: 'document',
        weight: 1,
      },
      {
        word: 'spark',
        weight: 2,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'bolt',
        weight: 1,
      },
    ],
  },
  {
    name: 'doc-user-semi-medium',
    className: 'custom-icon-doc-user-semi-medium',
    keywords: [
      {
        word: 'doc-user-semi-medium',
        weight: 5,
      },
      {
        word: 'document',
        weight: 1,
      },
      {
        word: 'user',
        weight: 2,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-warning-semi-medium',
    className: 'custom-icon-doc-warning-semi-medium',
    keywords: [
      {
        word: 'doc-warning-semi-medium',
        weight: 5,
      },
      {
        word: 'alert',
        weight: 1,
      },
      {
        word: 'document',
        weight: 1,
      },
      {
        word: 'warning',
        weight: 2,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-bell-semi-medium',
    className: 'custom-icon-user-bell-semi-medium',
    keywords: [
      {
        word: 'user-bell-semi-medium',
        weight: 5,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'bell',
        weight: 3,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'notification',
        weight: 4,
      },
      {
        word: 'alert',
        weight: 1,
      },
      {
        word: 'warning',
        weight: 3,
      },
    ],
  },
  {
    name: 'globe-user-cross-medium',
    className: 'custom-icon-globe-user-cross-medium',
    keywords: [
      {
        word: 'globe-user-cross-medium',
        weight: 5,
      },
      {
        word: 'globe',
        weight: 1,
      },
      {
        word: 'user',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'cross',
        weight: 4,
      },
    ],
  },
  {
    name: 'group-activity-semi-medium',
    className: 'custom-icon-group-activity-semi-medium',
    keywords: [
      {
        word: 'group-activity-semi-medium',
        weight: 5,
      },
      {
        word: 'group',
        weight: 1,
      },
      {
        word: 'activity',
        weight: 3,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'wave',
        weight: 4,
      },
      {
        word: 'pulse',
        weight: 3,
      },
    ],
  },
  {
    name: 'group-clock-semi-medium',
    className: 'custom-icon-group-clock-semi-medium',
    keywords: [
      {
        word: 'group-clock-semi-medium',
        weight: 5,
      },
      {
        word: 'group',
        weight: 1,
      },
      {
        word: 'clock',
        weight: 3,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'history',
        weight: 4,
      },
    ],
  },
  {
    name: 'group-timer-medium',
    className: 'custom-icon-group-timer-medium',
    keywords: [
      {
        word: 'group-timer-medium',
        weight: 5,
      },
      {
        word: 'group',
        weight: 1,
      },
      {
        word: 'timer',
        weight: 3,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'activity',
        weight: 4,
      },
      {
        word: 'history',
        weight: 3,
      },
    ],
  },
  {
    name: 'key-solid',
    className: 'custom-icon-key-solid',
    keywords: [
      {
        word: 'key-solid',
        weight: 5,
      },
      {
        word: 'key',
        weight: 1,
      },
      {
        word: 'password',
        weight: 3,
      },
      {
        word: 'solid',
        weight: 5,
      },
      {
        word: 'login',
        weight: 4,
      },
    ],
  },
  {
    name: 'platform-user-cross-medium',
    className: 'custom-icon-platform-user-cross-medium',
    keywords: [
      {
        word: 'platform-user-cross-medium',
        weight: 5,
      },
      {
        word: 'cross',
        weight: 3,
      },
      {
        word: 'user',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'platform',
        weight: 1,
      },
    ],
  },
  {
    name: 'policy-tag-semi-medium',
    className: 'custom-icon-policy-tag-semi-medium',
    keywords: [
      {
        word: 'policy-tag-semi-medium',
        weight: 5,
      },
      {
        word: 'policy',
        weight: 1,
      },
      {
        word: 'notepad',
        weight: 4,
      },
      {
        word: 'checklist',
        weight: 1,
      },
      {
        word: 'tag',
        weight: 3,
      },
      {
        word: 'semi-medium',
        weight: 5,
      },
      {
        word: 'reportpad',
        weight: 4,
      },
    ],
  },
  {
    name: 'subscription-pie-chart-semi-medium',
    className: 'custom-icon-subscription-pie-chart-semi-medium',
    keywords: [
      {
        word: 'subscription-pie-chart-semi-medium',
        weight: 5,
      },
      {
        word: 'subscriptions',
        weight: 1,
      },
      {
        word: 'pie-chart',
        weight: 2,
      },
      {
        word: 'usage',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 4,
      },
    ],
  },
  {
    name: 'teams-checkmark-semi-medium',
    className: 'custom-icon-teams-checkmark-semi-medium',
    keywords: [
      {
        word: 'teams-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-checkmark-semi-medium',
    className: 'custom-icon-user-checkmark-semi-medium',
    keywords: [
      {
        word: 'user-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'warning-doc-semi-medium',
    className: 'custom-icon-warning-doc-semi-medium',
    keywords: [
      {
        word: 'warning-doc-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'alert-medium',
    className: 'custom-icon-alert-medium',
    keywords: [
      {
        word: 'alert-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-activity-medium',
    className: 'custom-icon-app-activity-medium',
    keywords: [
      {
        word: 'app-activity-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-cross-semi-medium',
    className: 'custom-icon-app-cross-semi-medium',
    keywords: [
      {
        word: 'app-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-medium',
    className: 'custom-icon-app-medium',
    keywords: [
      {
        word: 'app-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-pie-chart-semi-medium',
    className: 'custom-icon-app-pie-chart-semi-medium',
    keywords: [
      {
        word: 'app-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-platform-medium',
    className: 'custom-icon-app-platform-medium',
    keywords: [
      {
        word: 'app-platform-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'award-medium',
    className: 'custom-icon-award-medium',
    keywords: [
      {
        word: 'award-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'bin-restore-medium',
    className: 'custom-icon-bin-restore-medium',
    keywords: [
      {
        word: 'bin-restore-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-line-medium',
    className: 'custom-icon-calendar-line-medium',
    keywords: [
      {
        word: 'calendar-line-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-platform-medium',
    className: 'custom-icon-calendar-platform-medium',
    keywords: [
      {
        word: 'calendar-platform-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-pie-chart-semi-medium-1',
    className: 'custom-icon-desktop-pie-chart-semi-medium-1',
    keywords: [
      {
        word: 'desktop-pie-chart-semi-medium-1',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-pie-chart-semi-medium',
    className: 'custom-icon-desktop-pie-chart-semi-medium',
    keywords: [
      {
        word: 'desktop-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'external-user-medium',
    className: 'custom-icon-external-user-medium',
    keywords: [
      {
        word: 'external-user-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-forward-semi-medium',
    className: 'custom-icon-folder-forward-semi-medium',
    keywords: [
      {
        word: 'folder-forward-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-link-medium',
    className: 'custom-icon-folder-link-medium',
    keywords: [
      {
        word: 'folder-link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-lock-semi-medium',
    className: 'custom-icon-folder-lock-semi-medium',
    keywords: [
      {
        word: 'folder-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-file-medium',
    className: 'custom-icon-folder-file-medium',
    keywords: [
      {
        word: 'folder-file-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-share-semi-medium',
    className: 'custom-icon-folder-share-semi-medium',
    keywords: [
      {
        word: 'folder-share-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-folder-semi-medium',
    className: 'custom-icon-gear-user-folder-semi-medium',
    keywords: [
      {
        word: 'gear-user-folder-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-info-semi-medium',
    className: 'custom-icon-gear-user-info-semi-medium',
    keywords: [
      {
        word: 'gear-user-info-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-key-semi-medium',
    className: 'custom-icon-gear-user-key-semi-medium',
    keywords: [
      {
        word: 'gear-user-key-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-mail-semi-medium',
    className: 'custom-icon-gear-user-mail-semi-medium',
    keywords: [
      {
        word: 'gear-user-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-plus-semi-medium',
    className: 'custom-icon-gear-user-plus-semi-medium',
    keywords: [
      {
        word: 'gear-user-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-eye-semi-medium',
    className: 'custom-icon-globe-eye-semi-medium',
    keywords: [
      {
        word: 'globe-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-location-marker-semi-medium',
    className: 'custom-icon-globe-location-marker-semi-medium',
    keywords: [
      {
        word: 'globe-location-marker-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-star-semi-medium',
    className: 'custom-icon-globe-star-semi-medium',
    keywords: [
      {
        word: 'globe-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'law-medium',
    className: 'custom-icon-law-medium',
    keywords: [
      {
        word: 'law-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-share-semi-medium',
    className: 'custom-icon-lens-share-semi-medium',
    keywords: [
      {
        word: 'lens-share-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'license-gear-semi-medium',
    className: 'custom-icon-license-gear-semi-medium',
    keywords: [
      {
        word: 'license-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'licenses-medium',
    className: 'custom-icon-licenses-medium',
    keywords: [
      {
        word: 'licenses-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-eye-medium',
    className: 'custom-icon-link-eye-medium',
    keywords: [
      {
        word: 'link-eye-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-link-medium',
    className: 'custom-icon-lens-link-medium',
    keywords: [
      {
        word: 'lens-link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-ques-semi-medium',
    className: 'custom-icon-lock-ques-semi-medium',
    keywords: [
      {
        word: 'lock-ques-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-forward-medium',
    className: 'custom-icon-lens-forward-medium',
    keywords: [
      {
        word: 'lens-forward-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-share-semi-medium',
    className: 'custom-icon-mail-share-semi-medium',
    keywords: [
      {
        word: 'mail-share-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mfa-semi-medium',
    className: 'custom-icon-mfa-semi-medium',
    keywords: [
      {
        word: 'mfa-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-cross-semi-bold',
    className: 'custom-icon-site-cross-semi-bold',
    keywords: [
      {
        word: 'site-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-database-semi-medium',
    className: 'custom-icon-site-database-semi-medium',
    keywords: [
      {
        word: 'site-database-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-plus-semi-bold',
    className: 'custom-icon-site-plus-semi-bold',
    keywords: [
      {
        word: 'site-plus-semi-bold',
        weight: 5,
      },
      {
        word: 'site',
        weight: 1,
      },
      {
        word: 'semi-bold',
        weight: 4,
      },
      {
        word: 'plus',
        weight: 1,
      },
      {
        word: 'add',
        weight: 4,
      },
      {
        word: 'create',
        weight: 1,
      },
    ],
  },
  {
    name: 'site-connection-medium',
    className: 'custom-icon-site-connection-medium',
    keywords: [
      {
        word: 'site-connection-medium',
        weight: 5,
      },
      {
        word: 'site',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 4,
      },
      {
        word: 'location',
        weight: 1,
      },
      {
        word: 'marker',
        weight: 4,
      },
      {
        word: 'pin',
        weight: 1,
      },
      {
        word: 'tab',
        weight: 4,
      },
    ],
  },
  {
    name: 'site-connection-semi-bold',
    className: 'custom-icon-site-connection-semi-bold',
    keywords: [
      {
        word: 'site-connection-semi-bold',
        weight: 5,
      },
      {
        word: 'site',
        weight: 1,
      },
      {
        word: 'semi-bold',
        weight: 4,
      },
      {
        word: 'connection',
        weight: 1,
      },
      {
        word: 'gear',
        weight: 4,
      },
      {
        word: 'transfer',
        weight: 1,
      },
      {
        word: 'tab',
        weight: 4,
      },
    ],
  },
  {
    name: 'site-tab-database-semi-medium',
    className: 'custom-icon-site-tab-database-semi-medium',
    keywords: [
      {
        word: 'site-tab-database-semi-medium',
        weight: 5,
      },
      {
        word: 'site',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 4,
      },
      {
        word: 'database',
        weight: 1,
      },
      {
        word: 'storage',
        weight: 4,
      },
      {
        word: 'db',
        weight: 1,
      },
      {
        word: 'tab',
        weight: 4,
      },
    ],
  },
  {
    name: 'site-lens-medium',
    className: 'custom-icon-site-lens-medium',
    keywords: [
      {
        word: 'site-lens-medium',
        weight: 5,
      },
      {
        word: 'site',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 4,
      },
      {
        word: 'lens',
        weight: 1,
      },
      {
        word: 'magnifying glass',
        weight: 4,
      },
      {
        word: 'search',
        weight: 1,
      },
      {
        word: 'tab',
        weight: 4,
      },
    ],
  },
  {
    name: 'site-location-semi-medium',
    className: 'custom-icon-site-location-semi-medium',
    keywords: [
      {
        word: 'site-location-semi-medium',
        weight: 5,
      },
      {
        word: 'site',
        weight: 1,
      },
      {
        word: 'semi-medium',
        weight: 4,
      },
      {
        word: 'location',
        weight: 1,
      },
      {
        word: 'marker',
        weight: 4,
      },
      {
        word: 'pin',
        weight: 1,
      },
      {
        word: 'tab',
        weight: 4,
      },
    ],
  },
  {
    name: 'stats-medium',
    className: 'custom-icon-stats-medium',
    keywords: [
      {
        word: 'stats-medium',
        weight: 5,
      },
      {
        word: 'statistics',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 4,
      },
    ],
  },
  {
    name: 'subscription1-medium',
    className: 'custom-icon-subscription1-medium',
    keywords: [
      {
        word: 'subscription1-medium',
        weight: 5,
      },
      {
        word: 'subscription1',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 4,
      },
    ],
  },
  {
    name: 'tags-medium',
    className: 'custom-icon-tags-medium',
    keywords: [
      {
        word: 'tags-medium',
        weight: 5,
      },
      {
        word: 'tags',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 4,
      },
    ],
  },
  {
    name: 'traffic-medium',
    className: 'custom-icon-traffic-medium',
    keywords: [
      {
        word: 'traffic-medium',
        weight: 5,
      },
      {
        word: 'traffic signal',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 4,
      },
    ],
  },
  {
    name: 'traffic-solid',
    className: 'custom-icon-traffic-solid',
    keywords: [
      {
        word: 'traffic-solid',
        weight: 5,
      },
      {
        word: 'traffic signal',
        weight: 1,
      },
      {
        word: 'solid',
        weight: 4,
      },
    ],
  },
  {
    name: 'wave-medium',
    className: 'custom-icon-wave-medium',
    keywords: [
      {
        word: 'wave-medium',
        weight: 5,
      },
      {
        word: 'wave',
        weight: 1,
      },
      {
        word: 'activity',
        weight: 2,
      },
      {
        word: 'pulse',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 4,
      },
    ],
  },
  {
    name: 'chat-extrabold',
    className: 'custom-icon-chat-extrabold',
    keywords: [
      {
        word: 'chat-extrabold',
        weight: 5,
      },
    ],
  },
  {
    name: 'code-extrabold',
    className: 'custom-icon-code-extrabold',
    keywords: [
      {
        word: 'code-extrabold',
        weight: 5,
      },
    ],
  },
  {
    name: 'comment-extrabold',
    className: 'custom-icon-comment-extrabold',
    keywords: [
      {
        word: 'comment-extrabold',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-gear-semibold',
    className: 'custom-icon-database-gear-semibold',
    keywords: [
      {
        word: 'database-gear-semibold',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-lens-bold',
    className: 'custom-icon-database-lens-bold',
    keywords: [
      {
        word: 'database-lens-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'shield-gear-semibold',
    className: 'custom-icon-shield-gear-semibold',
    keywords: [
      {
        word: 'shield-gear-semibold',
        weight: 5,
      },
    ],
  },
  {
    name: 'extrabold',
    className: 'custom-icon-extrabold',
    keywords: [
      {
        word: 'extrabold',
        weight: 5,
      },
    ],
  },
  {
    name: 'eye-extrabold',
    className: 'custom-icon-eye-extrabold',
    keywords: [
      {
        word: 'eye-extrabold',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-lens-semibold',
    className: 'custom-icon-folder-lens-semibold',
    keywords: [
      {
        word: 'folder-lens-semibold',
        weight: 5,
      },
    ],
  },
  {
    name: 'Gear-checkmark-semi-bold',
    className: 'custom-icon-Gear-checkmark-semi-bold',
    keywords: [
      {
        word: 'Gear-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-extrabold',
    className: 'custom-icon-message-extrabold',
    keywords: [
      {
        word: 'message-extrabold',
        weight: 5,
      },
    ],
  },
  {
    name: 'plus-extrabold',
    className: 'custom-icon-plus-extrabold',
    keywords: [
      {
        word: 'plus-extrabold',
        weight: 5,
      },
    ],
  },
  {
    name: 'smile-extrabold',
    className: 'custom-icon-smile-extrabold',
    keywords: [
      {
        word: 'smile-extrabold',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-lens-bold',
    className: 'custom-icon-app-lens-bold',
    keywords: [
      {
        word: 'app-lens-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-user-semi-bold',
    className: 'custom-icon-app-user-semi-bold',
    keywords: [
      {
        word: 'app-user-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-gear-semi-bold',
    className: 'custom-icon-cloud-gear-semi-bold',
    keywords: [
      {
        word: 'cloud-gear-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-gears-semi-bold',
    className: 'custom-icon-cloud-gears-semi-bold',
    keywords: [
      {
        word: 'cloud-gears-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'connect-semi-bold',
    className: 'custom-icon-connect-semi-bold',
    keywords: [
      {
        word: 'connect-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'license-solid',
    className: 'custom-icon-license-solid',
    keywords: [
      {
        word: 'license-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mailbox-refresh-semi-solid',
    className: 'custom-icon-mailbox-refresh-semi-solid',
    keywords: [
      {
        word: 'mailbox-refresh-semi-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mailbox-send-semi-solid',
    className: 'custom-icon-mailbox-send-semi-solid',
    keywords: [
      {
        word: 'mailbox-send-semi-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-email-semi-solid',
    className: 'custom-icon-mail-email-semi-solid',
    keywords: [
      {
        word: 'mail-email-semi-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'toggle-checkmark-semi-bold',
    className: 'custom-icon-toggle-checkmark-semi-bold',
    keywords: [
      {
        word: 'toggle-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'toggle-ques-semi-bold',
    className: 'custom-icon-toggle-ques-semi-bold',
    keywords: [
      {
        word: 'toggle-ques-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-group-semi-medium',
    className: 'custom-icon-calendar-group-semi-medium',
    keywords: [
      {
        word: 'calendar-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-share-arrow',
    className: 'custom-icon-cloud-share-arrow',
    keywords: [
      {
        word: 'cloud-share-arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-server-bold',
    className: 'custom-icon-desktop-server-bold',
    keywords: [
      {
        word: 'desktop-server-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-classification-semi-medium',
    className: 'custom-icon-file-classification-semi-medium',
    keywords: [
      {
        word: 'file-classification-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-external-share-medium',
    className: 'custom-icon-file-external-share-medium',
    keywords: [
      {
        word: 'file-external-share-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-shield-semi-medium',
    className: 'custom-icon-file-shield-semi-medium',
    keywords: [
      {
        word: 'file-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-classification-semi-medium',
    className: 'custom-icon-folder-classification-semi-medium',
    keywords: [
      {
        word: 'folder-classification-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-external-share-medium',
    className: 'custom-icon-folder-external-share-medium',
    keywords: [
      {
        word: 'folder-external-share-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-key-semi-medium',
    className: 'custom-icon-file-key-semi-medium',
    keywords: [
      {
        word: 'file-key-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'key-pie-chart-semi-medium',
    className: 'custom-icon-key-pie-chart-semi-medium',
    keywords: [
      {
        word: 'key-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-external-share-medium',
    className: 'custom-icon-link-external-share-medium',
    keywords: [
      {
        word: 'link-external-share-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-shield-semi-medium',
    className: 'custom-icon-link-shield-semi-medium',
    keywords: [
      {
        word: 'link-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-invite-share-medium',
    className: 'custom-icon-mail-invite-share-medium',
    keywords: [
      {
        word: 'mail-invite-share-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'server-user-semi-bold',
    className: 'custom-icon-server-user-semi-bold',
    keywords: [
      {
        word: 'server-user-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-user',
    className: 'custom-icon-site-user',
    keywords: [
      {
        word: 'site-user',
        weight: 5,
      },
    ],
  },
  {
    name: 'smile-lens-medium',
    className: 'custom-icon-smile-lens-medium',
    keywords: [
      {
        word: 'smile-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-share-semi-medium',
    className: 'custom-icon-user-share-semi-medium',
    keywords: [
      {
        word: 'user-share-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-request-mail-medium',
    className: 'custom-icon-user-request-mail-medium',
    keywords: [
      {
        word: 'user-request-mail-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-checkmark-semi-medium',
    className: 'custom-icon-app-checkmark-semi-medium',
    keywords: [
      {
        word: 'app-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-spark-semi-medium',
    className: 'custom-icon-globe-spark-semi-medium',
    keywords: [
      {
        word: 'app-checkmark-semi-medium-1',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-eye-semi-medium',
    className: 'custom-icon-app-eye-semi-medium',
    keywords: [
      {
        word: 'app-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-lens-medium',
    className: 'custom-icon-app-lens-medium',
    keywords: [
      {
        word: 'app-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-shield-checkmark-semi-medium',
    className: 'custom-icon-app-shield-checkmark-semi-medium',
    keywords: [
      {
        word: 'app-shield-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'bin-bar-chart-semi-medium',
    className: 'custom-icon-bin-bar-chart-semi-medium',
    keywords: [
      {
        word: 'bin-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-cross-semi-medium',
    className: 'custom-icon-cloud-cross-semi-medium',
    keywords: [
      {
        word: 'cloud-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-lens-semi-medium',
    className: 'custom-icon-cloud-lens-semi-medium',
    keywords: [
      {
        word: 'cloud-lens-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-downward-arrow-semi-medium',
    className: 'custom-icon-database-downward-arrow-semi-medium',
    keywords: [
      {
        word: 'database-downward-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-external-arrow-medium',
    className: 'custom-icon-database-external-arrow-medium',
    keywords: [
      {
        word: 'database-external-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-gear-semi-medium',
    className: 'custom-icon-database-gear-semi-medium',
    keywords: [
      {
        word: 'database-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-lens-semi-medium',
    className: 'custom-icon-database-lens-semi-medium',
    keywords: [
      {
        word: 'database-lens-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-user-semi-medium',
    className: 'custom-icon-database-user-semi-medium',
    keywords: [
      {
        word: 'database-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-exclamation-medium',
    className: 'custom-icon-desktop-exclamation-medium',
    keywords: [
      {
        word: 'desktop-exclamation-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-lens-medium',
    className: 'custom-icon-desktop-lens-medium',
    keywords: [
      {
        word: 'desktop-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-refresh-medium',
    className: 'custom-icon-desktop-refresh-medium',
    keywords: [
      {
        word: 'desktop-refresh-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-solid-user-semi-medium',
    className: 'custom-icon-desktop-solid-user-semi-medium',
    keywords: [
      {
        word: 'desktop-solid-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-bar-chart-semi-medium',
    className: 'custom-icon-doc-bar-chart-semi-medium',
    keywords: [
      {
        word: 'doc-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-cloud-semi-medium',
    className: 'custom-icon-doc-cloud-semi-medium',
    keywords: [
      {
        word: 'doc-cloud-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-gear-semi-medium',
    className: 'custom-icon-doc-gear-semi-medium',
    keywords: [
      {
        word: 'doc-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-group-semi-medium',
    className: 'custom-icon-doc-group-semi-medium',
    keywords: [
      {
        word: 'doc-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-key-medium',
    className: 'custom-icon-doc-key-medium',
    keywords: [
      {
        word: 'doc-key-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-lens-medium',
    className: 'custom-icon-doc-lens-medium',
    keywords: [
      {
        word: 'doc-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-pie-chart-semi-medium',
    className: 'custom-icon-doc-pie-chart-semi-medium',
    keywords: [
      {
        word: 'doc-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-checkmark-semi-medium',
    className: 'custom-icon-file-checkmark-semi-medium',
    keywords: [
      {
        word: 'file-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-clock-semi-medium',
    className: 'custom-icon-file-clock-semi-medium',
    keywords: [
      {
        word: 'file-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-exclamation-semi-medium',
    className: 'custom-icon-file-exclamation-semi-medium',
    keywords: [
      {
        word: 'file-exclamation-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-eye-semi-medium',
    className: 'custom-icon-file-eye-semi-medium',
    keywords: [
      {
        word: 'file-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-transfer-arrow-semi-medium',
    className: 'custom-icon-file-transfer-arrow-semi-medium',
    keywords: [
      {
        word: 'file-transfer-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'fingerprint-checkmark-semi-medium',
    className: 'custom-icon-fingerprint-checkmark-semi-medium',
    keywords: [
      {
        word: 'fingerprint-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'fingerprint-cross-semi-medium',
    className: 'custom-icon-fingerprint-cross-semi-medium',
    keywords: [
      {
        word: 'fingerprint-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-eye-semi-medium',
    className: 'custom-icon-folder-eye-semi-medium',
    keywords: [
      {
        word: 'folder-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-group-semi-medium',
    className: 'custom-icon-folder-group-semi-medium',
    keywords: [
      {
        word: 'folder-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-shield',
    className: 'custom-icon-folder-shield',
    keywords: [
      {
        word: 'folder-shield',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-warning-semi-medium',
    className: 'custom-icon-folder-warning-semi-medium',
    keywords: [
      {
        word: 'folder-warning-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-cloud-semi-medium',
    className: 'custom-icon-globe-cloud-semi-medium',
    keywords: [
      {
        word: 'globe-cloud-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-lock-semi-medium',
    className: 'custom-icon-globe-lock-semi-medium',
    keywords: [
      {
        word: 'globe-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-shield-checkmark',
    className: 'custom-icon-globe-shield-checkmark',
    keywords: [
      {
        word: 'globe-shield-checkmark',
        weight: 5,
      },
    ],
  },
  {
    name: 'users-gear-semi-medium',
    className: 'custom-icon-users-gear-semi-medium',
    keywords: [
      {
        word: 'users-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-globe-semi-mediun',
    className: 'custom-icon-group-globe-semi-mediun',
    keywords: [
      {
        word: 'group-globe-semi-mediun',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-refresh-medium',
    className: 'custom-icon-group-refresh-medium',
    keywords: [
      {
        word: 'group-refresh-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'id-checkmark-semi-medium',
    className: 'custom-icon-id-checkmark-semi-medium',
    keywords: [
      {
        word: 'id-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'inbox-eye-semi-medium',
    className: 'custom-icon-inbox-eye-semi-medium',
    keywords: [
      {
        word: 'inbox-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'inbox-gear-semi-medium',
    className: 'custom-icon-inbox-gear-semi-medium',
    keywords: [
      {
        word: 'inbox-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'key-checkmark-semi-medium',
    className: 'custom-icon-key-checkmark-semi-medium',
    keywords: [
      {
        word: 'key-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'key-exclamation-semi-medium',
    className: 'custom-icon-key-exclamation-semi-medium',
    keywords: [
      {
        word: 'key-exclamation-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-bar-chart-semi-medium',
    className: 'custom-icon-lens-bar-chart-semi-medium',
    keywords: [
      {
        word: 'lens-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-classification-semi-medium',
    className: 'custom-icon-lens-classification-semi-medium',
    keywords: [
      {
        word: 'lens-classification-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-keyhole-semi-medium',
    className: 'custom-icon-lens-keyhole-semi-medium',
    keywords: [
      {
        word: 'lens-keyhole-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-mail-semi-medium',
    className: 'custom-icon-lens-mail-semi-medium',
    keywords: [
      {
        word: 'lens-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-pie-chart-semi-medium',
    className: 'custom-icon-lens-pie-chart-semi-medium',
    keywords: [
      {
        word: 'lens-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-play-semi-medium',
    className: 'custom-icon-lens-play-semi-medium',
    keywords: [
      {
        word: 'lens-play-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-shield-semi-medium',
    className: 'custom-icon-lens-shield-semi-medium',
    keywords: [
      {
        word: 'lens-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-warning-semi-medium',
    className: 'custom-icon-lens-warning-semi-medium',
    keywords: [
      {
        word: 'lens-warning-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'license-lens-medium',
    className: 'custom-icon-license-lens-medium',
    keywords: [
      {
        word: 'license-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-exclamation-semi-medium',
    className: 'custom-icon-link-exclamation-semi-medium',
    keywords: [
      {
        word: 'link-exclamation-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-clock-semi-medium',
    className: 'custom-icon-lock-clock-semi-medium',
    keywords: [
      {
        word: 'lock-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-cross-semi-medium',
    className: 'custom-icon-lock-cross-semi-medium',
    keywords: [
      {
        word: 'lock-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-down-arrow-semi-medium',
    className: 'custom-icon-lock-down-arrow-semi-medium',
    keywords: [
      {
        word: 'lock-down-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-exclamation-semi-medium',
    className: 'custom-icon-lock-exclamation-semi-medium',
    keywords: [
      {
        word: 'lock-exclamation-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-eye-semi-medium',
    className: 'custom-icon-lock-eye-semi-medium',
    keywords: [
      {
        word: 'lock-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-group-semi-medium',
    className: 'custom-icon-lock-group-semi-medium',
    keywords: [
      {
        word: 'lock-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-lens-medium',
    className: 'custom-icon-lock-lens-medium',
    keywords: [
      {
        word: 'lock-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-play-semi-medium',
    className: 'custom-icon-lock-play-semi-medium',
    keywords: [
      {
        word: 'lock-play-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-refresh-semi-medium',
    className: 'custom-icon-lock-refresh-semi-medium',
    keywords: [
      {
        word: 'lock-refresh-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mailbox-exclamation-semi-medium',
    className: 'custom-icon-mailbox-exclamation-semi-medium',
    keywords: [
      {
        word: 'mailbox-exclamation-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-eye-semi-medium',
    className: 'custom-icon-notepad-eye-semi-medium',
    keywords: [
      {
        word: 'notepad-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-lock-semi-medium',
    className: 'custom-icon-notepad-lock-semi-medium',
    keywords: [
      {
        word: 'notepad-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-shield-semi-medium',
    className: 'custom-icon-notepad-shield-semi-medium',
    keywords: [
      {
        word: 'notepad-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'phone-bar-semi-medium',
    className: 'custom-icon-phone-bar-semi-medium',
    keywords: [
      {
        word: 'phone-bar-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'phone-checkmark-semi-medium',
    className: 'custom-icon-phone-checkmark-semi-medium',
    keywords: [
      {
        word: 'phone-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'phone-eye-semi-medium',
    className: 'custom-icon-phone-eye-semi-medium',
    keywords: [
      {
        word: 'phone-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'phone-shield-semi-medium',
    className: 'custom-icon-phone-shield-semi-medium',
    keywords: [
      {
        word: 'phone-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'phone-user-semi-medium',
    className: 'custom-icon-phone-user-semi-medium',
    keywords: [
      {
        word: 'phone-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-cloud-semi-medium',
    className: 'custom-icon-reportpad-cloud-semi-medium',
    keywords: [
      {
        word: 'reportpad-cloud-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-exclamation',
    className: 'custom-icon-reportpad-exclamation',
    keywords: [
      {
        word: 'reportpad-exclamation',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-group-semi-medium',
    className: 'custom-icon-reportpad-group-semi-medium',
    keywords: [
      {
        word: 'reportpad-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-key-medium',
    className: 'custom-icon-reportpad-key-medium',
    keywords: [
      {
        word: 'reportpad-key-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'server-gear-semi-medium',
    className: 'custom-icon-server-gear-semi-medium',
    keywords: [
      {
        word: 'server-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'subscription-lens-medium',
    className: 'custom-icon-subscription-lens-medium',
    keywords: [
      {
        word: 'subscription-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-lens-medium',
    className: 'custom-icon-teams-lens-medium',
    keywords: [
      {
        word: 'teams-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-refresh-medium',
    className: 'custom-icon-teams-refresh-medium',
    keywords: [
      {
        word: 'teams-refresh-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-bubble-semi-medium',
    className: 'custom-icon-user-bubble-semi-medium',
    keywords: [
      {
        word: 'user-bubble-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-eye-semi-medium',
    className: 'custom-icon-user-eye-semi-medium',
    keywords: [
      {
        word: 'user-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-id-semi-medium',
    className: 'custom-icon-user-id-semi-medium',
    keywords: [
      {
        word: 'user-id-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-shield-exclamation-semi-medium',
    className: 'custom-icon-user-shield-exclamation-semi-medium',
    keywords: [
      {
        word: 'user-shield-exclamation-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'alert-gear-semi-medium',
    className: 'custom-icon-alert-gear-semi-medium',
    keywords: [
      {
        word: 'alert-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-down-arrow-semi-medium',
    className: 'custom-icon-app-down-arrow-semi-medium',
    keywords: [
      {
        word: 'app-down-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-bar-semi-medium',
    className: 'custom-icon-cloud-bar-semi-medium',
    keywords: [
      {
        word: 'cloud-bar-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-checkmark-semi-medium',
    className: 'custom-icon-cloud-checkmark-semi-medium',
    keywords: [
      {
        word: 'cloud-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-clock-semi-medium',
    className: 'custom-icon-cloud-clock-semi-medium',
    keywords: [
      {
        word: 'cloud-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-double-side-arrow-semi-medium',
    className: 'custom-icon-cloud-double-side-arrow-semi-medium',
    keywords: [
      {
        word: 'cloud-double-side-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-restore-semi-medium',
    className: 'custom-icon-cloud-restore-semi-medium',
    keywords: [
      {
        word: 'cloud-restore-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-shield-semi-medium',
    className: 'custom-icon-cloud-shield-semi-medium',
    keywords: [
      {
        word: 'cloud-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-checkmark-semi-medium',
    className: 'custom-icon-database-checkmark-semi-medium',
    keywords: [
      {
        word: 'database-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-cross-semi-medium',
    className: 'custom-icon-database-cross-semi-medium',
    keywords: [
      {
        word: 'database-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-double-arrow-semi-medium',
    className: 'custom-icon-database-double-arrow-semi-medium',
    keywords: [
      {
        word: 'database-double-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-restore-medium',
    className: 'custom-icon-database-restore-medium',
    keywords: [
      {
        word: 'database-restore-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-warning-semi-medium',
    className: 'custom-icon-database-warning-semi-medium',
    keywords: [
      {
        word: 'database-warning-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-alert-semi-medium',
    className: 'custom-icon-desktop-alert-semi-medium',
    keywords: [
      {
        word: 'desktop-alert-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-cloud-semi-medium',
    className: 'custom-icon-desktop-cloud-semi-medium',
    keywords: [
      {
        word: 'desktop-cloud-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-down-arrow-medium',
    className: 'custom-icon-desktop-down-arrow-medium',
    keywords: [
      {
        word: 'desktop-down-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-grip-semi-medium',
    className: 'custom-icon-desktop-grip-semi-medium',
    keywords: [
      {
        word: 'desktop-grip-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-info-semi-medium',
    className: 'custom-icon-desktop-info-semi-medium',
    keywords: [
      {
        word: 'desktop-info-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-edit-semi-medium',
    className: 'custom-icon-file-edit-semi-medium',
    keywords: [
      {
        word: 'file-edit-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-refresh-arrow-semi-medium',
    className: 'custom-icon-file-refresh-arrow-semi-medium',
    keywords: [
      {
        word: 'file-refresh-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-key-semi-medium',
    className: 'custom-icon-folder-key-semi-medium',
    keywords: [
      {
        word: 'folder-key-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-gear-semi-medium',
    className: 'custom-icon-globe-gear-semi-medium',
    keywords: [
      {
        word: 'globe-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-refresh-arrow-semi-medium',
    className: 'custom-icon-globe-refresh-arrow-semi-medium',
    keywords: [
      {
        word: 'globe-refresh-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-cross-semi-medium',
    className: 'custom-icon-group-cross-semi-medium',
    keywords: [
      {
        word: 'group-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-edit-semi-medium',
    className: 'custom-icon-group-edit-semi-medium',
    keywords: [
      {
        word: 'group-edit-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'installation-medium',
    className: 'custom-icon-installation-medium',
    keywords: [
      {
        word: 'installation-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-download-medium',
    className: 'custom-icon-lens-download-medium',
    keywords: [
      {
        word: 'lens-download-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-graph-trend-medium',
    className: 'custom-icon-lens-graph-trend-medium',
    keywords: [
      {
        word: 'lens-graph-trend-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-restore-medium',
    className: 'custom-icon-lens-restore-medium',
    keywords: [
      {
        word: 'lens-restore-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-spark-semi-medium',
    className: 'custom-icon-lens-spark-semi-medium',
    keywords: [
      {
        word: 'lens-spark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-trend-graph-medium',
    className: 'custom-icon-lens-trend-graph-medium',
    keywords: [
      {
        word: 'lens-trend-graph-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-user-semi-medium',
    className: 'custom-icon-lens-user-semi-medium',
    keywords: [
      {
        word: 'lens-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-pad-lock-semi-medium',
    className: 'custom-icon-report-pad-lock-semi-medium',
    keywords: [
      {
        word: 'report-pad-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-database-semi-medium',
    className: 'custom-icon-reportpad-database-semi-medium',
    keywords: [
      {
        word: 'reportpad-database-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-gear-semi-medium',
    className: 'custom-icon-reportpad-gear-semi-medium',
    keywords: [
      {
        word: 'reportpad-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-user-semi-medium',
    className: 'custom-icon-reportpad-user-semi-medium',
    keywords: [
      {
        word: 'reportpad-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'rocket-gear-semi-medium',
    className: 'custom-icon-rocket-gear-semi-medium',
    keywords: [
      {
        word: 'rocket-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'server-checkmark-semi-medium',
    className: 'custom-icon-server-checkmark-semi-medium',
    keywords: [
      {
        word: 'server-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'server-cross-semi-medium',
    className: 'custom-icon-server-cross-semi-medium',
    keywords: [
      {
        word: 'server-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'server-warning-semi-medium',
    className: 'custom-icon-server-warning-semi-medium',
    keywords: [
      {
        word: 'server-warning-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'shield-eye-semi-medium',
    className: 'custom-icon-shield-eye-semi-medium',
    keywords: [
      {
        word: 'shield-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'shield-keyhole-semi-medium',
    className: 'custom-icon-shield-keyhole-semi-medium',
    keywords: [
      {
        word: 'shield-keyhole-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'shield-restore-medium',
    className: 'custom-icon-shield-restore-medium',
    keywords: [
      {
        word: 'shield-restore-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'tools-medium',
    className: 'custom-icon-tools-medium',
    keywords: [
      {
        word: 'tools-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-refresh-arrow-semi-medium',
    className: 'custom-icon-user-refresh-arrow-semi-medium',
    keywords: [
      {
        word: 'user-refresh-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'binocular-medium',
    className: 'custom-icon-binocular-medium',
    keywords: [
      {
        word: 'binocular-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'binocular-semi-medium',
    className: 'custom-icon-binocular-semi-medium',
    keywords: [
      {
        word: 'binocular-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'checklist-plus-semi-medium',
    className: 'custom-icon-checklist-plus-semi-medium',
    keywords: [
      {
        word: 'checklist-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'checkmark-extra-solid',
    className: 'custom-icon-checkmark-extra-solid',
    keywords: [
      {
        word: 'checkmark-extra-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'circular-arrow-checkmark-semi-bold',
    className: 'custom-icon-circular-arrow-checkmark-semi-bold',
    keywords: [
      {
        word: 'circular-arrow-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'circular-arrow-with-checkmark-bold',
    className: 'custom-icon-circular-arrow-with-checkmark-bold',
    keywords: [
      {
        word: 'circular-arrow-with-checkmark-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-checkmark-semi-medium',
    className: 'custom-icon-doc-checkmark-semi-medium',
    keywords: [
      {
        word: 'doc-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-cross-semi-medium',
    className: 'custom-icon-doc-cross-semi-medium',
    keywords: [
      {
        word: 'doc-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-eye-semi-medium',
    className: 'custom-icon-doc-eye-semi-medium',
    keywords: [
      {
        word: 'doc-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-plus-semi-medium',
    className: 'custom-icon-doc-plus-semi-medium',
    keywords: [
      {
        word: 'doc-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-globe-semi-medium',
    className: 'custom-icon-file-globe-semi-medium',
    keywords: [
      {
        word: 'file-globe-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-mail-semi-medium',
    className: 'custom-icon-file-mail-semi-medium',
    keywords: [
      {
        word: 'file-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-ques-semi-medium',
    className: 'custom-icon-file-ques-semi-medium',
    keywords: [
      {
        word: 'file-ques-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-size-arrow-medium',
    className: 'custom-icon-file-size-arrow-medium',
    keywords: [
      {
        word: 'file-size-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-up-arrow-semi-medium',
    className: 'custom-icon-file-up-arrow-semi-medium',
    keywords: [
      {
        word: 'file-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'files-medium',
    className: 'custom-icon-files-medium',
    keywords: [
      {
        word: 'files-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-globe-semi-medium',
    className: 'custom-icon-folder-globe-semi-medium',
    keywords: [
      {
        word: 'folder-globe-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-right-arrow-semi-medium',
    className: 'custom-icon-folder-right-arrow-semi-medium',
    keywords: [
      {
        word: 'folder-right-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-star-semi-medium',
    className: 'custom-icon-folder-star-semi-medium',
    keywords: [
      {
        word: 'folder-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-up-arrow-semi-medium',
    className: 'custom-icon-folder-up-arrow-semi-medium',
    keywords: [
      {
        word: 'folder-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-ques-semi-medium',
    className: 'custom-icon-folder-ques-semi-medium',
    keywords: [
      {
        word: 'folder-ques-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-checkmark-semi-medium',
    className: 'custom-icon-folder-checkmark-semi-medium',
    keywords: [
      {
        word: 'folder-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-pie-chart-semi-medium',
    className: 'custom-icon-folder-pie-chart-semi-medium',
    keywords: [
      {
        word: 'folder-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-arrow-semi-medium',
    className: 'custom-icon-gear-user-arrow-semi-medium',
    keywords: [
      {
        word: 'gear-user-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-checkmark-semi-medium',
    className: 'custom-icon-gear-user-checkmark-semi-medium',
    keywords: [
      {
        word: 'gear-user-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-cross-semi-medium',
    className: 'custom-icon-gear-user-cross-semi-medium',
    keywords: [
      {
        word: 'gear-user-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-eye-cross-semi-medium',
    className: 'custom-icon-globe-eye-cross-semi-medium',
    keywords: [
      {
        word: 'globe-eye-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-internal-arrow',
    className: 'custom-icon-globe-internal-arrow',
    keywords: [
      {
        word: 'globe-internal-arrow',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-pulse-semi-medium',
    className: 'custom-icon-globe-pulse-semi-medium',
    keywords: [
      {
        word: 'globe-pulse-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-trend-arrow-semi-medium',
    className: 'custom-icon-globe-trend-arrow-semi-medium',
    keywords: [
      {
        word: 'globe-trend-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-link-medium',
    className: 'custom-icon-group-link-medium',
    keywords: [
      {
        word: 'group-link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-alert-semi-medium',
    className: 'custom-icon-link-alert-semi-medium',
    keywords: [
      {
        word: 'link-alert-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-cross-semi-medium',
    className: 'custom-icon-link-cross-semi-medium',
    keywords: [
      {
        word: 'link-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-group-semi-medium',
    className: 'custom-icon-link-group-semi-medium',
    keywords: [
      {
        word: 'link-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-key-medium',
    className: 'custom-icon-link-key-medium',
    keywords: [
      {
        word: 'link-key-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-plus-semi-medium',
    className: 'custom-icon-link-plus-semi-medium',
    keywords: [
      {
        word: 'link-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-bar-chart-semi-medium',
    className: 'custom-icon-list-bar-chart-semi-medium',
    keywords: [
      {
        word: 'list-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-forward-semi-medium',
    className: 'custom-icon-list-forward-semi-medium',
    keywords: [
      {
        word: 'list-forward-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-lens-medium',
    className: 'custom-icon-list-lens-medium',
    keywords: [
      {
        word: 'list-lens-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-link-semi-medium',
    className: 'custom-icon-list-link-semi-medium',
    keywords: [
      {
        word: 'list-link-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-mail-semi-medium',
    className: 'custom-icon-list-mail-semi-medium',
    keywords: [
      {
        word: 'list-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-ques-semi-medium',
    className: 'custom-icon-list-ques-semi-medium',
    keywords: [
      {
        word: 'list-ques-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-checkmark-semi-medium',
    className: 'custom-icon-mail-checkmark-semi-medium',
    keywords: [
      {
        word: 'mail-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'roman-list-bold',
    className: 'custom-icon-roman-list-bold',
    keywords: [
      {
        word: 'roman-list-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-bar-chart-semi-medium',
    className: 'custom-icon-site-bar-chart-semi-medium',
    keywords: [
      {
        word: 'site-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-checkmark-semi-mediun',
    className: 'custom-icon-site-checkmark-semi-mediun',
    keywords: [
      {
        word: 'site-checkmark-semi-mediun',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-eye-cross-semi-medium',
    className: 'custom-icon-site-eye-cross-semi-medium',
    keywords: [
      {
        word: 'site-eye-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-eye-semi-medium',
    className: 'custom-icon-site-eye-semi-medium',
    keywords: [
      {
        word: 'site-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-forward-semi-medium',
    className: 'custom-icon-site-forward-semi-medium',
    keywords: [
      {
        word: 'site-forward-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-gear-user-semi-medium',
    className: 'custom-icon-site-gear-user-semi-medium',
    keywords: [
      {
        word: 'site-gear-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-group-semi-medium',
    className: 'custom-icon-site-group-semi-medium',
    keywords: [
      {
        word: 'site-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-history-semi-medium',
    className: 'custom-icon-site-history-semi-medium',
    keywords: [
      {
        word: 'site-history-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-mail-semi-medium',
    className: 'custom-icon-site-mail-semi-medium',
    keywords: [
      {
        word: 'site-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-minus-semi-medium',
    className: 'custom-icon-site-minus-semi-medium',
    keywords: [
      {
        word: 'site-minus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-pulse-semi-medium',
    className: 'custom-icon-site-pulse-semi-medium',
    keywords: [
      {
        word: 'site-pulse-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-question-semi-medium',
    className: 'custom-icon-site-question-semi-medium',
    keywords: [
      {
        word: 'site-question-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-shield-semi-medium',
    className: 'custom-icon-site-shield-semi-medium',
    keywords: [
      {
        word: 'site-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-brush-semi-medium',
    className: 'custom-icon-user-brush-semi-medium',
    keywords: [
      {
        word: 'user-brush-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-folder-semi-medium',
    className: 'custom-icon-user-folder-semi-medium',
    keywords: [
      {
        word: 'user-folder-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-link-medium',
    className: 'custom-icon-user-link-medium',
    keywords: [
      {
        word: 'user-link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-user-semi-medium',
    className: 'custom-icon-mail-user-semi-medium',
    keywords: [
      {
        word: 'mail-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cable-bold',
    className: 'custom-icon-cable-bold',
    keywords: [
      {
        word: 'cable-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'wire-bold',
    className: 'custom-icon-wire-bold',
    keywords: [
      {
        word: 'wire-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mobile-bold',
    className: 'custom-icon-mobile-bold',
    keywords: [
      {
        word: 'mobile-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'wifi-bold',
    className: 'custom-icon-wifi-bold',
    keywords: [
      {
        word: 'wifi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'question-solid',
    className: 'custom-icon-question-solid',
    keywords: [
      {
        word: 'question-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'listpad-semi-medium',
    className: 'custom-icon-listpad-semi-medium',
    keywords: [
      {
        word: 'listpad-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-video-semi-medium',
    className: 'custom-icon-group-video-semi-medium',
    keywords: [
      {
        word: 'group-video-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-data-semi-medium',
    className: 'custom-icon-desktop-data-semi-medium',
    keywords: [
      {
        word: 'desktop-data-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'share-medium',
    className: 'custom-icon-share-medium',
    keywords: [
      {
        word: 'share-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clock-refresh-semi-medium',
    className: 'custom-icon-clock-refresh-semi-medium',
    keywords: [
      {
        word: 'clock-refresh-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-mail-semi-medium',
    className: 'custom-icon-group-mail-semi-medium',
    keywords: [
      {
        word: 'group-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-cross-semi-medium',
    className: 'custom-icon-calendar-cross-semi-medium',
    keywords: [
      {
        word: 'calendar-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-globe-semi-medium',
    className: 'custom-icon-doc-globe-semi-medium',
    keywords: [
      {
        word: 'doc-globe-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'Doc-link-medium',
    className: 'custom-icon-Doc-link-medium',
    keywords: [
      {
        word: 'Doc-link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'growth-chart-semi-medium',
    className: 'custom-icon-growth-chart-semi-medium',
    keywords: [
      {
        word: 'growth-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'drop-chart-semi-medium',
    className: 'custom-icon-drop-chart-semi-medium',
    keywords: [
      {
        word: 'drop-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'eye-medium',
    className: 'custom-icon-eye-medium',
    keywords: [
      {
        word: 'eye-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'eye-cross-semi-medium',
    className: 'custom-icon-eye-cross-semi-medium',
    keywords: [
      {
        word: 'eye-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-group-semi-medium',
    className: 'custom-icon-file-group-semi-medium',
    keywords: [
      {
        word: 'file-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-clock-semi-medium',
    className: 'custom-icon-folder-clock-semi-medium',
    keywords: [
      {
        word: 'folder-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-open-lock-semi-medium',
    className: 'custom-icon-folder-open-lock-semi-medium',
    keywords: [
      {
        word: 'folder-open-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clock-dots-medium',
    className: 'custom-icon-clock-dots-medium',
    keywords: [
      {
        word: 'clock-dots-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'thumbs-down-medium',
    className: 'custom-icon-thumbs-down-medium',
    keywords: [
      {
        word: 'thumbs-down-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'incognitive-semi-medium',
    className: 'custom-icon-incognitive-semi-medium',
    keywords: [
      {
        word: 'incognitive-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'hotspot-semi-medium',
    className: 'custom-icon-hotspot-semi-medium',
    keywords: [
      {
        word: 'hotspot-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'circular-pie-chart-semi-medium',
    className: 'custom-icon-circular-pie-chart-semi-medium',
    keywords: [
      {
        word: 'circular-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'edit-medium',
    className: 'custom-icon-edit-medium',
    keywords: [
      {
        word: 'edit-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clock-semi-medium',
    className: 'custom-icon-clock-semi-medium',
    keywords: [
      {
        word: 'clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'tag-user-semi-medium',
    className: 'custom-icon-tag-user-semi-medium',
    keywords: [
      {
        word: 'tag-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'activity-semi-medium',
    className: 'custom-icon-activity-semi-medium',
    keywords: [
      {
        word: 'activity-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'thumbs-up-medium',
    className: 'custom-icon-thumbs-up-medium',
    keywords: [
      {
        word: 'thumbs-up-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'trashcan-medium',
    className: 'custom-icon-trashcan-medium',
    keywords: [
      {
        word: 'trashcan-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'pie-chart-semi-medium',
    className: 'custom-icon-pie-chart-semi-medium',
    keywords: [
      {
        word: 'pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-hotspot-semi-medium',
    className: 'custom-icon-user-hotspot-semi-medium',
    keywords: [
      {
        word: 'user-hotspot-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'checkmark-medium',
    className: 'custom-icon-checkmark-medium',
    keywords: [
      {
        word: 'checkmark-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cross-medium',
    className: 'custom-icon-cross-medium',
    keywords: [
      {
        word: 'cross-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-medium',
    className: 'custom-icon-link-medium',
    keywords: [
      {
        word: 'link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'plus-medium',
    className: 'custom-icon-plus-medium',
    keywords: [
      {
        word: 'plus-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'restore-medium',
    className: 'custom-icon-restore-medium',
    keywords: [
      {
        word: 'restore-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'block-medium',
    className: 'custom-icon-block-medium',
    keywords: [
      {
        word: 'block-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-info-semi-medium',
    className: 'custom-icon-database-info-semi-medium',
    keywords: [
      {
        word: 'database-info-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'replace-medium',
    className: 'custom-icon-replace-medium',
    keywords: [
      {
        word: 'replace-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'info-mail-medium',
    className: 'custom-icon-info-mail-medium',
    keywords: [
      {
        word: 'info-mail-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-checkmark-semi-medium',
    className: 'custom-icon-link-checkmark-semi-medium',
    keywords: [
      {
        word: 'link-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-globe-semi-medium',
    className: 'custom-icon-teams-globe-semi-medium',
    keywords: [
      {
        word: 'teams-globe-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-alert-semi-medium',
    className: 'custom-icon-site-alert-semi-medium',
    keywords: [
      {
        word: 'site-alert-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-clock-semi-medium',
    className: 'custom-icon-notepad-clock-semi-medium',
    keywords: [
      {
        word: 'notepad-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-mail-semi-medium',
    className: 'custom-icon-reportpad-mail-semi-medium',
    keywords: [
      {
        word: 'reportpad-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-cursor-semi-medium',
    className: 'custom-icon-file-cursor-semi-medium',
    keywords: [
      {
        word: 'file-cursor-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'checkmark-mail-medium',
    className: 'custom-icon-checkmark-mail-medium',
    keywords: [
      {
        word: 'checkmark-mail-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cross-mail-medium',
    className: 'custom-icon-cross-mail-medium',
    keywords: [
      {
        word: 'cross-mail-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-checkmark-semi-medium',
    className: 'custom-icon-notepad-checkmark-semi-medium',
    keywords: [
      {
        word: 'notepad-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-lock-semi-medium',
    className: 'custom-icon-file-lock-semi-medium',
    keywords: [
      {
        word: 'file-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-restore-semi-medium',
    className: 'custom-icon-lock-restore-semi-medium',
    keywords: [
      {
        word: 'lock-restore-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clock-star-semi-medium',
    className: 'custom-icon-clock-star-semi-medium',
    keywords: [
      {
        word: 'clock-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-refresh-semi-medium',
    className: 'custom-icon-doc-refresh-semi-medium',
    keywords: [
      {
        word: 'doc-refresh-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-star-semi-medium',
    className: 'custom-icon-doc-star-semi-medium',
    keywords: [
      {
        word: 'doc-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-cross-semi-medium',
    className: 'custom-icon-notepad-cross-semi-medium',
    keywords: [
      {
        word: 'notepad-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'listpad-uparrow-semi-medium',
    className: 'custom-icon-listpad-uparrow-semi-medium',
    keywords: [
      {
        word: 'listpad-uparrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-up-arrow-semi-medium',
    className: 'custom-icon-reportpad-up-arrow-semi-medium',
    keywords: [
      {
        word: 'reportpad-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-medium',
    className: 'custom-icon-heart-medium',
    keywords: [
      {
        word: 'heart-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-pulse-medium',
    className: 'custom-icon-heart-pulse-medium',
    keywords: [
      {
        word: 'heart-pulse-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'plus-solid',
    className: 'custom-icon-plus-solid',
    keywords: [
      {
        word: 'plus-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'spark-medium',
    className: 'custom-icon-spark-medium',
    keywords: [
      {
        word: 'spark-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-plus-semi-medium',
    className: 'custom-icon-user-plus-semi-medium',
    keywords: [
      {
        word: 'user-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-clock-semi-medium',
    className: 'custom-icon-site-clock-semi-medium',
    keywords: [
      {
        word: 'site-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-forward-semi-medium',
    className: 'custom-icon-globe-forward-semi-medium',
    keywords: [
      {
        word: 'globe-forward-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'flow-dependency-bold',
    className: 'custom-icon-flow-dependency-bold',
    keywords: [
      {
        word: 'flow-dependency-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-gear-semi-medium',
    className: 'custom-icon-app-gear-semi-medium',
    keywords: [
      {
        word: 'app-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'bot-gear-semi-medium',
    className: 'custom-icon-bot-gear-semi-medium',
    keywords: [
      {
        word: 'bot-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-cursor-semi-medium',
    className: 'custom-icon-calendar-cursor-semi-medium',
    keywords: [
      {
        word: 'calendar-cursor-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-down-arrow-semi-medium',
    className: 'custom-icon-calendar-down-arrow-semi-medium',
    keywords: [
      {
        word: 'calendar-down-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-key-medium',
    className: 'custom-icon-calendar-key-medium',
    keywords: [
      {
        word: 'calendar-key-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-pulse-semi-medium',
    className: 'custom-icon-calendar-pulse-semi-medium',
    keywords: [
      {
        word: 'calendar-pulse-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-right-arrows-semi-medium',
    className: 'custom-icon-calendar-right-arrows-semi-medium',
    keywords: [
      {
        word: 'calendar-right-arrows-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-right-semi-medium',
    className: 'custom-icon-calendar-right-semi-medium',
    keywords: [
      {
        word: 'calendar-right-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-group-semi-medium',
    className: 'custom-icon-chat-group-semi-medium',
    keywords: [
      {
        word: 'chat-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-key-medium',
    className: 'custom-icon-desktop-key-medium',
    keywords: [
      {
        word: 'desktop-key-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-chat-semi-medium',
    className: 'custom-icon-doc-chat-semi-medium',
    keywords: [
      {
        word: 'doc-chat-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'documents-medium',
    className: 'custom-icon-documents-medium',
    keywords: [
      {
        word: 'documents-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'filter-medium',
    className: 'custom-icon-filter-medium',
    keywords: [
      {
        word: 'filter-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-link-sei-medium',
    className: 'custom-icon-user-link-sei-medium',
    keywords: [
      {
        word: 'user-link-sei-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-at-medium',
    className: 'custom-icon-group-at-medium',
    keywords: [
      {
        word: 'group-at-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'input-bold',
    className: 'custom-icon-input-bold',
    keywords: [
      {
        word: 'input-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-bar-chart-semi-medium',
    className: 'custom-icon-lock-bar-chart-semi-medium',
    keywords: [
      {
        word: 'lock-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-bell-semi-medium',
    className: 'custom-icon-notepad-bell-semi-medium',
    keywords: [
      {
        word: 'notepad-bell-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-refresh-medium',
    className: 'custom-icon-notepad-refresh-medium',
    keywords: [
      {
        word: 'notepad-refresh-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-file-attach-semi-medium',
    className: 'custom-icon-report-file-attach-semi-medium',
    keywords: [
      {
        word: 'report-file-attach-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-file-clock-semi-medium',
    className: 'custom-icon-report-file-clock-semi-medium',
    keywords: [
      {
        word: 'report-file-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-file-down-arrow-semi-medium',
    className: 'custom-icon-report-file-down-arrow-semi-medium',
    keywords: [
      {
        word: 'report-file-down-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-file-eye-semi-medium',
    className: 'custom-icon-report-file-eye-semi-medium',
    keywords: [
      {
        word: 'report-file-eye-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-file-gear-semi-medium',
    className: 'custom-icon-report-file-gear-semi-medium',
    keywords: [
      {
        word: 'report-file-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-file-lens-semi-medium',
    className: 'custom-icon-report-file-lens-semi-medium',
    keywords: [
      {
        word: 'report-file-lens-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-file-mail-semi-medium',
    className: 'custom-icon-report-file-mail-semi-medium',
    keywords: [
      {
        word: 'report-file-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-file-unlock-semi-medium',
    className: 'custom-icon-report-file-unlock-semi-medium',
    keywords: [
      {
        word: 'report-file-unlock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-bell-semi-medium',
    className: 'custom-icon-reportpad-bell-semi-medium',
    keywords: [
      {
        word: 'reportpad-bell-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'unlock-link-medium',
    className: 'custom-icon-unlock-link-medium',
    keywords: [
      {
        word: 'unlock-link-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-heart-semi-medium',
    className: 'custom-icon-user-heart-semi-medium',
    keywords: [
      {
        word: 'user-heart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-reply-arrow-semi-medium',
    className: 'custom-icon-user-reply-arrow-semi-medium',
    keywords: [
      {
        word: 'user-reply-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-thumbs-up-semi-medium',
    className: 'custom-icon-user-thumbs-up-semi-medium',
    keywords: [
      {
        word: 'user-thumbs-up-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'video-clock-semi-medium',
    className: 'custom-icon-video-clock-semi-medium',
    keywords: [
      {
        word: 'video-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: '360-degree-solid',
    className: 'custom-icon-360-degree-solid',
    keywords: [
      {
        word: '360-degree-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'ai-sparkle-semi-medium',
    className: 'custom-icon-ai-sparkle-semi-medium',
    keywords: [
      {
        word: 'ai-sparkle-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'circular-puzzle-bold',
    className: 'custom-icon-circular-puzzle-bold',
    keywords: [
      {
        word: 'circular-puzzle-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'hand-pie-chart-semi-bold',
    className: 'custom-icon-hand-pie-chart-semi-bold',
    keywords: [
      {
        word: 'hand-pie-chart-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'megaphone-bold',
    className: 'custom-icon-megaphone-bold',
    keywords: [
      {
        word: 'megaphone-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'auto-click-semi-medium',
    className: 'custom-icon-auto-click-semi-medium',
    keywords: [
      {
        word: 'auto-click-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'brush-pencil-bold',
    className: 'custom-icon-brush-pencil-bold',
    keywords: [
      {
        word: 'brush-pencil-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'edit-bold',
    className: 'custom-icon-edit-bold',
    keywords: [
      {
        word: 'edit-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-sparkle-semi-medium',
    className: 'custom-icon-file-sparkle-semi-medium',
    keywords: [
      {
        word: 'file-sparkle-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-bolt-medium',
    className: 'custom-icon-file-bolt-medium',
    keywords: [
      {
        word: 'file-bolt-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-group-semi-medium',
    className: 'custom-icon-gear-group-semi-medium',
    keywords: [
      {
        word: 'gear-group-semi-medium',
        weight: 5,
      },
      {
        word: 'settings',
        weight: 5,
      },
      {
        word: 'group',
        weight: 1,
      },
    ],
  },
  {
    name: 'group-semi-gear-semi-medium',
    className: 'custom-icon-group-semi-gear-semi-medium',
    keywords: [
      {
        word: 'group-semi-gear-semi-medium',
        weight: 5,
      },
      {
        word: 'settings',
        weight: 5,
      },
      {
        word: 'group',
        weight: 1,
      },
    ],
  },
  {
    name: 'hand-dollar-semi-bold',
    className: 'custom-icon-hand-dollar-semi-bold',
    keywords: [
      {
        word: 'hand-dollar-semi-bold',
        weight: 5,
      },
      {
        word: 'hand',
        weight: 5,
      },
      {
        word: 'dollar',
        weight: 1,
      },
      {
        word: 'semi bold',
        weight: 2,
      },
    ],
  },
  {
    name: 'pen-tool-semi-bold',
    className: 'custom-icon-pen-tool-semi-bold',
    keywords: [
      {
        word: 'pen-tool-semi-bold',
        weight: 5,
      },
      {
        word: 'design',
        weight: 5,
      },
      {
        word: 'graphical design',
        weight: 5,
      },
    ],
  },
  {
    name: 'puzzle-piece-bold',
    className: 'custom-icon-puzzle-piece-bold',
    keywords: [
      {
        word: 'puzzle-piece-bold',
        weight: 5,
      },
      {
        word: 'piece',
        weight: 1,
      },
      {
        word: 'bold',
        weight: 5,
      },
      {
        word: 'puzzle',
        weight: 5,
      },
    ],
  },
  {
    name: 'saved-bold',
    className: 'custom-icon-saved-bold',
    keywords: [
      {
        word: 'saved-bold',
        weight: 5,
      },
      {
        word: 'bookmark',
        weight: 1,
      },
      {
        word: 'saved',
        weight: 5,
      },
      {
        word: 'bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'sleep-emoji-medium',
    className: 'custom-icon-sleep-emoji-medium',
    keywords: [
      {
        word: 'sleep-emoji-medium',
        weight: 1,
      },
      {
        word: 'medium',
        weight: 5,
      },
      {
        word: 'sleep',
        weight: 1,
      },
      {
        word: 'emoji',
        weight: 2,
      },
    ],
  },
  {
    name: 'bird-bold',
    className: 'custom-icon-bird-bold',
    keywords: [
      {
        word: 'bird-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-bar-chart-semi-medium',
    className: 'custom-icon-call-bar-chart-semi-medium',
    keywords: [
      {
        word: 'call-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-ring-medium',
    className: 'custom-icon-call-ring-medium',
    keywords: [
      {
        word: 'call-ring-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-clock-semi-medium',
    className: 'custom-icon-chat-clock-semi-medium',
    keywords: [
      {
        word: 'chat-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-lock-semi-medium',
    className: 'custom-icon-chat-lock-semi-medium',
    keywords: [
      {
        word: 'chat-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-ques-semi-medium',
    className: 'custom-icon-chat-ques-semi-medium',
    keywords: [
      {
        word: 'chat-ques-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'checklist-share-semi-medium',
    className: 'custom-icon-checklist-share-semi-medium',
    keywords: [
      {
        word: 'checklist-share-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clipboard-checkmark-semi-medium',
    className: 'custom-icon-clipboard-checkmark-semi-medium',
    keywords: [
      {
        word: 'clipboard-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clipboard-clock-semi-medium',
    className: 'custom-icon-clipboard-clock-semi-medium',
    keywords: [
      {
        word: 'clipboard-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clipboard-cross-semi-medium',
    className: 'custom-icon-clipboard-cross-semi-medium',
    keywords: [
      {
        word: 'clipboard-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clipboard-plus-semi-medium',
    className: 'custom-icon-clipboard-plus-semi-medium',
    keywords: [
      {
        word: 'clipboard-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clipboard-user-semi-medium',
    className: 'custom-icon-clipboard-user-semi-medium',
    keywords: [
      {
        word: 'clipboard-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-arrow-cursor-semi-medium',
    className: 'custom-icon-file-arrow-cursor-semi-medium',
    keywords: [
      {
        word: 'file-arrow-cursor-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-upward-trend-medium',
    className: 'custom-icon-folder-upward-trend-medium',
    keywords: [
      {
        word: 'folder-upward-trend-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-user-out-arrow-medium',
    className: 'custom-icon-folder-user-out-arrow-medium',
    keywords: [
      {
        word: 'folder-user-out-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-barchart-semi-medium',
    className: 'custom-icon-database-barchart-semi-medium',
    keywords: [
      {
        word: 'database-barchart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-barchart-semi-medium',
    className: 'custom-icon-group-barchart-semi-medium',
    keywords: [
      {
        word: 'group-barchart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-piechart-semi-medium',
    className: 'custom-icon-link-piechart-semi-medium',
    keywords: [
      {
        word: 'link-piechart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-bulb-bolt-semi-medium',
    className: 'custom-icon-gear-bulb-bolt-semi-medium',
    keywords: [
      {
        word: 'gear-bulb-bolt-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-bulb-semi-medium',
    className: 'custom-icon-gear-bulb-semi-medium',
    keywords: [
      {
        word: 'gear-bulb-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'illuminated-bulb-gear-semi-medium',
    className: 'custom-icon-illuminated-bulb-gear-semi-medium',
    keywords: [
      {
        word: 'illuminated-bulb-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-block-semi-medium',
    className: 'custom-icon-link-block-semi-medium',
    keywords: [
      {
        word: 'link-block-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-clock-semi-medium',
    className: 'custom-icon-link-clock-semi-medium',
    keywords: [
      {
        word: 'link-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-shield-exclamation',
    className: 'custom-icon-link-shield-exclamation',
    keywords: [
      {
        word: 'link-shield-exclamation',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-plus-semi-medium',
    className: 'custom-icon-lock-plus-semi-medium',
    keywords: [
      {
        word: 'lock-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-globe-semi-medium',
    className: 'custom-icon-mail-globe-semi-medium',
    keywords: [
      {
        word: 'mail-globe-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-lock-semi-medium',
    className: 'custom-icon-message-lock-semi-medium',
    keywords: [
      {
        word: 'message-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notpad-cursor-semi-medium',
    className: 'custom-icon-notpad-cursor-semi-medium',
    keywords: [
      {
        word: 'notpad-cursor-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'opened-mail-user-semi-medium',
    className: 'custom-icon-opened-mail-user-semi-medium',
    keywords: [
      {
        word: 'opened-mail-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-info-semi-medium',
    className: 'custom-icon-site-info-semi-medium',
    keywords: [
      {
        word: 'site-info-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-link-semi-medium',
    className: 'custom-icon-site-link-semi-medium',
    keywords: [
      {
        word: 'site-link-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-plus-semi-medium',
    className: 'custom-icon-site-plus-semi-medium',
    keywords: [
      {
        word: 'site-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-upward-trend-medium',
    className: 'custom-icon-site-upward-trend-medium',
    keywords: [
      {
        word: 'site-upward-trend-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'star-notepad-semi-medium',
    className: 'custom-icon-star-notepad-semi-medium',
    keywords: [
      {
        word: 'star-notepad-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-bar-chart-semi-medium',
    className: 'custom-icon-teams-bar-chart-semi-medium',
    keywords: [
      {
        word: 'teams-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-chat-semi-medium',
    className: 'custom-icon-teams-chat-semi-medium',
    keywords: [
      {
        word: 'teams-chat-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-circle-semi-medium',
    className: 'custom-icon-user-circle-semi-medium',
    keywords: [
      {
        word: 'user-circle-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-info-semi-medium',
    className: 'custom-icon-user-info-semi-medium',
    keywords: [
      {
        word: 'user-info-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-minus-semi-medium',
    className: 'custom-icon-user-minus-semi-medium',
    keywords: [
      {
        word: 'user-minus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-smiley-semi-medium',
    className: 'custom-icon-user-smiley-semi-medium',
    keywords: [
      {
        word: 'user-smiley-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'tower-signal-icon',
    className: 'custom-icon-tower-signal-icon',
    keywords: [
      {
        word: 'tower-signal-icon',
        weight: 5,
      },
    ],
  },
  {
    name: 'bell-heart-semi-medium',
    className: 'custom-icon-bell-heart-semi-medium',
    keywords: [
      {
        word: 'bell-heart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-call-semi-medium',
    className: 'custom-icon-calendar-call-semi-medium',
    keywords: [
      {
        word: 'calendar-call-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-heart-semi-medium',
    className: 'custom-icon-calendar-heart-semi-medium',
    keywords: [
      {
        word: 'calendar-heart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-smiley-semi-medium',
    className: 'custom-icon-calendar-smiley-semi-medium',
    keywords: [
      {
        word: 'calendar-smiley-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-star-semi-medium',
    className: 'custom-icon-calendar-star-semi-medium',
    keywords: [
      {
        word: 'calendar-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-timer-semi-medium',
    className: 'custom-icon-calendar-timer-semi-medium',
    keywords: [
      {
        word: 'calendar-timer-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-video-semi-medium',
    className: 'custom-icon-calendar-video-semi-medium',
    keywords: [
      {
        word: 'calendar-video-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-checkmark-semi-medium',
    className: 'custom-icon-call-checkmark-semi-medium',
    keywords: [
      {
        word: 'call-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-clock-semi-medium',
    className: 'custom-icon-call-clock-semi-medium',
    keywords: [
      {
        word: 'call-clock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-clock-semi-medium-1',
    className: 'custom-icon-call-clock-semi-medium-1',
    keywords: [
      {
        word: 'call-clock-semi-medium-1',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-double-arrow-semi-medium',
    className: 'custom-icon-call-double-arrow-semi-medium',
    keywords: [
      {
        word: 'call-double-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-group-1-semi-medium',
    className: 'custom-icon-call-group-1-semi-medium',
    keywords: [
      {
        word: 'call-group-1-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-pie-chart-semi-medium',
    className: 'custom-icon-call-pie-chart-semi-medium',
    keywords: [
      {
        word: 'call-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-signal-semi-medium',
    className: 'custom-icon-call-signal-semi-medium',
    keywords: [
      {
        word: 'call-signal-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-signal-semi-medium-1',
    className: 'custom-icon-call-signal-semi-medium-1',
    keywords: [
      {
        word: 'call-signal-semi-medium-1',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-star-semi-medium',
    className: 'custom-icon-call-star-semi-medium',
    keywords: [
      {
        word: 'call-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'call-timer-semi-medium',
    className: 'custom-icon-call-timer-semi-medium',
    keywords: [
      {
        word: 'call-timer-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-external-medium',
    className: 'custom-icon-channel-external-medium',
    keywords: [
      {
        word: 'channel-external-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-group-semi-medium',
    className: 'custom-icon-channel-group-semi-medium',
    keywords: [
      {
        word: 'channel-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-thumbs-down-semi-medium',
    className: 'custom-icon-channel-thumbs-down-semi-medium',
    keywords: [
      {
        word: 'channel-thumbs-down-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-thumbs-up-semi-medium',
    className: 'custom-icon-channel-thumbs-up-semi-medium',
    keywords: [
      {
        word: 'channel-thumbs-up-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-piechart-semi-medium',
    className: 'custom-icon-chat-piechart-semi-medium',
    keywords: [
      {
        word: 'chat-piechart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-up-arrow-semi-medium',
    className: 'custom-icon-chat-up-arrow-semi-medium',
    keywords: [
      {
        word: 'chat-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clock-in-out-arrow-medium',
    className: 'custom-icon-clock-in-out-arrow-medium',
    keywords: [
      {
        word: 'clock-in-out-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'crown-teams-semi-medium',
    className: 'custom-icon-crown-teams-semi-medium',
    keywords: [
      {
        word: 'crown-teams-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-call-semi-medium',
    className: 'custom-icon-doc-call-semi-medium',
    keywords: [
      {
        word: 'doc-call-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-head-teams-semi-medium',
    className: 'custom-icon-gear-head-teams-semi-medium',
    keywords: [
      {
        word: 'gear-head-teams-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-connect-semi-medium',
    className: 'custom-icon-group-connect-semi-medium',
    keywords: [
      {
        word: 'group-connect-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-lock-semi-medium',
    className: 'custom-icon-group-lock-semi-medium',
    keywords: [
      {
        word: 'group-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-mention-medium',
    className: 'custom-icon-group-mention-medium',
    keywords: [
      {
        word: 'group-mention-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-dotted-circle-medium',
    className: 'custom-icon-heart-dotted-circle-medium',
    keywords: [
      {
        word: 'heart-dotted-circle-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-dotted-circle-semi-medium',
    className: 'custom-icon-heart-dotted-circle-semi-medium',
    keywords: [
      {
        word: 'heart-dotted-circle-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-down-arrow-semi-medium',
    className: 'custom-icon-heart-down-arrow-semi-medium',
    keywords: [
      {
        word: 'heart-down-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-spark-semi-medium',
    className: 'custom-icon-heart-spark-semi-medium',
    keywords: [
      {
        word: 'heart-spark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'heart-up-arrow-semi-medium',
    className: 'custom-icon-heart-up-arrow-semi-medium',
    keywords: [
      {
        word: 'heart-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-bar-chart-semi-medium',
    className: 'custom-icon-message-bar-chart-semi-medium',
    keywords: [
      {
        word: 'message-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'arrow-up-bold',
    className: 'custom-icon-arrow-up-bold',
    keywords: [
      {
        word: 'message-bar-chart-semi-medium-1',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-down-arrow-semi-medium',
    className: 'custom-icon-message-down-arrow-semi-medium',
    keywords: [
      {
        word: 'message-down-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-up-arrow-semi-medium',
    className: 'custom-icon-message-up-arrow-semi-medium',
    keywords: [
      {
        word: 'message-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'new-teams-semi-medium',
    className: 'custom-icon-new-teams-semi-medium',
    keywords: [
      {
        word: 'new-teams-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'post-group-semi-medium',
    className: 'custom-icon-post-group-semi-medium',
    keywords: [
      {
        word: 'post-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'post-heart-semi-medium',
    className: 'custom-icon-post-heart-semi-medium',
    keywords: [
      {
        word: 'post-heart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'post-star-semi-medium',
    className: 'custom-icon-post-star-semi-medium',
    keywords: [
      {
        word: 'post-star-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'post-thumbs-down-semi-medium',
    className: 'custom-icon-post-thumbs-down-semi-medium',
    keywords: [
      {
        word: 'post-thumbs-down-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'post-thumbs-up-semi-medium',
    className: 'custom-icon-post-thumbs-up-semi-medium',
    keywords: [
      {
        word: 'post-thumbs-up-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'radar-semi-medium',
    className: 'custom-icon-radar-semi-medium',
    keywords: [
      {
        word: 'radar-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'screenshare-medium',
    className: 'custom-icon-screenshare-medium',
    keywords: [
      {
        word: 'screenshare-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'signal-medium',
    className: 'custom-icon-signal-medium',
    keywords: [
      {
        word: 'signal-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-channel-semi-medium',
    className: 'custom-icon-teams-channel-semi-medium',
    keywords: [
      {
        word: 'teams-channel-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-cloud-semi-medium',
    className: 'custom-icon-teams-cloud-semi-medium',
    keywords: [
      {
        word: 'teams-cloud-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-database-semi-medium',
    className: 'custom-icon-teams-database-semi-medium',
    keywords: [
      {
        word: 'teams-database-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-external-arrow-medium',
    className: 'custom-icon-teams-external-arrow-medium',
    keywords: [
      {
        word: 'teams-external-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-in-out-semi-medium',
    className: 'custom-icon-teams-in-out-semi-medium',
    keywords: [
      {
        word: 'teams-in-out-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-link-semi-medium',
    className: 'custom-icon-teams-link-semi-medium',
    keywords: [
      {
        word: 'teams-link-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-lock-semi-medium',
    className: 'custom-icon-teams-lock-semi-medium',
    keywords: [
      {
        word: 'teams-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-piechart-semi-medium',
    className: 'custom-icon-teams-piechart-semi-medium',
    keywords: [
      {
        word: 'teams-piechart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-spark-semi-medium',
    className: 'custom-icon-teams-spark-semi-medium',
    keywords: [
      {
        word: 'teams-spark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-thumbs-down-semi-medium',
    className: 'custom-icon-teams-thumbs-down-semi-medium',
    keywords: [
      {
        word: 'teams-thumbs-down-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-thumbs-up-semi-medium',
    className: 'custom-icon-teams-thumbs-up-semi-medium',
    keywords: [
      {
        word: 'teams-thumbs-up-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-trend-arrow-semi-medium',
    className: 'custom-icon-teams-trend-arrow-semi-medium',
    keywords: [
      {
        word: 'teams-trend-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-video-semi-medium',
    className: 'custom-icon-teams-video-semi-medium',
    keywords: [
      {
        word: 'teams-video-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'up-trend-medium',
    className: 'custom-icon-up-trend-medium',
    keywords: [
      {
        word: 'up-trend-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-call-medium',
    className: 'custom-icon-user-call-medium',
    keywords: [
      {
        word: 'user-call-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-location-pin-semi-medium',
    className: 'custom-icon-user-location-pin-semi-medium',
    keywords: [
      {
        word: 'user-location-pin-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-radar-semi-medium',
    className: 'custom-icon-user-radar-semi-medium',
    keywords: [
      {
        word: 'user-radar-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-sent-semi-medium',
    className: 'custom-icon-user-sent-semi-medium',
    keywords: [
      {
        word: 'user-sent-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-thumbs-down-semi-medium',
    className: 'custom-icon-user-thumbs-down-semi-medium',
    keywords: [
      {
        word: 'user-thumbs-down-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-timer-semi-medium',
    className: 'custom-icon-user-timer-semi-medium',
    keywords: [
      {
        word: 'user-timer-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'active-directory-lens-semi-medium',
    className: 'custom-icon-active-directory-lens-semi-medium',
    keywords: [
      {
        word: 'active-directory-lens-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'archive-semi-medium',
    className: 'custom-icon-archive-semi-medium',
    keywords: [
      {
        word: 'archive-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'attach-bold',
    className: 'custom-icon-attach-bold',
    keywords: [
      {
        word: 'attach-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'attach-up-arrow-semi-medium',
    className: 'custom-icon-attach-up-arrow-semi-medium',
    keywords: [
      {
        word: 'attach-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-attach-medium',
    className: 'custom-icon-calendar-attach-medium',
    keywords: [
      {
        word: 'calendar-attach-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-attach-semi-medium',
    className: 'custom-icon-database-attach-semi-medium',
    keywords: [
      {
        word: 'database-attach-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-archive-semi-medium',
    className: 'custom-icon-database-archive-semi-medium',
    keywords: [
      {
        word: 'database-archive-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-folder-semi-medium',
    className: 'custom-icon-database-folder-semi-medium',
    keywords: [
      {
        word: 'database-folder-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-pie-chart-semi-medium',
    className: 'custom-icon-database-pie-chart-semi-medium',
    keywords: [
      {
        word: 'database-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-shield',
    className: 'custom-icon-doc-shield',
    keywords: [
      {
        word: 'doc-shield',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-attach-bold',
    className: 'custom-icon-file-attach-bold',
    keywords: [
      {
        word: 'file-attach-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-lens-bold',
    className: 'custom-icon-file-lens-bold',
    keywords: [
      {
        word: 'file-lens-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'flag-cross-bold',
    className: 'custom-icon-flag-cross-bold',
    keywords: [
      {
        word: 'flag-cross-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-database-semi-medium',
    className: 'custom-icon-folder-database-semi-medium',
    keywords: [
      {
        word: 'folder-database-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-location-2-semi-medium',
    className: 'custom-icon-globe-location-2-semi-medium',
    keywords: [
      {
        word: 'globe-location-2-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-receive-semi-medium',
    className: 'custom-icon-globe-receive-semi-medium',
    keywords: [
      {
        word: 'globe-receive-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-sent-semi-medium',
    className: 'custom-icon-globe-sent-semi-medium',
    keywords: [
      {
        word: 'globe-sent-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'hexagonal-link-semi-medium',
    className: 'custom-icon-hexagonal-link-semi-medium',
    keywords: [
      {
        word: 'hexagonal-link-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-arrows-medium',
    className: 'custom-icon-link-arrows-medium',
    keywords: [
      {
        word: 'link-arrows-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-bar-chart-semi-medium',
    className: 'custom-icon-link-bar-chart-semi-medium',
    keywords: [
      {
        word: 'link-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-exclamation-semi-bold',
    className: 'custom-icon-link-exclamation-semi-bold',
    keywords: [
      {
        word: 'link-exclamation-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-globe-semi-medium',
    className: 'custom-icon-link-globe-semi-medium',
    keywords: [
      {
        word: 'link-globe-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-location-semi-medium',
    className: 'custom-icon-link-location-semi-medium',
    keywords: [
      {
        word: 'link-location-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-pie-chart-semi-bold',
    className: 'custom-icon-link-pie-chart-semi-bold',
    keywords: [
      {
        word: 'link-pie-chart-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-ques-semi-bold',
    className: 'custom-icon-link-ques-semi-bold',
    keywords: [
      {
        word: 'link-ques-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-shield-exclamation-semi-bold',
    className: 'custom-icon-link-shield-exclamation-semi-bold',
    keywords: [
      {
        word: 'link-shield-exclamation-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-sparkle-semi-medium',
    className: 'custom-icon-link-sparkle-semi-medium',
    keywords: [
      {
        word: 'link-sparkle-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-tag-semi-medium',
    className: 'custom-icon-link-tag-semi-medium',
    keywords: [
      {
        word: 'link-tag-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-attach-bold',
    className: 'custom-icon-mail-attach-bold',
    keywords: [
      {
        word: 'mail-attach-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-classification-semi-medium',
    className: 'custom-icon-mail-classification-semi-medium',
    keywords: [
      {
        word: 'mail-classification-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-location-semi-medium',
    className: 'custom-icon-mail-location-semi-medium',
    keywords: [
      {
        word: 'mail-location-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-growth-bar-semi-medium',
    className: 'custom-icon-mail-growth-bar-semi-medium',
    keywords: [
      {
        word: 'mail-growth-bar-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'open-lock-bold',
    className: 'custom-icon-open-lock-bold',
    keywords: [
      {
        word: 'open-lock-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'refresh-trend-semi-medium',
    className: 'custom-icon-refresh-trend-semi-medium',
    keywords: [
      {
        word: 'refresh-trend-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-shield-semi-medium',
    className: 'custom-icon-lock-shield-semi-medium',
    keywords: [
      {
        word: 'lock-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'reply-all-bold',
    className: 'custom-icon-reply-all-bold',
    keywords: [
      {
        word: 'reply-all-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'reply-bold',
    className: 'custom-icon-reply-bold',
    keywords: [
      {
        word: 'reply-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'shield-attach-bold',
    className: 'custom-icon-shield-attach-bold',
    keywords: [
      {
        word: 'shield-attach-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'forward-bold',
    className: 'custom-icon-forward-bold',
    keywords: [
      {
        word: 'forward-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'shield-link-bold',
    className: 'custom-icon-shield-link-bold',
    keywords: [
      {
        word: 'shield-link-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'shield-wave-bold',
    className: 'custom-icon-shield-wave-bold',
    keywords: [
      {
        word: 'shield-wave-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'trashcan-pie-chart-semi-medium',
    className: 'custom-icon-trashcan-pie-chart-semi-medium',
    keywords: [
      {
        word: 'trashcan-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-bolt-bulb-semi-medium',
    className: 'custom-icon-user-bolt-bulb-semi-medium',
    keywords: [
      {
        word: 'user-bolt-bulb-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-branch-medium',
    className: 'custom-icon-user-branch-medium',
    keywords: [
      {
        word: 'user-branch-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'unlocked-user-semi-medium',
    className: 'custom-icon-unlocked-user-semi-medium',
    keywords: [
      {
        word: 'unlocked-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-active-directory-semi-medium',
    className: 'custom-icon-lens-active-directory-semi-medium',
    keywords: [
      {
        word: 'lens-active-directory-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'brush-solid',
    className: 'custom-icon-brush-solid',
    keywords: [
      {
        word: 'brush-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-gear-solid',
    className: 'custom-icon-calendar-gear-solid',
    keywords: [
      {
        word: 'calendar-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-settings-solid',
    className: 'custom-icon-calendar-settings-solid',
    keywords: [
      {
        word: 'calendar-settings-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-gear-solid',
    className: 'custom-icon-channel-gear-solid',
    keywords: [
      {
        word: 'channel-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-group-solid',
    className: 'custom-icon-channel-group-solid',
    keywords: [
      {
        word: 'channel-group-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-star-solid',
    className: 'custom-icon-channel-star-solid',
    keywords: [
      {
        word: 'channel-star-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'computer-solid',
    className: 'custom-icon-computer-solid',
    keywords: [
      {
        word: 'computer-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'contact-book-solid',
    className: 'custom-icon-contact-book-solid',
    keywords: [
      {
        word: 'contact-book-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'contact-solid',
    className: 'custom-icon-contact-solid',
    keywords: [
      {
        word: 'contact-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-key-solid',
    className: 'custom-icon-file-key-solid',
    keywords: [
      {
        word: 'file-key-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-lock-solid',
    className: 'custom-icon-file-lock-solid',
    keywords: [
      {
        word: 'file-lock-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-checkmark-solid',
    className: 'custom-icon-folder-checkmark-solid',
    keywords: [
      {
        word: 'folder-checkmark-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-gear-solid',
    className: 'custom-icon-folder-gear-solid',
    keywords: [
      {
        word: 'folder-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-lens-solid',
    className: 'custom-icon-folder-lens-solid',
    keywords: [
      {
        word: 'folder-lens-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-solid',
    className: 'custom-icon-folder-solid',
    keywords: [
      {
        word: 'folder-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-play-button-solid',
    className: 'custom-icon-gear-play-button-solid',
    keywords: [
      {
        word: 'gear-play-button-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-forward-solid',
    className: 'custom-icon-globe-forward-solid',
    keywords: [
      {
        word: 'globe-forward-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-gear-solid',
    className: 'custom-icon-globe-gear-solid',
    keywords: [
      {
        word: 'globe-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-link-solid',
    className: 'custom-icon-globe-link-solid',
    keywords: [
      {
        word: 'globe-link-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-plus-solid',
    className: 'custom-icon-group-plus-solid',
    keywords: [
      {
        word: 'group-plus-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-refresh-solid',
    className: 'custom-icon-group-refresh-solid',
    keywords: [
      {
        word: 'group-refresh-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-settings-solid',
    className: 'custom-icon-group-settings-solid',
    keywords: [
      {
        word: 'group-settings-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-star-solid',
    className: 'custom-icon-group-star-solid',
    keywords: [
      {
        word: 'group-star-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'layers-solid',
    className: 'custom-icon-layers-solid',
    keywords: [
      {
        word: 'layers-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-checkmark-solid',
    className: 'custom-icon-mail-checkmark-solid',
    keywords: [
      {
        word: 'mail-checkmark-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-group-solid',
    className: 'custom-icon-mail-group-solid',
    keywords: [
      {
        word: 'mail-group-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-user-solid',
    className: 'custom-icon-mail-user-solid',
    keywords: [
      {
        word: 'mail-user-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-copy-solid',
    className: 'custom-icon-message-copy-solid',
    keywords: [
      {
        word: 'message-copy-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-gear-solid',
    className: 'custom-icon-message-gear-solid',
    keywords: [
      {
        word: 'message-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'notepad-gear-solid',
    className: 'custom-icon-notepad-gear-solid',
    keywords: [
      {
        word: 'notepad-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'reaction-medium',
    className: 'custom-icon-reaction-medium',
    keywords: [
      {
        word: 'reaction-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'server-lens-semi-medium',
    className: 'custom-icon-server-lens-semi-medium',
    keywords: [
      {
        word: 'server-lens-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'share1-solid',
    className: 'custom-icon-share1-solid',
    keywords: [
      {
        word: 'share1-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-gear-solid',
    className: 'custom-icon-site-gear-solid',
    keywords: [
      {
        word: 'site-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-group-solid',
    className: 'custom-icon-site-group-solid',
    keywords: [
      {
        word: 'site-group-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-share-solid',
    className: 'custom-icon-site-share-solid',
    keywords: [
      {
        word: 'site-share-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-user-solid',
    className: 'custom-icon-site-user-solid',
    keywords: [
      {
        word: 'site-user-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'teams-star-solid',
    className: 'custom-icon-teams-star-solid',
    keywords: [
      {
        word: 'teams-star-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-gear-solid',
    className: 'custom-icon-user-gear-solid',
    keywords: [
      {
        word: 'user-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-id-gear-solid',
    className: 'custom-icon-user-id-gear-solid',
    keywords: [
      {
        word: 'user-id-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-key-solid',
    className: 'custom-icon-user-key-solid',
    keywords: [
      {
        word: 'user-key-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-link-solid',
    className: 'custom-icon-user-link-solid',
    keywords: [
      {
        word: 'user-link-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-star-solid',
    className: 'custom-icon-user-star-solid',
    keywords: [
      {
        word: 'user-star-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'video-gear-solid',
    className: 'custom-icon-video-gear-solid',
    keywords: [
      {
        word: 'video-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-circular-gear-solid',
    className: 'custom-icon-mail-circular-gear-solid',
    keywords: [
      {
        word: 'mail-circular-gear-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-download-solid',
    className: 'custom-icon-cloud-download-solid',
    keywords: [
      {
        word: 'cloud-download-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'devices-lens-semi-medium',
    className: 'custom-icon-devices-lens-semi-medium',
    keywords: [
      {
        word: 'devices-lens-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'address-contact-semi-bold',
    className: 'custom-icon-address-contact-semi-bold',
    keywords: [
      {
        word: 'address-contact-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-block-bold',
    className: 'custom-icon-app-block-bold',
    keywords: [
      {
        word: 'app-block-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-call-semi-bold',
    className: 'custom-icon-calendar-call-semi-bold',
    keywords: [
      {
        word: 'calendar-call-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-edit-semi-bold',
    className: 'custom-icon-calendar-edit-semi-bold',
    keywords: [
      {
        word: 'calendar-edit-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-refresh-bold',
    className: 'custom-icon-calendar-refresh-bold',
    keywords: [
      {
        word: 'calendar-refresh-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-wrench-semi-bold',
    className: 'custom-icon-calendar-wrench-semi-bold',
    keywords: [
      {
        word: 'calendar-wrench-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-archive-semi-bold',
    className: 'custom-icon-channel-archive-semi-bold',
    keywords: [
      {
        word: 'channel-archive-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-unarchive-semi-bold',
    className: 'custom-icon-channel-unarchive-semi-bold',
    keywords: [
      {
        word: 'channel-unarchive-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'circular-paper-plane-semi-bold',
    className: 'custom-icon-circular-paper-plane-semi-bold',
    keywords: [
      {
        word: 'circular-paper-plane-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'clock-warning-semi-bold',
    className: 'custom-icon-clock-warning-semi-bold',
    keywords: [
      {
        word: 'clock-warning-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-checkmark-semi-bold',
    className: 'custom-icon-cloud-checkmark-semi-bold',
    keywords: [
      {
        word: 'cloud-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-cross-semi-bold',
    className: 'custom-icon-cloud-cross-semi-bold',
    keywords: [
      {
        word: 'cloud-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-down-arrow-semi-bold',
    className: 'custom-icon-cloud-down-arrow-semi-bold',
    keywords: [
      {
        word: 'cloud-down-arrow-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-forward-semi-bold',
    className: 'custom-icon-cloud-forward-semi-bold',
    keywords: [
      {
        word: 'cloud-forward-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-open-lock-bold',
    className: 'custom-icon-cloud-open-lock-bold',
    keywords: [
      {
        word: 'cloud-open-lock-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-revoke-bold',
    className: 'custom-icon-cloud-revoke-bold',
    keywords: [
      {
        word: 'cloud-revoke-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'crown-user-update',
    className: 'custom-icon-crown-user-update',
    keywords: [
      {
        word: 'crown-user-update',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-checkmark-semi-bold',
    className: 'custom-icon-database-checkmark-semi-bold',
    keywords: [
      {
        word: 'database-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-cross-semi-bold',
    className: 'custom-icon-database-cross-semi-bold',
    keywords: [
      {
        word: 'database-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'database-refresh-bold',
    className: 'custom-icon-database-refresh-bold',
    keywords: [
      {
        word: 'database-refresh-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-activity-clock-bold',
    className: 'custom-icon-doc-activity-clock-bold',
    keywords: [
      {
        word: 'doc-activity-clock-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-down-arrow-semi-bold',
    className: 'custom-icon-doc-down-arrow-semi-bold',
    keywords: [
      {
        word: 'doc-down-arrow-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-group-semi-bold',
    className: 'custom-icon-doc-group-semi-bold',
    keywords: [
      {
        word: 'doc-group-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-link-bold',
    className: 'custom-icon-doc-link-bold',
    keywords: [
      {
        word: 'doc-link-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-edit-semi-bold',
    className: 'custom-icon-file-edit-semi-bold',
    keywords: [
      {
        word: 'file-edit-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-gear-semi-bold',
    className: 'custom-icon-file-gear-semi-bold',
    keywords: [
      {
        word: 'file-gear-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-globe-semi-bold',
    className: 'custom-icon-file-globe-semi-bold',
    keywords: [
      {
        word: 'file-globe-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-link-bold',
    className: 'custom-icon-file-link-bold',
    keywords: [
      {
        word: 'file-link-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-update-bold',
    className: 'custom-icon-file-update-bold',
    keywords: [
      {
        word: 'file-update-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-user-update-semi-bold',
    className: 'custom-icon-gear-user-update-semi-bold',
    keywords: [
      {
        word: 'gear-user-update-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-replace-bold',
    className: 'custom-icon-group-replace-bold',
    keywords: [
      {
        word: 'group-replace-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'key-refresh-bold',
    className: 'custom-icon-key-refresh-bold',
    keywords: [
      {
        word: 'key-refresh-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'lens-heirarchy-semi-bold',
    className: 'custom-icon-lens-heirarchy-semi-bold',
    keywords: [
      {
        word: 'lens-heirarchy-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-block-bold',
    className: 'custom-icon-link-block-bold',
    keywords: [
      {
        word: 'link-block-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-crossed-forward-semi-bold',
    className: 'custom-icon-link-crossed-forward-semi-bold',
    keywords: [
      {
        word: 'link-crossed-forward-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-globe',
    className: 'custom-icon-link-globe',
    keywords: [
      {
        word: 'link-globe',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-shield-checkmark-semi-bold',
    className: 'custom-icon-link-shield-checkmark-semi-bold',
    keywords: [
      {
        word: 'link-shield-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-activity-clock-bold',
    className: 'custom-icon-list-activity-clock-bold',
    keywords: [
      {
        word: 'list-activity-clock-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-checkmark-semi-bold',
    className: 'custom-icon-list-checkmark-semi-bold',
    keywords: [
      {
        word: 'list-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-gear-semi-bold',
    className: 'custom-icon-list-gear-semi-bold',
    keywords: [
      {
        word: 'list-gear-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-group-semi-bold',
    className: 'custom-icon-list-group-semi-bold',
    keywords: [
      {
        word: 'list-group-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-link-semi-bold',
    className: 'custom-icon-list-link-semi-bold',
    keywords: [
      {
        word: 'list-link-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-lock-semi-bold',
    className: 'custom-icon-list-lock-semi-bold',
    keywords: [
      {
        word: 'list-lock-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-restore-bold',
    className: 'custom-icon-list-restore-bold',
    keywords: [
      {
        word: 'list-restore-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'list-user-semi-bold',
    className: 'custom-icon-list-user-semi-bold',
    keywords: [
      {
        word: 'list-user-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-plus-semi-bold',
    className: 'custom-icon-lock-plus-semi-bold',
    keywords: [
      {
        word: 'lock-plus-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-folder-semi-bold',
    className: 'custom-icon-mail-folder-semi-bold',
    keywords: [
      {
        word: 'mail-folder-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-globe-semi-bold',
    className: 'custom-icon-mail-globe-semi-bold',
    keywords: [
      {
        word: 'mail-globe-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-star-semi-bold',
    className: 'custom-icon-mail-star-semi-bold',
    keywords: [
      {
        word: 'mail-star-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-checkmark-semi-bold',
    className: 'custom-icon-message-checkmark-semi-bold',
    keywords: [
      {
        word: 'message-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mobile-message-checkmark-semi-bold',
    className: 'custom-icon-mobile-message-checkmark-semi-bold',
    keywords: [
      {
        word: 'mobile-message-checkmark-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'mobile-message-cross-semi-bold',
    className: 'custom-icon-mobile-message-cross-semi-bold',
    keywords: [
      {
        word: 'mobile-message-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'opened-lock-update-bold',
    className: 'custom-icon-opened-lock-update-bold',
    keywords: [
      {
        word: 'opened-lock-update-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-down-arrow-semi-bold',
    className: 'custom-icon-reportpad-down-arrow-semi-bold',
    keywords: [
      {
        word: 'reportpad-down-arrow-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'reportpad-exclamation-semi-bold',
    className: 'custom-icon-reportpad-exclamation-semi-bold',
    keywords: [
      {
        word: 'reportpad-exclamation-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-archive-semi-bold',
    className: 'custom-icon-site-archive-semi-bold',
    keywords: [
      {
        word: 'site-archive-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-brush-semi-bold',
    className: 'custom-icon-site-brush-semi-bold',
    keywords: [
      {
        word: 'site-brush-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-down-arrow-semi-bold',
    className: 'custom-icon-site-down-arrow-semi-bold',
    keywords: [
      {
        word: 'site-down-arrow-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-info-semi-bold',
    className: 'custom-icon-site-info-semi-bold',
    keywords: [
      {
        word: 'site-info-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-refresh-bold',
    className: 'custom-icon-site-refresh-bold',
    keywords: [
      {
        word: 'site-refresh-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-unarchive-semi-bold',
    className: 'custom-icon-site-unarchive-semi-bold',
    keywords: [
      {
        word: 'site-unarchive-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-update-bold',
    className: 'custom-icon-site-update-bold',
    keywords: [
      {
        word: 'site-update-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-classification-semi-bold',
    className: 'custom-icon-user-classification-semi-bold',
    keywords: [
      {
        word: 'user-classification-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-forward-semi-bold',
    className: 'custom-icon-user-forward-semi-bold',
    keywords: [
      {
        word: 'user-forward-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-lock-semi-bold',
    className: 'custom-icon-user-lock-semi-bold',
    keywords: [
      {
        word: 'user-lock-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-paper-plane-semi-bold',
    className: 'custom-icon-user-paper-plane-semi-bold',
    keywords: [
      {
        word: 'user-paper-plane-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-shield-cross-semi-bold',
    className: 'custom-icon-user-shield-cross-semi-bold',
    keywords: [
      {
        word: 'user-shield-cross-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-shield-plus-semi-bold',
    className: 'custom-icon-user-shield-plus-semi-bold',
    keywords: [
      {
        word: 'user-shield-plus-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'min-stopwatch-semi-medium',
    className: 'custom-icon-min-stopwatch-semi-medium',
    keywords: [
      {
        word: 'min-stopwatch-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'm-stopwatch-semi-medium',
    className: 'custom-icon-m-stopwatch-semi-medium',
    keywords: [
      {
        word: 'm-stopwatch-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'min-stopwatch-semi-medium1',
    className: 'custom-icon-min-stopwatch-semi-medium1',
    keywords: [
      {
        word: 'min-stopwatch-semi-medium1',
        weight: 5,
      },
    ],
  },
  {
    name: 'm-stopwatch-semi-medium1',
    className: 'custom-icon-m-stopwatch-semi-medium1',
    keywords: [
      {
        word: 'm-stopwatch-semi-medium1',
        weight: 5,
      },
    ],
  },
  {
    name: 'attach-bar-chart-semi-medium',
    className: 'custom-icon-attach-bar-chart-semi-medium',
    keywords: [
      {
        word: 'attach-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'attach-info-semi-medium',
    className: 'custom-icon-attach-info-semi-medium',
    keywords: [
      {
        word: 'attach-info-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-link-semi-medium',
    className: 'custom-icon-calendar-link-semi-medium',
    keywords: [
      {
        word: 'calendar-link-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-mention-semi-medium',
    className: 'custom-icon-calendar-mention-semi-medium',
    keywords: [
      {
        word: 'calendar-mention-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'calendar-message-semi-medium',
    className: 'custom-icon-calendar-message-semi-medium',
    keywords: [
      {
        word: 'calendar-message-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-bar-chart-semi-medium',
    className: 'custom-icon-channel-bar-chart-semi-medium',
    keywords: [
      {
        word: 'channel-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-heart-semi-medium',
    className: 'custom-icon-channel-heart-semi-medium',
    keywords: [
      {
        word: 'channel-heart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-mention-semi-medium',
    className: 'custom-icon-channel-mention-semi-medium',
    keywords: [
      {
        word: 'channel-mention-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-message-semi-medium',
    className: 'custom-icon-channel-message-semi-medium',
    keywords: [
      {
        word: 'channel-message-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'channel-smiley-semi-medium',
    className: 'custom-icon-channel-smiley-semi-medium',
    keywords: [
      {
        word: 'channel-smiley-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-external-semi-medium',
    className: 'custom-icon-chat-external-semi-medium',
    keywords: [
      {
        word: 'chat-external-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-globe-semi-medium',
    className: 'custom-icon-chat-globe-semi-medium',
    keywords: [
      {
        word: 'chat-globe-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-guest-semi-medium',
    className: 'custom-icon-chat-guest-semi-medium',
    keywords: [
      {
        word: 'chat-guest-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-heart-semi-medium',
    className: 'custom-icon-chat-heart-semi-medium',
    keywords: [
      {
        word: 'chat-heart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-mention',
    className: 'custom-icon-chat-mention',
    keywords: [
      {
        word: 'chat-mention',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-smiley-semi-medium',
    className: 'custom-icon-chat-smiley-semi-medium',
    keywords: [
      {
        word: 'chat-smiley-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-tag-semi-medium',
    className: 'custom-icon-chat-tag-semi-medium',
    keywords: [
      {
        word: 'chat-tag-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'clock-and-user-semi-bold',
    className: 'custom-icon-clock-and-user-semi-bold',
    keywords: [
      {
        word: 'clock-and-user-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-server-semi-medium',
    className: 'custom-icon-cloud-server-semi-medium',
    keywords: [
      {
        word: 'cloud-server-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'contact-move-bold',
    className: 'custom-icon-contact-move-bold',
    keywords: [
      {
        word: 'contact-move-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'contact-restore-bold',
    className: 'custom-icon-contact-restore-bold',
    keywords: [
      {
        word: 'contact-restore-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'conversation-medium',
    className: 'custom-icon-conversation-medium',
    keywords: [
      {
        word: 'conversation-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'date-calendar-bar-chart-semi-medium',
    className: 'custom-icon-date-calendar-bar-chart-semi-medium',
    keywords: [
      {
        word: 'date-calendar-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'delete-cross-semi-medium',
    className: 'custom-icon-delete-cross-semi-medium',
    keywords: [
      {
        word: 'delete-cross-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-globe-bold',
    className: 'custom-icon-desktop-globe-bold',
    keywords: [
      {
        word: 'desktop-globe-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'desktop-key-bold',
    className: 'custom-icon-desktop-key-bold',
    keywords: [
      {
        word: 'desktop-key-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-attach-semi-medium',
    className: 'custom-icon-doc-attach-semi-medium',
    keywords: [
      {
        word: 'doc-attach-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-call-vibration-semi-medium',
    className: 'custom-icon-doc-call-vibration-semi-medium',
    keywords: [
      {
        word: 'doc-call-vibration-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'donut-chart',
    className: 'custom-icon-donut-chart',
    keywords: [
      {
        word: 'donut-chart',
        weight: 5,
      },
    ],
  },
  {
    name: 'download-arrow-medium',
    className: 'custom-icon-download-arrow-medium',
    keywords: [
      {
        word: 'download-arrow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'download-medium',
    className: 'custom-icon-download-medium',
    keywords: [
      {
        word: 'download-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'eye-shield-exclamation-semi-medium',
    className: 'custom-icon-eye-shield-exclamation-semi-medium',
    keywords: [
      {
        word: 'eye-shield-exclamation-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-semi-medium',
    className: 'custom-icon-folder-semi-medium',
    keywords: [
      {
        word: 'folder-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-chat-semi-medium',
    className: 'custom-icon-globe-chat-semi-medium',
    keywords: [
      {
        word: 'globe-chat-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-message-semi-medium',
    className: 'custom-icon-group-message-semi-medium',
    keywords: [
      {
        word: 'group-message-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'group-smiley-semi-medium',
    className: 'custom-icon-group-smiley-semi-medium',
    keywords: [
      {
        word: 'group-smiley-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'head-insights-semi-medium',
    className: 'custom-icon-head-insights-semi-medium',
    keywords: [
      {
        word: 'head-insights-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'hourglass',
    className: 'custom-icon-hourglass',
    keywords: [
      {
        word: 'hourglass',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-fingerprint-semi-medium',
    className: 'custom-icon-mail-fingerprint-semi-medium',
    keywords: [
      {
        word: 'mail-fingerprint-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-reply-semi-medium',
    className: 'custom-icon-mail-reply-semi-medium',
    keywords: [
      {
        word: 'mail-reply-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-shield-lock-semi-medium',
    className: 'custom-icon-mail-shield-lock-semi-medium',
    keywords: [
      {
        word: 'mail-shield-lock-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-sync-semi-medium',
    className: 'custom-icon-mail-sync-semi-medium',
    keywords: [
      {
        word: 'mail-sync-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-track-semi-medium',
    className: 'custom-icon-mail-track-semi-medium',
    keywords: [
      {
        word: 'mail-track-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-warning-semi-medium',
    className: 'custom-icon-mail-warning-semi-medium',
    keywords: [
      {
        word: 'mail-warning-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-heart-semi-medium',
    className: 'custom-icon-message-heart-semi-medium',
    keywords: [
      {
        word: 'message-heart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-mention-medium',
    className: 'custom-icon-message-mention-medium',
    keywords: [
      {
        word: 'message-mention-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-receive-semi-medium',
    className: 'custom-icon-message-receive-semi-medium',
    keywords: [
      {
        word: 'message-receive-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-smiley-semi-medium',
    className: 'custom-icon-message-smiley-semi-medium',
    keywords: [
      {
        word: 'message-smiley-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'message-user-semi-medium',
    className: 'custom-icon-message-user-semi-medium',
    keywords: [
      {
        word: 'message-user-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'monthly-calendar-bar-chart-semi-medium',
    className: 'custom-icon-monthly-calendar-bar-chart-semi-medium',
    keywords: [
      {
        word: 'monthly-calendar-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'notification-plus-semi-bold',
    className: 'custom-icon-notification-plus-semi-bold',
    keywords: [
      {
        word: 'notification-plus-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'printer-medium',
    className: 'custom-icon-printer-medium',
    keywords: [
      {
        word: 'printer-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'report-pad-semi-medium',
    className: 'custom-icon-report-pad-semi-medium',
    keywords: [
      {
        word: 'report-pad-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'rotating-arrow-checkmark',
    className: 'custom-icon-rotating-arrow-checkmark',
    keywords: [
      {
        word: 'rotating-arrow-checkmark',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-channel-semi-medium',
    className: 'custom-icon-site-channel-semi-medium',
    keywords: [
      {
        word: 'site-channel-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-chat-semi-medium',
    className: 'custom-icon-site-chat-semi-medium',
    keywords: [
      {
        word: 'site-chat-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'stopwatch-icon-semi-medium',
    className: 'custom-icon-stopwatch-icon-semi-medium',
    keywords: [
      {
        word: 'stopwatch-icon-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'stopwatch-timer-semi-medium',
    className: 'custom-icon-stopwatch-timer-semi-medium',
    keywords: [
      {
        word: 'stopwatch-timer-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'stppwatch-checkmark-semi-medium',
    className: 'custom-icon-stppwatch-checkmark-semi-medium',
    keywords: [
      {
        word: 'stppwatch-checkmark-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'table-medium',
    className: 'custom-icon-table-medium',
    keywords: [
      {
        word: 'table-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'table-pie-chart-semi-medium',
    className: 'custom-icon-table-pie-chart-semi-medium',
    keywords: [
      {
        word: 'table-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'time-semi-medium',
    className: 'custom-icon-time-semi-medium',
    keywords: [
      {
        word: 'time-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'upload-arrow-semi-medium',
    className: 'custom-icon-upload-arrow-semi-medium',
    keywords: [
      {
        word: 'upload-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'upload-medium',
    className: 'custom-icon-upload-medium',
    keywords: [
      {
        word: 'upload-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-message-semi-medium',
    className: 'custom-icon-user-message-semi-medium',
    keywords: [
      {
        word: 'user-message-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-with-hourglass',
    className: 'custom-icon-site-with-hourglass',
    keywords: [
      {
        word: 'site-with-hourglass',
        weight: 5,
      },
    ],
  },
  {
    name: 'site-with-refresh',
    className: 'custom-icon-site-with-refresh',
    keywords: [
      {
        word: 'site-with-refresh',
        weight: 5,
      },
    ],
  },
  {
    name: 'ai-semi-medium',
    className: 'custom-icon-ai-semi-medium',
    keywords: [
      {
        word: 'ai-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'anchor-bold',
    className: 'custom-icon-anchor-bold',
    keywords: [
      {
        word: 'anchor-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'attach-count-medium',
    className: 'custom-icon-attach-count-medium',
    keywords: [
      {
        word: 'attach-count-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'attach-size-medium',
    className: 'custom-icon-attach-size-medium',
    keywords: [
      {
        word: 'attach-size-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'bot-node-semi-medium',
    className: 'custom-icon-bot-node-semi-medium',
    keywords: [
      {
        word: 'bot-node-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'cloud-plus-semi-medium',
    className: 'custom-icon-cloud-plus-semi-medium',
    keywords: [
      {
        word: 'cloud-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'file-gear-semi-medium-1',
    className: 'custom-icon-file-gear-semi-medium-1',
    keywords: [
      {
        word: 'file-gear-semi-medium-1',
        weight: 5,
      },
    ],
  },
  {
    name: 'flow-medium',
    className: 'custom-icon-flow-medium',
    keywords: [
      {
        word: 'flow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'groups-call-semi-medium',
    className: 'custom-icon-groups-call-semi-medium',
    keywords: [
      {
        word: 'groups-call-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'groups-chat-semi-medium',
    className: 'custom-icon-groups-chat-semi-medium',
    keywords: [
      {
        word: 'groups-chat-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'key-block-medium',
    className: 'custom-icon-key-block-medium',
    keywords: [
      {
        word: 'key-block-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-bell-semi-medium',
    className: 'custom-icon-mail-bell-semi-medium',
    keywords: [
      {
        word: 'mail-bell-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-eye-slash-semi-medium',
    className: 'custom-icon-mail-eye-slash-semi-medium',
    keywords: [
      {
        word: 'mail-eye-slash-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'note-activity-semi-medium',
    className: 'custom-icon-note-activity-semi-medium',
    keywords: [
      {
        word: 'note-activity-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'note-pie-chart-semi-medium',
    className: 'custom-icon-note-pie-chart-semi-medium',
    keywords: [
      {
        word: 'note-pie-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'roof-group-semi-medium',
    className: 'custom-icon-roof-group-semi-medium',
    keywords: [
      {
        word: 'roof-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'share-block',
    className: 'custom-icon-share-block',
    keywords: [
      {
        word: 'share-block',
        weight: 5,
      },
    ],
  },
  {
    name: 'template-medium',
    className: 'custom-icon-template-medium',
    keywords: [
      {
        word: 'template-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'template-plus-semi-medium',
    className: 'custom-icon-template-plus-semi-medium',
    keywords: [
      {
        word: 'template-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'workflow-eye',
    className: 'custom-icon-workflow-eye',
    keywords: [
      {
        word: 'workflow-eye',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-ques-semi-medium',
    className: 'custom-icon-doc-ques-semi-medium',
    keywords: [
      {
        word: 'doc-ques-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'doc-up-arrow-semi-medium',
    className: 'custom-icon-doc-up-arrow-semi-medium',
    keywords: [
      {
        word: 'doc-up-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'anchor-solid',
    className: 'custom-icon-anchor-solid',
    keywords: [
      {
        word: 'anchor-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'copy-extra-bold',
    className: 'custom-icon-copy-extra-bold',
    keywords: [
      {
        word: 'copy-extra-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'bot-plus-semi-medium',
    className: 'custom-icon-bot-plus-semi-medium',
    keywords: [
      {
        word: 'bot-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'bot-settings-semi-medium',
    className: 'custom-icon-bot-settings-semi-medium',
    keywords: [
      {
        word: 'bot-settings-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'robot-plus-semi-medium',
    className: 'custom-icon-robot-plus-semi-medium',
    keywords: [
      {
        word: 'robot-plus-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'robot-gear-semi-medium',
    className: 'custom-icon-robot-gear-semi-medium',
    keywords: [
      {
        word: 'robot-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'chat-user-group-semi-medium',
    className: 'custom-icon-chat-user-group-semi-medium',
    keywords: [
      {
        word: 'chat-user-group-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-users-hierarchy-semi-medium',
    className: 'custom-icon-gear-users-hierarchy-semi-medium',
    keywords: [
      {
        word: 'gear-users-hierarchy-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'hourly-calendar-bar-semi-medium',
    className: 'custom-icon-hourly-calendar-bar-semi-medium',
    keywords: [
      {
        word: 'hourly-calendar-bar-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'mail-in-out-reply-semi-medium',
    className: 'custom-icon-mail-in-out-reply-semi-medium',
    keywords: [
      {
        word: 'mail-in-out-reply-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'dataflow-medium',
    className: 'custom-icon-dataflow-medium',
    keywords: [
      {
        word: 'dataflow-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'folder-directory-gear-semi-medium',
    className: 'custom-icon-folder-directory-gear-semi-medium',
    keywords: [
      {
        word: 'folder-directory-gear-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'link-share-semi-medium',
    className: 'custom-icon-link-share-semi-medium',
    keywords: [
      {
        word: 'link-share-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'lock-block-medium',
    className: 'custom-icon-lock-block-medium',
    keywords: [
      {
        word: 'lock-block-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'template-shield-semi-medium',
    className: 'custom-icon-template-shield-semi-medium',
    keywords: [
      {
        word: 'template-shield-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-group-security',
    className: 'custom-icon-user-group-security',
    keywords: [
      {
        word: 'user-group-security',
        weight: 5,
      },
    ],
  },
  {
    name: 'user-group-mail-semi-medium',
    className: 'custom-icon-user-group-mail-semi-medium',
    keywords: [
      {
        word: 'user-group-mail-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'linkedin-solid',
    className: 'custom-icon-linkedin-solid',
    keywords: [
      {
        word: 'linkedin-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'attach-down-arrow-semi-medium',
    className: 'custom-icon-attach-down-arrow-semi-medium',
    keywords: [
      {
        word: 'attach-down-arrow-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-bar-chart-semi-medium',
    className: 'custom-icon-globe-bar-chart-semi-medium',
    keywords: [
      {
        word: 'globe-bar-chart-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-plus-semi-bold',
    className: 'custom-icon-app-plus-semi-bold',
    keywords: [
      {
        word: 'app-plus-semi-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'automation-robot-solid',
    className: 'custom-icon-automation-robot-solid',
    keywords: [
      {
        word: 'automation-robot-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'cog-bot-solid',
    className: 'custom-icon-cog-bot-solid',
    keywords: [
      {
        word: 'cog-bot-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'system-bot-solid',
    className: 'custom-icon-system-bot-solid',
    keywords: [
      {
        word: 'system-bot-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'color-palette-bold',
    className: 'custom-icon-color-palette-bold',
    keywords: [
      {
        word: 'color-palette-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'half-filled-circle-bold',
    className: 'custom-icon-half-filled-circle-bold',
    keywords: [
      {
        word: 'half-filled-circle-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'home-bold',
    className: 'custom-icon-home-bold',
    keywords: [
      {
        word: 'home-solid',
        weight: 5,
      },
    ],
  },
  {
    name: 'street-sign-bold',
    className: 'custom-icon-street-sign-bold',
    keywords: [
      {
        word: 'street-sign-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'gear-id-semi-medium',
    className: 'custom-icon-gear-id-semi-medium',
    keywords: [
      {
        word: 'gear-id-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-forms-bold',
    className: 'custom-icon-ms-forms-bold',
    keywords: [
      {
        word: 'ms-forms-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-learning-bold',
    className: 'custom-icon-ms-learning-bold',
    keywords: [
      {
        word: 'ms-learning-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-power-apps-bold',
    className: 'custom-icon-ms-power-apps-bold',
    keywords: [
      {
        word: 'ms-power-apps-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-sway-bold',
    className: 'custom-icon-ms-sway-bold',
    keywords: [
      {
        word: 'ms-sway-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-to-do-bold',
    className: 'custom-icon-ms-to-do-bold',
    keywords: [
      {
        word: 'ms-to-do-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'ms-viva-bold',
    className: 'custom-icon-ms-viva-bold',
    keywords: [
      {
        word: 'ms-viva-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'viva-insights-bold',
    className: 'custom-icon-viva-insights-bold',
    keywords: [
      {
        word: 'viva-insights-bold',
        weight: 5,
      },
    ],
  },
  {
    name: 'app-id-semi-medium',
    className: 'custom-icon-app-id-semi-medium',
    keywords: [
      {
        word: 'app-id-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'globe-id-semi-medium',
    className: 'custom-icon-globe-id-semi-medium',
    keywords: [
      {
        word: 'globe-id-semi-medium',
        weight: 5,
      },
    ],
  },
  {
    name: 'filtering-reports-medium',
    className: 'custom-icon-filtering-reports-medium',
    keywords: [
      {
        word: 'filtering-reports-medium',
        weight: 5,
      },
    ],
  },
];
