import { helper } from '@ember/component/helper';

export default helper(function isExpanded([value, expandedSet]) {
  return expandedSet.has(value);
});
