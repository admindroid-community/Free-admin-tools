import { helper } from '@ember/component/helper';
import { getHeaderFromData } from '../utils/get-header';

export default helper(([data]) => getHeaderFromData(data));
