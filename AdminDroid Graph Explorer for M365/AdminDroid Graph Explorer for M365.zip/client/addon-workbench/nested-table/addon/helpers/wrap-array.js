import { helper } from '@ember/component/helper';

export default helper(function wrapArray([value]) {
  return [value];
});
