import { helper } from '@ember/component/helper';

export default helper(function isArrayOfObjects([value]) {
  if (!Array.isArray(value) || !value.length) {
    return false;
  }

  return value.every(
    (item) =>
      item !== null &&
      typeof item === 'object' &&
      !Array.isArray(item) &&
      typeof item !== 'function',
  );
});
