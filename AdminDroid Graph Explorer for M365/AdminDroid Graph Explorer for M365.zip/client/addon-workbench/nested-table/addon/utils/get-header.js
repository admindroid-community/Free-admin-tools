export function getHeaderFromData(data) {
  if (Array.isArray(data)) {
    const keySet = new Set();
    data.forEach(item => {
      if (item && typeof item === 'object') {
        Object.keys(item).forEach(key => keySet.add(key));
      }
    });
    return Array.from(keySet);
  } else if (data && typeof data === 'object') {
    return Object.keys(data);
  } else {
    return [];
  }
}
