import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { stickFirstNCols as applyStickyHelper, resetStickyCols } from '../utils/stick-table-first-n-column';
import { getHeaderFromData } from '../utils/get-header';

export default class TableContainerComponent extends Component {
  @tracked currentPage = this.args.currentTablePage ?? 1;
  @tracked isPagination = this.args.isPagination ?? true;

  @tracked expandedKeys = new Set();
  previousData = null

  constructor() {
    super(...arguments);
    this.currentPage = this.args.currentTablePage ?? 1;
    this.isPagination = this.args.isPagination ?? true
  }

  get hasDataChanged() {
    const newData = this.args.tableData?.tableValue;
    if (newData !== this.previousData) {
      this.previousData = newData;
      this.reset();
    }
  }

  reset() {
    this.currentPage = this.args.currentTablePage ?? 1;
    this.isPagination = this.args.isPagination ?? true
  }
  @action
  toggleKey(key, event) {
    event.stopPropagation();
    if (this.expandedKeys.has(key)) {
      this.expandedKeys.delete(key);
    } else {
      this.expandedKeys.add(key);
    }

    // Force reactivity
    this.expandedKeys = new Set(this.expandedKeys);
  }

  isExpanded(key) {
    return this.expandedKeys.has(key);
  }

  @action
  setupTable(element) {
    // console.log("tav", element)
    let tableContainer = element;
    this.stickFirstNCols(tableContainer)
    if (tableContainer) {
      tableContainer.scrollLeft = 0;
      tableContainer.scrollTop = 0;
    }
  }

  @action
  stickFirstNCols(tableContainer) {
    if (!this.args.isNestedTable) {
      this.setupTableIntializer(tableContainer);
    }
  }

  get tableMaxData() {
    return this.args.tableMaxData?? this.args.tableData.tableValue.length
  }
  get upperLimit() {
    const upper = this.currentPage * this.tableMaxData;
    return !this.isPagination && !this.tableMaxData
      ? this.args.tableData.tableValue.length
      : Math.min(upper, this.args.tableData.tableValue.length);
  }

  get lowerLimit() {
    const lower = (this.currentPage - 1) * this.tableMaxData;
    return !this.isPagination && !this.tableMaxData
      ? 0
      : Math.max(0, lower);
  }

  get tableDatas() {
    return this.args.tableData?.tableValue?.slice(
      this.lowerLimit,
      this.upperLimit,
    );
  }

  get tableHeader() {
    return (
      this.args.tableData?.tableHeader ??
      getHeaderFromData(this.args.tableData.tableValue)
    );
  }
  get hasNextPage() {
    return this.upperLimit < this.args.tableData.tableValue.length;
  }

  get hasPrevPage() {
    return this.currentPage > 1;
  }

  get isLastPage() {
    return !this.hasNextPage && !this.args.hasMoreNextData && this.args.tableData.tableValue.length >= (this.args.maxCountForRestriction?? 2000)
  }

  @action
  movePrevPage() {
    if (this.hasPrevPage) {
      --this.currentPage;
      this.args.updateCurrentPageSize?.(this.currentPage);
    }
  }

  @action
  async moveNextPage() {
    if (this.hasNextPage) {
      ++this.currentPage;
      this.args.updateCurrentPageSize?.(this.currentPage);
    } else if (this.args.supportsExternalPagination && this.args.hasMoreNextData) {
      const result = await this.args.handleNextPage?.perform()
      if (result) {
        ++this.currentPage;
        this.args.updateCurrentPageSize?.(this.currentPage);
      }
    }
  }

  @action
  onRowClick(row, index) {
    this.args.handleRowClick?.(row, index);
  }

  setupTableIntializer(tableContainer) {
    const parent = tableContainer;
    const table = tableContainer.querySelector('table');

    if (!parent || !table) {
      console.warn('Parent or table element not found');
      return;
    }

    const parentRect = parent.getBoundingClientRect();
    const tableRect = table.getBoundingClientRect();

    const parentWidth = parentRect.width;
    const tableWidth = tableRect.width;

    // console.log('parent', parentWidth, 'child', tableWidth);
    // Only proceed if parent is wider than table
    if (parentWidth >= tableWidth) {
      console.log(
        'Parent width is less than or equal to table width — skipping sticky logic',
      );
      resetStickyCols(table);
      return;
    }

    // Existing logic
    const firstRow = table.rows[0];
    const col1 = firstRow.cells[0];
    const col2 = firstRow.cells[1];

    const col1Width = col1.offsetWidth;
    const col2Width = col2.offsetWidth;
    const combinedWidth = col1Width + col2Width;

    const threshold = parentWidth * 0.4;

    if (combinedWidth < threshold) {
      applyStickyHelper(table, 2);
    } else if (col1Width < threshold) {
      applyStickyHelper(table, 1);
    } else {
      resetStickyCols(table);
    }
  }
}
