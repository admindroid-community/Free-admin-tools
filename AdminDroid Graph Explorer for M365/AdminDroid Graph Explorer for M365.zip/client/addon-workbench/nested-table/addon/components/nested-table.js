import Component from '@glimmer/component';

export default class TableContainerComponent extends Component {}
