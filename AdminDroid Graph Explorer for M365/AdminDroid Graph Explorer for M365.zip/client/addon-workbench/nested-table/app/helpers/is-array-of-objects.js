export { default } from 'nested-table/helpers/is-array-of-objects';
