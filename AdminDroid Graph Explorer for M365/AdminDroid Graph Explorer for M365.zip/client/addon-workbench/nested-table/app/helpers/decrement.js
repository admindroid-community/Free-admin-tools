export { default } from 'nested-table/helpers/decrement';
