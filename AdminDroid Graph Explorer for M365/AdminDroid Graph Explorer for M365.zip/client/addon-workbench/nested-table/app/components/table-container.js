export { default } from 'nested-table/components/table-container';
