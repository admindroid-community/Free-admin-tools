export { default } from 'nested-table/components/nested-table';
