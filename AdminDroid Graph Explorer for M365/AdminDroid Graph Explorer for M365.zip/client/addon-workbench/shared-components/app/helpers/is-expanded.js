export { default } from '@admindroid/shared-components/helpers/is-expanded';
