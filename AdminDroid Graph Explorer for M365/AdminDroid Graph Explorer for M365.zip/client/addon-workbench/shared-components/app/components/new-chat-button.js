export { default } from '@admindroid/shared-components/components/new-chat-button';
