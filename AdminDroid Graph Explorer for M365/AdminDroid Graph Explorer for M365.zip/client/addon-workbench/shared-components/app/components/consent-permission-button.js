export { default } from '@admindroid/shared-components/components/consent-permission-button';
