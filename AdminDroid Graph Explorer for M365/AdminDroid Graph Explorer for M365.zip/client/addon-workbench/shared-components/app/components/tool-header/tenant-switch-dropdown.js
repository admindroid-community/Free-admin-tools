export { default } from '@admindroid/shared-components/components/tool-header/tenant-switch-dropdown';
