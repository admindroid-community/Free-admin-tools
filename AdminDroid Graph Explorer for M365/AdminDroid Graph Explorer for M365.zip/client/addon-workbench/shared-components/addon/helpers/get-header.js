import { helper } from '@ember/component/helper';

export default helper(function getHeader([data]) {
  if (Array.isArray(data)) {
    // Handle array of objects
    const keySet = new Set();
    data.forEach((item) => {
      if (typeof item === 'object' && item !== null) {
        Object.keys(item).forEach((key) => keySet.add(key));
      }
    });
    return Array.from(keySet);
  } else if (typeof data === 'object' && data !== null) {
    // Handle single object
    return Object.keys(data);
  } else {
    // Fallback for non-object types
    return [];
  }
});
