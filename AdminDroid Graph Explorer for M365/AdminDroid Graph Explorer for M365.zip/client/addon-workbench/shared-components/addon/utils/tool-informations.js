const TOOL_INFORMATIONS = {
  APP_DETAILS: {
    name: 'AdminDroid Community Tool',
    author: 'AdminDroid',
    shortName: "Community Tool" 
  },
  MODULE_M365: {
    id: 'm365',
    name: 'AI assistant for Microsoft 365',
  },
  MODULE_AD: {
    id: 'ad',
    name: 'AI assistant for Active Directory',
  },
  MODULE_GRAPH_EXPLORER: {
    id: 'graph-explorer',
    name: 'Graph Explorer for M365',
  },
  MODULE_LDAP_EXPLORER: {
    id: 'ldap-explorer',
    name: 'LDAP Explorer',
  },
};

const AUTH_TYPES = {
  AD: {
    id: 'ad',
    name: 'Active Directory',
  },
  M365: {
    id: 'm365',
    name: 'Microsoft 365',
  },
};

const CHAT_STORAGE_CONFIG = {
  AD: {
    engineType: 'AD',
    dbStorageKeys: {
      history: 'historyStorageAD',
      aiHistory: 'aiHistoryStorageAD',
    },
    storeNames: {
      history: 'adChatStorage',
      aiHistory: 'modelAdChatStorage',
    },
    localStorageKeys: {
      provider: 'providerChatAD',
      model: 'modelChatAD',
      selectedIndex: '_selectedIndexAD',
      isResponseTabOpen: 'isResponseTabOpenAD'
    },
  },
  M365: {
    engineType: 'M365',
    dbStorageKeys: {
      history: 'historyStorageM365',
      aiHistory: 'aiHistoryStorageM365',
    },
    storeNames: {
      history: 'm365ChatStorage',
      aiHistory: 'modelM365ChatStorage',
    },
    localStorageKeys: {
      provider: 'providerChatM365',
      model: 'modelChatM365',
      selectedIndex: '_selectedIndexM365',
      isResponseTabOpen: 'isResponseTabOpenM365' 
    },
  },
};

export { TOOL_INFORMATIONS, AUTH_TYPES, CHAT_STORAGE_CONFIG };
