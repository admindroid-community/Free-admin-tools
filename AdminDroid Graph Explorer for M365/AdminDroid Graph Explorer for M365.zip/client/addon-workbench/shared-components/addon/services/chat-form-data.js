import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { TrackedArray } from 'tracked-built-ins';
import { CHAT_STORAGE_CONFIG } from '@admindroid/shared-components/utils/tool-informations';

export default class BaseChatFormDataService extends Service {
  history = [];
  historyMaskValues = {};
  promptChat = null;
  @tracked isMasked = false;
  isJSONOperation = false;
  promptTable = null;
  @service chatStorage;

  @tracked maskedInfoPopupCount = 0;

  /**
   * Override this in child classes to return the engine type ('AD' or 'M365')
   * @returns {string} The engine type key from CHAT_STORAGE_CONFIG
   */
  get engineType() {
    throw new Error('engineType getter must be implemented in the child class');
  }

  /**
   * Override this in child classes to return the appropriate chat storage service
   * @returns {Service} The chat storage service instance
   */
  get chatStorageService() {
    throw new Error(
      'chatStorageService getter must be implemented in the child class',
    );
  }

  /**
   * Gets the storage configuration for the current engine
   * @returns {Object} The storage configuration
   */
  get storageConfig() {
    return CHAT_STORAGE_CONFIG[this.engineType];
  }

  /**
   * Gets the AI history storage key from configuration
   * @returns {string} The storage key for IndexedDB
   */
  get storageKey() {
    return this.storageConfig.dbStorageKeys.aiHistory;
  }

  @action
  updateData(field, data) {
    if (Array.isArray(this[field])) {
      this[field].push(data);
    }
  }

  @action
  async updateChatStorage(field, response, isSetEntirely) {
    if (this.chatStorage?.isNewConversation) {
      return;
    }
    let data =
      (await this.chatStorageService.getIndexDBData('0', this.storageKey)) ||
      {};
    let dbField = field == 'history' ? 'conversations' : field;
    let dbData =
      (await data?.[dbField]) || (dbField == 'conversations' ? [] : {});

    if (isSetEntirely) {
      dbData = response;
    } else {
      dbData.push(response);
    }

    data[dbField] = dbData;
    await this.chatStorageService.setIndexDBData('0', data, this.storageKey);
    this[field] = dbData;
  }

  @action
  setData(field, data) {
    this[field] = data;
  }

  @action
  async clearAllData() {
    await this.chatStorageService.deleteAllIndexDBData('0', this.storageKey);
    this.historyMaskValues = {};
    this.history = [];
    this.isJSONOperation = false;
  }

  @action
  async getAllChatHistory() {
    let res = await this.chatStorageService.getIndexDBData(
      '0',
      this.storageKey,
    );
    this.history = res?.conversations ?? [];
    this.historyMaskValues = res?.historyMaskValues ?? {};
    if (this.chatStorageService.chatStorage?.length) {
      let lastData =
        this.chatStorageService.chatStorage[
          this.chatStorageService.chatStorage.length - 1
        ];
      let key = this.getAIResponseTextKey(lastData);
      this.isJSONOperation = lastData[key][0].text?.json ? true : false;
    }
  }

  // @action
  // getAllChatHistory() {
  //   let datas = JSON.parse(JSON.stringify(this.chatStorageService.chatStorage));
  //
  //   datas.forEach((data) => {
  //     let key = this.getAIResponseTextKey(data);
  //     let entry = data[key]?.[0]; // first element safely
  //
  //     if (!entry) return; // skip if missing
  //
  //     // --- 1. Replace tableData / chartData with message
  //     if (entry.text?.tableData || entry.text?.chartData) {
  //       entry.text = 'Data successfully generated';
  //     }
  //
  //     // --- 3. Remove `isSuccess` inside text object
  //     if (
  //       entry.text &&
  //       typeof entry.text === 'object' &&
  //       'isSuccess' in entry.text
  //     ) {
  //       delete entry.text.isSuccess;
  //     }
  //
  //     // --- 4. Remove `masked` if it exists at same level
  //     if ('masked' in entry) {
  //       delete entry.masked;
  //     }
  //
  //     if (this.chatStorageService.providerChat.name == 'Gemini') {
  //       if (typeof entry.text !== 'string') {
  //         entry.text = JSON.stringify(entry.text ?? '');
  //       }
  //     } else {
  //       if (typeof data[key] !== 'string') {
  //         data[key] = JSON.stringify(data[key] ?? '');
  //       }
  //     }
  //   });
  //
  //   this.history = datas;
  // }

  getAIResponseTextKey(obj) {
    if (!obj) {
      return null;
    }
    for (const [key, value] of Object.entries(obj)) {
      if (Array.isArray(value) && value[0].text) {
        return key;
      }
    }
    return null;
  }
}
