import Application from '@ember/application';
import Resolver from 'ember-resolver';
import loadInitializers from 'ember-load-initializers';
import 'ember-power-select/styles';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';
import config from 'community-base-tool/config/environment';

export default class App extends Application {
  modulePrefix = config.modulePrefix;
  podModulePrefix = config.podModulePrefix;
  Resolver = Resolver;

  engines = {
    [TOOL_INFORMATIONS.MODULE_GRAPH_EXPLORER.id]: {
      dependencies: {
        services: [
          'router',
          { 'authentication-m365': 'authentication-microsoft-365' },
          'settings-data',
          'engine-registry',
          'user',
          'index-db-storage',
          { 'tool-information': 'tool-info' },
          'flashMessages',
        ],
      },
    }
  };
}

loadInitializers(App, config.modulePrefix);
