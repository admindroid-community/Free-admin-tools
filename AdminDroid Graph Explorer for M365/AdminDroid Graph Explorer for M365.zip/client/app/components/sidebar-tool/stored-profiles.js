import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';

export default class StoredProfilesComponent extends Component {
  @service router;
  @service('user') userService;
  @service('tool-info') toolInfoService;
  @service('authentication-active-directory') authenticationAD;
  @service('authentication-microsoft-365') authenticationM365;

  @tracked isDeleteModalOpen = false;
  @tracked selectedProfile = null;

  get authDetails() {
    return AUTH_TYPES
  }
  @action
  async handleProfileClick(data) {
    //console.log('handleProfileClick called', data);
    if (this.args.profilePopup) {
      this.args.togglePopup('profilePopup');
    }

    if (this.args.authType == AUTH_TYPES.AD.id) {
      let foundAccount = this.authenticationAD.sessionData?.find(
        (item) => item.userBindID == data.userBindID,
      );
      if (foundAccount) {
        await this.userService.sessionSwitchAccount(AUTH_TYPES.AD.id, foundAccount)
        this.authenticationAD.loginFormAdPopup = false
        return
      }
      this.userService.openADLoginForm(data)
    } else if (this.args.authType == AUTH_TYPES.M365.id) {
      let foundAccount = this.authenticationM365.sessionData.find(
        (i) => i.username == data.username,
      );
      if (foundAccount) {
        await this.userService.sessionSwitchAccount(AUTH_TYPES.M365.id, foundAccount);
        return;
      }
      await this.userService.login.perform(this.userService.authType, {
        mode: 'accountSpecific',
        loginHint: data.username,
      });
    } else {
      console.warn('Invalid auth type');
    }
  } 

  @action
  handleMoreModal(profile, event) {
    event.stopPropagation();
    this.selectedProfile = profile;
    this.isDeleteModalOpen = !this.isDeleteModalOpen;
    //console.log("handleMoreModal")
  }

  @action
  closeDeleteModal() {
    this.selectedProfile = null;
    this.isDeleteModalOpen = false;
  }

  @action
  async deleteProfile(profile) {
    if (this.args.authType == 'ad') {
      await this.authenticationAD.deleteProfile(profile);
    } else if (this.args.authType == 'm365') {
      await this.authenticationM365.deleteProfile(profile);
    } else {
      console.warn('Invalid auth type');
      return;
    }
  }
}
