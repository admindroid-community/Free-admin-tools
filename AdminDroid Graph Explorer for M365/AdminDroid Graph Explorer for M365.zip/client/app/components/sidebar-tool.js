import Component from '@glimmer/component';
import { service } from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import config from 'community-base-tool/config/environment';
import logger from '../utils/logger';
import { task } from 'ember-concurrency';
import localStorageUtils from '../utils/local-storage-utils';
import sessionStorageUtils from '../utils/session-storage-utils';
import { AUTH_TYPES, TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

export default class SidebarToolComponent extends Component {
  @service('engine-registry') engineRegistry;
  @service('tool-info') toolInfoService;
  @service('authentication-active-directory') authenticationAD;
  @service('authentication-microsoft-365') authenticationM365;
  @service('user') userService;
  @service('update-app') updateAppService;
  @service router;
  @service('settings-data') settingsDataService;
  @service('tool-installer') toolInstaller;

  @tracked profilePopup = false;
  @tracked baseToolPopup = true;
  // Onboarding popups now managed by toolInstaller

  get baseToolList() {
    return this.toolInfoService.baseToolList;
  }
  get apiHost() {
    return config.APP.apiHost;
  }
  get user() {
    if (
      this.userService.authType == AUTH_TYPES.AD.id &&
      this.authenticationAD.currentActiveUser
    ) {
      return this.authenticationAD.currentActiveUser;
    } else if (
      this.userService.authType == AUTH_TYPES.M365.id &&
      this.authenticationM365.currentActiveUser
    ) {
      return this.authenticationM365.currentActiveUser;
    }
    return null;
  }

  get authType() {
    return this.userService.authType;
  }

  get appDetails() {
    return TOOL_INFORMATIONS.APP_DETAILS
  }

  get currentAppDetails() {
    return (
      Object.values(TOOL_INFORMATIONS)
        .find(tool => tool.id === this.currentActiveTool)
        ?.name || TOOL_INFORMATIONS.APP_DETAILS.shortName
    );
  }

  get storedData() {
    if (this.userService.authType == AUTH_TYPES.AD.id && this.authenticationAD.storedData) {
      return this.authenticationAD.storedData;
    } else if (
      this.userService.authType == AUTH_TYPES.M365.id &&
      this.authenticationM365.storedProfileData
    ) {
      return this.authenticationM365.storedProfileData;
    }
    return null;
  }

  get currentActiveTool() {
    return this.toolInfoService.currentActiveTool;
  }

  get mandatoryTools() {
    return this.updateAppService.availableUpdates
      ?.filter((tool) => tool.isMandatory)
      .map((tool) => tool.moduleId);
  }

  get activatedTab() {
    return this.settingsDataService.activatedTab;
  }

  getCurrentAppID() {
    const url = new URL(window.location.href);
    const parts = url.pathname.split('/').filter(Boolean);
    const segment = parts[0];
    return segment;
  }

  // Removed local installer state (handled in toolInstaller)

  handleProfileClick = task({ drop: true }, async () => {
    // let type =
    //   this.toolInfoService.currentActiveTool === 'ad' ||
    //     this.toolInfoService.currentActiveTool === 'ldapExplorer'
    //     ? 'ad'
    //     : this.toolInfoService.currentActiveTool === 'm365' ||
    //       this.toolInfoService.currentActiveTool === 'graphExplorer'
    //       ? 'm365'
    //       : null;
    let type = this.userService.authType;

    if (!type) {
      logger.warn('Invalid auth type');
      return;
    }

    if (type == AUTH_TYPES.AD.id) {
      if (this.user) {
        this.togglePopup('profilePopup');
      } else {
        this.userService.openADLoginForm()
      }
    } else if (type == AUTH_TYPES.M365.id) {
      if (this.user) {
        this.togglePopup('profilePopup');
      } else {
        // console.log('No user found, initiating login...');
        await this.userService.login.perform(type, {
          mode: 'login',
          loginHint: '',
        });
      }
    }
  });

  @action
  async handleToolImport(item) {
    if (this.getCurrentAppID() == item.moduleId) {
      return;
    }
    this.toolInstaller.selectedTool = item;
    if (item.isEnabled) {
      if (this.mandatoryTools.includes(item.moduleId)) {
        this.updateAppService.isToolUpdatePopup = true;
      } else {
        this.toolInfoService.isToolLoading = true;
        this.router.transitionTo(`index.${item.moduleId}`);
        this.settingsDataService.activatedTab = null;
      }
    } else {
      // Persist intended selection early so index route picks it correctly post‑install
      sessionStorageUtils.set('currentActiveTool', item.moduleId);
      localStorageUtils.set('currentActiveTool', item.moduleId);
      this.toolInstaller.beginInstall(item);
    }
  }

  @action
  navigateHome() {
    this.toolInfoService.currentActiveTool = null;
    this.settingsDataService.activatedTab = null;
    this.router.transitionTo('home');
  }

  @action
  async importTool(compatibilityUpdate) {
    return this.toolInstaller.importTool(compatibilityUpdate);
  }

  @action
  togglePopup(name) {
    this[name] = !this[name];
  }

  @action
  async handleLogout() {
    this.togglePopup('profilePopup');
    await this.userService.logout(this.userService.authType);
  }

  @action
  async handleAddAccount() {
    this.togglePopup('profilePopup');
    if (this.userService.authType == AUTH_TYPES.AD.id) {
      this.userService.openADLoginForm(null, true)
    } else {
      await this.userService.login.perform(this.userService.authType, {
        mode: 'addAccount',
        loginHint: '',
      });
    }
  }

  @action
  moveToSettings() {
    this.router.transitionTo('settings');
  }
}
