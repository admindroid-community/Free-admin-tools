import Component from '@glimmer/component';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

import permissions from 'graph-explorer/utils/permissions';

import { action } from '@ember/object';
import { service } from '@ember/service';
import { tracked } from 'tracked-built-ins';
import { debounce } from '@ember/runloop';
import { task } from 'ember-concurrency';
export default class ConsentPermission extends Component {
  @service('authentication-microsoft-365') authenticationM365;
  @service flashMessages;
  @service('engine-registry') engineRegistryService;

  get commonDataService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_GRAPH_EXPLORER.id,
      'common-data',
    );
  }

  @tracked permissionInput = '';
  @tracked categories = permissions;
  @tracked permissionType = this.permissionsList[2];
  @tracked permissionsList = [
    'Consented permissions',
    'Unconsented permissions',
    'All permissions',
  ];

  @tracked consentPermissionMessage = null
  @tracked selectedPermission = null

  get user() {
    return this.authenticationM365.currentActiveUser;
  }

  filteredCategories() {
    const input = this.permissionInput.trim().toLowerCase();

    if (
      (this.permissionType === null ||
        this.permissionType === 'All permissions') &&
      input === ''
    ) {
      this.categories = structuredClone(permissions);
      return;
    }

    const filteredData = [];

    for (let cat of structuredClone(permissions)) {
      const currentpermissions = cat.permission.filter((permission) => {
        if (!permission.name.toLowerCase().includes(input)) return false;

        if (
          this.permissionType === null ||
          this.permissionType === 'All permissions'
        ) {
          return true;
        } else if (this.permissionType === 'Consented permissions') {
          return this.isConsentAvailableWithUser(permission.name);
        } else {
          return !this.isConsentAvailableWithUser(permission.name);
        }
      });

      if (currentpermissions.length) {
        cat.permission = currentpermissions;
        filteredData.push(cat);
      }
    }

    this.categories = filteredData;
  }

  @action
  isConsentAvailableWithUser(value) {
    if (this.user && Array.isArray(this.user.scopes)) {
      return this.user.scopes.includes(value);
    }
    return false;
  }

  @action
  isUserHasBasicScopes() {
    if (Array.isArray(this.user.scopes)) {
      return (
        this.user.scopes.includes('Directory.Read.All') &&
        this.user.scopes.includes('DelegatedPermissionGrant.ReadWrite.All')
      );
    }
  }

  handleConsent = task({ drop: true }, async (permission) => {
    this.selectedPermission = permission
    if (this.isConsentAvailableWithUser(permission)) {
      if (await this.authenticationM365.getUnconsent(permission)) {
        this.consentPermissionMessage =
          `Consent for "${permission}" has been successfully revoked. Please wait a moment and sign in again to see the changes.`;
        this.consentPermissionMessageSuccess = true;
      } else {
        this.consentPermissionMessage =
          `Consent for "${permission}" could not be revoked. Please try again later or sign in again to check the status.`;
        this.consentPermissionMessageSuccess = false;
      }

    } else {
      if (await this.authenticationM365.getConsent([permission])) {
        this.consentPermissionMessage = `${permission} access granted`
        this.consentPermissionMessageSuccess = true
      }
      else {
        this.consentPermissionMessage = `${permission} access denied`
        this.consentPermissionMessageSuccess = false
      }
    }

    this.selectedPermission = null
  })

  @action choosePermissionType(perType) {
    this.permissionType = perType;
    this.filteredCategories();
  }

  @action onPermissionInput(e) {
    this.permissionInput = e.target.value;
    debounce(this, this.filteredCategories, 300);
  }

  @action onPermissionSelect(index) {
    let allPermissionCategories = document.querySelectorAll(
      '.permissionCategory',
    );

    let reqPermissionCategory = Array.from(allPermissionCategories)[index];
    reqPermissionCategory.classList.toggle('expand');
    let permissionTable =
      reqPermissionCategory.querySelector('.permissionTable');

    if (reqPermissionCategory.classList.contains('expand')) {
      permissionTable.style.height = 'auto';
    } else {
      permissionTable.style.height = '0';
    }
  }

  @action
  onClose() {
    this.commonDataService.isPermissionsModalVisible = false
  }

  @action
  closeConsentMessageWarning() {
    this.consentPermissionMessage = null
  }
}
