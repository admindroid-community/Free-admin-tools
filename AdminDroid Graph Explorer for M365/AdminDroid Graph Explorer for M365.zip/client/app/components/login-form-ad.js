import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { task } from 'ember-concurrency';
import { tracked } from 'tracked-built-ins';

export default class LoginComponent extends Component {
  @service('authentication-active-directory') authenticationAD;
  @service('user') userService;
  @service('tool-info') toolInfoService;
  @service router;
  @tracked isPasswordVisible;

  constructor() {
    super(...arguments);

    let storedData = this.authenticationAD.storedData ?? {};
    let keys = Object.keys(storedData);
    if (keys.length === 1 && !this.authenticationAD.addNewUser) {
      this.authenticationAD.storeProfileData(storedData[keys[0]]);
    }

    this.authenticationAD.isFormUI = this.authenticationAD.existingUser
      ? true
      : this.authenticationAD.addNewUser
        ? true
        : keys.length == 1 ||
          !keys.length
          ? true
          : false;
  }

  get username() {
    return this.authenticationAD.username;
  }
  get domainName() {
    return this.authenticationAD.ipAddress ?? this.authenticationAD.domainName;
  }
  get bindPassword() {
    return this.authenticationAD.bindPassword;
  }
  get isStoreDetails() {
    return this.authenticationAD.isStoreDetails;
  }
  get isUPN() {
    return this.authenticationAD.isUPN;
  }
  get isAnonymousDataStored() {
    return this.authenticationAD.isAnonymousDataStored;
  }
  get updateData() {
    return this.authenticationAD.updateInputData;
  }

  get sessionData() {
    return this.authenticationAD.sessionData;
  }
  get currentActiveUser() {
    return this.authenticationAD.currentActiveUser;
  }
  get storedData() {
    return this.authenticationAD.storedData;
  }

  get isFormUI() {
    return this.authenticationAD.isFormUI;
  }

  get toggleIsFormUI() {
    return this.authenticationAD.toggleIsFormUI;
  }

  get existingUser() {
    return this.authenticationAD.existingUser;
  }

  get isBindDNAvailable() {
    return this.authenticationAD.isBindDNAvailable;
  }

  get bindDNMsg() {
    return this.authenticationAD.bindDNMsg;
  }

  get loginFormErrorMsg() {
    return this.authenticationAD.loginFormErrorMsg;
  }

  get authType() {
    return this.userService.authType;
  }

  handleSubmit = task({ drop: true }, async (event) => {
    event.preventDefault();
    // const response = yield this.authenticationAD.checkBindDN();
    // if (!response.isAvailable) {
    //   alert("binddn", res.message)
    //   return
    // }

    if (!this.authenticationAD.domainName) {
      this.authenticationAD.loginFormErrorMsg =
        'Domain name is required to connect';
      return;
    }
    if (!this.authenticationAD.username) {
      this.authenticationAD.loginFormErrorMsg =
        'Username is required to connect';
      return;
    }
    if (!this.authenticationAD.bindPassword) {
      this.authenticationAD.loginFormErrorMsg =
        'Password is required to connect';
      return;
    }

    this.authenticationAD.loginFormErrorMsg = null
    await this.userService.login.perform('ad');

    if (!this.authenticationAD.loginFormErrorMsg) {
      this.authenticationAD.resetData();
      this.authenticationAD.loginFormAdPopup = false;
    }
  });

  @action
  closeLogin() {
    this.authenticationAD.resetData();
    this.authenticationAD.loginFormAdPopup = false;
  }

  get isStoredDataAvailable() {
    return Object.keys(this.authenticationAD.storedData).length > 1 || (Object.keys(this.storedData).length == 1 && !this.authenticationAD.currentActiveUser ? true : false);
  }

  @action
  handleCreateAnAccount() {
    this.authenticationAD.existingUser = false;
    this.authenticationAD.resetData();
    this.toggleIsFormUI();
  }

  @action
  togglePasswordVisibility() {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  willDestroy() {
    this.authenticationAD.resetData()
  }
}
