import Component from '@glimmer/component';
import { service } from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';

export default class ToolOnboardingInfoComponent extends Component {
  @service authenticationAd;
  @service router;
  @service('chat-form-data') chatFormDataService;
  @service('update-app') updateAppService;

  @tracked isCompatibilityUpdate = true;

  get compatibilityCheck() {
    return this.updateAppService.compatibilityCheck;
  }

  get isCompatibilityUpdateAvailable() {
    return this.compatibilityCheck.some((item) => item.isMandatory ?? false);
  }

  @action
  getFeatureIndex(index, maxIndex = 4) {
    return index % maxIndex
  }

  @action
  updateData() {
    this.isCompatibilityUpdate = !this.isCompatibilityUpdate;
  }
}
