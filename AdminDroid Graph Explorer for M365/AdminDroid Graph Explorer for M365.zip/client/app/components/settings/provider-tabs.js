import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { task } from 'ember-concurrency';

export default class SidebarComponent extends Component {
  @service('ai-providers') AIProviderService;
  @service('encrypt-and-decrypt') encryptAndDecryptService;
  @service router;

  @tracked isApikeyFormOpen = false;
  @tracked newApikey = '';
  @tracked apikeyName = '';
  @tracked visibleApikeyData = null;
  @tracked apikeyFormError = '';

  get providers() {
    return this.AIProviderService.providers;
  }
  get selectedAIProvider() {
    return this.AIProviderService.selectedAIProvider;
  }
  get providersLocal() {
    return this.AIProviderService.providersLocal;
  }
  @action
  handleProviderTabClick(provider) {
    // this.AIProviderService.setData("selectedAIProvider", provider)
    this.isApikeyFormOpen = false;
    this.apikeyFormError = null;

    this.router.transitionTo({ queryParams: { providerName: provider.name } });
  }

  @action
  handleAddNewApikey() {
    this.isApikeyFormOpen = true;
  }

  @action
  maskedApiKey(key) {
    if (!key || key.length <= 5) return key;
    const visible = key.slice(-5);
    return '*'.repeat(key.length - 5) + visible;
  }

  handleApikeySubmit = task({ drop: true }, async (provider, event) => {
    event.preventDefault();
    // if (!this.apikeyName) {
    //     this.apikeyFormError = 'Key name is required to label the API key'
    //     return
    // }
    if (!this.newApikey) {
      this.apikeyFormError = 'API key required';
      return;
    }

    let encrypted = this.encryptAndDecryptService.encryption(
      this.newApikey.trim(),
    );

    const res = await this.AIProviderService.setApiKey(
      {
        provider: provider,
        // keyName: this.apikeyName,
        apiKey: encrypted,
      },
      'POST',
    );

    if (!res || !res.isSuccess) {
      this.apikeyFormError =
        res.message || 'Invalid API key, recheck and try again';
      return;
    }
    this.newApikey = '';
    // this.apikeyName = ''
  });

  @action
  async handleApikeyEnable(provider, keyName, event) {
    event.preventDefault();
    if (!event.target.checked) {
      event.target.checked = true;
      return;
    }
    await this.AIProviderService.setApiKey(
      {
        provider: provider,
        keyName: keyName,
      },
      'PATCH',
    );
  }

  @action
  async handleApikeyDelete(provider, keyName, event) {
    event.preventDefault();

    await this.AIProviderService.setApiKey(
      {
        provider: provider,
        keyName: keyName,
      },
      'DELETE',
    );
  }

  @action
  updateData(event) {
    const { name, value } = event.target;
    this[name] = value;
    this.apikeyFormError = null;
  }

  @action
  scrollToRight(element) {
    element.scrollLeft = element.scrollWidth;
  }

  @action
  handleApikeyVisibility(key) {
    if (!key) {
      this.visibleApikeyData = null;
    } else {
      this.visibleApikeyData = key;
    }
  }

  @action
  setData(field, value) {
    this[field] = value;
  }
}
