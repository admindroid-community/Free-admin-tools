import Component from '@glimmer/component';
import { htmlSafe } from '@ember/template';

export default class ProviderSetupGuideComponent extends Component {
  get providerInstructions() {
    const provider = this.args.provider;
    const url = this.args.url;

    return [
      {
        step: `Go to the ${provider} Developer Console`,
        detail:
          htmlSafe(`Visit the official <a href=${url} target="_blank" class="highlight-url">
          <span>${provider} Developer Portal
          <span class="droid-custom-icon-external icon"></span></span></a>`),
      },
      {
        step: 'Sign In or Create an Account',
        detail: `Log in with your existing account or complete the sign-up process.`,
      },
      {
        step: 'Verify Your Identity (if required)',
        detail: `${provider} may require phone or email verification.`,
      },
      {
        step: "Navigate to the 'API Keys' Section",
        detail:
          'Look for a menu or tab labeled API Keys, Access Tokens, or something similar.',
      },
      {
        step: "Click 'Create API Key'",
        detail:
          'Generate a new API key and optionally name it for easy identification.',
      },
      {
        step: 'Copy the Generated API Key',
        detail:
          'Copy the generated API key immediately and store it safely for your records.',
      },
    ];
  }
}
