import Component from '@glimmer/component';

export default class SidebarComponent extends Component {
  exampleMaskData = [
    {
      name: 'Usernames & User IDs',
      icon: 'custom-icon-user',
    },
    {
      name: 'Email Addresses',
      icon: 'custom-icon-mail-medium',
    },
    {
      name: 'Phone Numbers & Contact Info',
      icon: 'custom-icon-call',
    },
    {
      name: 'Passwords & API Keys',
      icon: 'custom-icon-password',
    },
  ];


  maskingData = [
    {
      type: 'Automatic Masking',
      examples: [
        { input: 'Create user john.doe@contoso.com', aiSees: 'Create user {{mail}}' }
      ],
      iconType: "🧠"
    },
    {
      type: 'Custom Masking',
      examples: [
        { input: 'Get details of group “Finance Managers”', aiSees: 'Get details of group {{group1}}' }
      ],
      iconType: "✍️"
    },
    {
      type: 'Unmasked',
      examples: [
        { input: 'Get details of group Finance Managers', aiSees: 'Get details of group Finance Managers' }
      ],
      iconType: "🔓"
    }
  ];
}
