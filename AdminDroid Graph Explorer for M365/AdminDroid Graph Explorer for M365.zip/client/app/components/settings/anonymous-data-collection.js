import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';
import localStorageUtils from '../../utils/local-storage-utils';

export default class AnonymousDataCollectionComponent extends Component {
  @service('anonymous-data-tracking') anonymousDataTrackingService;

  get anonymousDataTracking() {
    return this.anonymousDataTrackingService.anonymousDataTracking;
  }

  @action
  updateAnonymousData(event) {
    localStorageUtils.set('anonymousDataTracking', event.target.checked);
    this.anonymousDataTrackingService.setData(
      'anonymousDataTracking',
      event.target.checked,
    );
  }
}
