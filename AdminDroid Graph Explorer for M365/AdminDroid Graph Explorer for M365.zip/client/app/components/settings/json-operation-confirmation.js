import Component from '@glimmer/component';
import { action } from '@ember/object';
import { service } from '@ember/service';
import localStorageUtils from '../../utils/local-storage-utils';

export default class AnonymousDataCollectionComponent extends Component {
  @service('settings-data') settingsDataService;

  get askConfimationBeforeAccess() {
    return this.settingsDataService.askConfimationBeforeAccess;
  }

  @action
  updateAskConfirmationData(event) {
    localStorageUtils.set('askConfimationBeforeAccess', event.target.checked);
    this.settingsDataService.setData(
      'askConfimationBeforeAccess',
      event.target.checked,
    );
  }
}
