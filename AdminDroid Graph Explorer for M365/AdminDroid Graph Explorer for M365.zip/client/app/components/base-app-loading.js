import Component from '@glimmer/component';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';
import config from 'community-base-tool/config/environment';

export default class BaseAppLoadingComponent extends Component {

    get appDetails() {
        return {
            ...TOOL_INFORMATIONS.APP_DETAILS,
            version: config.APP.version
        }
    }

}
