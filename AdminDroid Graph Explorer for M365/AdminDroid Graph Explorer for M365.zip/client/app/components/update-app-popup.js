import Component from '@glimmer/component';
import { service } from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { apiRequest } from '../utils/api-service';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

export default class UpdateAppPopupComponent extends Component {
  @service('update-app') updateAppService;
  @service('tool-info') toolInfoService;
  @service router;
  @service flashMessages;

  get appDetails() {
    return TOOL_INFORMATIONS.APP_DETAILS
  }

  get filteredUpdates() {
    return this.updateAppService.filteredUpdates(this.args.updateAppData)
  }

  get compatibilityTools() {
    return this.updateAppService.compatibilityCheck
      ?.filter((tool) => tool.isMandatory)
      .map((tool) => tool.moduleId);
  }

  get mandatoryTools() {
    return this.updateAppService.availableUpdates
      ?.filter((tool) => tool.isMandatory)
      .map((tool) => tool.moduleId);
  }

  @action
  async handleUpdateApp() {
    if (!this.selectedTools.length) {
      this.flashMessages.warning(
        'Oops! You need to select at least one tool to update.',
        {
          timeout: 10000,
          preventDuplicates: true,
        },
      );
      return;
    }
    this.updateAppService.setData('isToolUpdatePopup', false);
    this.updateAppService.setData('updateAllAppPopup', true);
    await this.updateAppService.UpdateAllApps.unlinked().perform(
      this.selectedTools,
    );

    if (this.updateAppService.isBaseServerUpdate) {
      return
    }
    if (!this.updateAppService.isErrorOccured) {
      const restartResponse = await this.updateAppService.restartApp();

      let maxAttempt = 3;
      if (restartResponse) {
        const intervalId = setInterval(async () => {
          --maxAttempt;
          const statusResponse = await apiRequest(
            '/module/import-status',
            'POST',
            { moduleId: this.selectedTools[this.selectedTools.length - 1] },
          );
          if (statusResponse.isSuccess) {
            this.delay(1000)
            window.location.reload(true);
            clearInterval(intervalId);
          }

          if (!maxAttempt && !statusResponse.isSuccess) {
            this.updateAppService.isErrorOccured = true
            clearInterval(intervalId);
          }
        }, 9000);
      }
    }

    // else {
    //   await this.delay(5000);
    // }
  }
  delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  @tracked selectedTools = [];

  constructor() {
    super(...arguments);
    if (Array.isArray(this.args.updateAppData)) {
      this.selectedTools = this.args.updateAppData.map((d) => d.moduleId);
    }

    this.updateAppService.updateCurrentDateAndTime();
  }

  @action
  isModuleAvailable(data) {
    return this.selectedTools.includes(data.moduleId);
  }

  @action
  handleToolSelection(data) {
    if (data.isMandatory) {
      return;
    } else if (this.selectedTools.includes(data.moduleId)) {
      this.selectedTools = this.selectedTools.filter(
        (item) => item !== data.moduleId,
      );
    } else {
      this.selectedTools = [...this.selectedTools, data.moduleId];
    }
  }

  @action
  handleClose() {
    this.updateAppService.setData('isToolUpdatePopup', false);
  }
}
