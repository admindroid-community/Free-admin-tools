import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { apiRequest } from '../utils/api-service';
import { action } from '@ember/object';
import { task, timeout } from 'ember-concurrency';
import localStorageUtils from '../utils/local-storage-utils';

export default class UpdateAppService extends Service {
  @tracked availableUpdates = null;
  @tracked isToolUpdatePopup = false;
  @tracked isBaseServerUpdate = false;
  @tracked isErrorOccured = false;
  @tracked currentUpdateTool = null;
  @tracked updateAllAppPopup = false;
  @tracked compatibilityCheck = [];

  @action
  async checkUpdate() {
    try {
      const response = await apiRequest(`/module/update-check`, 'GET', null);
      this.availableUpdates = response.updateToolsList || [];
      this.compatibilityCheck = response.compatibilityToolsList || [];
      this.baseAppDetails = response.baseUpdate;
      this.isToolUpdatePopup =
        this.availableUpdates?.length && this.checkUpdateBannerStatus()
          ? true
          : false;
    } catch (error) {
      console.error("checkUpdate", error)
      return error
    }
  }

  @action
  filteredUpdates(updateList) {
    const updates = updateList || this.availableUpdates || [];
    const ignoreList = ["tool", "baseServer"];

    if (updates.length === 0) {
      return [];
    }

    const baseUpdates = updates.filter(u => ignoreList.includes(u.moduleId));
    const nonBaseUpdates = updates.filter(u => !ignoreList.includes(u.moduleId));

    // Rule 2: only one update and it's a base update → show it
    if (updates.length === 1 && baseUpdates.length === 1) {
      return updates;
    }

    // Rule 3: all updates are base updates → show only baseServer
    if (baseUpdates.length === updates.length) {
      return baseUpdates.filter(u => u.moduleId === "baseServer");
    }

    // Rule 1 & 4: normally hide base updates
    return nonBaseUpdates;
  }


  UpdateAllApps = task({ drop: true }, async (selectedTools) => {
    const hasBaseServerUpdate = this.availableUpdates.some(item => item.moduleId === "tool");

    if (hasBaseServerUpdate && !selectedTools.includes("tool")) {
      selectedTools.push("tool");
    }
    for (const tool of selectedTools) {
      const res = await this.updateTool(tool);
      await timeout(500);
      if (!res || !res.isSuccess) {
        this.setData('isErrorOccured', true);
        return;
      } else if (res.isSuccess && tool == "tool") {
        this.isBaseServerUpdate = true;
        return
      }
    }
  });

  @action
  async updateTool(tool) {
    const toolUpdate = this.availableUpdates.find((t) => t.moduleId === tool);
    this.currentUpdateTool = toolUpdate;
    if (toolUpdate) {
      try {
        let response = await apiRequest(`/module/update`, 'POST', {
          moduleId: toolUpdate.moduleId,
          url: toolUpdate.url,
          version: toolUpdate.version,
        });

        return response;
      } catch (error) {
        return null;
      }
    }
    return null;
  }

  @action
  async restartApp() {
    return await apiRequest('/restart', 'POST');
  }

  @action
  setData(field, value) {
    this[field] = value;
  }

  // @action
  // updateCurrentDateAndTime() {
  //     localStorage.updateBannerDateAndTime = JSON.stringify({
  //         date: new Date().toLocaleDateString(),
  //         time: new Date().toLocaleTimeString([], { hour12: false })
  //     });
  // }

  // checkUpdateBannerStatus() {
  //     let data = localStorage.updateBannerDateAndTime;

  //     if (!data) {
  //         return true; // No previous data stored
  //     }

  //     try {
  //         data = JSON.parse(data);
  //     } catch (e) {
  //         return true; // If JSON parsing fails, treat as no data
  //     }

  //     const storedDate = data.date;
  //     const storedTime = data.time;

  //     const now = new Date();
  //     const todayDate = now.toLocaleDateString();

  //     if (storedDate === todayDate) {
  //         // Combine storedDate and storedTime into a Date object
  //         const storedDateTime = new Date(`${storedDate} ${storedTime}`);
  //         console.log(this.storedDateTime)

  //         // Calculate time difference in milliseconds
  //         const diffMs = now - storedDateTime;

  //         // Convert milliseconds to hours
  //         const diffHours = diffMs / (1000 * 60 * 60);

  //         console.log('hy', diffHours)
  //         if (diffHours >= 3) {
  //             return true; // More than or equal to 3 hours passed
  //         } else {
  //             return false; // Less than 3 hours
  //         }
  //     } else {
  //         return true; // Date is not today
  //     }
  // }

  // @action
  // updateCurrentDateAndTime() {
  //   localStorageUtils.set('updateBannerDateAndTime', new Date().toISOString());
  // }

  // checkUpdateBannerStatus() {
  //   let data = localStorageUtils.get('updateBannerDateAndTime');

  //   if (!data) {
  //     return true;
  //   }

  //   const now = new Date();
  //   const stored = new Date(data);
  //   const diffMs = now - stored;
  //   const diff = diffMs / (1000 * 60 * 60);

  //   return diff > 3;
  // }

  @action
  updateCurrentDateAndTime() {
    const todayStr = new Date().toISOString().split('T')[0]; // 'YYYY-MM-DD'
    localStorageUtils.set('updateBanner', {
      date: todayStr,
      version: this.baseAppDetails?.version
    });
  }

  checkUpdateBannerStatus() {
    const storedData = localStorageUtils.get('updateBanner');

    // if no data is found, return true to show update banner
    if (!storedData || !storedData.date || !storedData.version) {
      return true;
    }

    const storedDate = storedData.date;
    const storedVersion = storedData.version;
    const todayStr = new Date().toISOString().split('T')[0];

    return storedDate !== todayStr || storedVersion !== this.baseAppDetails.version;
  }

}
