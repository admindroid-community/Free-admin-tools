import Service from '@ember/service';
import { service } from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { apiRequest } from '../utils/api-service';
import sessionStorageUtils from '../utils/session-storage-utils';
import localStorageUtils from '../utils/local-storage-utils';

export default class ToolInstallerService extends Service {
  @service router;
  @service('update-app') updateAppService;
  @service('tool-info') toolInfoService;

  // Shared onboarding/install state
  @tracked selectedTool = null;
  @tracked toolOnboardPopup = false;
  @tracked isInitialImportPopup = false;
  @tracked isImportStartedBT = false;
  @tracked isConnectedBT = false;
  @tracked isDownloadedBT = false;
  @tracked isInitializedBT = false;
  @tracked isServerRestartError = false;

  @action
  beginInstall(tool) {
    this.selectedTool = tool;
    this.toolOnboardPopup = true;
    // Persist intended selection early so any route refresh picks it
    if (tool?.moduleId) {
      sessionStorageUtils.set('currentActiveTool', tool.moduleId);
      localStorageUtils.set('currentActiveTool', tool.moduleId);
    }
  }

  @action
  togglePopup(name) {
    this[name] = !this[name];
    if (name === 'isInitialImportPopup') {
      this.resetBT();
    }
  }

  resetBT() {
    this.isImportStartedBT = false;
    this.isConnectedBT = false;
    this.isDownloadedBT = false;
    this.isInitializedBT = false;
    this.isServerRestartError = false;
  }

  @action
  async importTool(compatibilityUpdate) {
    // Mirrors previous component/controller logic
    this.togglePopup('toolOnboardPopup');

    if (compatibilityUpdate) {
      let compatibilityTools = this.updateAppService.compatibilityCheck
        ?.filter((tool) => tool.isMandatory)
        .map((tool) => tool.moduleId);

      this.updateAppService.updateAllAppPopup = true;
      await this.updateAppService.UpdateAllApps.unlinked().perform(
        compatibilityTools,
      );
      this.updateAppService.updateAllAppPopup = false;
    }

    this.isInitialImportPopup = true;
    this.isImportStartedBT = true;

    try {
      const serverCheckResponse = await apiRequest('/module/import', 'HEAD');
      if (!serverCheckResponse) {
        throw new Error('Import failed');
      }
      this.isConnectedBT = true;

      const importResponse = await apiRequest('/module/import', 'POST', {
        moduleId: this.selectedTool.moduleId,
        url: this.selectedTool.url,
      });
      if (!importResponse.isSuccess) {
        throw new Error('Import failed');
      }
      this.isDownloadedBT = true;

      const restartResponse = await apiRequest('/restart', 'POST');
      let maxAttempt = 3;
      if (restartResponse) {
        const intervalId = setInterval(async () => {
          --maxAttempt;
          const statusResponse = await apiRequest(
            '/module/import-status',
            'POST',
            { moduleId: this.selectedTool.moduleId },
          );
          if (statusResponse.isSuccess) {
            this.isInitializedBT = true;
            this.isImportStartedBT = false;
            clearInterval(intervalId);

            setTimeout(async () => {
              this.isInitialImportPopup = false;
              // let id = this.selectedTool.moduleId;
              this.resetBT();
              // this.toolInfoService.currentActiveTool = id;
              this.toolInfoService.isToolLoading = true;

              // // Persist selection so IndexRoute picks the correct engine
              // sessionStorageUtils.set('currentActiveTool', id);
              // localStorageUtils.set('currentActiveTool', id);

              window.location.href = this.router.urlFor(`index.${this.selectedTool.moduleId}`);
            }, 1000);
            return;
          }

          if (!maxAttempt) {
            this.isServerRestartError = true;
            this.isImportStartedBT = false;
            clearInterval(intervalId);
          }
        }, 9000);
      }
    } catch (_error) {
      this.isImportStartedBT = false;
    }
  }
}
