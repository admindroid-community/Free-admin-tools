import Service from '@ember/service';
import localforage from 'localforage';

export default class IndexDBStorageService extends Service {

  createInstance(name, storeName) {
    const instance = localforage.createInstance({ name, storeName });
    return {
      get: async (key) => {
        try {
          return await instance.getItem(key);
        } catch (e) {
          console.error(
            `Error getting key "${key}" from ${instance._config.storeName}:`,
            e,
          );
          return null;
        }
      },
      set: async (key, value) => {
        try {
          await instance.setItem(key, value);
        } catch (e) {
          console.error(
            `Error setting key "${key}" in ${instance._config.storeName}:`,
            e,
          );
        }
      },
      remove: async (key) => {
        try {
          await instance.removeItem(key);
        } catch (e) {
          console.error(
            `Error removing key "${key}" from ${instance._config.storeName}:`,
            e,
          );
        }
      },
      clear: async () => {
        try {
          await instance.clear();
        } catch (e) {
          console.error(`Error clearing ${instance._config.storeName}:`, e);
        }
      },
      keys: async () => {
        try {
          return await instance.keys();
        } catch (e) {
          console.error(
            `Error getting keys from ${instance._config.storeName}:`,
            e,
          );
          return [];
        }
      },
    };
  }
}
