import Service from '@ember/service';

export default class EngineRegistryService extends Service {
  constructor() {
    super(...arguments);
    this._map = Object.create(null);
  }

  register(mountPointName, engineInstance) {
    this._map[mountPointName] = engineInstance;
  }

  unregister(mountPointName) {
    delete this._map[mountPointName];
  }

  getEngine(mountPointName) {
    return this._map[mountPointName];
  }

  getService(mountPointName, serviceName) {
    let engineInstance = this.getEngine(mountPointName);
    return engineInstance?.lookup(`service:${serviceName}`);
  }
}
