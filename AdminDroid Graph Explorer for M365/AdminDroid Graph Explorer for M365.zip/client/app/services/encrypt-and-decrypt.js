import Service from '@ember/service';

import { action } from '@ember/object';
import { service } from '@ember/service';
import { TrackedArray } from 'tracked-built-ins';
import AES from 'crypto-js/aes';

export default class EncryptAndDecryptService extends Service {
  secretKey = 'my-secret-key';

  @action
  encryption(data) {
    return AES.encrypt(data, this.secretKey).toString();
  }
}
