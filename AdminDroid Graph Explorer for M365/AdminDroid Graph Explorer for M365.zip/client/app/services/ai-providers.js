import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { apiRequest } from '../utils/api-service';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';

export default class AiProvidersService extends Service {
  @service('tool-info') toolInfoService;
  @tracked providers = null;
  @tracked selectedAIProvider = this.providers ? this.providers[0] : null;
  @service('engine-registry') engineRegistryService;

  providersLocal = {
    openai: {
      icon: `/assets/images/openai.svg`,
      description: 'Powerful, versatile, and widely trusted AI.',
      url: 'https://platform.openai.com/api-keys',
    },
    gemini: {
      icon: `/assets/images/gemini.svg`,
      description: 'Smarter, multimodal AI from Google.',
      url: 'https://aistudio.google.com/app/apikey',
    },
    groq: {
      icon: `/assets/images/groq.png`,
      description: 'Blazing-fast, ultra-responsive AI.',
      url: 'https://console.groq.com/keys',
    },
    cohere: {
      icon: `/assets/images/cohere.svg`,
      description: 'Private, customizable, enterprise-ready AI.',
      url: 'https://dashboard.cohere.com/',
    },
    claude: {
      icon: `/assets/images/claude.png`,
      description: 'Safer, friendlier, human-aligned AI.',
      url: 'https://console.anthropic.com/',
    },
  };

  get m365ChatStorageService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_M365.id,
      'chat-storage',
    );
  }

  get adChatStorageService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_AD.id,
      'chat-storage',
    );
  }

  async setApiKey(dataObj, method) {
    try {
      const response = await apiRequest('/settings/apikey', method, dataObj, {
        credentials: 'include',
      });
      if (response.isSuccess) {
        await this.updateProviders();
      }
      return response;
    } catch (error) {
      //console.log('Error setting the API keys:', error.message);
    }
  }

  @action
  async fetchProviders() {
    try {
      const response = await apiRequest('/settings/providers', 'GET');
      this.providers = response;

      return response;
    } catch (error) {
      console.error('Error fetching providers:', error);
    }
  }

  @action
  async loadProviders() {
    const providers = await this.fetchProviders();
    this.providers = providers;

    this.providers.forEach((provider) => {
      provider.iconSvg = this.providersLocal[provider.name.toLowerCase()].icon;
    });
  }

  @action
  async updateProviders() {
    await this.loadProviders();

    if (this.selectedAIProvider) {
      this.providers.forEach((item) => {
        if (item.name == this.selectedAIProvider.name) {
          this.selectedAIProvider = item;
          return;
        }
      });
    } else {
      this.selectedAIProvider = this.providers[0];
    }

    // Safely update the active engine's provider/model if available
    const isAD =
      this.toolInfoService.currentActiveTool ===
      TOOL_INFORMATIONS.MODULE_AD.id;
    const chatService = isAD
      ? this.adChatStorageService
      : this.m365ChatStorageService;

    if (chatService && typeof chatService.loadProviderAndModel === 'function') {
      chatService.loadProviderAndModel();
    } else {
      // Dev hint only: engine service not yet available (e.g., module not installed/loaded)
      // Avoids throwing while still explaining why nothing happened.
      console.debug(
        'AIProviders: chat storage service unavailable; skipped loadProviderAndModel',
        {
          isAD,
          currentTool: this.toolInfoService.currentActiveTool,
        },
      );
    }
  }

  @action
  setData(name, value) {
    this[name] = value;
  }
}
