import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { msalInstance } from '../config/msal';
import { service } from '@ember/service';
import { apiRequest } from '../utils/api-service';
import { BrowserAuthError } from '@azure/msal-browser';
import logger from '../utils/logger';
import localStorageUtils from '../utils/local-storage-utils';
import { AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';
import { getLocalUserProfileId } from '../utils/common-usages';

export default class AuthenticationMicrosoft365Service extends Service {
  @service('anonymous-data-tracking') anonymousDataTrackingService;
  @service('tool-info') toolInfoService;

  @tracked sessionData = null;
  @tracked storedProfileData = null;
  @tracked isInitialized = false;
  @tracked selectedProfileToSwitchAccount = null;
  @tracked currentActiveUser = null;
  @tracked loginPopupM365 = false;
  currentAccount = null;

  constructor() {
    super(...arguments);
    logger.log('AuthService initialized');
    this.initialize();
  }

  @action
  setData(name, value) {
    this[name] = value;
  }

  @action
  async getStoredProfiles() {
    return (
      (await apiRequest(
        `/${this.toolInfoService.currentActiveTool ?? this.toolInfoService.getFutureToolId()}/profiles`,
        'GET',
      )) ?? null
    );
  }

  @action
  async deleteProfile(user) {
    await apiRequest(
      `/${this.toolInfoService.currentActiveTool ?? this.toolInfoService.getFutureToolId()}/profiles/${user.username}`,
      'DELETE',
    );
    await this.checkSession();
  }

  @action
  async initialize() {
    if (this.isInitialized) return;

    try {
      await msalInstance.initialize();
      this.isInitialized = true;
    } catch (error) {
      console.error('MSAL initialization failed:', error);
    }
  }

  getLoginHint(account) {
    return (
      account?.idTokenClaims?.login_hint ||
      account?.idTokenClaims?.preferred_username ||
      account?.username
    );
  }

  getTenant(username) {
    // split using @
  }

  @action
  createUserData(response) {
    return {
      id: response.uniqueId || response.account.homeAccountId.split('.')[0],
      name: response.account.name || 'Unknown',
      username: response.account.username,
      domainName: response.account.username.split('@')[1],
      tenantId: response.account.tenantId,
      accessToken: response.accessToken,
      loginHint: this.getLoginHint(response.account),
      scopes: response.scopes,
      expiresOn: response.expiresOn?.getTime() || 0,
    };
  }

  @action
  async checkSession(id) {
    if (!this.isInitialized) {
      await this.initialize();
    }

    try {
      const accounts = msalInstance.getAllAccounts();
      const serverSession = await this.checkServerSession(id);

      const finalActiveAccounts = serverSession.filter((account) =>
        accounts.some((session) => session.username === account.username),
      );

      if (!finalActiveAccounts.length) {
        this.currentAccount = null;
        this.sessionData = null;
        this.currentActiveUser = null;
        return;
      }

      this.sessionData = finalActiveAccounts;

      if (!id) {
        id =
          getLocalUserProfileId(
            this.toolInfoService.currentActiveUser,
            AUTH_TYPES.M365.id,
          ) ?? this.sessionData[0].username;
      }
      let foundAccount = this.sessionData.find((item) => item.username == id);

      if (!foundAccount) {
        foundAccount = this.sessionData[0];
      }

      if (foundAccount) {
        let imageUrl = await this.getUserPhoto(foundAccount.username);
        this.currentActiveUser = { ...foundAccount, userPhotoUrl: imageUrl };
      } else {
        this.currentActiveUser = null;
      }

      this.currentAccount = accounts.find(
        (acc) => acc.username === this.currentActiveUser?.username,
      );

      this.storedProfileData = await this.getStoredProfiles();
    } catch (error) {
      console.error('Session check failed:', error);
      this.sessionData = null;
      this.currentActiveUser = null;
    }
  }

  @action
  async login({ mode = 'login', loginHint = '' } = {}) {
    if (!this.isInitialized) {
      await this.initialize();
    }

    const loginRequest = { scopes: ['User.Read'] };

    if (mode === 'accountSpecific' && loginHint) {
      loginRequest.loginHint = loginHint;
    } else if (mode === 'addAccount') {
      loginRequest.prompt = 'select_account';
    }

    try {
      if (mode === 'login') {
        const ssoResponse = await msalInstance.ssoSilent({
          scopes: loginRequest.scopes,
          loginHint: loginHint || '',
        });
        return await this.handleAuthResponse(ssoResponse);
      }
      const popupResponse = await msalInstance.loginPopup(loginRequest);
      return await this.handleAuthResponse(popupResponse);
    } catch (error) {
      console.error('Login error:', error);
      if (
        mode === 'login' ||
        (error instanceof BrowserAuthError &&
          error.errorCode === 'interaction_in_progress')
      ) {
        sessionStorage.removeItem('msal.interaction.status');
        const popupResponse = await msalInstance.loginPopup(loginRequest);
        return await this.handleAuthResponse(popupResponse);
      }
      // }
      else {
        return {
          isSuccess: false,
        };
      }
    }
  }

  @action
  async handleAuthResponse(response) {
    if (!response?.account) {
      throw new Error('Invalid auth response');
    }

    this.currentAccount = response.account;
    const userData = this.createUserData(response);

    return await this.storeServerSession(
      userData,
      this.anonymousDataTrackingService.anonymousDataTracking,
    );
  }

  @action
  async logout() {
    if (!this.isInitialized || !this.currentAccount) return;

    this.storeAccount(
      this.currentActiveUser?.username,
      this.currentActiveUser.name,
    );

    try {
      const loginHint = this.getLoginHint(this.currentAccount);

      const logoutRequest = {
        account: this.currentAccount,
        ...(loginHint && { logoutHint: loginHint }),
      };

      await msalInstance.logoutPopup(logoutRequest);
      await this.clearServerSession(this.currentActiveUser?.username);
      // await this.checkSession();
    } catch (error) {
      console.error('Logout error:', error);
      return {
        isSuccess: false,
      };
      // throw error;
    }
  }

  storeAccount(upn, name) {
    if (!upn || !name) {
      console.warn('Invalid account data, not storing:', { upn, name });
      return;
    }
    const key = 'userAccounts';

    const existingAccounts = JSON.parse(localStorage.getItem(key)) || [];

    if (!existingAccounts.some((account) => account.upn === upn)) {
      existingAccounts.push({ upn, name });
      localStorage.setItem(key, JSON.stringify(existingAccounts));
    }
  }

  @action
  async getConsent(scopes) {
    if (!this.isInitialized || !this.currentAccount) {
      throw new Error('No authenticated account found');
    }

    if (this.currentActiveUser?.scopes) {
      const hasScopes = scopes.every((scope) =>
        this.currentActiveUser.scopes.includes(scope),
      );
      if (hasScopes) return true;
    }

    try {
      const tokenRequest = {
        scopes,
        account: this.currentAccount,
      };

      const tokenResponse = await msalInstance.acquireTokenPopup(tokenRequest);
      await this.handleTokenResponse(
        this.currentActiveUser?.username,
        tokenResponse,
      );
      return true;
    } catch (error) {
      console.error('Consent acquisition failed:', error);
      return false;
    }
  }

  async handleTokenResponse(username, tokenResponse) {
    if (!tokenResponse) {
      throw new Error('No token response received');
    }

    if (this.currentActiveUser) {
      this.currentActiveUser = {
        ...this.currentActiveUser,
        expiresOn: tokenResponse.expiresOn?.getTime() || 0,
        scopes: tokenResponse.scopes,
      };
    }

    return await this.updateServerSession(username, {
      accessToken: tokenResponse.accessToken,
      scopes: tokenResponse.scopes,
      expiresOn: tokenResponse.expiresOn?.getTime() || 0,
    });
  }

  async acquireTokenSilent(username, scopes = ['User.Read']) {
    if (!this.isInitialized) {
      await this.initialize();
    }

    const accounts = msalInstance.getAllAccounts();
    if (accounts.length === 0) {
      return null;
    }
    let account = accounts.find((acc) => acc.username === username);
    if (!account) {
      return null;
    }

    try {
      const tokenRequest = {
        scopes,
        account: account,
      };

      const tokenResponse = await msalInstance.acquireTokenSilent(tokenRequest);
      this.currentAccount = account;
      return tokenResponse;
    } catch (error) {
      if (error.name === 'InteractionRequiredAuthError') {
        // console.log('Interaction required, requesting consent...');

        const loginRequest = {
          scopes,
          account: this.account,
        };

        const loginResponse = await msalInstance.loginPopup(loginRequest);

        if (loginResponse?.account) {
          const userData = this.createUserData(loginResponse);
          await this.storeServerSession(userData);
          this.currentAccount = loginResponse.account;
          this.currentActiveUser = { ...userData };
        }

        return loginResponse;
      }
      throw error;
    }
  }

  @action
  async refreshToken() {
    try {
      const tokenResponse = await this.acquireTokenSilent(
        this.currentActiveUser.username,
      );
      await this.handleTokenResponse(
        this.currentActiveUser.username,
        tokenResponse,
      );
      // console.log('Token refreshed successfully');
      return tokenResponse.accessToken;
    } catch (error) {
      console.error('Token refresh failed:', error);
      throw error;
    }
  }

  isTokenExpiringSoon() {
    if (!this.currentActiveUser?.expiresOn) return true;

    const fiveMinutesFromNow = Date.now() + 5 * 60 * 1000;
    return this.currentActiveUser.expiresOn <= fiveMinutesFromNow;
  }

  @action
  async ensureValidToken() {
    if (this.isTokenExpiringSoon()) {
      // console.log('Token expiring soon, refreshing...');

      try {
        await this.refreshToken();
      } catch (error) {
        console.warn('Token refresh failed, attempting re-login:', error);
        await this.login('login', '');
      }
    }
  }

  // Server session methods
  async storeServerSession(userData, storeVisit = false) {
    try {
      return await apiRequest(
        `/${this.toolInfoService.currentActiveTool ?? this.toolInfoService.getFutureToolId()}/user`,
        'POST',
        {
          id: userData.id,
          name: userData.name,
          username: userData.username,
          tenantId: userData.tenantId,
          domainName: userData.domainName,
          scopes: userData.scopes || ['User.Read'],
          accessToken: userData.accessToken,
          expiresOn: userData.expiresOn,
          storeVisit,
        },
        {
          credentials: 'include',
        },
      );
    } catch (error) {
      console.error('Failed to store server session:', error);
      throw error;
    }
  }

  async checkServerSession(id) {
    try {
      const response = await apiRequest(
        `/${this.toolInfoService.currentActiveTool ?? this.toolInfoService.getFutureToolId()}/user`,
        'GET',
        null,
        {
          credentials: 'include',
        },
      );
      // Normalize to an array; server may return object on some edge cases
      const sessionList = Array.isArray(response)
        ? response
        : Array.isArray(response?.data)
          ? response.data
          : [];

      // console.log('sessionList', id, sessionList);

      if (!id) {
        return sessionList;
      }

      let foundUser = sessionList.find((item) => {
        return item.username == id;
      });

      if (!foundUser) {
        return sessionList;
      }

      if (foundUser?.expiresOn > Date.now()) {
        return sessionList;
      }
      let currentExpiredUser = await this.handleExpiredServerToken(
        foundUser.username,
      );

      if (!currentExpiredUser) {
        return sessionList;
      } else {
        let updatedResponse = sessionList.map((item) =>
          item.username === foundUser.username ? currentExpiredUser : item,
        );
        return updatedResponse;
      }
    } catch (error) {
      console.error('Server session check failed:', error);
      return [];
    }
  }

  async updateServerSession(id, tokenData) {
    try {
      return await apiRequest(
        `/${this.toolInfoService.currentActiveTool ?? this.toolInfoService.getFutureToolId()}/user/${id}`,
        'PATCH',
        tokenData,
        {
          credentials: 'include',
        },
      );
    } catch (error) {
      console.error('Failed to update server session:', error);
      throw error;
    }
  }

  async clearServerSession(id) {
    try {
      return await apiRequest(
        `/${this.toolInfoService.currentActiveTool ?? this.toolInfoService.getFutureToolId()}/user/${id}`,
        'DELETE',
        null,
        {
          credentials: 'include',
        },
      );
    } catch (error) {
      console.error('Failed to clear server session:', error);
    }
  }

  async handleExpiredServerToken(username) {
    try {
      const tokenResponse = await this.acquireTokenSilent(username);

      if (tokenResponse) {
        const updatedUser = await this.handleTokenResponse(
          username,
          tokenResponse,
        );
        return updatedUser;
      }
    } catch (error) {
      console.error('Failed to handle expired server token:', error);
      return [];
    }

    return [];
  }

  @action
  async getUserPhoto(id) {
    try {
      const response = await apiRequest(
        `/${this.toolInfoService.currentActiveTool ?? this.toolInfoService.getFutureToolId()}/user/${id}/photo`,
        'GET',
        null,
        {
          credentials: 'include',
        },
      );

      return response.isSuccess ? response.imageUrl : null;
    } catch (error) {
      console.error('Failed to fetch user photo:', error);
      return null;
    }
  }

  @action
  async getUnconsent(scope) {
    if (!this.currentActiveUser) {
      throw new Error('User is not logged in or scope is not defined');
    }

    try {
      const servicePrincipleId = await this.getServicePrincipleId();
      const oauth2grantId = await this.getOauth2grantId(servicePrincipleId);
      const newScope = this.currentActiveUser.scopes
        .filter((s) => s !== scope)
        .join(' ');
      return await this.unconsentScope(newScope, oauth2grantId);
    } catch (error) {
      console.error('Unconsent operation failed:', error);
      return false;
    }
  }

  async getServicePrincipleId() {
    try {
      const res = await apiRequest(
        `/graph-explorer/graph/${this.currentActiveUser.username}`,
        'POST',
        {
          path: `https://graph.microsoft.com/v1.0/servicePrincipals?$filter=appId eq '79cd1e8d-8150-4ca2-95ce-944a6a80cd7d'`,
          method: 'GET',
          responseType: 'json',
        },
        {
          credentials: 'include',
        },
      );

      return res.data.value[0].id;
    } catch (error) {
      console.error('Error fetching service principle ID:', error);
      throw new Error('Failed to fetch service principle ID');
    }
  }

  @action
  async getOauth2grantId(servicePrincipleId) {
    try {
      const res = await apiRequest(
        `/graph-explorer/graph/${this.currentActiveUser.username}`,
        'POST',
        {
          path: `https://graph.microsoft.com/v1.0/oauth2PermissionGrants?$filter=clientId eq '${servicePrincipleId}' and principalId eq '${this.currentActiveUser.id}'`,
          method: 'GET',
          responseType: 'json',
        },
        {
          credentials: 'include',
        },
      );

      return res.data.value[0].id;
    } catch (error) {
      console.error('Error fetching OAuth2 grant ID:', error);
      throw new Error('Failed to fetch OAuth2 grant ID');
    }
  }

  async unconsentScope(scope, oauth2grantId) {
    try {
      const response = await apiRequest(
        `/graph-explorer/graph/${this.currentActiveUser.username}`,
        'POST',
        {
          path: `https://graph.microsoft.com/v1.0/oauth2PermissionGrants/${oauth2grantId}`,
          method: 'PATCH',
          version: 'v1.0',
          body: {
            scope: scope,
          },
          responseType: 'json',
        },
        {
          credentials: 'include',
        },
      );

      return true;
    } catch (error) {
      console.error('Error unconsenting scope:', error);
      return false;
    }
  }
}
