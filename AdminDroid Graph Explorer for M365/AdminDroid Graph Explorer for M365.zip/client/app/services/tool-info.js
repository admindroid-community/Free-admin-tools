import Service from '@ember/service';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';
import { service } from '@ember/service';
import { task } from 'ember-concurrency';
import { apiRequest } from '../utils/api-service';
import { logger } from '../utils/logger';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';
import sessionStorageUtils from '../utils/session-storage-utils';
import localStorageUtils from '../utils/local-storage-utils';
export default class ToolInfoService extends Service {
  @service('update-app') updateAppService
  @tracked currentActiveTool = null;
  @tracked baseToolList = [];
  @service('engine-registry') engineRegistryService;

  get m365ChatStorageService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_M365.id,
      'chat-storage',
    );
  }

  get m365ChatFormDataService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_M365.id,
      'chat-form-data',
    );
  }

  get adChatStorageService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_AD.id,
      'chat-storage'
    );
  }

  get adChatFormDataService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_AD.id,
      'chat-form-data'
    );
  }

  get graphResponseDataService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_GRAPH_EXPLORER.id,
      'response-data'
    );
  }

  get ldapStateService() {
    return this.engineRegistryService.getService(
      TOOL_INFORMATIONS.MODULE_LDAP_EXPLORER.id,
      'state',
    );
  }

  @tracked isToolLoading = false;
  @tracked isBaseAppLoading = false;
  @tracked loadingMessage = '';

  @action
  async fetchToolsDetails() {
    try {
      const response = await apiRequest('/module/tools', 'GET');
      this.baseToolList = response;
    } catch (error) {
      console.error("fetchToolsDetails", error)
      return error
    }
  }

  @action
  async clearAllData() {
    if (this.currentActiveTool == TOOL_INFORMATIONS.MODULE_AD.id) {
      await this.adChatStorageService.clearAllData('historyStorageAD');
      await this.adChatFormDataService.clearAllData();
    } else if (this.currentActiveTool == TOOL_INFORMATIONS.MODULE_M365.id) {
      await this.m365ChatStorageService.clearAllData('historyStorageM365');
      await this.m365ChatFormDataService.clearAllData();
    } else if (
      this.currentActiveTool == TOOL_INFORMATIONS.MODULE_GRAPH_EXPLORER.id
    ) {
      // No persisted data to clear for Graph Explorer currently
      this.graphResponseDataService.clearAllData();
    } else if (
      this.currentActiveTool == TOOL_INFORMATIONS.MODULE_LDAP_EXPLORER.id
    ) {
      this.ldapStateService.clearState();
    }
  }

  getFutureToolId() {
    const mandatoryTools = this.updateAppService.availableUpdates
      ?.filter((tool) => tool.isMandatory)
      .map((tool) => tool.moduleId);

    const validToolIds = this.baseToolList
      .filter((tool) => tool.isEnabled)
      .map((tool) => tool.moduleId);
    let foundId;

    if (this.currentActiveTool) {
      foundId = this.currentActiveTool
    } else {
      foundId =
        sessionStorageUtils.get('currentActiveTool') ??
        localStorageUtils.get('currentActiveTool') ??
        this.baseToolList.find(item => item.isEnabled)?.moduleId;

      if (
        mandatoryTools.includes(foundId) ||
        !validToolIds.includes(foundId)
      ) {
        foundId = this.baseToolList.find(
          item => item.isEnabled && !mandatoryTools.includes(item.moduleId)
        )?.moduleId;
      }
    }

    return foundId
  }
}
