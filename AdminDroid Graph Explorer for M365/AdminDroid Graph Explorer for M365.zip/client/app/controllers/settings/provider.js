import Controller from '@ember/controller';
import { action } from '@ember/object';

import { service } from '@ember/service';

export default class IndexController extends Controller {
  @service('ai-providers') aiProviderService;

  get selectedAIProvider() {
    return this.aiProviderService.selectedAIProvider;
  }
  get providersLocal() {
    return this.aiProviderService.providersLocal;
  }

  @action
  getRelativeUrl(provider) {
    const key = provider?.toLowerCase();
    const providerConfig = this.providersLocal?.[key];

    return providerConfig?.url ?? '';
  }
}
