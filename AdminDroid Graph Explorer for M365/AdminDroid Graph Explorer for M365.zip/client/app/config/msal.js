// utils/msal-instances.js
import { PublicClientApplication } from '@azure/msal-browser';

const msalInstance = new PublicClientApplication({
  auth: {
    // clientId: '1351ae40-4563-4b54-b028-214dc2072d58',
    clientId: '79cd1e8d-8150-4ca2-95ce-944a6a80cd7d',
    // clientId:'5095af9c-abed-4274-b77f-7fcb1f65761b',
    // clientId: '4a21e0a0-9d05-45af-aa72-e519a539d6ef',
    // clientId:'6d66961c-7233-4043-b2e7-6eb6bce760c8',
    authority: 'https://login.microsoftonline.com/common',
    redirectUri: window.location.origin,
  },
  cache: {
    cacheLocation: 'localStorage',
    storeAuthStateInCookie: false,
  },
});

export { msalInstance };
