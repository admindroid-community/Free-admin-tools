const sessionStorageUtils = {
  get(field) {
    const data = sessionStorage.getItem(field);
    if (!data || data === 'undefined') {
      return null;
    }

    try {
      return JSON.parse(data);
    } catch (e) {
      console.error(
        `Error parsing JSON from sessionStorage for key "${field}":`,
        e,
      );
      return null;
    }
  },

  set(field, data) {
    try {
      sessionStorage.setItem(field, JSON.stringify(data));
    } catch (e) {
      console.error(`Error saving to sessionStorage for key "${field}":`, e);
    }
  },

  remove(field) {
    try {
      sessionStorage.removeItem(field);
    } catch (e) {
      console.error(`Error removing key "${field}" from sessionStorage:`, e);
    }
  },

  clear() {
    try {
      sessionStorage.clear();
    } catch (e) {
      console.error('Error clearing sessionStorage:', e);
    }
  },
};

export default sessionStorageUtils;
