const localStorageUtils = {
  get(field) {
    const data = localStorage.getItem(field);
    if (!data || data === 'undefined') {
      return null;
    }

    try {
      return JSON.parse(data);
    } catch (e) {
      console.error(
        `Error parsing JSON from localStorage for key "${field}":`,
        e,
      );
      return null;
    }
  },

  set(field, data) {
    try {
      localStorage.setItem(field, JSON.stringify(data));
    } catch (e) {
      console.error(`Error saving to localStorage for key "${field}":`, e);
    }
  },

  remove(field) {
    try {
      localStorage.removeItem(field);
    } catch (e) {
      console.error(`Error removing key "${field}" from localStorage:`, e);
    }
  },

  clear() {
    try {
      localStorage.clear();
    } catch (e) {
      console.error('Error clearing localStorage:', e);
    }
  },
};

export default localStorageUtils;
