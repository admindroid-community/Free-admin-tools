import Route from '@ember/routing/route';
import { service } from '@ember/service';
import sessionStorageUtils from '../utils/session-storage-utils';
import { action } from '@ember/object';
import localStorageUtils from '../utils/local-storage-utils';
import { TOOL_INFORMATIONS, AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';

export default class IndexRoute extends Route {
  @service('user') userService;
  @service router;
  @service('tool-info') toolInfoService;
  @service('settings-data') settingsDataService;
  @service('ai-providers') AIProvidersService;
  @service('update-app') updateAppService;

  constructor() {
    super(...arguments);

    this.router.on('routeDidChange', (transition) => {
      if (transition?.to?.name.startsWith('settings')) {
        this.settingsDataService.activatedTab = 'settings';
        this.settingsDataService.isExtraSidebarOpen = true;
      } else {
        this.settingsDataService.isExtraSidebarOpen = false;
      }
    });
  }

  //tab activation visibilitychange
  activate() {
    super.activate(...arguments);
    document.addEventListener('visibilitychange', this.handleVisibilityChange);
  }

  deactivate() {
    super.deactivate(...arguments);
    document.removeEventListener(
      'visibilitychange',
      this.handleVisibilityChange,
    );
  }

  handleVisibilityChange = async () => {
    if (document.visibilityState === 'visible') {
      await this.userService.checkSession(null, null, true)
    }
  };

  async beforeModel() {
    // Return a single promise so loading substate is triggered

    await Promise.all([
      this.toolInfoService.fetchToolsDetails(),
      this.updateAppService.checkUpdate(),
      this.AIProvidersService.updateProviders()
    ]);

    this.configAuthType()
    await this.userService.checkSession(null, null, false);
    await new Promise(resolve => setTimeout(resolve, 500));
  }


  // async afterModel() {
  //   this.toolInfoService.isBaseAppLoading = true;

  //   await Promise.all([
  //     this.toolInfoService.fetchToolsDetails(),
  //     this.updateAppService.checkUpdate(),
  //     this.AIProvidersService.updateProviders()
  //   ]);

  //   await new Promise(resolve => setTimeout(resolve, 10000)); // wait 10 seconds

  //   this.configAuthType();
  //   this.toolInfoService.isBaseAppLoading = false;
  // }

  configAuthType() {
    let foundId = this.toolInfoService.getFutureToolId()
    if (foundId == TOOL_INFORMATIONS.MODULE_M365.id) {
      this.userService.authType = AUTH_TYPES.M365.id
    } else if (foundId == TOOL_INFORMATIONS.MODULE_AD.id) {
      this.userService.authType = AUTH_TYPES.AD.id
    } else {
      console.warn("Invalid authe type", foundId, "from application route")
    }
  }
}
