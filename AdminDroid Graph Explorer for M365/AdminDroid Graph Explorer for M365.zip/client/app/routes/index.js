import Route from '@ember/routing/route';
import { service } from '@ember/service';
import { action } from '@ember/object';
import sessionStorageUtils from '../utils/session-storage-utils';
import localStorageUtils from '../utils/local-storage-utils';
import { TOOL_INFORMATIONS, AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';

export default class IndexRoute extends Route {
  @service('user') userService;
  @service router;
  @service('tool-info') toolInfoService;
  @service('settings-data') settingsDataService;
  @service('ai-providers') AIProvidersSerice;
  @service('update-app') updateAppService;

  async beforeModel() {
    this.toolInfoService.isToolLoading = true;
    this.settingsDataService.activatedTab = null;
    this.configCurrentTool();
    this.router.on('routeWillChange', this.handleRouteTransition.bind(this));
  }

  get mandatoryTools() {
    return this.updateAppService.availableUpdates
      ?.filter((tool) => tool.isMandatory)
      .map((tool) => tool.moduleId);
  }

  @action
  error(error, transition) {
    // Redirect to top-level not-found route on error
    this.router.replaceWith('not-found');
    return false; // prevent bubbling
  }

  @action
  configCurrentTool() {
    const currentURL = this.router.currentURL || window.location.pathname;

    const pathSegments = currentURL.replace(/^\/|\/$/g, '').split('/');

    if (pathSegments[0] === 'index' && pathSegments.length > 1) {
      console.warn('More than allowed segments in URL, skipping navigation');
      return;
    }

    const validToolIds = this.toolInfoService.baseToolList
      .filter((tool) => tool.isEnabled)
      .map((tool) => tool.moduleId);

    let toolId = validToolIds.find((id) => currentURL.includes(`/${id}`));

    if (!toolId || this.mandatoryTools.includes(toolId)) {
      toolId = sessionStorageUtils.get('currentActiveTool') ??
        localStorageUtils.get('currentActiveTool') ??
        this.toolInfoService.baseToolList.find((item) => item.isEnabled)
          ?.moduleId;

      if (this.mandatoryTools.includes(toolId) ||
        !validToolIds.includes(toolId)) {
        toolId = this.toolInfoService.baseToolList.find((item) =>
          item.isEnabled && !this.mandatoryTools.includes(item.moduleId),
        )?.moduleId;
      }
    }

    if (!toolId) {
      console.error('none tool is active or enabled');
    } else {
      this.activateTool(toolId)

      if (currentURL.startsWith('/') || currentURL.startsWith('/index')) {
        this.router.replaceWith(
          `index.${this.toolInfoService.currentActiveTool}`,
        );
      }
    }
  }


  activateTool(foundId) {
    this.toolInfoService.currentActiveTool = foundId;

    sessionStorageUtils.set(
      'currentActiveTool',
      this.toolInfoService.currentActiveTool,
    );
    localStorageUtils.set(
      'currentActiveTool',
      this.toolInfoService.currentActiveTool,
    );

    this.configAuthType(this.toolInfoService.currentActiveTool)
  }

  @action
  handleRouteTransition(transition) {
    const targetRouteName = transition.to?.name;

    if (!targetRouteName) return;

    // Split by '.' and find the first segment after 'index'
    const segments = targetRouteName.split('.');
    const indexPos = segments.indexOf('index');

    // Tool ID is the segment immediately after 'index'
    const toolId = indexPos >= 0 && segments.length > indexPos + 1 ? segments[indexPos + 1] : null;

    if (toolId && toolId != "index") {
      this.activateTool(toolId);
    }
  }

  configAuthType(foundId) {
    if (foundId == TOOL_INFORMATIONS.MODULE_M365.id) {
      this.userService.authType = AUTH_TYPES.M365.id
    } else if (foundId == TOOL_INFORMATIONS.MODULE_AD.id) {
      this.userService.authType = AUTH_TYPES.AD.id
    } else {
      console.warn("Invalid authe type", foundId, "from index route")
    }
  }

}
