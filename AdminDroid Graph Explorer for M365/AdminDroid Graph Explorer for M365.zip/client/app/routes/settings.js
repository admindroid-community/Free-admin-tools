import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';

export default class SettingsRoute extends Route {
  @service('settings-data') settingsDataService;
  @service('ai-providers') aiProvidersService;
  @service('tool-info') toolInfoService;

  @service router;

  constructor() {
    super(...arguments);
    // Store bound function reference for removal later
    // this.boundHandleRouteChange = this.handleRouteChange.bind(this);
    this.router.on('routeDidChange', this.handleRouteChange.bind(this));
  }

  async beforeModel() {
    await this.aiProvidersService.updateProviders();
  }

  handleRouteChange(transition) {
    const name = transition.to?.name;
    if (!name) return;

    if (name.startsWith('settings')) {
      this.settingsDataService.isExtraSidebarOpen = true;
      this.toolInfoService.currentActiveTool = null;
      const tabName = name.split('.')[1];
      const matchedTab = this.settingsDataService.sidebarTabs.find(
        (tab) => tab.name === tabName,
      );

      if (matchedTab) {
        this.settingsDataService.setData('selectedSidebarTab', matchedTab);
      }
    } else {
      this.settingsDataService.isExtraSidebarOpen = false;
    }
  }

  willDestroy() {
    super.willDestroy(...arguments);
    this.router.off('routeDidChange', this.boundHandleRouteChange);
  }
  // get currentTabName() {
  //     const segments = this.router.currentRouteName?.split('.') || [];
  //     const settingsIndex = segments.indexOf('settings');
  //     return segments[settingsIndex + 1] || 'general';
  // }
}
