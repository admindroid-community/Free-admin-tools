import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';

export default class SettingsProviderRoute extends Route {
  queryParams = {
    providerName: { refreshModel: true },
  };

  @service('ai-providers') aiProvidersService;

  model({ providerName }) {
    if (providerName) {
      const matchedProvider = this.aiProvidersService.providers.find(
        (provider) => provider.name === providerName,
      );
      if (matchedProvider) {
        this.aiProvidersService.setData('selectedAIProvider', matchedProvider);
      }
    }
  }
}
