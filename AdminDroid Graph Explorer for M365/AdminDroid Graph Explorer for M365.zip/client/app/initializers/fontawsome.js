// app/initializers/fontawesome.js

import { library } from '@fortawesome/fontawesome-svg-core';
import {
  faPlus,
  faArrowRightFromBracket,
  faLock,
  faLockOpen,
  faKey,
  faArrowRight,
  faXmark,
  faCheckDouble,
  faArrowUpRightFromSquare,
  faWandMagicSparkles,
  faArrowDown,
  faExclamation,
  faStop,
  faRightToBracket,
  faRotateRight,
  faAnglesLeft,
  faTriangleExclamation,
  faAngleDoubleUp,
  faAngleDoubleDown,
  faCaretUp,
  faCaretDown,
  faArrowPointer,
  faClockRotateLeft,
  faGaugeHigh,
  faChartPie,
  faTable,
  faAnglesRight,
  faAnglesDown,
  faHouse
} from '@fortawesome/free-solid-svg-icons';

import { faMicrosoft } from '@fortawesome/free-brands-svg-icons';
import { faEyeSlash } from '@fortawesome/free-regular-svg-icons';

export function initialize() {
  library.add(
    faPlus,
    faArrowRightFromBracket,
    faLock,
    faTriangleExclamation,
    faLockOpen,
    faAnglesLeft,
    faAnglesDown,
    faAnglesRight,
    faAngleDoubleUp,
    faAngleDoubleDown,
    faKey,
    faArrowPointer,
    faCaretUp,
    faCaretDown,
    faMicrosoft,
    faArrowRight,
    faXmark,
    faCheckDouble,
    faArrowUpRightFromSquare,
    faWandMagicSparkles,
    faArrowDown,
    faEyeSlash,
    faExclamation,
    faStop,
    faRightToBracket,
    faRotateRight,
    faClockRotateLeft,
    faGaugeHigh,
    faChartPie,
    faTable,
    faHouse
  );
}

export default {
  initialize,
};
