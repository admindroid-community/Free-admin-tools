# AdminDroid Graph Explorer for M365

- Module: Microsoft Graph Explorer
- Module ID: graph-explorer
- Module version: 1.7.9.45
- Server (base): 2.0.0.33
- Client (base): 2.0.0.66
