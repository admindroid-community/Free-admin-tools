## Overview

The AdminDroid Graph Explorer Tool for M365, lets developers explore, test, and manage Microsoft Graph
and related APIs through a simple web interface.

The application is built using:

- Ember.js (Frontend)
- Node.js with Express (Backend)

---

## 📁 Project Structure

This repository contains two main parts:

- `/client` → Ember.js frontend application  
- `/server` → Node.js backend API and service layer

Each module has its own README file with detailed setup instructions.

---

## 🚀 Getting Started

Please refer to the respective documentation:

- Client Setup: `/client/README.md`
- Server Setup: `/server/README.md`

---

## 🔗 Dependencies

This project uses Microsoft Graph and related developer APIs, including:

- Microsoft Graph API  
- Microsoft Graph DevX APIs  
  (https://devxapi-func-prod-eastus.azurewebsites.net)

These services are provided by Microsoft and are subject to their own
terms of use and availability.
