# Backend Development Notes

## Error Handling & Logging

The server uses a standardized error pattern to ensure consistent API responses and logs.

- Always throw errors via `sendAndLogError(loggerNamespace, message, statusCode, details)` from `server/util/errorResponse.js`.
- Do not send responses directly from services. Throw and let the global `errorHandler` middleware format the response.
- Controllers may early‑validate input and call `sendAndLogError` on validation failures.
- Choose the right logger namespace from `server/util/logger.js` (e.g., `logger.ai`, `logger.graph`, `logger.session`, `logger.ldap`, `logger.core`).
- Avoid `console.log`; use the logger.

Example (controller validation):

```js
const { sendAndLogError } = require("../util/errorResponse");
const { logger } = require("../util/logger");

if (!req.body.apiKey) {
  sendAndLogError(
    logger.apikey,
    "Missing apiKey",
    400,
    "API key is required for authentication.",
  );
}
```

Example (service failure):

```js
const { sendAndLogError } = require("../util/errorResponse");
const { logger } = require("../util/logger");

if (!response.ok) {
  sendAndLogError(
    logger.core,
    "File Download error",
    500,
    "Failed to download ZIP file",
  );
}
```

Provider adapters follow a unified mapping:

- 401 → Authentication failed
- 429 → Rate limited
- 500 → Provider internal error

## Validation

- Use `zod` and the helper middleware `validateBody(schema)` from `server/util/validator.js` to validate request bodies.
- See `server/core/src/routes/settingsRoutes.js` for usage.

## AI Providers

- Providers (OpenAI, Groq, Claude, Gemini, Cohere) are centralized under `server/core/providers/`.
- Module‑specific prompts/contexts are injected by factories in each module to preserve behavior.
- Prefer shared adapters over module‑local implementations.

## Environment Variables

- `ADMIN_SERVER_URL`: Base URL for admin update service.
- `CORS_ORIGINS`: Comma‑separated list of allowed origins, e.g. `http://localhost:4200,http://localhost:4201`.
- `PREFERRED_PORTS`: Comma‑separated port list, used to find an available port.
- `BUILD_TYPE`: `development` | `testing` | `production`.
- `APP_INSTALL_PATH`: Override default install path for modules/files.
- `LOG_CLEAR_INTERVAL_DAYS`: Days between automatic log cleanup checks.
- `SESSION_SECRET`: Single session secret (fallback if `SESSION_SECRETS` not set).
- `SESSION_SECRETS`: Comma‑separated secrets for rolling rotation (first is used to sign new cookies).
