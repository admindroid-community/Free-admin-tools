process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

require("../config/env.js");

const express = require("express");
const session = require("express-session");
const cors = require("cors");
const dotenv = require("dotenv")
const cookieParser = require("cookie-parser");
const crypto = require("crypto");
// const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");
const http = require("http");
const open = require("open");
const FileStoreImport = require("session-file-store")

// dotenv.config();

const appInfo = require("../config/appInfo.js");
const pathUtils = require("../util/pathUtils.js");
const { errorHandler } = require("../util/errorResponse.js");

const moduleRoutes = require("./src/routes/moduleRoutes.js");
const configureRoutes = require("./src/routes/configurationRoutes.js");
const settingsRoutes = require("./src/routes/settingsRoutes.js");
const toolsDetailsFileServices = require("./src/utils/toolsDetailsFileServices.js");
const PortFinder = require("./src/services/portFinderService.js");
const ModuleLoader = require("./src/services/moduleLoaderService.js");
const { Logger, logger } = require("../util/logger.js");
const { stopService } = require("./src/utils/windows-utils.js");

logger.core.info(`Running in ${appInfo.buildType} mode`);

let app;
let server;


const portFinder = new PortFinder(
  appInfo,
  http
);
const moduleLoader = new ModuleLoader(
  fs,
  path,
  toolsDetailsFileServices,
  appInfo,
  pathUtils
);

function createApp() {
  const app = express();

  app.use(cors({ origin: appInfo.corsOrigins, credentials: true }));
  // app.use(bodyParser.json({ limit: "10mb" }));
  app.use(express.json({ limit: "10mb" }));
  app.use(cookieParser());
  const envType = (appInfo.buildType || "development").toLowerCase();
  const isProduction = envType !== "development";
  const sessionSecret = isProduction ? crypto.randomBytes(32).toString("hex") : 'dev-session-secret';
  logger.core.info("appinfo : " + JSON.stringify(appInfo));

  const cookieOptions = {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    maxAge: isProduction ? 2 * 60 * 60 * 1000 : 60 * 60 * 1000,
  };

  let sessionOptions = {
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: cookieOptions,
  };

  if (envType == "development") {
    const FileStore = FileStoreImport(session);

    sessionOptions.store = new FileStore({ path: './sessions' });
  }

  app.use(session(sessionOptions));



  app.use("/module", moduleRoutes);
  app.use("/configure", configureRoutes);
  app.use("/settings", settingsRoutes);

  app.get("/admindroid-ct", (req, res) => res.json({ message: "AdminDroid Community Tool is running...", type: appInfo.buildType }));

  app.post("/shutdown", (req, res) => {
    if (!isLocalRequest(req)) {
      logger.core.warn(`Unauthorized shutdown attempt from ${req.ip}`);
      return res.status(403).json({ error: "Forbidden" });
    }
    res.status(200).json("Server received shutdown signal. Terminating...");
    logger.core.info("Server received shutdown signal. Terminating...");
    cleanupAndExit();
  });

  app.post("/restart", (req, res) => {
    if (!isLocalRequest(req)) {
      logger.core.warn(`Unauthorized restart attempt from ${req.ip}`);
      return res.status(403).json({ error: "Forbidden" });
    }
    res.status(200).json("Restarting...");
    logger.core.info("Server Restarting...");
    shutdownServer(() => {
      startServer(false);
    });
  });

  return app;
}

async function startServer(launchApp = true) {
  try {
    const portResponse = await portFinder.findAvailablePort();
    if (!portResponse) {
      logger.core.info("Error in port configuration.")
      cleanupAndExit();
    }
    const port = portResponse?.port;

    if (!portResponse.existingPort) {

      app = createApp();

      if (appInfo.buildType === "development") {
        await moduleLoader.loadModulesDev(app);
      } else {
        await moduleLoader.loadModules(app);
      }

      const distPath = path.resolve(pathUtils.getClientDir())

      app.use(express.static(distPath));

      app.get("{*file}", (req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });

      app.use(errorHandler);

      server = app.listen(port, "127.0.0.1");

      server.on('error', async (err) => {
        if (appInfo.buildType !== "development") await toolsDetailsFileServices.writeApplicationFiles("listening_port.txt", "", true);
        let msg;
        if (err.code === 'EADDRINUSE') {
          msg = `Port ${port} is already in use. Please close the existing process or choose another port.`;
        } else {
          msg = `Server error: ${err}`;
        }
        logger.core.error(msg);
        console.error(msg);
        cleanupAndExit();
      });

      server.on('listening', async () => {
        const addr = server.address();
        const actualPort = typeof addr === 'string' ? addr : addr && addr.port;
        const msg = `Server is listening on port ${actualPort}`;
        logger.core.info(msg);
        if (appInfo.buildType !== "development") {
          await toolsDetailsFileServices.writeApplicationFiles("listening_port.txt", `${actualPort}`, true)
          console.log(msg);
          console.log(`Application started successfully.\nPlease open the following URL in your browser:\nhttp://localhost:${actualPort}`);
        };
      });

    } else if (appInfo.buildType === 'development') {
      logger.core.error(`Port ${port} is already in use. Please close the existing process or choose another port.`);
      console.error(`Port ${port} is already in use. Please close the existing process or choose another port.`);
      cleanupAndExit();
    }

    // if (appInfo.buildType !== "development" && launchApp) {
    //   const moduleId = await toolsDetailsFileServices.readApplicationFiles("default_tool.txt") || "";
    //   const launchMsg = `Launching : http://localhost:${port}/${moduleId}`;
    //   logger.core.info(launchMsg);
    //   console.log(launchMsg);
    //   await open(`http://localhost:${port}/${moduleId}`).catch(err => {
    //     logger.core.error(err); 
    //     console.error(err);
    //   });
    // }

    await new Logger().clearLog();

  } catch (error) {
    if (appInfo.buildType !== "development") await toolsDetailsFileServices.writeApplicationFiles("listening_port.txt", "", true);
    logger.core.error(`Error starting server: ${error}`);
    console.error(`Error starting server:`, error);
    process.exit(1);
  }
}

function shutdownServer(callback) {
  if (server) {
    server.close(() => {
      logger.core.debug("HTTP server closed.");
      server = null;
      app = null;
      callback && callback();
    });
  }
}

function isLocalRequest(req) {
  const ip = req.ip || req.connection?.remoteAddress || "";
  return (
    ip === "::1" ||
    ip === "127.0.0.1" ||
    ip.endsWith("::1") ||
    ip.includes("127.0.0.1")
  );
}

let isShuttingDown = false;

async function cleanupAndExit(signalOrReason) {
  if (isShuttingDown) return;
  isShuttingDown = true;

  logger.core.debug(`Cleanup triggered by: ${signalOrReason || 'unknown'}`);
  logger.core.debug('Cleaning up resources...');

  try {
    await stopService();
  } catch (err) {
    logger.core.error(`Error stopping service: ${err.message}`);
  }

  if (server && typeof server.close === 'function') {
    server.close(() => {
      logger.core.debug('Server closed.');
      process.exit(0);
    });

    setTimeout(() => {
      logger.core.error('Forced shutdown after timeout...');
      process.exit(1);
    }, 5000);
  } else {
    logger.core.debug('Server not started or already closed. Exiting...');
    process.exit(0);
  }
}

['SIGINT', 'SIGTERM'].forEach((sig) =>
  process.on(sig, () => cleanupAndExit(sig))
);

process.on('uncaughtException', (err) => {
  logger.core.error(`Uncaught exception: ${err}`);
  cleanupAndExit('uncaughtException');
});

process.on('unhandledRejection', (reason) => {
  logger.core.error(`Unhandled rejection: ${reason}`);
  cleanupAndExit('unhandledRejection');
});

startServer();
