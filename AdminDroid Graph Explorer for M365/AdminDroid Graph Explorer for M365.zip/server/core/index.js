const { logger } = require("../util/logger");
const { getServerDir, moduleNames } = require("../util/pathUtils");
const path = require('path');
const { stopService } = require("./src/utils/windows-utils");

process.chdir(path.dirname(process.execPath));
logger.core.debug("Working Dir : " + process.cwd());

const serverID = moduleNames.baseServer
const serverPath = path.join(getServerDir(), serverID, `${serverID}.cjs`);

try {
    require(serverPath);
} catch (err) {
    logger.core.error(`Failed to load ${serverPath}:` + err);
    stopService();
    // process.exit(1);
}
