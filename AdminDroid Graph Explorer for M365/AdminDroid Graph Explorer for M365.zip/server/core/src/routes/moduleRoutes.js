
const express = require("express");
const moduleController = require("../controllers/moduleController.js");

const router = express.Router();

router.post("/import", moduleController.importModule);
router.post("/import-status", moduleController.importModuleStatus);
router.post("/remove", moduleController.removeModule);
router.get("/update-check", moduleController.updateCheck);
router.post("/update", moduleController.updateModule);
router.post("/revert", moduleController.revertModule);
router.get("/tools", moduleController.listAllTools);

module.exports = router;