
const express = require("express");
const configurationController = require("../controllers/configurationController");

const router = express.Router();

router.get('/', configurationController.getConfiguration);
router.post('/', configurationController.setConfiguration);

module.exports = router;