const { logger } = require("../../../util/logger");
const { moduleNames } = require("../../../util/pathUtils");
class ModuleLoaderService {
    constructor(fs, path, toolsDetailsFileServices, appInfo, pathUtils) {
        this.fs = fs;
        this.path = path;
        this.toolsDetailsFileServices = toolsDetailsFileServices;
        this.appInfo = appInfo;
        this.pathUtils = pathUtils;
    }

    async loadModules(app) {
        const loadedModule = [];
        const modulesDir = this.pathUtils.getServerDir();

        logger.core.debug("modules path : " + modulesDir);

        if (!this.fs.existsSync(modulesDir)) {
            logger.core.debug("Invalid Modules path : " + modulesDir);
            return;
        }

        const moduleFolders = this.fs
            .readdirSync(modulesDir, { withFileTypes: true })
            .filter((entry) => entry.isDirectory())
            .map((entry) => entry.name);

        for (const modName of moduleFolders) {

            if (modName === moduleNames.baseServer) continue;

            const pluginDir = this.path.join(modulesDir, modName);
            const entryFile = this.path.join(pluginDir, "router.cjs");

            if (!this.fs.existsSync(entryFile)) {
                logger.core.debug(`No router.cjs found for module ${modName}`);
                continue;
            }

            try {
                delete require.cache[require.resolve(entryFile)];
                const router = require(entryFile);
                if (typeof router === "function") {
                    app.use(`/${modName}`, router);
                    loadedModule.push(modName);
                } else {
                    logger.core.debug(`Module ${modName} did not export a valid router.`);
                }
            } catch (err) {
                logger.core.error(`Failed to load module '${modName}': ${err.stack}`);
            }
        }
        logger.core.info(`Modules loaded: ${loadedModule}`);
        await this.toolsDetailsFileServices.setAppInfo("loadedModules", loadedModule);
    }

    async loadModulesDev(app) {
        const loadedModule = [];
        const modulesDir = this.path.resolve("module");

        const testingModulesDir = this.pathUtils.getServerDir();
        const testingModuleFolders = this.fs
            .readdirSync(testingModulesDir, { withFileTypes: true })
            .filter((entry) => entry.isDirectory())
            .map((entry) => entry.name);

        if (!this.fs.existsSync(modulesDir)) return;

        const moduleFolders = this.fs
            .readdirSync(modulesDir, { withFileTypes: true })
            .filter((entry) => entry.isDirectory())
            .map((entry) => entry.name);

        for (const modName of moduleFolders) {

            if (modName === "build") continue;

            const pluginDir = this.path.join(modulesDir, modName);
            const entryFile = this.path.join(pluginDir, "src", "router.js");

            if (!this.fs.existsSync(entryFile)) {
                logger.development.core.debug(`No router.js found for module ${modName}`);
                continue;
            }

            try {
                delete require.cache[require.resolve(entryFile)];
                const router = require(entryFile);
                if (typeof router === "function") {
                    app.use(`/${modName}`, router);
                    loadedModule.push(modName);
                } else {
                    logger.development.core.debug(`Module ${modName} did not export a valid router.`);
                }
            } catch (err) {
                logger.development.core.error(`Failed to load module '${modName}': ${err.stack}`);

            }
        }

        logger.development.core.info(`Module enabled : ${testingModuleFolders}`);
        logger.development.core.info(`Modules loaded: ${loadedModule}`);
        await this.toolsDetailsFileServices.setAppInfo("loadedModules", testingModuleFolders);
    }
}

module.exports = ModuleLoaderService;