const path = require("path");
const pathUtils = require("../../../util/pathUtils.js");
const { logger } = require("../../../util/logger.js");
const fileServices = require("../../../util/fileServices.js");

class ConfigurationService {

  constructor() {
    this.configFilePath = path.resolve(pathUtils.getFilesDir(), "configure.json");
    fileServices.ensureFileDirectory(this.configFilePath);
  }


  async ensureFileInitialized() {
    const configData = await fileServices.readFile(this.configFilePath);
    if (!configData.length) {
      const initialData = {
        maskingWarningEnabled: false,
        anonymousDataTracking: false,
        askActionConfiguration: false,
        clearLocalStorage: false
      };
      await fileServices.writeFile(this.configFilePath, initialData, false);
    }
  }

  async getConfigurations(key = null) {
    try {
      const data = await fileServices.readFile(this.configFilePath);
      if (!data.length) await this.ensureFileInitialized();
      const jsonData = JSON.parse(data || "{}");
      return key ?
        jsonData[key] :
        jsonData || {};
    } catch (err) {
      logger.core.error(`Error fetching stored configuration reading or parsing file: ${JSON.stringify(err)}`);
      return {};
    }
  }

  async setConfigurations(key, value) {
    try {
      const data = await fileServices.readFile(this.configFilePath);
      if (!data.length) await this.ensureFileInitialized();
      let jsonData = JSON.parse(data || "{}");
      jsonData[key] = value;
      await fileServices.writeFile(this.configFilePath, jsonData, false);
      return { message: "Data successfully stored", isSuccess: true };
    } catch (err) {
      logger.core.error(`Error storing stored configuration reading or parsing file: ${JSON.stringify(err)}`);
      return { message: "Data storing failed", isSuccess: false };
    }
  }

}

module.exports = new ConfigurationService();
