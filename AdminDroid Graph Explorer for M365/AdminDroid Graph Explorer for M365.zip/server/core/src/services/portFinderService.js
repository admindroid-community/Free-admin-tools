const fetch = require("node-fetch");
const toolsDetailsFileServices = require("../utils/toolsDetailsFileServices");
const configurationService = require("./configurationService");
const { logger } = require("../../../util/logger");
class PortFinderService {
    constructor(appInfo, http) {
        this.appInfo = appInfo;
        this.http = http;
    }

    async findAvailablePort() {


        if (this.appInfo.buildType === 'development') {
            return { port: this.appInfo.devServerPort, existingPort: false };
        }

        const customizedPort = await toolsDetailsFileServices.readApplicationFiles("port.txt");

        const validatePortResult = this.validatePort(customizedPort);

        if (validatePortResult.valid) {
            return { port: customizedPort, existingPort: false };
        } else {
            logger.core.error("Customized Port invalid : " + validatePortResult.error);
        }

        let preferredPort = 8020;
        let start = 8001;
        let end = 9000;

        const tryPort = (port) => {
            logger.core.debug(`Port checking : ${port}`);
            return new Promise((resolve, reject) => {
                const server = this.http.createServer();

                server.listen(port, '127.0.0.1', () => {
                    server.close(() => resolve({ port, existingPort: false }));
                });

                server.on('error', async () => {
                    try {
                        const response = await fetch(`http://localhost:${port}/admindroid-ct`).catch(() => null);
                        if (response && response.ok) {
                            const data = await response.json();
                            if (data?.message?.includes("AdminDroid Community Tool")) {
                                if (data.type === this.appInfo.buildType) {
                                    return resolve({ port, existingPort: true });
                                }
                                logger.core.info(`AdminDroid Community Tool port is already running in ${port} with different build type: ${data.type}`);
                            }
                        }
                    } catch (_) {
                        // ignore error
                    }
                    reject(new Error('Port in use'));
                });
            });
        };

        try {
            const result = await tryPort(preferredPort);
            return result;
        } catch (err) {
            logger.core.error("port issue : " + err)
            logger.core.info(`Preferred port ${preferredPort} unavailable, scanning range...`);
        }

        for (let port = start; port <= end; port++) {
            try {
                const result = await tryPort(port);
                return result;
            } catch {
                // continue to next port
            }
        }

        logger.core.info(`No available ports found in range ${start}-${end}`);
        return null;
    }

    validatePort(port) {
        if (port === null || port === undefined || port === "") {
            return { valid: false, error: "Port value is missing." };
        }

        const num = Number(port);

        if (Number.isNaN(num)) {
            return { valid: false, error: "Port must be a valid number." };
        }

        if (!Number.isInteger(num)) {
            return { valid: false, error: "Port must be an integer." };
        }

        if (num < 0 || num > 65535) {
            return { valid: false, error: "Port must be between 0 and 65535." };
        }

        return { valid: true, value: num };
    }

}

module.exports = PortFinderService;
