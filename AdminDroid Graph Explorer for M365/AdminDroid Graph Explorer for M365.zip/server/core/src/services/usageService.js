const AppInfo = require("../../../config/appInfo");
const crypto = require('crypto');
const { sendAndLogError } = require("../../../util/errorResponse.js");
const path = require("path");
const { logger } = require("../../../util/logger");
const fileServices = require("../../../util/fileServices");
const CredentialFileService = require("./credentialFileService");
const pathUtils = require("../../../util/pathUtils.js");
const toolsDetailsFileServices = require("../utils/toolsDetailsFileServices.js");

class UsageService extends CredentialFileService {

    constructor() {
        super();
    }

    async validateKey(provider, apiKey) {
        try {
            let response;
            switch (provider.toLowerCase()) {
                case "gemini":
                    response = await fetch(`https://generativelanguage.googleapis.com/v1/models?key=${apiKey}`);
                    break;
                case "groq":
                    response = await fetch("https://api.groq.com/openai/v1/models", {
                        headers: { Authorization: `Bearer ${apiKey}` },
                    });
                    break;
                case "cohere":
                    response = await fetch("https://api.cohere.ai/v1/models", {
                        headers: { Authorization: `Bearer ${apiKey}` },
                    });
                    break;
                case "openai":
                    response = await fetch("https://api.openai.com/v1/models", {
                        headers: { Authorization: `Bearer ${apiKey}` },
                    });
                    break;
                case "claude":
                    response = await fetch("https://api.anthropic.com/v1/models", {
                        headers: {
                            "x-api-key": apiKey,
                            "anthropic-version": "2023-06-01"
                        },
                    });
                    break;
                default:
                    logger.ai.error(`Unsupported provider type: ${provider}`);
                    return sendAndLogError(logger.ai, "The specified AI provider is not supported.", 400, `Unsupported provider type: ${provider}`);
            }

            return response.status === 200
                ? { message: "Valid Api key", isSuccess: true }
                : { message: "Invalid Api key", isSuccess: false };

        } catch (error) {
            logger.apikey.error(`${provider} error : ${error}`);
            if (error.status == 401) {
                sendAndLogError(logger.apikey, "Invalid api key", 401, `${provider} error: ${error.message || "Unknown"}`);
            }
            sendAndLogError(logger.apikey, error.error?.error?.message || "Internal Server Error", error.status || 500, error.status ? `${provider} error: ${error.message || "Unknown"}` : `Error in ${provider} generation`);
        }
    }

    hashing(data) {
        const sha256Hash = crypto.createHash('sha256');
        sha256Hash.update(data);
        const sha256Digest = sha256Hash.digest('hex');
        return sha256Digest;
    }

}

module.exports = new UsageService();
