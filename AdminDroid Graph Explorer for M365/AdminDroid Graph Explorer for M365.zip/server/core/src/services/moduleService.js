const path = require("path");
const fetch = require("node-fetch");
const { exec } = require("child_process");
const AppInfo = require("../../../config/appInfo.js");
const toolsDetailsFileServices = require("../utils/toolsDetailsFileServices.js");
const updateService = require("./updateService.js");
const { sendAndLogError } = require("../../../util/errorResponse.js");
const { logger } = require("../../../util/logger.js");
const fileServices = require("../../../util/fileServices.js");
const pathUtils = require("../../../util/pathUtils.js");
const { updateRegistryVersion } = require("../utils/windows-utils.js");

class ModuleService {
  constructor() {
    this.appDir = pathUtils.getInstalledDir();
    fileServices.ensureFileDirectory(this.appDir);
  }

  async importModule(moduleId, url) {
    try {

      await this.basePreCheck();

      const downloadResponse = await fileServices.downloadFile(
        `${moduleId}.zip`,
        url
      );
      if (!downloadResponse.isSuccess) {
        sendAndLogError(
          logger.core,
          "Import Module Failed",
          500,
          "Failed to download module files."
        );
      }

      const moduleServerSourceFolderPath = path.join(
        downloadResponse.path,
        moduleId,
        pathUtils.folderNames.server
      );
      const moduleServerDestinationFolderPath = path.join(
        pathUtils.getServerDir(),
        moduleId
      );

      const moduleClientSourceFolderPath = path.join(
        downloadResponse.path,
        moduleId,
        pathUtils.folderNames.client
      );
      const moduleClientDestinationFolderPath = path.join(
        pathUtils.getClientDir(),
        "engines-dist"
      );

      await fileServices.copy(
        moduleServerSourceFolderPath,
        moduleServerDestinationFolderPath
      );
      await fileServices.copy(
        moduleClientSourceFolderPath,
        moduleClientDestinationFolderPath
      );
      await fileServices.delete(downloadResponse.path);
      await toolsDetailsFileServices.setAppInfo(
        "lastUpdated",
        toolsDetailsFileServices.getCurrentDateTime
      );

      logger.core.info(`${moduleId} Module added successfully!`);
      return {
        message: "Module added successfully!",
        isSuccess: true,
      };
    } catch (error) {
      logger.core.error(`import module processing error: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async importModuleStatus(moduleId) {
    try {
      const loadedTools =
        (await toolsDetailsFileServices.getAppInfo("loadedModules")) || [];
      if (loadedTools.includes(moduleId)) {
        return {
          message: "Module loaded successfully",
          isSuccess: true,
        };
      } else {
        return {
          message: "Module not loaded yet",
          isSuccess: false,
        };
      }
    } catch (error) {
      logger.core.error(`import module processing error: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async removeModule(moduleId) {
    try {
      const moduleServerFolderPath = path.join(
        pathUtils.getServerDir(),
        moduleId
      );
      const moduleClientFolderPath = path.join(
        pathUtils.getClientDir(),
        "engines-dist",
        moduleId
      );
      await fileServices.delete(moduleServerFolderPath);
      await fileServices.delete(moduleClientFolderPath);
      return {
        message: "Module removed and files are deleted successfully",
        isSuccess: true,
      };
    } catch (error) {
      logger.core.error(`remove module processing error: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async checkUpdate(compatibilityCheck = false) {
    try {
      let  installedApps =
        (await toolsDetailsFileServices.getAppInfo("loadedModules")) || [];

      installedApps.push(pathUtils.moduleNames.baseClient);
      // installedApps.push(pathUtils.moduleNames.baseServer);
      installedApps.push(pathUtils.moduleNames.tool);
      let requestBody = [];
      let baseClientInstalledVersion;
      for (const appId of installedApps) {
        var version = await toolsDetailsFileServices.getModuleInfo(
          appId,
          "version"
        );
        if (appId === pathUtils.moduleNames.baseClient) baseClientInstalledVersion = version;

        requestBody.push({
          appId: appId,
          version: version,
        });
      }

      const updateResult = (await this.updateCheckCall(requestBody)) || [];
      if (updateResult.errors) {
        sendAndLogError(
          logger.core,
          "Update check failed",
          500,
          `Failed during the check update api call`
        );
      }

      // console.log("updateres", updateResult);
   
      const baseUpdate = updateResult.find(
        (item) =>
          item?.moduleId === pathUtils.moduleNames.baseClient
      );

      // logger.testing.core.debug("requestBody : " + JSON.stringify(requestBody))
      // logger.testing.core.debug("updateResult : " + JSON.stringify(updateResult))

      let updateToolsList = this.checkVersionCompatability(
        updateResult,
        baseUpdate,
        requestBody,
        baseClientInstalledVersion
      );

      let compatibilityToolsList = this.checkVersionCompatability(
        updateResult,
        baseUpdate,
        requestBody,
        baseClientInstalledVersion,
        true
      );

      return { updateToolsList, compatibilityToolsList, baseUpdate };
    } catch (error) {
      logger.core.error(`check update tool processing error: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  checkVersionCompatability(
    updateResult,
    baseUpdate,
    requestBody,
    baseClientInstalledVersion,
    compatibilityCheck = false
  ) {
    let updatesList = [];

    updateResult.forEach((element, index) => {
      if (element == null) return;
      if (element.url == "" || element.url == null) return;
      if (compatibilityCheck) {
        if (
          element.moduleId === "tool" ||
          element.moduleId === pathUtils.moduleNames.baseClient ||
          element.moduleId === pathUtils.moduleNames.baseServer
        ) return;
      }
      if (element.moduleId === pathUtils.moduleNames.baseClient) return;

      if (element.isAvailable) {
        const cloned = { ...element };

        if (
          baseClientInstalledVersion === baseUpdate.version ||
          compatibilityCheck
        ) {
          cloned.isMandatory =
            cloned.supportedVersion !== requestBody[index].version;
        } else {
          cloned.isMandatory = false;
        }

        updatesList.push(cloned);
      }
    });

    return updatesList;
  }

  async updateCheckCall(body) {
    try {
      const response = await fetch(
        `${AppInfo.adminServerUrl}/community-tools/is-available`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(body),
        }
      );

      let updateResponse = await response.json();

      return updateResponse;
    } catch (error) {
      logger.core.error(`check update tool processing error: ${error}`);
      sendAndLogError(
        logger.core,
        "Update check failed",
        500,
        `Failed during the check update api call : ${JSON.stringify(error)}`
      );
    }
  }

  async updateModule(moduleId, url) {
    try {
      const backupPath = path.join(pathUtils.getBackupDir(), moduleId);

      await this.basePreCheck();

      const downloadResponse = await fileServices.downloadFile(
        `${moduleId}.zip`,
        url
      );
      if (!downloadResponse.isSuccess) {
        sendAndLogError(
          logger.core,
          "Import Moduel Failed",
          500,
          "Failed to download module files."
        );
      }

      const moduleServerSourceFolderPath = path.join(
        downloadResponse.path,
        moduleId,
        pathUtils.folderNames.server
      );
      const moduleServerDestinationFolderPath = path.join(
        pathUtils.getServerDir(),
        moduleId
      );

      const moduleClientSourceFolderPath = path.join(
        downloadResponse.path,
        moduleId,
        pathUtils.folderNames.client
      );
      const moduleClientDestinationFolderPath = path.join(
        pathUtils.getClientDir(),
        "engines-dist"
      );

      logger.core.debug("Applying update...");
      await updateService.updateApply(
        moduleId,
        moduleServerDestinationFolderPath,
        moduleServerSourceFolderPath,
        backupPath,
        false
      );
      await updateService.updateApply(
        moduleId,
        moduleClientDestinationFolderPath,
        moduleClientSourceFolderPath,
        backupPath,
        false
      );
      await fileServices.delete(downloadResponse.path);
      await toolsDetailsFileServices.setAppInfo(
        "lastUpdated",
        toolsDetailsFileServices.getCurrentDateTime
      );

      logger.core.info(`${moduleId} Module update completed successfully`);
      return {
        message: "Module updated successfully",
        isSuccess: true,
      };
    } catch (error) {
      logger.core.error(`update module processing error: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async revertModule(moduleId) {
    try {
      const moduleDestinationFolderPath = path.join(
        pathUtils.getServerDir(),
        moduleId
      );
      const backupFolderPath = path.join(pathUtils.getBackupDir(), moduleId);

      await updateService.revertApply(
        backupFolderPath,
        moduleDestinationFolderPath
      );
      await toolsDetailsFileServices.setAppInfo(
        "lastUpdated",
        toolsDetailsFileServices.getCurrentDateTime
      );

      logger.core.info("Module update reverted completed successfully");
      return {
        message: "Module updated reverted successfully",
        isSuccess: true,
      };
    } catch (error) {
      logger.core.error(`update module revert processing error: ${JSON.stringify(error)}`);
      throw new Error(`update module revert processing error: ${error}`);
    }
  }

  async updateBaseTool(url) {
    try {
      const batDir = path.resolve(pathUtils.getInstalledDir(), "script");
      const command = `powershell -Command "Start-Process cmd.exe -ArgumentList '/c cd /d \\"${batDir}\\" && update_base_files.bat "${url}"' -Verb runAs"`;

      logger.core.debug(`Base tool update parameter : ${command}`);

      return new Promise((resolve, reject) => {
        const child = exec(command, (error, stdout, stderr) => {
          if (error) {
            if (
              stderr.includes("The operation was canceled by the user") ||
              error.message.includes("canceled by the user")
            ) {
              return reject(new Error("User canceled the UAC prompt (clicked No)."));
            }
            return reject(error);
          }
          resolve("AdminDroid Community Tool Manager update started successfully.");
        });

        setTimeout(() => {
          try { child.kill(); } catch (_) { }
        }, 5000);
      });
    } catch (error) {
      logger.core.error(`update baseapp processing error: ${JSON.stringify(error)}`);
      sendAndLogError(logger.core, "Update base app failed!", 500, error.message);
    }
  }

  async updateBaseServer(baseDownloadURL) {
    try {

      const oldModulePath = path.join(pathUtils.getServerDir(), pathUtils.moduleNames.baseServer);
      const backupPath = path.join(pathUtils.getBackupDir(), pathUtils.moduleNames.baseServer);

      const newVersionFilesResponse = await fileServices.downloadFile(
        `${pathUtils.moduleNames.baseServer}.zip`,
        baseDownloadURL
      );
      if (!newVersionFilesResponse.isSuccess) {
        sendAndLogError(
          logger.core,
          "File Download error",
          500,
          `Failed to download update file`
        );
      }
      logger.core.debug("Applying Base Server update...");
      const newFolderPath = newVersionFilesResponse.path;
      await updateService.updateApply(
        pathUtils.moduleNames.baseServer,
        oldModulePath,
        newFolderPath,
        backupPath
      );
      await fileServices.delete(newVersionFilesResponse.path);
      await toolsDetailsFileServices.setAppInfo(
        "lastUpdated",
        toolsDetailsFileServices.getCurrentDateTime
      );

      logger.core.info(`Base Server Module update completed successfully`);
      return {
        message: "Base Server updated successfully",
        isSuccess: true,
      };
    } catch (error) {
      logger.core.error(`update module processing error: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async updateBaseClient(version, baseDownloadURL) {
    try {

      const oldModulePath = pathUtils.getClientDir();
      const backupPath = path.join(pathUtils.getBackupDir(), pathUtils.moduleNames.baseClient);

      const newVersionFilesResponse = await fileServices.downloadFile(
        `${pathUtils.moduleNames.baseClient}.zip`,
        baseDownloadURL
      );
      if (!newVersionFilesResponse.isSuccess) {
        sendAndLogError(
          logger.core,
          "File Download error",
          500,
          `Failed to download update file`
        );
      }
      logger.core.debug("Applying Base Client update...");
      const newFolderPath = path.resolve(newVersionFilesResponse.path, "dist");
      await updateService.updateApply(
        pathUtils.moduleNames.baseClient,
        oldModulePath,
        newFolderPath,
        backupPath
      );
      await fileServices.delete(newVersionFilesResponse.path);
      await toolsDetailsFileServices.setAppInfo(
        "lastUpdated",
        toolsDetailsFileServices.getCurrentDateTime
      );


      await updateRegistryVersion(version)

      logger.core.info(`Base Client Module update completed successfully`);
      return {
        message: "Base Client updated successfully",
        isSuccess: true,
      };
    } catch (error) {
      logger.core.error(`update module processing error: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  async basePreCheck() {
    const baseServerInstalledVersion = await toolsDetailsFileServices.getModuleInfo(
      pathUtils.moduleNames.baseServer,
      "version"
    );
    const baseClientInstalledVersion = await toolsDetailsFileServices.getModuleInfo(
      pathUtils.moduleNames.baseClient,
      "version"
    );
    const baseUpdateCheckResponse =
      (await this.updateCheckCall([
        {
          appId: pathUtils.moduleNames.baseServer,
          version: baseServerInstalledVersion,
        },
        {
          appId: pathUtils.moduleNames.baseClient,
          version: baseClientInstalledVersion,
        },
      ])) || [];

    for (const updateResponse of baseUpdateCheckResponse) {
      logger.testing.core.debug("update response : " + JSON.stringify(updateResponse));
      if (updateResponse?.isAvailable) {
        logger.core.debug(updateResponse.moduleId + " need to be update");
        if (updateResponse?.moduleId === pathUtils.moduleNames.baseServer) {
          await this.updateBaseServer(updateResponse?.url);
        } else {
          await this.updateBaseClient(updateResponse?.version, updateResponse?.url);
        }
        logger.core.debug(updateResponse.moduleId + " updated");
      }
    }


  }

  async listAllTools() {
    try {
      let finalizedToolList = [];
      const response = await fetch(`${AppInfo.adminServerUrl}/community-tools/tools`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const toolList = await response.json();
      let loadedTools = await toolsDetailsFileServices.getAppInfo(
        "loadedModules"
      );
      toolList.forEach((element) => {
        element["isEnabled"] = loadedTools.includes(element.moduleId) && element.url!=null;
        finalizedToolList.push(element);
      });
    
      await toolsDetailsFileServices.setToolCache(toolList);
      return finalizedToolList;
    } catch (error) {
      logger.core.error(`list all tool processing error: ${error}`);
      sendAndLogError(
        logger.core,
        "List all tools failed",
        500,
        `Failed list tool : ${error.message}`
      );
    }
  }
}

module.exports = new ModuleService();
