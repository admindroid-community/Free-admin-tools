const providerService = require("../services/providerService.js");
const usageService = require("../services/usageService.js");
const { sendAndLogError } = require("../../../util/errorResponse.js");
const { logger } = require("../../../util/logger.js");
const encryptService = require("../../../util/encryptService.js");

class ApiKeyController {

    async getApiKey(req, res, next) {
        try {
            const response = await providerService.getStoredCredentialData(
                "API_KEY_HIDE"
            );
            const usageData = await providerService.getStoredCredentialData(
                "API_KEY_USAGE"
            );
            let providers = await providerService.getProviders();
            providers = Object.values(providers);
            providers = providers.map((provider) => ({
                ...provider,
                apiKeys: response[provider.name] || [],
                usage: usageData[provider.name] || {},
            }));

            res.status(200).json(providers);
        } catch (error) {
            next(error);
        }
    }

    async setApiKey(req, res, next) {
        try {
            let { provider, apiKey } = req.body;
            if (!apiKey) {
                sendAndLogError(logger.apikey, "Missing apiKey in request body", 400, "API key is required for Validation.");
            }


            apiKey = encryptService.keyBasedDecrypt(apiKey);

            let response = await usageService.validateKey(
                provider,
                apiKey
            );

            if (response.isSuccess) {
                const data = { provider, apiKey };
                response = await providerService.setApiKeyData(data);
            }

            return res.json(response);

        } catch (error) {
            next(error);
        }
    }

    async enableKey(req, res, next) {
        try {
            const { provider, keyName } = req.body;
            if (!keyName) {
                sendAndLogError(logger.apikey, "Missing keyname in request body", 400, "Keyname is required.");
            }

            const data = { provider, keyName, type: "enable" };
            const response = await providerService.updateApiKeyData(data);

            return res.json(response);

        } catch (error) {
            next(error);
        }
    }

    async deleteKey(req, res, next) {
        try {
            const { provider, keyName } = req.body;
            if (!keyName) {
                sendAndLogError(logger.apikey, "Missing keyname in request body", 400, "Keyname is required.");
            }

            const data = { provider, keyName, type: "delete" };
            const response = await providerService.updateApiKeyData(data);

            return res.json(response);
        } catch (error) {
            next(error);
        }
    }

}

module.exports = new ApiKeyController();
