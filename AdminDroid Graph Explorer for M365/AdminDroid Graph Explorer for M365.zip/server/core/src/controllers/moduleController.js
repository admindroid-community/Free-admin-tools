const { moduleNames } = require("../../../util/pathUtils.js");
const moduleService = require("../services/moduleService.js");
const toolsDetailsFileServices = require("../utils/toolsDetailsFileServices.js");

class ModuleController {
  async importModule(req, res, next) {
    try {
      const { moduleId, url } = req.body;
      const result = await moduleService.importModule(moduleId, url);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  async importModuleStatus(req, res, next) {
    try {
      const { moduleId } = req.body;
      const result = await moduleService.importModuleStatus(moduleId);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  async removeModule(req, res, next) {
    try {
      const { moduleId } = req.body;
      const result = await moduleService.removeModule(moduleId);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }


  async updateCheck(req, res, next) {
    try {
      const result = (await moduleService.checkUpdate()) || {};
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  async updateModule(req, res, next) {
    try {
      const { moduleId, url, version } = req.body;
      let result;
      if (moduleId == moduleNames.tool) {
        result = await moduleService.updateBaseTool(url);
        result = { message: result, isSuccess: true };
      } else if (moduleId == moduleNames.baseServer) {
        result = await moduleService.updateBaseServer(url);
      } else if (moduleId == moduleNames.baseClient) {
        result = await moduleService.updateBaseClient(version, url);
      } else {
        result = await moduleService.updateModule(moduleId, url);
      }
      res.status(200).json(result);
    } catch (error) {
      // next(error);
      res.status(201).json({
        isSuccess: false,
        message: error
      });
    }
  }

  async revertModule(req, res, next) {
    try {
      const { moduleId } = req.body;
      const result = await moduleService.revertModule(moduleId);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }

  async listAllTools(req, res, next) {
    try {
      let data;
      try {
        const localData =
          (await toolsDetailsFileServices.getToolCache()) || [];
        if (localData.length > 0) {
          const loadedTools = await toolsDetailsFileServices.getAppInfo(
            "loadedModules"
          );
          localData.forEach(
            (element) =>
              (element["isEnabled"] = loadedTools.includes(element.moduleId) && element.url != null)
          );
          data = localData;
        } else {
          data = await moduleService.listAllTools();
        }
      } catch (err) {
        data = await moduleService.listAllTools();
      }
      res.status(200).json(data);
      moduleService.listAllTools();
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new ModuleController();
