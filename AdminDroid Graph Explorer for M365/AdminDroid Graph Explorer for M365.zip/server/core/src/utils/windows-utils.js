const { exec } = require('child_process');
const { logger } = require('../../../util/logger');
const AppInfo = require('../../../config/appInfo');
const toolsDetailsFileServices = require('./toolsDetailsFileServices');

const serviceName = "AdminDroid_Community_Tool";
const appId = "{BE7827A1-565F-4AA4-A7C0-8A6F3BFEBBB5}_AdminDroid_CT_is1";

function runAsAdmin(command) {
  logger.core.debug("Comment to run : " + command);
  return new Promise((resolve, reject) => {
    const safeCmd = command.replace(/"/g, '\\"');
    const runCommand = `powershell -Command "Start-Process cmd.exe -ArgumentList '/c ${safeCmd}' -Verb RunAs"`;

    exec(runCommand, (error, stdout, stderr) => {
      if (error) {
        reject(`Admin command failed: ${stderr || error.message}`);
      } else {
        resolve(stdout ? stdout.trim() : '');
      }
    });
  });
}

async function stopService() {
  if (AppInfo.buildType === "development") return;
  try {
    const serviceStatus = await checkWindowsService(serviceName);
    if (serviceStatus?.exists === true && serviceStatus?.isRunning === true) {
      const cmd = `sc stop "${serviceName}"`;
      const output = await runAsAdmin(cmd);
      await toolsDetailsFileServices.writeApplicationFiles("listening_port.txt", "", true);
      return output;
    }
  } catch (err) {
    console.error(`Failed to stop service "${serviceName}": ${err}`);
  }
}

async function updateRegistryVersion(newVersion) {
  try {
    const cmd = `reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\${appId}" /v DisplayVersion /t REG_SZ /d "${newVersion}" /f`;
    await runAsAdmin(cmd);
  } catch (err) {
    console.error(`Failed to update registry for "${appId}": ${err}`);
  }
}

function checkWindowsService(serviceName) {
  return new Promise((resolve, reject) => {
    exec(
      `powershell -Command "Get-Service -Name '${serviceName}' -ErrorAction SilentlyContinue"`,
      (error, stdout) => {
        if (!stdout.trim()) {
          resolve({ exists: false, running: false });
          return;
        }

        const isRunning = stdout.includes("Running");
        resolve({ exists: true, running: isRunning });
      }
    );
  });
}


module.exports = {
  stopService,
  updateRegistryVersion,
};
