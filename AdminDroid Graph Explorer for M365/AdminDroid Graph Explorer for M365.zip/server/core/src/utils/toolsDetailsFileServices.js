const path = require("path");
const { sendAndLogError } = require("../../../util/errorResponse.js");
const AppInfo = require("../../../config/appInfo.js");
const fileServices = require("../../../util/fileServices.js");
const pathUtils = require("../../../util/pathUtils.js");
const { logger } = require("../../../util/logger.js");

class ToolsDetailsFileServices {
  constructor() {
    (this.appDirPath = pathUtils.getInstalledDir()),
      (this.fileDirPath = pathUtils.getFilesDir()),
      fileServices.ensureFileDirectory(this.fileDirPath);
    this.appInfoFilePath = path.resolve(this.fileDirPath, "appInfo.json");
    this.toolCacheFilePath = path.resolve(this.fileDirPath, "toolCache.json");
  }

  async getAppInfo(key) {
    try {
      const data = await fileServices.readFile(this.appInfoFilePath);
      const jsonData = JSON.parse(data || "{}");
      return jsonData[key];
    } catch (err) {
      logger.core.error(`Error reading or parsing file: ${err}`);
      sendAndLogError(
        logger.core,
        "Error file action",
        500,
        `Error reading or parsing file: ${err}`
      );
    }
  }

  async getToolCache() {
    try {
      const data = await fileServices.readFile(this.toolCacheFilePath);
      const jsonData = JSON.parse(data || "{}");
      return jsonData;
    } catch (err) {
      logger.core.error(`Error reading or parsing file: ${err}`);
      sendAndLogError(
        logger.core,
        "Error file action",
        500,
        `Error reading or parsing file: ${err}`
      );
    }
  }

  async setAppInfo(key, value) {
    try {
      const data = await fileServices.readFile(this.appInfoFilePath);
      let jsonData = JSON.parse(data || "{}");
      jsonData[key] = value;
      await fileServices.writeFile(this.appInfoFilePath, jsonData, false);
      return { message: "Data successfully stored" };
    } catch (err) {
      logger.core.error(`Error reading or parsing file: ${err}`);
      sendAndLogError(
        logger.core,
        "Error file action",
        500,
        `Error reading or parsing file: ${err}`
      );
    }
  }

  async setToolCache(value) {
    try {
      await fileServices.writeFile(this.toolCacheFilePath, value, false)
      return { message: "Data successfully stored" };
    }
    catch {
      logger.core.error(`Error reading or parsing file: ${err}`);
      sendAndLogError(
        logger.core,
        "Error file action",
        500,
        `Error reading or parsing file: ${err}`
      );
    }
  }



  async getModuleInfo(moduleId, key) {
    try {
      let filePath;
      if (moduleId === pathUtils.moduleNames.baseClient) {
        filePath = path.resolve(
          this.appDirPath,
          "modules",
          pathUtils.folderNames.client,
          "info.json"
        );
      } else if (moduleId === pathUtils.moduleNames.tool) {
        filePath = path.resolve(this.appDirPath, "tool-info.json");
      } else {
        filePath = path.resolve(
          this.appDirPath,
          "modules",
          pathUtils.folderNames.server,
          moduleId,
          "info.json"
        );
      }
      const data = await fileServices.readFile(filePath);
      const jsonData = JSON.parse(data || "{}");
      return jsonData[key];
    } catch (err) {
      logger.core.error(`Error reading or parsing file: ${err}`);
      sendAndLogError(
        logger.core,
        "Error file action",
        500,
        `Error reading or parsing file: ${err}`
      );
    }
  }

  async readApplicationFiles(filename) {
    try {
      const execFolderPath = pathUtils.getInstalledDir();
      const filePath = path.resolve(path.join(execFolderPath, filename));
      return await fileServices.readFile(filePath);
    } catch (err) {
      logger.core.error(`Error reading or parsing file: ${err}`);
    }
  }

  async writeApplicationFiles(filename, data, isString) {
    try {
      const execFolderPath = pathUtils.getInstalledDir();
      const filePath = path.resolve(path.join(execFolderPath, filename));
      return await fileServices.writeFile(filePath, data, isString);
    } catch (err) {
      logger.core.error(`Error writing or parsing file: ${err}`);
    }
  }

  get getCurrentDateTime() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, "0");
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const year = now.getFullYear();

    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");

    return `${day}-${month}-${year}T${hours}:${minutes}:${seconds}`;
  }
}

module.exports = new ToolsDetailsFileServices();
