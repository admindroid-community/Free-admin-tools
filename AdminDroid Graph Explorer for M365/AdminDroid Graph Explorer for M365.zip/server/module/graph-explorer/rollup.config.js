const resolve = require('@rollup/plugin-node-resolve');
const commonjs = require('@rollup/plugin-commonjs');
const json = require('@rollup/plugin-json');
const { builtinModules } = require('module');
const path = require('path');

module.exports = {
  input: './src/router.js',
  output: {
    file: '../build/graph-explorer/router.cjs',
    format: 'cjs',
    sourcemap: false,
    inlineDynamicImports: true,
    intro: 'console.log("graphExplorer module started");',
  },
  external: [...builtinModules],

  plugins: [
    resolve({
      preferBuiltins: true,
      exportConditions: ['node'],
      browser: false,
    }),
    commonjs({
      include: ['../../node_modules/**', 'src/**', '../../config/**', '../../util/**', '../../core/**'],
      defaultIsModuleExports: true,
      ignoreDynamicRequires: false,
      sourceMap: true,
      transformMixedEsModules: true,
      dynamicRequireTargets: [
        'node_modules/express/lib/view.js',
        'node_modules/express/lib/view/*.js',
      ],
      dynamicRequireRoot: path.resolve(__dirname, 'node_modules'),
    }),
    json(),
  ],
};
