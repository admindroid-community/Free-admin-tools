const { logger } = require("../../../../util/logger.js");
const { Client } = require("@microsoft/microsoft-graph-client");

const { parse } = require("csv-parse/sync");
class GraphService {
  constructor() {
    this.graphClient = null;
  }

  async executeGraphRequest(path, version, method, body, headers, accessToken) {
    try {
      logger.graph.debug(`Executing Graph request
        ${path},
        ${version},
        ${method},
        ${body},
        ${headers}`);
      path = path.replace(/"/g, "'");
      this.graphClient = Client.init({
        authProvider: (done) => {
          done(null, accessToken);
        },
      });

      let request = this.graphClient.api(path);
      if (version) {
        request = request.version(version);
      }

      request = request.header("ConsistencyLevel", "eventual");

      if (headers && Array.isArray(headers)) {
        headers.forEach((element) => {
          request = request.header(element.name, element.value);
        });
      }

      let graphResponse;
      let statusCode;
      let statusMessage;
      let type;

      switch (method.toUpperCase()) {
        case "GET":
          const isPhotoRequest =
            path.endsWith("/photo/$value") ||
            /branding\/(logo|icon|backgroundImage)$/.test(path);

          const isCsvReportRequest =
            /^\/?reports\/get/i.test(path) ||
            /^\/?deviceManagement\/reports\//i.test(path);

          if (isPhotoRequest) {
            try {
              const imageBuffer = await request
                .responseType("arraybuffer")
                .get();
              const base64Image = Buffer.from(imageBuffer).toString("base64");
              return {
                type: "image",
                data: {
                  imageUrl: `data:image/png;base64,${base64Image}`,
                },
                statusCode: 200,
                statusMessage: "Ok",
                isSuccess: true,
              };
            } catch (error) {
              logger.graph.error(
                `Error fetching photo: ${JSON.stringify(error)}`,
              );
              const errorText = Buffer.from(error.body).toString("utf8");
              const errorObj = JSON.parse(errorText);
              return {
                type: "image",
                data: {
                  code: errorObj.error?.code || "ImageNotFound",
                  imageUrl: null,
                },
                statusCode: error.statusCode || 500,

                isSuccess: false,
              };
            }
          } else if (isCsvReportRequest) {
            try {
              // Request CSV as array buffer
              const csvBuffer = await request.responseType("arraybuffer").get();
              console.log("csvBuffer", csvBuffer);
              const csvText = Buffer.from(csvBuffer).toString("utf8");

              // Parse CSV into JSON
              const parsed = parse(csvText, {
                columns: true,
                skip_empty_lines: true,
              });

              return {
                type: "json",
                data: { value: parsed },
                statusCode: 200,
                statusMessage: "Ok",
                isSuccess: true,
              };
            } catch (err) {
              const errorText = Buffer.from(err.body).toString("utf8");
              const errorObj = JSON.parse(errorText);

              return {
                statusCode: err.statusCode || 500,
                data: {
                  code: errorObj?.error?.code || "graph_request_failed",
                  message:
                    errorObj?.error?.message ||
                    "Failed to execute Graph request",
                  innerError: errorObj.error?.innerError,
                },
                isSuccess: false,
              };
            }
          } else {
            graphResponse = await request.get();
    

            if (typeof graphResponse == "string") {
              type = "string";
              graphResponse = { value: graphResponse || [] };
            }
            statusMessage = "Ok";
            statusCode = 200;
            break;
          }

        case "POST":
          graphResponse = await request.post(body);
          statusCode = graphResponse ? 201 : 204;
          statusMessage = graphResponse ? "Created" : "No Content";
          break;
        case "PATCH":
          graphResponse = await request.patch(body);
          statusCode = graphResponse ? 200 : 204;
          statusMessage = graphResponse ? "Ok" : "No Content";
          break;
        case "DELETE":
          graphResponse = await request.delete();
          // if (!graphResponse) {
          //   graphResponse = {result:"Record deleted successfully"}
          // }
          statusCode = 204;
          statusMessage = "No Content";
          break;
        case "PUT":
          graphResponse = await request.put(body);
          statusCode = graphResponse ? 200 : 204;
          break;
        default:
          throw new Error(`Unsupported method: ${method}`);
      }

      return {
        type: "json",
        data: graphResponse || { value: [] },
        statusCode: statusCode || 200,
        statusMessage: statusMessage,
        isSuccess: true,
      };
    } catch (error) {
      logger.graph.error(`Graph request error: ${JSON.stringify(error)}`);
      const body =
        typeof error.body === "string" ? JSON.parse(error.body) : error.body;
      return {
        statusCode: error.statusCode,
        data: {
          code: error.code,
          message: error.message,
          innerError: body.innerError,
        },
        isSuccess: false,
      };
    }
  }
}
module.exports = new GraphService();
