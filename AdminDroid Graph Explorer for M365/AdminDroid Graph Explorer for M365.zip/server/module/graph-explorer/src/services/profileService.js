const encryptionService = require("../../../../util/encryptService.js");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const fileServices = require("../../../../util/fileServices.js");
const CredentialFileService = require("../../../../core/src/services/credentialFileService.js");
const { logger } = require("../../../../util/logger.js");

class ProfileService extends CredentialFileService {
  constructor() {
    super();
  }

  async saveUserProfile(inputData) {
    return await this.withProfileLock(async () => {
      try {
        let data = await this.getStoredProfileDataInternal();

        if (!data.MS) {
          data.MS = {};
        }

        data.MS[inputData.username] = inputData;

        // const encryptedData = encryptionService.encrypt(JSON.stringify(data));
        await fileServices.writeFile(this.profileFilePath, data, false);
        return { message: "Data successfully stored", isSuccess: true };
      } catch (error) {
        logger.session.error(`saving user profile: ${JSON.stringify(error)}`);
        return sendAndLogError(logger.session, "Error storing user profile", 500, "Failed to store user profile data.");
      }
    });
  }

  async deleteUserProfile(upn) {
    return await this.withProfileLock(async () => {
      try {
        let data = await this.getStoredProfileDataInternal();

        if (data.MS && data.MS[upn]) {
          delete data.MS[upn];
        }
        await fileServices.writeFile(this.profileFilePath, data, false);

        return { message: "Data successfully removed" };
      } catch (error) {
       logger.session.error(`deleting userprofile to file: ${JSON.stringify(error)}`);
        return sendAndLogError(logger.session, "Error deleting user profile", 500, "Failed to remove user profile data.");
      }
    });
  }

  async getStoredProfileData() {
    return await this.withProfileLock(async () => {
      return await this.getStoredProfileDataInternal();
    });
  }

  async getStoredProfileDataInternal() {
    try {
      const data = await fileServices.readFile(this.profileFilePath);

      if (!data || !data.length) {
        await this.ensureFileInitialized();
        return {};
      }

      const jsonData = JSON.parse(data || "{}");
      return jsonData || {};
    } catch (err) {
      logger.session.error(`getstoredProfile: ${JSON.stringify(err)}`);
      return {};
    }
  }
}

module.exports = new ProfileService();
