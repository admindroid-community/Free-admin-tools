const usageService = require("../../../../core/src/services/usageService.js");
const graphService = require("../services/graphService.js");
const profileService = require("../services/profileService.js");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const { logger } = require("../../../../util/logger.js");
class SessionController {
  async storeSession(req, res, next) {
  try {
        const {
          id,
          name,
          username,
          tenantId,
          accessToken,
          domainName,
          expiresOn,
          scopes,
          storeVisit,
        } = req.body;
  
        if (!id || !name || !username || !tenantId || !accessToken) {
          return sendAndLogError(logger.session, "Missing required session data", 400, "User and accessToken are required to store session.");
        }
        
  
        if (!req.session.m365user) {
          req.session.m365user = {};
        }
  
        req.session.m365user[username] = {
          id: id,
          name: name,
          username: username,
          tenantId: tenantId,
          accessToken: accessToken,
          domainName:domainName,
          scopes: scopes || [],
          expiresOn: expiresOn,
        };
  
        req.session.save((err) => {
          if (err) {
            console.error("Session save error:", err);
            res.json({
              isSuccess: false,
            });
            return;
          }
  
          res.json({
            username: username,
            isSuccess: true,
          });
        setImmediate(async () => {
          try {
            let response = await graphService.executeGraphRequest(
              "me/photo/$value",
              null,
              "GET",
              null,
              null,
              accessToken
            );

            await profileService.saveUserProfile({
              name: name,
              username: username,
              domainName:domainName,
              userPhotoUrl: response.data.imageUrl || null,
            });
          } catch (err) {
            console.error("Error saving user profile after response:", err);
          }
        });
      });
    } catch (error) {
      next(error);
    }
  }


  async getSession(req, res, next) {
    try {
      if (!req.session.m365user) {
        return sendAndLogError(logger.session, "No active session", 401, "User session not found.");
      }

      const sessions = Object.values(req.session.m365user).map((user) => {
        const isExpired = user.expiresOn && user.expiresOn <= Date.now();
        return {
          id: user.id,
          name: user.name,
          username: user.username,
          tenantId: user.tenantId,
          domainName:user.domainName,
          scopes: user.scopes || [],
          expiresOn: user.expiresOn,
          isExpired: isExpired,
        };
      });

      res.json(sessions);
    } catch (error) {
      console.error("Get session error:", error);
      next(error);
    }
  }

  async updateSession(req, res, next) {
    try {
      const { username } = req.params;
      if (!req.session.m365user[username]) {
        return sendAndLogError(logger.session, "No active session to update", 401, "User session not found.");
      }

      const { accessToken, expiresOn, scopes } = req.body;

      if (accessToken) {
        req.session.m365user[username].accessToken = accessToken;
      }
      if (expiresOn) {
        req.session.m365user[username].expiresOn = expiresOn;
      }
      if (scopes) {
        req.session.m365user[username].scopes = scopes;
      }

      const m365user = req.session.m365user[username];

      const isExpired = m365user.expiresOn && m365user.expiresOn <= Date.now();

      req.session.save((err) => {
        if (err) {
          console.error("Session update error:", err);
          return sendAndLogError(logger.session, "Failed to update session", 500, "Error while updating user session.");
        }
        res.json({
          id: m365user.id,
          name: m365user.name,
          username: m365user.username,
          tenantId: m365user.tenantId,
          domainName:m365user.domainName,
          scopes: m365user.scopes || [],
          expiresOn: m365user.expiresOn,
          isExpired: isExpired,
        });
      });

    } catch (error) {
      console.error("Update session error:", error);
      next(error);
    }
  }
  async deleteSession(req, res, next) {
    let { username } = req.params;
    try {
      if (req.session.m365user[username]) {
        delete req.session.m365user[username];

        return res.json({
          username: username,
          isSuccess: true,
        });
      } else {
        return res.json({
          username: username,
          isSuccess: false,
        });
      }
    } catch (error) {
      console.error("Clear session error:", error);
      next(error);
    }
  }
  async userPhoto(req, res, next) {
    try {
      const { username } = req.params;
      if (!req.session.m365user || !req.session.m365user[username]) {
        return sendAndLogError(logger.session, "No active session", 401, "User session not found.");
      }
      const accessToken = req.session.m365user[username].accessToken;

      let response = await graphService.executeGraphRequest(
        "me/photo/$value",
        null,
        "GET",
        null,
        null,
        accessToken
      );
      if (
        response.type === "image" &&
        response.data &&
        response.data.imageUrl
      ) {
        res.json({
          type: "image",
          imageUrl: response.data.imageUrl,
          isSuccess: true,
        });
      } else {
        res.json({
          type: "image",
          imageUrl: null,
          isSuccess: false,
        });
      }
    } catch (error) {
      console.error("Get user photo error:", error);
      next(error);
    }
  }
}
module.exports = new SessionController();
