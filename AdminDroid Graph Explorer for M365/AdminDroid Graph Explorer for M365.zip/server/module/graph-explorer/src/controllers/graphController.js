const { sendAndLogError } = require("../../../../util/errorResponse");
const { logger } = require("../../../../util/logger.js");
const graphService = require("../services/graphService");


class GraphController {
  async executeGraphRequest(req, res, next) {
    try {
      const { path, method, body, version ,headers} = req.body;
      const { username } = req.params;
      if (!req.session.m365user || !req.session.m365user[username]) {
        return sendAndLogError(logger.session, "No active session", 401, "User session not found.");
      }
      const accessToken = req.session.m365user[username].accessToken;
      if (!accessToken) {
        sendAndLogError(logger.graph, 'missing_access_token', 401, "Unauthorized: No access token provided");
      }

      if (!path || !method) {
        sendAndLogError(logger.graph, 'missing_parameters', 400, "Bad Request: Path and method are required");
      }

      const response = await graphService.executeGraphRequest(
        path,
        version,
        method,
        body,
        headers,
        accessToken
      );

      res.json(response);
    } catch (error) {
      console.error("error", error);
      next(error);
    }
  }
}

module.exports = new GraphController();
