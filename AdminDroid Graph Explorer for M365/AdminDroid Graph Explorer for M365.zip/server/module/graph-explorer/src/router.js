require("../../../config/polyfills.js");

const express = require("express");
const path = require("path");

const sessionController = require("./controllers/sessionController.js");
const graphController = require("./controllers/graphController.js");
const profileController = require("./controllers/profileController.js");
const { logger } = require("../../../util/logger.js");
const router = express.Router();
logger.production.core.info(`graphRouter`)
//session routes
router.post("/user", sessionController.storeSession);
router.get("/user", sessionController.getSession);
router.patch("/user/:username", sessionController.updateSession);
router.delete("/user/:username", sessionController.deleteSession);
router.get("/user/:username/photo", sessionController.userPhoto);


// graph routes
router.post("/graph/:username", graphController.executeGraphRequest);

router.get("/profiles", profileController.profiles);
router.delete("/profiles/:upn", profileController.deleteUserProfile);

module.exports = router;
