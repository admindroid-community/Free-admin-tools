function cleanJson(text) {
  if (typeof text !== "string") {
    text = JSON.stringify(text);
  }

  let cleaned = text
    .replace(/^json\\n/, "")
    .replace(/```json/, "")
    .replace(/```javascript/, "")
    .replace(/```/, "")
    .trim()
    .trimStart();

  while (cleaned.startsWith('"') || cleaned.endsWith('"')) {
    if (cleaned.startsWith('"')) cleaned = cleaned.slice(1);
    if (cleaned.endsWith('"')) cleaned = cleaned.slice(0, -1);
  }
  return cleaned;
}

function getText(text) {
  while (!text.json) {
    text = text.text;
  }
  return text;
}

function getCallTool(text) {
  while (typeof text.callTool !== "boolean") {
    text =
      typeof text.callTool === "string"
        ? JSON.parse(text.callTool)
        : text.callTool;
  }
  return text.callTool;
}

function getTextCode(text) {
  while (!text.inputToken) {
    text = text.text;
  }
  return text;
}

function getTextFromList(text) {
  text = JSON.parse(text);
  while (Array.isArray(text)) {
    text = text[0];
  }
  return text;
}

function isValidJson(text) {

  if (text[0] === "{" || text[0] === "[" || text[1] === "{" || text[1] === "["
  ) {
    try {
      text = JSON.parse(text)
      if (!text.json || !text.text) {
        return false;
      }
    }
    catch (ex) {
      return false;
    }
    return true;
  }
  return false;
}

function extractJson(text) {
  let json = text;
  let match;
  if (text.includes("javascript")) {
    match = text.match(/\`\`\`javascript\s*([\s\S]*?)\s*\`\`\`/);
  } else if (text.includes("json")) {
    match = text.match(/\`\`\`json\s*([\s\S]*?)\s*\`\`\`/);
  }
  if (match) {
    if (match.length > 1) {
      json = match[1].trim();
    }
  }

  const firstBrace = json.indexOf("{");
  const lastBrace = json.lastIndexOf("}");
  if (firstBrace >= 0 && lastBrace >= 1) {
    json = json.slice(firstBrace, lastBrace + 1);
  }
  return cleanJson(json);
}

function changeDN(originalDomain, inputText) {
  try {
    const originalDomainDN = `DC=${originalDomain.split(".").join(",DC=")}`;
    const changedJson = JSON.stringify(inputText)
      .replace(/test.com/g, originalDomain)
      .replace(/DC=test,DC=com/g, originalDomainDN);
    return JSON.parse(changedJson);
  } catch (err) {
    //console.log("Error in ChangeDN : ", err);
    return inputText;
  }
}

module.exports = {
  cleanJson,
  getText,
  getCallTool,
  getTextCode,
  changeDN,
  getTextFromList,
  isValidJson,
  extractJson,
};
