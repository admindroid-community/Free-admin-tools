const fs = require("fs-extra");
const fsPromise = require("fs/promises");
const path = require("path");
const appInfo = require("../config/appInfo.js");
const pathUtils = require("../util/pathUtils.js");

class Logger {
    constructor(moduleName = "", environment = "default") {
        this.moduleName = moduleName;
        this.environment = environment;
        this.activeEnv = appInfo.buildType?.toLowerCase() || "development";
        this.logDir = this.getLogDir();
        this.appInfoFilePath = path.resolve(
            pathUtils.getFilesDir(),
            "appInfo.json"
        );
        this.configurationFilePath = path.resolve(
            pathUtils.getFilesDir(),
            "configure.json"
        );
        this.ensureLogDir();
    }

    ensureLogDir() {
        if (this.logDir && !fs.existsSync(this.logDir)) {
            fs.mkdirSync(this.logDir, { recursive: true });
        }
    }

    getLogDir() {
        switch (this.activeEnv) {
            case "development":
                return path.join(process.cwd(), "logs");
            case "testing":
                return path.join(
                    pathUtils.getLogDir()
                );
            case "production":
                return path.join(pathUtils.getLogDir());
            default:
                return null;
        }
    }

    getTimestamp() {
        return new Date().toLocaleString();
    }

    shouldLog() {
        if (this.environment === "default") return true;
        else if (this.environment === "testing" && this.activeEnv !== "production") return true;
        else if (this.environment === "production") return true;
        return this.environment === this.activeEnv;
    }

    write(level, message) {
        if (!this.shouldLog()) return;
        const timestamp = this.getTimestamp();
        const logMessage = `[${timestamp}] ${level.toUpperCase()}: ${message}`;
        this.ensureLogDir();
        if (this.logDir) {
            const logFile = path.join(this.logDir, `${this.moduleName}.log`);
            fs.appendFileSync(logFile, logMessage + "\n", "utf8");
        }
        if (this.activeEnv === "development") {
            console.log(logMessage);
        }
    }

    async clearLog() {
        try {
            let jsonData = await this.readJSONData(this.appInfoFilePath) ?? {};
            let lastLogClearedData = jsonData["lastLogCleared"];
            let logClearIntervalDays;

            if (this.activeEnv === "development") {
                logClearIntervalDays = appInfo.logClearIntervalDays ?? 7
            } else {
                logClearIntervalDays = await this.readJSONData(this.configurationFilePath, "logClearIntervalDays") ?? 7;
            }

            const today = new Date();
            if (!lastLogClearedData) {
                lastLogClearedData = today;
            } else {
                const lastDate = new Date(lastLogClearedData);
                const diffMs = today - lastDate;
                const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
                if (diffDays >= logClearIntervalDays) {
                    fs.removeSync(this.getLogDir());
                    lastLogClearedData = today;
                }
            }

            jsonData["lastLogCleared"] = lastLogClearedData;
            await fsPromise.writeFile(this.appInfoFilePath, JSON.stringify(jsonData), "utf8");
        } catch (err) {
            console.error("Failed to clear logs:", err);
        }
    }

    async readJSONData(path, key) {
        const data = await fsPromise.readFile(path, "utf8");
        const jsonData = JSON.parse(data || "{}");
        return key
            ? jsonData[key] ?? null
            : jsonData;
    }

    debug(msg) { this.write("debug", msg); }
    info(msg) { this.write("info", msg); }
    warn(msg) { this.write("warn", msg); }
    error(msg) { this.write("error", msg); }
}

const createEnvLogger = (env) => ({
    ai: new Logger("ai", env),
    apikey: new Logger("apikey", env),
    session: new Logger("session", env),
    ldap: new Logger("ldap", env),
    graph: new Logger('Graph', env),
    core: new Logger("core", env),

});

const logger = {
    development: createEnvLogger("development"),
    testing: createEnvLogger("testing"),
    production: createEnvLogger("production"),
    ...createEnvLogger("default"),
};

module.exports = { Logger, logger };
