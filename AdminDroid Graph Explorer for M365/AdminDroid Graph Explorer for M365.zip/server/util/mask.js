const { logger } = require("./logger");

function regexMasking(query, maskingHistory,type) {
  const result = quoteMasking(query, maskingHistory);
  const finalResult = basicMasking(result.current, result.history,type);
  return finalResult;
}

function quoteMasking(query, maskingHistory) {
  try {
    const regex = /(?:(\b\w+\b)\s+)?\"([^"]+)\"/g;
    const values = JSON.parse(JSON.stringify(maskingHistory.values || {}));
    const keyCounts = JSON.parse(JSON.stringify(maskingHistory.keyCounts || {}));
    let currentlyUsedKeys = {};
    let template = query;
    let match;

    while ((match = regex.exec(query)) !== null) {
      let key = match[1] || "value";
      const value = match[2];

      keyCounts[key] = (keyCounts[key] || 0) + 1;
      const indexedKey = keyCounts[key] > 1 ? `${key}${keyCounts[key]}` : `${key}1`;

      values[indexedKey] = value;
      currentlyUsedKeys[indexedKey] = value;
      template = template.replace(`"${value}"`, `{{${indexedKey}}}`);
    }

    return {
      current: { template: template, values: currentlyUsedKeys },
      history: { values: values, keyCounts: keyCounts }
    };
  } catch (error) {
    console.error("Error during masking:", error);
  }
}

function basicMasking(currentMasking, maskingHistory,type) {
  // Common Regex for email,id, phone, URL, date, IP, postal code, username, credit card
const regex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b|\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b|\b(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{2,4}\)?[\s-]?)?\d{3,4}[\s-]?\d{3,4}\b|\bhttps?:\/\/[^\s/$.?#].[^\s]*\b|\b(?:\d{1,2}[-\/]\d{1,2}[-\/]\d{4}|\d{4}[-\/]\d{1,2}[-\/]\d{1,2})\b|\b(?:\d{1,3}\.){3}\d{1,3}\b|\b\d{5,6}\b|(?:^|\s)@[A-Za-z0-9_]{3,20}\b|\b(?:\d[ -]*?){13,19}\b/gi;

  let template = currentMasking.template;
  let keyCounts = JSON.parse(JSON.stringify(maskingHistory.keyCounts || {}));
  let values = JSON.parse(JSON.stringify(maskingHistory.values || {}));
  let currentlyUsedKeys = JSON.parse(JSON.stringify(currentMasking.values || {}));
  let match;

  while ((match = regex.exec(template)) !== null) {
    const value = match[0];

    let keyType = "";
    if (/^[A-Za-z0-9._%+-]+@/.test(value))
    {
      keyType = type == 'm365' ? "upn" : "email";
    }
    else if (/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(value)) keyType = "id";
    else if (/^\+?\d[\d\s()-]{7,}$/.test(value)) keyType = "phone";
    else if (/^https?:\/\//.test(value)) keyType = "url";
    else if (/^\d{1,2}[-\/]\d{1,2}[-\/]\d{4}$|^\d{4}[-\/]\d{1,2}[-\/]\d{1,2}$/.test(value)) keyType = "date";
    else if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(value)) keyType = "ip";
    else if (/^\d{5,6}$/.test(value)) keyType = "postal";
    else if (/(?:^|\s)@[A-Za-z0-9_]{3,20}\b/.test(value)) keyType = "username";
    else if (/^(?:\d[ -]*?){13,19}$/.test(value)) keyType = "card";
    else keyType = "value";

    keyCounts[keyType] = (keyCounts[keyType] || 0) + 1;
    const indexedKey = `${keyType}${keyCounts[keyType]}`;

    values[indexedKey] = value;
    currentlyUsedKeys[indexedKey] = value;
    template = template.replace(value, `{{${indexedKey}}}`);
  }
  return {
    current: { template: template, values: currentlyUsedKeys },
    history: { values: values, keyCounts: keyCounts }
  };
}

module.exports = { regexMasking };