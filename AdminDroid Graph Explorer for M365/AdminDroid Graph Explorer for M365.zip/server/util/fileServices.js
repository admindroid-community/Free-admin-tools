const fs = require("fs-extra");
const AdmZip = require("adm-zip");
const path = require("path");
const fetch = require("node-fetch");
const { execSync } = require("child_process");
const fsPromise = require("fs/promises");


const { sendAndLogError } = require("../util/errorResponse.js");
const { logger } = require("./logger.js");

const pathUtils = require("../util/pathUtils.js");

class FileServices {

    async downloadFile(filename, url) {

        try {
            const randomPart = Math.random().toString(36).substring(2, 7);
            filename = `${randomPart}_${filename}`;
            const tempFilePath = path.join(pathUtils.getTempDir(), filename);
            const isZip = (filename.split(".")[1] === "zip") || false;
            const nameOnly = filename.replace(/\.[^/.]+$/, "");
            const extractPath = path.join(pathUtils.getTempDir(), `${nameOnly}-unzipped`);

            await this.ensureFileDirectory(pathUtils.getTempDir());
            await this.delete(tempFilePath);

            // const response = await fetch(`${url}?cache_bust=${Date.now()}`, {
            //     method: "GET",
            //     headers: {
            //         "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            //         "accept-encoding": "gzip, deflate, br, zstd",
            //         "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
            //         "cache-control": "no-cache",
            //         "pragma": "no-cache",
            //         "sec-ch-ua": "\"Chromium\";v=\"142\", \"Google Chrome\";v=\"142\", \"Not_A Brand\";v=\"99\"",
            //         "sec-ch-ua-mobile": "?0",
            //         "sec-ch-ua-platform": "\"Windows\"",
            //         "sec-fetch-dest": "document",
            //         "sec-fetch-mode": "navigate",
            //         "sec-fetch-site": "none",
            //         "sec-fetch-user": "?1",
            //         "upgrade-insecure-requests": "1",
            //         "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
            //     }
            // });

            // logger.core.info(`This is the url downlaoded for module ${nameOnly} and old url :${url} and new url : ${response.url}`)

            // if (!response.ok) {
            //     sendAndLogError(logger.core, "File Download error", 500, `Failed to download ZIP file`);
            // }
            // const buffer = await response.arrayBuffer();
            // await fs.writeFile(tempFilePath, Buffer.from(buffer));

            // logger.core.debug(`resposne headers start`);
            // response.headers.forEach((v, k) => console.log(k, v));
            // console.log([...response.headers.entries()]);
            // logger.core.debug(`resposne headers end`);
            // logger.core.debug(`zip url : ${response.url}`);
            
            try {
                execSync(
                    `curl -L --fail --silent --show-error -o "${tempFilePath}" "${`${url}?t=${Date.now()}`}"`,
                    { stdio: "inherit" }
                );
                logger.core.info("Download completed" + tempFilePath);

            } catch (err) {
                logger.core.error("Download failed!");
                if (err.status) {
                    logger.core.error(`Curl exited with code: ${err.status}`);
                }
                if (err.stderr) {
                    logger.core.error("Error output:", err.stderr.toString());
                }
            }

            logger.core.info("Download completed");

            if (isZip) {
                await this.delete(extractPath);
                const zip = new AdmZip(tempFilePath);
                zip.extractAllTo(extractPath, true);
                await this.delete(tempFilePath);
                logger.core.info("Zip Extracted completed");
            }
            logger.core.info(`extractPath : ${extractPath}`);
            logger.core.info(`tempFilePath : ${tempFilePath}`);
            return { path: isZip ? extractPath : tempFilePath, isSuccess: true };

        } catch (error) {
            logger.core.error(`file download processing error: ${error}`);
            sendAndLogError(logger.core, "File Download error", 500, `file download processing error: ${error}`);
        }
    }

    async ensureFileDirectory(filePathOrDir) {
        const hasExtension = path.extname(filePathOrDir) !== '';
        const dir = hasExtension ? path.dirname(filePathOrDir) : filePathOrDir;
        try {
            fs.mkdir(dir, { recursive: true });
        } catch (err) {
            logger.core.error(`Failed to create directory: ${err}`);
            sendAndLogError(logger.core, "File Download error", 500, `file download processing error: ${err}`);
        }
    }

    async copy(sourcePath, destinationPath) {
        try {
            await fs.copy(sourcePath, destinationPath, { overwrite: true });
            logger.core.info(`Copied successfully: ${sourcePath}`);
        } catch (err) {
            logger.core.error(`Copy failed: ${err}`);
            sendAndLogError(logger.core, `Copying failed : ${sourcePath}`, 500, `Copy failed : ${err}`);
        }
    }

    async delete(targetPath) {
        try {
            const exists = await fs.pathExists(targetPath);
            if (!exists) {
                logger.core.debug(`Nothing to delete (path does not exist): ${targetPath}`);
                return;
            }
            await fs.remove(targetPath);
            logger.core.info(`Deleted successfully: ${targetPath}`);
        } catch (err) {
            logger.core.error(`Deletion failed: ${err}`);
            sendAndLogError(logger.core, `Deletion failed : ${targetPath}`, 500, `Delete failed : ${err}`);
        }
    }

    checkDirExists(path) {
        return fs.existsSync(path);
    }

    async readFile(filePath) {
        try {
            return await fsPromise.readFile(filePath, 'utf8');
        } catch (err) {
            console.error(`Error reading file: ${err}`);
            throw new Error(`Error reading file: ${err}`);
        }
    }

    async writeFile(filePath, content, isString) {
        try {
            const data = isString ? content : JSON.stringify(content, null, 2);
            await fsPromise.writeFile(filePath, data, 'utf8');
        } catch (err) {
            console.error(`Error writing JSON file: ${err}`);
            throw new Error(`Error writing JSON file: ${err}`);
        }
    }

    async getAllDir(rootPath) {
        try {
            const entries = await fs.readdir(rootPath, { withFileTypes: true });
            const dirs = entries
                .filter(dirent => dirent.isDirectory())
                .map(dirent => dirent.name);
            return dirs;
        } catch (err) {
            logger.core.error("Error reading directories:", err);
            return [];
        }
    }

}

module.exports = new FileServices();
