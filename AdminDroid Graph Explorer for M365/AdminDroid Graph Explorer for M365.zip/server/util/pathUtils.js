const appInfo = require('../config/appInfo.js');
const path = require('path');

const folderNames = {
  modules: "modules",
  files: "files",
  temp: "temp",
  backup: "backup",
  log: "logs",
  server: "server",
  client: "client"
}

const moduleNames = {
  "ad": "ad",
  "m365": "m365",
  "graph-explorer": "graph-explorer",
  "ldap-explorer": "ldap-explorer",
  "baseServer": "baseServer",
  "baseClient": "baseClient",
  "tool": "tool"
}

function getInstalledDir() {
  if (appInfo.buildType === "development") {
    return path.resolve(appInfo.defaultInstallationPath);
  } else {
    return path.dirname(process.execPath);
  }
}

function getModulesDir() {
  return path.resolve(getInstalledDir(), folderNames.modules);
}

function getFilesDir() {
  return path.resolve(getInstalledDir(), folderNames.files);
}

function getTempDir() {
  return path.resolve(getInstalledDir(), folderNames.temp);
}

function getLogDir() {
  return path.resolve(getInstalledDir(), folderNames.log);
}

function getBackupDir() {
  return path.resolve(getInstalledDir(), folderNames.backup);
}

function getServerDir() {
  return path.resolve(getModulesDir(), folderNames.server);
}

function getClientDir() {
  return path.resolve(getModulesDir(), folderNames.client);
}

module.exports = {
  folderNames,
  moduleNames,
  getInstalledDir,
  getModulesDir,
  getFilesDir,
  getTempDir,
  getLogDir,
  getBackupDir,
  getServerDir,
  getClientDir
}