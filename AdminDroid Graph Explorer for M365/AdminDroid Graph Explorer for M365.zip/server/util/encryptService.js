const crypto = require("crypto");
const machineIdModule = require("node-machine-id");
const CryptoJS = require("crypto-js");

const { machineIdSync } = machineIdModule;

class EncryptService {
  constructor() {
    this.machineId = machineIdSync();
    this.key = crypto.createHash("sha256").update(this.machineId).digest();
  }

  encrypt(text) {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv("aes-256-cbc", this.key, iv);
    const encrypted = Buffer.concat([
      cipher.update(text, "utf8"),
      cipher.final(),
    ]);
    return `${iv.toString("hex")}:${encrypted.toString("hex")}`;
  }

  decrypt(data) {
    const [ivHex, encryptedHex] = data.split(":");
    const iv = Buffer.from(ivHex, "hex");
    const encrypted = Buffer.from(encryptedHex, "hex");
    const decipher = crypto.createDecipheriv("aes-256-cbc", this.key, iv);
    const decrypted = Buffer.concat([
      decipher.update(encrypted),
      decipher.final(),
    ]);
    return decrypted.toString("utf8");
  }

  keyBasedDecrypt(data) {
    return CryptoJS.AES.decrypt(data, "my-secret-key").toString(
      CryptoJS.enc.Utf8,
    );
  }
}

module.exports = new EncryptService();
