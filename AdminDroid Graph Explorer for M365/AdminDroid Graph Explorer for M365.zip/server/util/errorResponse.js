const { logger } = require("./logger.js");

class ErrorResponse extends Error {
  constructor(message, statusCode, details = null) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
  }
}

const errorHandler = (err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  const details = err.details || null;

  // Log consistently
  try {
    logger.core.error(`[${statusCode}] ${message}${details ? ` - ${details}` : ""}`);
  } catch (_) { /* ignore logging failures */ }

  res.status(statusCode).json({
    error: message,
    status: statusCode,
    ...(details && { details }),
  });
};

const sendError = (message, statusCode, details = null) => {
  throw new ErrorResponse(message, statusCode, details);
};

const sendAndLogError = (log, message, statusCode, details = null) => {
  try {
    if (log && typeof log.error === "function") {
      log.error(`[${statusCode}] ${message}${details ? ` - ${details}` : ""}`);
    }
  } catch (_) { /* ignore logging failures */ }
  throw new ErrorResponse(message, statusCode, details);
};

module.exports = { ErrorResponse, errorHandler, sendError, sendAndLogError };
