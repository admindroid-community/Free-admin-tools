const Mustache = require("mustache");

async function unMaskMacro(template, value = {}) {
  const safeValue = new Proxy(value, {
    get: (target, prop) => (prop in target ? target[prop] : "")
  });

  return Mustache.render(template, safeValue);
}

module.exports = { unMaskMacro };
