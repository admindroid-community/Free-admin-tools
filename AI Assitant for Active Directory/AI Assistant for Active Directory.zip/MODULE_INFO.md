# AI Assistant for Active Directory

- Module: Active Directory
- Module ID: ad
- Module version: 1.7.9.50
- Server (base): 2.0.0.33
- Client (base): 2.0.0.66
