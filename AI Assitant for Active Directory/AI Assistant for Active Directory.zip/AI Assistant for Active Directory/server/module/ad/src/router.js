require('../../../config/polyfills.js');

const express = require("express");
const path = require("path");
const rateLimit = require("express-rate-limit");

const aiController = require("./controllers/aiController.js");
const authControllerAD = require("./controllers/authControllerAD.js");
const ldapController = require("./controllers/ldapController.js");
const { logger } = require('../../../util/logger.js');
const configurationService = require('../../../core/src/services/configurationService.js');

const pathUtils = require("../../../util/pathUtils.js");
// const { exec } = require('child_process');
const { execFile } = require("child_process");
const AppInfo = require('../../../config/appInfo.js');
const { sendAndLogError } = require('../../../util/errorResponse.js');
const { validateBody } = require('../../../util/validator.js');
const { ldapOperationSchema } = require('../../../core/src/routes/validationSchemas.js');

const router = express.Router();

logger.production.core.info(`adRouter`)


async function needToRestart() {

    // if (AppInfo.buildType === "development") return;

    logger.core.debug("Need to restart check function.")
    const testKey = "isNeedToRestart";
    const configData = await configurationService.getConfigurations(testKey);

    logger.testing.core.debug(configData + "configdata")

    if (configData === undefined || configData === null || configData === true) {
        logger.core.debug("Need to restart check function : true")
        await configurationService.setConfigurations(testKey, false)

        try {
            await callRestartBat();
            logger.core.debug("Restarted successfully");
        } catch (error) {
            await configurationService.setConfigurations(testKey, true);
            logger.core.debug("Restarted failed");
        }

    }
    logger.core.debug("Need to restart check function : false")
}

// async function callRestartBat() {
//     try {
//         const batFilePath = path.resolve(pathUtils.getInstalledDir(), "script", "service_restart.bat");
//         const command = `"${batFilePath}"`;

//         logger.core.debug("Command to run : " + command);

//         return await new Promise((resolve, reject) => {
//             const safeCmd = command.replace(/"/g, '\\"');

//             const runCommand = `powershell -Command "Start-Process cmd.exe -ArgumentList '/c ${safeCmd}' -Verb RunAs -Wait"`;

//             exec(runCommand, (error, stdout, stderr) => {
//                 if (error) {
//                     reject(`Admin command failed: ${stderr || error.message}`);
//                 } else {
//                     resolve(stdout ? stdout.trim() : '');
//                 }
//             });
//         });

//     } catch (err) {
//         logger.core.error(`Failed to execute BAT file: ${err}`);
//         reject(`Admin command failed: ${err}`);
//     }
// }

async function callRestartBat() {
    try {

        const installDir = pathUtils.getInstalledDir();
        const batFilePath = path.resolve(installDir, "script", "service_restart.bat");

        logger.core.debug("Executing restart script: " + batFilePath);

        logger.core.debug("Executing restart script: " + batFilePath);

        return await new Promise((resolve, reject) => {

            const psCommand = `
        try {
          $p = Start-Process -FilePath "cmd.exe" -ArgumentList '/c "${batFilePath}"' -Verb RunAs -Wait -PassThru -ErrorAction Stop
          if ($null -eq $p) { exit 1 }
          exit $p.ExitCode
        } catch {
          exit 1
        }
      `;

            execFile(
                "powershell.exe",
                ["-NoProfile", "-Command", psCommand],
                { windowsHide: true },
                (error, stdout, stderr) => {

                    if (error) {
                        logger.core.error(`Admin command failed: ${stderr || error.message}`);
                        return reject(stderr || error.message);
                    }

                    resolve(stdout ? stdout.trim() : "");

                }
            );

        });

    } catch (err) {
        logger.core.error(`Failed to execute BAT file: ${err}`);
        throw err;
    }
}

needToRestart()
    .then(() => {
        logger.core.info("Restart verified.");
    })
    .catch(err => {
        logger.core.error(err);
    });

const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 15,
    handler: (req, res) => {
        logger.session.warn("Rate limit hit:" + req.ip);
        res.status(429).json({
            "error": "Too many login attempts. Try again later.",
            "status": 429
        });
    },
    standardHeaders: true,
    legacyHeaders: false
});

// ai routes
router.post("/ai/json/:userBindID", aiController.getResponse.bind(aiController));
router.post("/ai/code", aiController.generateCode.bind(aiController));
router.post("/ai/keys", aiController.priorityContext.bind(aiController));
router.post("/ai/CallTool", aiController.handleCallTool.bind(aiController));

// ad-auth routes
router.post("/login", loginLimiter, authControllerAD.login);
router.get("/profile", authControllerAD.profile);
router.delete("/profile/:userBindID", authControllerAD.deleteProfile);
router.post("/logout/:userBindID", authControllerAD.logout);

// ldap routes
router.post("/ldap/:userBindID", validateBody(ldapOperationSchema), ldapController.executeLDAPRequest);
router.post("/thumbnail-photo/:userBindID", ldapController.getThumbnailPhoto);

module.exports = router;