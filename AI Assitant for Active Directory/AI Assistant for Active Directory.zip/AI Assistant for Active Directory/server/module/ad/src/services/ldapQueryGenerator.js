const { logger } = require("../../../../util/logger");
const { ObjectTypes, FilterTypes, ScopeTypes, FilterLogicalConditionTypes, FilterValueTypes, FilterActionsAvailable } = require("./ldapEnums");
const { ObjectClassFilters, FilterPresetOptions, TabHeaders } = require("./ldapConfig");
const ldapService = require("./ldapService");
const { unMaskMacro } = require("../../../../util/unmask");
const { sendAndLogError } = require("../../../../util/errorResponse");
const { escapeLDAPValue } = require("../utils/ldapDataFormat");

class LDAPQueryGenerator {


    static appliedFilterActions = [];


    static attrUsingFileTimeFormat = ["accountexpires", "lastlogon", "lastlogoff", "lastlogontimestamp", "pwdlastset", "badpasswordtime", "lockouttime", "creationtime"];
    static attrUsingGeneralizedTimeFormat = ["whencreated", "whenchanged", "modifytimestamp", "createtimestamp"];
    static attrStoreDN = ["manager", "memberof", "member", "managedby", "gplink", "objectcategory", "msds-resultantpso", "homemdb", "homemta", "msexchhomeservername"];

    static UPNReplacement = {};

    static addUPNReplacement(key, dn) {
        if (!Object.keys(this.UPNReplacement).includes(key)) {
            this.UPNReplacement[key] = dn;
        }
    }

    static async getUPNReplacement(key, { bindData = null }) {
        try {

            if (key === null || key === "" || this.isActiveDirectoryDN(key)) return key;

            logger.testing.ldap.debug("getUPNReplacement : " + key);

            if (Object.keys(this.UPNReplacement).includes(key)) {
                logger.testing.ldap.debug("getUPNReplacement : conatins " + key);
                return this.UPNReplacement[key];
            } else {
                logger.testing.ldap.debug("getUPNReplacement : not contains" + key);
                var result = await ldapService.getObjectDN(bindData, key);
                logger.testing.ldap.debug("getUPNReplacement : result" + JSON.stringify(result));
                const dn = result?.distinguishedName;
                logger.testing.ldap.debug("getUPNReplacement : dn" + dn);
                if (dn != null && this.isActiveDirectoryDN(dn)) {
                    logger.testing.ldap.debug("getUPNReplacement : valid dn" + dn);
                    this.addUPNReplacement(key, dn);
                    logger.testing.ldap.debug("getUPNReplacement : added in cache" + dn);
                    return dn;
                }
                return key;
            }
        } catch (err) {
            logger.ldap.error("Get DN Based Filter Error : " + err);
            sendAndLogError(
                err?.details,
                err?.details || "Serach Failed",
                err?.statusCode || 401,
                `Failed to fetch DN for "${key}"`
            );
        }
    }

    static clearUPNCache() {
        this.UPNReplacement = {};
        logger.ldap.debug("UPN cache cleared.");
    }


    static async generate(params, { bindData = null, maskingHistory = null }) {

        this.appliedFilterActions = [];
        const maskedParams = structuredClone(params);

        logger.testing.ldap.debug("params : " + JSON.stringify(params));
        logger.testing.ldap.debug("maskedParams : " + JSON.stringify(maskedParams));

        if (params?.operation !== "search") {
            return { query: maskedParams, unmaskedQuery: await this.updateOtherOperations(params, { bindData: bindData, maskingHistory: maskingHistory }), appliedFilterActions: this.appliedFilterActions };
        }

        logger.testing.ldap.debug(1)
        var query = {};

        query.operation = maskedParams?.operation;
        query.dn = maskedParams.dn ?? "-"
        query.params = {};

        query.params.scope = this.prepareScope(maskedParams?.scope);
        query.params.filter = await this.prepareLDAPFilter(maskedParams?.filter, maskedParams?.objectType, bindData, maskingHistory, { unmasked: false });
        query.params.attributes = this.appendMustIncludedAttributes(maskedParams?.attributes || ["cn", "sn", "mail"], maskedParams?.objectType);

        query.sortKeys = maskedParams?.sortKeys;
        query.size = maskedParams?.size;

        logger.testing.ldap.debug("after query : " + JSON.stringify(params));

        var unmaskedQuery = {};

        unmaskedQuery.operation = params?.operation;
        unmaskedQuery.dn = params?.dn ?? "-"
        unmaskedQuery.params = {};

        unmaskedQuery.params.scope = this.prepareScope(params?.scope);
        unmaskedQuery.params.filter = await this.prepareLDAPFilter(params?.filter, params?.objectType, bindData, maskingHistory, { unmasked: true });
        unmaskedQuery.params.attributes = this.appendMustIncludedAttributes(params?.attributes || ["cn", "sn", "mail"], params?.objectType);

        unmaskedQuery.sortKeys = params?.sortKeys;
        unmaskedQuery.size = params?.size;

        return { query: query, unmaskedQuery: unmaskedQuery, appliedFilterActions: this.appliedFilterActions };
    }

    static async updateOtherOperations(params, { bindData = null, maskingHistory = null }) {

        if (params?.operation === "add") {
            // if (params?.params?.groupType) {
            //     const oldValue = params?.params?.groupType;
            //     params.params.groupType = FilterPresetOptions.groupType[oldValue]?.ldapGroupType ?? oldValue;
            // }
            return await this.updateUPNInAddOperation(params, { bindData: bindData, maskingHistory: maskingHistory });
        } else if (params?.operation === "modify") {
            return await this.updateUPNInUpdateOperation(params, { bindData: bindData, maskingHistory: maskingHistory });
        } else if (params?.operation === "delete") {
            return await this.updateUPNInDeleteOperation(params, { bindData: bindData, maskingHistory: maskingHistory });
        } else if (params?.operation === "move") {
            return await this.updateUPNInMoveOperation(params, { bindData: bindData, maskingHistory: maskingHistory });
        }

        return params;

    }

    static async updateUPNInAddOperation(params, { bindData = null, maskingHistory = null }) {

        if (params?.params) {
            params.params = this.filterValidADAttributes(params?.params)
        }

        for (const [key, value] of Object.entries(params?.params ?? {})) {
            if (this.attrStoreDN.includes(key.toLowerCase())) {

                if (Array.isArray(value)) {
                    for (let i = 0; i < value?.length; i++) {
                        var unmaskedValue = value[i];

                        if (this.isValidMaskedData(unmaskedValue)) {
                            unmaskedValue = await unMaskMacro(
                                unmaskedValue,
                                maskingHistory,
                            );
                        }
                        if (this.isActiveDirectoryDN(unmaskedValue)) {
                            const dnResult = await ldapService.verifyOrGetFirstRDN(bindData, unmaskedValue);

                            if (dnResult != null && dnResult.found && dnResult.distinguishedName) {
                                unmaskedValue = dnResult.distinguishedName
                            } else {
                                unmaskedValue = this.getFirstDNValue(unmaskedValue) ?? "-";
                            }
                        }
                        const dn = await this.getUPNReplacement(unmaskedValue, { bindData: bindData });

                        if (dn != null) {
                            params.params[key][i] = dn;
                        }
                    }

                } else {

                    var unmaskedValue = value;

                    if (this.isValidMaskedData(unmaskedValue)) {
                        unmaskedValue = await unMaskMacro(
                            unmaskedValue,
                            maskingHistory,
                        );
                    }
                    if (this.isActiveDirectoryDN(unmaskedValue)) {
                        const dnResult = await ldapService.verifyOrGetFirstRDN(bindData, unmaskedValue);

                        if (dnResult != null && dnResult.found && dnResult.distinguishedName) {
                            unmaskedValue = dnResult.distinguishedName
                        } else {
                            unmaskedValue = this.getFirstDNValue(unmaskedValue) ?? "-";
                        }
                    }
                    const dn = await this.getUPNReplacement(unmaskedValue, { bindData: bindData });

                    if (dn != null) {
                        params.params[key] = dn;
                    }
                }
            } else if (key === "groupType") {
                params.params[key] = FilterPresetOptions.groupType[value]?.ldapGroupType ?? value;
            }
        }
        return params;

        function ensureArray(value) {
            if (Array.isArray(value)) {
                return value;
            }
            return [value];
        }
    }

    static async updateUPNInUpdateOperation(params, { bindData = null, maskingHistory = null }) {
        var changes = params?.changes ?? [];
        for (let i = 0; i < changes.length; i++) {

            const item = changes[i];
            const key = item?.modification?.type ?? "-";
            const values = item?.modification?.vals ?? [];

            if (this.attrStoreDN.includes(key.toLowerCase())) {

                for (let j = 0; j < values.length; j++) {

                    var unmaskedValue = values[j];

                    if (this.isValidMaskedData(unmaskedValue)) {
                        unmaskedValue = await unMaskMacro(
                            unmaskedValue,
                            maskingHistory,
                        );
                    }
                    if (this.isActiveDirectoryDN(unmaskedValue)) {
                        const dnResult = await ldapService.verifyOrGetFirstRDN(bindData, unmaskedValue);

                        if (dnResult != null && dnResult.found && dnResult.distinguishedName) {
                            unmaskedValue = dnResult.distinguishedName
                        } else {
                            unmaskedValue = this.getFirstDNValue(unmaskedValue) ?? "-";
                        }
                    }
                    const dn = await this.getUPNReplacement(unmaskedValue, { bindData: bindData });

                    if (dn != null) {
                        params.changes[i].modification.vals[j] = dn;
                    }
                }
            }
        }

        var unmaskedValue = params?.dn;

        if (this.isValidMaskedData(unmaskedValue)) {
            unmaskedValue = await unMaskMacro(
                unmaskedValue,
                maskingHistory,
            );
        }
        var isDN = this.isActiveDirectoryDN(unmaskedValue);
        if (isDN) {
            const dnResult = await ldapService.verifyOrGetFirstRDN(bindData, unmaskedValue);

            if (dnResult != null && dnResult.found && dnResult.distinguishedName) {
                unmaskedValue = dnResult.distinguishedName
            } else {
                unmaskedValue = this.getFirstDNValue(unmaskedValue) ?? "-";
            }
        }
        if ((isDN && isEmail(unmaskedValue)) || (!isDN)) {
            const dn = await this.getUPNReplacement(unmaskedValue, { bindData: bindData });
            if (dn != null) {
                params.dn = dn;
            }
        }
        return params;

        function isEmail(str) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
        }
    }

    static async updateUPNInDeleteOperation(params, { bindData = null, maskingHistory = null }) {

        var unmaskedValue = params?.dn;

        if (this.isValidMaskedData(unmaskedValue)) {
            unmaskedValue = await unMaskMacro(
                unmaskedValue,
                maskingHistory,
            );
        }
        if (this.isActiveDirectoryDN(unmaskedValue)) {
            const dnResult = await ldapService.verifyOrGetFirstRDN(bindData, unmaskedValue);

            if (dnResult != null && dnResult.found && dnResult.distinguishedName) {
                unmaskedValue = dnResult.distinguishedName
            } else {
                unmaskedValue = this.getFirstDNValue(unmaskedValue) ?? "-";
            }
        }
        if (isEmail(unmaskedValue)) {
            const dn = await this.getUPNReplacement(unmaskedValue, { bindData: bindData });
            if (dn != null) {
                params.dn = dn;
            }

        }
        return params;

        function isEmail(str) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
        }
    }

    static async updateUPNInMoveOperation(params, { bindData = null, maskingHistory = null }) {

        var unmaskedValue = params?.olddn;

        if (this.isValidMaskedData(unmaskedValue)) {
            unmaskedValue = await unMaskMacro(
                unmaskedValue,
                maskingHistory,
            );
        }
        if (this.isActiveDirectoryDN(unmaskedValue)) {
            const dnResult = await ldapService.verifyOrGetFirstRDN(bindData, unmaskedValue);

            if (dnResult != null && dnResult.found && dnResult.distinguishedName) {
                unmaskedValue = dnResult.distinguishedName
            } else {
                unmaskedValue = this.getFirstDNValue(unmaskedValue) ?? "-";
            }
        }
        if (isEmail(unmaskedValue)) {
            const dn = await this.getUPNReplacement(unmaskedValue, { bindData: bindData });
            if (dn != null) {
                params.olddn = dn;
                params.newdn = replaceFirstRdn(dn, params.newdn);
            }

        }
        return params;

        function isEmail(str) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
        }

        function replaceFirstRdn(dn1, dn2) {
            const parts1 = dn1.split(",");
            const parts2 = dn2.split(",");

            const [type1, value1] = parts1[0].split("=");
            const [type2, value2] = parts2[0].split("=");

            if (type1.toLowerCase() === type2.toLowerCase()) {
                parts2[0] = `${type1}=${value1}`;
                return parts2.join(",");
            }

            return `${parts1[0]},${dn2}`;
        }
    }

    static prepareScope(scope) {
        if (scope == null || !Object.values(ScopeTypes).includes(scope)) {
            return "sub";
        } else {
            switch (scope) {
                case ScopeTypes.BASE:
                    return "base";
                case ScopeTypes.ONE:
                    return "one";
                case ScopeTypes.SUB:
                    return "sub";
            }
        }
    }

    static async prepareLDAPFilter(filters, objectType, bindData, maskingHistory, { unmasked = false }) {

        let filterQuery = "";

        logger.testing.ldap.debug("filters : " + JSON.stringify(filters));
        logger.testing.ldap.debug("objectType : " + objectType);
        logger.testing.ldap.debug("filterQuery : " + filterQuery);

        if (objectType == null || !Object.values(ObjectTypes).includes(objectType)) {
            filterQuery = ObjectClassFilters[ObjectTypes.ALL].filter;
        } else {
            filterQuery = ObjectClassFilters[objectType].filter;
        }

        logger.testing.ldap.debug("filterQuery : " + filterQuery);

        if (filters &&
            typeof filters === 'object' &&
            Object.keys(filters).length > 0) {

            const customFilters = await this.prepareGroupedFilter(filters, filterQuery, bindData, maskingHistory, { unmasked: unmasked });
            filterQuery = `(&${filterQuery}${customFilters})`;

            logger.testing.ldap.debug("filterQuery : " + filterQuery);
            this.appliedFilterActions.push(FilterActionsAvailable.FILTER);
        }

        return this.appendExclusionFilters(filterQuery);
    }

    static async prepareGroupedFilter(filters, objectClassFilter, bindData, maskingHistory, { unmasked = false }) {

        if (!filters || typeof filters !== 'object') return "";

        if ('logicType' in filters) {
            if (!Object.values(FilterLogicalConditionTypes).includes(filters.logicType)) {
                return "";
            }
        }

        if (!Array.isArray(filters.condition) || filters.condition.length === 0) {
            return "";
        }

        let filterQueryList = [];


        logger.testing.ldap.debug("get dn : 00 " + JSON.stringify(filters.condition));

        // filters.condition.forEach(filter => {
        for (var filter of filters.condition) {

            logger.testing.ldap.debug("filter item : " + JSON.stringify(filter))
            if (filter.logicType != null && filter.condition != null) {
                filterQueryList.push(await this.prepareGroupedFilter(filter, objectClassFilter, bindData, maskingHistory, { unmasked: unmasked }) ?? "");
                // return;
                break;
            };

            if (filter.filterType == null) return;
            if (
                typeof filter.filterType === "number" &&
                !Object.values(FilterTypes).includes(filter.filterType) &&
                this.isNullOrEmpty(filter.attribute) &&
                this.isNullOrEmpty(filter.value)
            ) return;


            let transformedValue;

            logger.testing.ldap.debug("inside unmased masked : " + filter.value + transformedValue + unmasked + this.isValidMaskedData(filter.value));
            if (unmasked && this.isValidMaskedData(filter.value)) {
                logger.testing.ldap.debug("inside unmased masked : " + filter.value + transformedValue + unmasked + JSON.stringify(maskingHistory));
                transformedValue = await unMaskMacro(filter.value, maskingHistory);
            } else {
                transformedValue = filter.value;
            }

            transformedValue ??= filter.value;

            if (!(filter.filterType === FilterTypes.EMPTY || filter.filterType === FilterTypes.NON_EMPTY)) {

                logger.testing.ldap.debug("filter.value : " + filter.value);
                logger.testing.ldap.debug("transformedValue : " + transformedValue);
                if ((this.attrUsingFileTimeFormat.includes(filter.attribute.toLowerCase()))) {
                    transformedValue = this.convertToLdapFileTime(transformedValue);
                }
                if ((this.attrUsingGeneralizedTimeFormat.includes(filter.attribute.toLowerCase()))) {
                    transformedValue = this.convertToGeneralizedTime(transformedValue);
                }
                logger.testing.ldap.debug("transformedValue : " + transformedValue);
                transformedValue ??= filter.value;
                logger.testing.ldap.debug("transformedValue : " + transformedValue);
            }

            let filterString = '';
            const attr = this.sanitizeLDAPAttribute(filter.attribute);

            logger.testing.ldap.debug("filter : " + JSON.stringify(filter));

            logger.testing.ldap.debug("filter.valueType : " + JSON.stringify(filter.valueType));
            logger.testing.ldap.debug("(filter.valueType === FilterValueTypes.PRESET_OPTIONS) : " + JSON.stringify((filter.valueType === FilterValueTypes.PRESET_OPTIONS)));

            logger.testing.ldap.debug("attr : " + JSON.stringify(attr));
            logger.testing.ldap.debug("FilterPresetOptions[attr] : " + JSON.stringify(FilterPresetOptions[attr]));

            if (filter.valueType === FilterValueTypes.PRESET_OPTIONS) {
                if (FilterPresetOptions[attr] != null) {
                    logger.testing.ldap.debug("inside the true : ");
                    filterString = FilterPresetOptions[attr][transformedValue]?.value;
                    logger.testing.ldap.debug("inside the true filterString : " + filterString);
                }
            } else {

                const attrLower = attr.toLowerCase();
                var isGeneralizedTime = false;
                var isFileTime = false;
                var isDNConvertObject = false;

                if (this.attrStoreDN.includes(attrLower)) {
                    isDNConvertObject = true;
                } else if (this.attrUsingGeneralizedTimeFormat.includes(attrLower)) {
                    isGeneralizedTime = true;
                } else if (this.attrUsingFileTimeFormat.includes(attrLower)) {
                    isFileTime = true;
                }

                const equalFilter = async () => {
                    if (transformedValue === 0 || transformedValue === "0") {
                        return `(${attr}=${escapeLDAPValue(transformedValue)})`;
                    } else if (isDNConvertObject) {
                        logger.testing.ldap.debug("get dn : 0 " + isDNConvertObject)
                        return await this.getDnBasedFilter(attr, transformedValue, bindData, maskingHistory, { unmasked: unmasked });
                    } else if (isGeneralizedTime) {
                        return this.createEqualToGeneralizedTimeFilterRange(attr, transformedValue);
                    }
                    if (isFileTime) {
                        return this.createEqualToLdapTimeFilterRange(attr, transformedValue);
                    }
                    return `(${attr}=${escapeLDAPValue(transformedValue)})`;
                };

                const containsFilter = async () => {
                    if (isDNConvertObject) {
                        logger.testing.ldap.debug("get dn : 0 " + isDNConvertObject)
                        return await this.getDnBasedFilter(attr, transformedValue, bindData, maskingHistory, { unmasked: unmasked });
                    }
                    return `(${attr}=*${escapeLDAPValue(transformedValue)}*)`;
                };

                const escapedValue = escapeLDAPValue(transformedValue);

                switch (filter.filterType) {

                    case FilterTypes.EQUALS:
                        filterString = await equalFilter();
                        break;

                    case FilterTypes.NOT_EQUALS:
                        filterString = `(!${await equalFilter()})`;
                        break;

                    case FilterTypes.CONTAINS:
                        // filterString = `(${attr}=*${transformedValue}*)`;
                        filterString = await containsFilter();
                        break;

                    case FilterTypes.NOT_CONTAINS:
                        // filterString = `(!(${attr}=*${transformedValue}*))`;
                        filterString = `(!${await containsFilter()})`;
                        break;

                    case FilterTypes.STARTS_WITH:
                        filterString = `(${attr}=${escapedValue}*)`;
                        break;

                    case FilterTypes.ENDS_WITH:
                        filterString = `(${attr}=*${escapedValue})`;
                        break;

                    case FilterTypes.GREATER_THAN_OR_EQUAL:
                        filterString = `(${attr}>=${escapedValue})`;
                        break;

                    case FilterTypes.LESS_THAN_OR_EQUAL:
                        filterString = `(${attr}<=${escapedValue})`;
                        break;

                    case FilterTypes.EMPTY:
                        filterString = `(!(${attr}=*))`;
                        break;

                    case FilterTypes.NON_EMPTY:
                        filterString = `(${attr}=*)`;
                        break;
                }
            }

            logger.testing.ldap.debug("ldap query filter skip objectClassFilter : " + objectClassFilter);
            logger.testing.ldap.debug("ldap query filter skip filterQueryList : " + filterQueryList);
            logger.testing.ldap.debug("ldap query filter skip query : " + filterString);
            if (!(objectClassFilter.includes(filterString) || filterQueryList.includes(filterString))) filterQueryList.push(filterString);

        }
        // });

        if (filterQueryList.length === 0) return "";

        const operation = filters.logicType === FilterLogicalConditionTypes.AND ? "&" : "|";
        return `(${operation}${filterQueryList.join("")})`

    }

    static appendExclusionFilters(userFilter) {
        const exclusionFilters = [
            // '(!(cn=*system*))',
            '(!(cn=*wmipolicy*))',
            '(!(cn=*ipsec*))'
        ].join('');
        const finalFilter = `(&${userFilter}${exclusionFilters})`;
        logger.testing.ldap.debug("final filter : " + finalFilter);
        return finalFilter;
    }

    static appendMustIncludedAttributes(requestedAttributes, objectType) {

        const mustIncludedAttributes = ["distinguishedName"];

        if (!Array.isArray(requestedAttributes)) {
            requestedAttributes = typeof requestedAttributes === 'string' ? requestedAttributes.split(',').map(attr => attr.trim()) : requestedAttributes;
        }

        if (requestedAttributes?.length < TabHeaders[objectType]?.length) this.appliedFilterActions.push(FilterActionsAvailable.CUSTOMIZE_TABLE);

        const lowerCaseAttributes = requestedAttributes.map(attr => attr.toLowerCase().trim());

        mustIncludedAttributes.forEach(element => {
            if (!lowerCaseAttributes.includes(element.toLowerCase().trim())) {
                requestedAttributes.push(element.trim());
            }
        });

        return requestedAttributes;
    }

    static isNullOrEmpty(s) {
        return s == null || s.trim() === "";
    }

    static standardizeDateInput(dateString) {
        if (!dateString || typeof dateString !== 'string') {
            return dateString;
        }

        dateString = dateString.trim();

        const compactMatch = dateString.match(
            /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(?:\.\d+)?Z$/
        );

        if (compactMatch) {
            const [, y, mo, d, h, mi, s] = compactMatch;

            const isoString = `${y}-${mo}-${d}T${h}:${mi}:${s}Z`;
            const date = new Date(isoString);

            if (isNaN(date.getTime())) {
                return dateString;
            }

            return date.toISOString().replace('.000', '');
        }

        const validFormat = /^\d{4}-\d{2}-\d{2}(T.*)?$/;

        if (!validFormat.test(dateString)) {
            return dateString;
        }

        if (isNaN(new Date(dateString).getTime())) {
            return dateString;
        }

        if (!dateString.includes('T')) {
            const localDate = new Date(`${dateString}T00:00:00`);
            return localDate.toISOString().replace('.000', '');
        }

        const hasTimeZone = /Z$|[+-]\d{2}:?\d{2}$/.test(dateString);

        let date;

        if (hasTimeZone) {
            date = new Date(dateString);
        } else {
            const [datePart, timePart] = dateString.split('T');
            const [h = '00', m = '00', s = '00'] = timePart.split(':');

            const local = new Date(
                `${datePart}T${h.padStart(2, '0')}:${m.padStart(2, '0')}:${s.padStart(2, '0')}`
            );

            date = local;
        }

        if (isNaN(date.getTime())) {
            return dateString;
        }

        return date.toISOString().replace('.000', '');
    }

    static convertToLdapFileTime(dateString) {
        if (dateString === "0" || dateString === 0 || dateString === "1" || dateString === 1) return dateString;
        const standardizedDateString = this.standardizeDateInput(dateString);
        const AD_EPOCH_OFFSET_MS = 11644473600000n;
        const inputDate = new Date(standardizedDateString);
        const msSinceUnixEpoch = BigInt(inputDate.getTime());
        const msSinceADEpoch = msSinceUnixEpoch + AD_EPOCH_OFFSET_MS;
        const fileTime = msSinceADEpoch * 10000n;
        return fileTime.toString();
    }

    static convertToGeneralizedTime(dateString) {

        logger.testing.ldap.debug("datestring : " + dateString);

        if (dateString === "0" || dateString === 0) return dateString;
        const standardizedDateString = this.standardizeDateInput(dateString);

        const date = new Date(standardizedDateString);

        if (isNaN(date.getTime())) {
            return dateString;
        }

        const pad = (num) => String(num).padStart(2, '0');

        const year = date.getUTCFullYear();
        const month = pad(date.getUTCMonth() + 1);
        const day = pad(date.getUTCDate());
        const hour = pad(date.getUTCHours());
        const minute = pad(date.getUTCMinutes());
        const second = pad(date.getUTCSeconds());

        const generalizedTime = `${year}${month}${day}${hour}${minute}${second}.0Z`;

        return generalizedTime;
    }

    static createEqualToGeneralizedTimeFilterRange(attributeName, targetDateString) {

        const startGeneralizedTimeFull = this.convertToGeneralizedTime(targetDateString);

        logger.testing.ldap.debug("startGeneralizedTimeFull : " + startGeneralizedTimeFull);

        if (!startGeneralizedTimeFull) {
            return "Invalid date input for GeneralizedTime filter.";
        }

        const standardizedStartString = this.standardizeDateInput(startGeneralizedTimeFull);
        logger.testing.ldap.debug("standardizedStartString : " + standardizedStartString);
        const startDate = new Date(standardizedStartString);
        logger.testing.ldap.debug("startDate : " + startDate);
        const pad = (num) => String(num).padStart(2, '0');

        const year = startDate.getUTCFullYear();
        const month = pad(startDate.getUTCMonth() + 1);
        const day = pad(startDate.getUTCDate());

        const endTime = `${year}${month}${day}235959.0Z`;

        return `(&(${attributeName}>=${escapeLDAPValue(startGeneralizedTimeFull)})(${attributeName}<=${escapeLDAPValue(endTime)}))`;
    }

    static createEqualToLdapTimeFilterRange(attributeName, targetDateString) {

        const startTimeTicks = this.convertToLdapFileTime(targetDateString);

        if (startTimeTicks === null || startTimeTicks === 'NaN') {
            return "";
        }

        const startDate = new Date(this.standardizeDateInput(targetDateString));
        const nextDayDate = new Date(startDate);
        nextDayDate.setUTCDate(startDate.getUTCDate() + 1);

        const pad = (num) => String(num).padStart(2, '0');
        const nextDayString = `${nextDayDate.getUTCFullYear()}-${pad(nextDayDate.getUTCMonth() + 1)}-${pad(nextDayDate.getUTCDate())}T00:00:00Z`;

        const nextDayMidnightTicks = this.convertToLdapFileTime(nextDayString);

        const endTimeTicks = BigInt(nextDayMidnightTicks) - BigInt(1);

        return `(&(${attributeName}>=${escapeLDAPValue(startTimeTicks)})(${attributeName}<=${escapeLDAPValue(endTimeTicks.toString())}))`;
    }


    static async getDnBasedFilter(attirbute, value, bindData, maskingHistory, { unmasked = false }) {

        if (!unmasked) return `(${attirbute}=${value})`;
        var unmaskedValue = value;

        if (this.isValidMaskedData(value)) {
            unmaskedValue = await unMaskMacro(
                value,
                maskingHistory,
            );
        }

        if (this.isActiveDirectoryDN(unmaskedValue)) {
            const dnResult = await ldapService.verifyOrGetFirstRDN(bindData, unmaskedValue);

            if (dnResult != null && dnResult.found && dnResult.distinguishedName) {
                unmaskedValue = dnResult.distinguishedName
            } else {
                unmaskedValue = this.getFirstDNValue(unmaskedValue) ?? "-";
            }
        }

        const dn = await this.getUPNReplacement(unmaskedValue, { bindData: bindData });

        if (dn == null) {
            return `(${attirbute}=${escapeLDAPValue(value)})`
        }
        return `(${attirbute}=${escapeLDAPValue(dn)})`


    }

    static isValidMaskedData(str) {
        const regex = /\{\{[^{}]+\}\}/;
        return regex.test(str);
    }

    static isActiveDirectoryDN(str) {
        if (typeof str !== "string") return str;
        const dnRegex = /^([A-Za-z]+=[^,=]+)(,[A-Za-z]+=[^,=]+)*$/;
        return dnRegex.test(str?.trim());
    }

    static getFirstDNValue(dn) {
        if (!dn || typeof dn !== "string") return null;

        const firstPart = dn?.split(",")[0];
        const parts = firstPart?.split("=");
        return parts.length > 1 ? parts[1] : null;
    }

    static filterValidADAttributes(data) {
        const VALID_AD_ATTRIBUTES = new Set([
            "cn", "distinguishedName", "name", "objectClass", "description", "displayName", "managedBy",
            "sAMAccountName", "userPrincipalName", "givenName", "sn", "initials", "mail",
            "telephoneNumber", "mobile", "title", "department", "company", "manager",
            "physicalDeliveryOfficeName", "streetAddress", "l", "st", "postalCode", "co",
            "homeDirectory", "homeDrive", "scriptPath", "profilePath",
            "userAccountControl", "accountExpires", "pwdLastSet", "lockoutTime", "memberOf",
            "groupType", "member",
            "dNSHostName", "operatingSystem", "operatingSystemVersion", "servicePrincipalName",
            "ou"
        ]);

        return Object.fromEntries(
            Object.entries(data).filter(([k]) => VALID_AD_ATTRIBUTES.has(k))
        );
    }

    static sanitizeLDAPAttribute(attr) {
        if (typeof attr !== "string") {
            sendAndLogError(
                logger.ldap,
                "Invalid LDAP attribute",
                400,
                `Rejected attribute: ${attr}`
            );
        }

        let sanitized = attr.replace(/[^a-zA-Z0-9-]/g, "");

        if (!sanitized || !/^[a-zA-Z]/.test(sanitized)) {
            sendAndLogError(
                logger.ldap,
                "Invalid LDAP attribute",
                400,
                `Rejected attribute: ${attr}`
            );
        }

        return sanitized;
    }

}

module.exports = LDAPQueryGenerator;
