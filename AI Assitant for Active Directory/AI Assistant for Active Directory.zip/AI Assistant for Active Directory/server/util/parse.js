const { sendAndLogError } = require("./errorResponse");
const { logger } = require("./logger");

function cleanJson(text) {
  if (typeof text !== "string") {
    text = JSON.stringify(text);
  }

  let cleaned = text
    .replace(/^json\\n/, "")
    .replace(/```json/, "")
    .replace(/```javascript/, "")
    .replace(/```/, "")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .trim()
    .trimStart();

  while (cleaned.startsWith('"') || cleaned.endsWith('"')) {
    if (cleaned.startsWith('"')) cleaned = cleaned.slice(1);
    if (cleaned.endsWith('"')) cleaned = cleaned.slice(0, -1);
  }
  return cleaned;
}

function getText(text) {
  while (!text.json) {
    text = text.text;
  }
  return text;
}

function getCallTool(text) {
  while (typeof text.callTool !== "boolean") {
    text =
      typeof text.callTool === "string"
        ? JSON.parse(text.callTool)
        : text.callTool;
  }
  return text.callTool;
}

function getTextCode(text) {
  while (!text.inputToken) {
    text = text.text;
  }
  return text;
}

function getTextFromList(text) {
  text = JSON.parse(text);
  while (Array.isArray(text)) {
    text = text[0];
  }
  return text;
}

function isValidJson(text) {

  if (text[0] === "{" || text[0] === "[" || text[1] === "{" || text[1] === "["
  ) {
    try {
      text = JSON.parse(text)
      if (!text.json || !text.text) {
        return false;
      }
    }
    catch (ex) {
      return false;
    }
    return true;
  }
  return false;
}

function extractJson(text) {
  let json = text;
  let match;
  if (text.includes("javascript")) {
    match = text.match(/\`\`\`javascript\s*([\s\S]*?)\s*\`\`\`/);
  } else if (text.includes("json")) {
    match = text.match(/\`\`\`json\s*([\s\S]*?)\s*\`\`\`/);
  }
  if (match) {
    if (match.length > 1) {
      json = match[1].trim();
    }
  }

  const firstBrace = json.indexOf("{");
  const lastBrace = json.lastIndexOf("}");
  if (firstBrace >= 0 && lastBrace >= 1) {
    json = json.slice(firstBrace, lastBrace + 1);
  }
  return cleanJson(json);
}

function changeDN(originalDomain, inputText) {
  try {
    const originalDomainDN = `DC=${originalDomain.split(".").join(",DC=")}`;
    const changedJson = JSON.stringify(inputText)
      .replace(/test.com/g, originalDomain)
      .replace(/DC=test,DC=com/g, originalDomainDN);
    return JSON.parse(changedJson);
  } catch (err) {
    //console.log("Error in ChangeDN : ", err);
    return inputText;
  }
}

function replaceWithLocalTime(inputText) {
  try {
    const changedJson = JSON.stringify(inputText).replace(
      /\b(\d{4}-\d{2}-\d{2}T\d{2}:\d{2})\b/g,
      (match) => {
        const date = new Date(match);
        if (isNaN(date.getTime())) return match;
        return date.toLocaleString();
      }
    );
    return JSON.parse(changedJson);
  } catch (err) {
    return inputText;
  }
}

function replaceWithRestrictedMsg(inputText) {
  try {

    const changedJson = JSON.stringify(inputText).replace(
      /\[\[RESTRICTED\]\]/g,
      '<a href=\"https://admindroid.com/active-directory-all-in-one-tool\" target=\"_blank\" rel=\"noopener noreferrer\">AdminDroid 365</a> to explore additional features, deeper insights and management actions.'
      // "Switch to **AdminDroid 365** to explore additional features and deeper insights and management actions. https://admindroid.com/active-directory-all-in-one-tool"
    );
    return JSON.parse(changedJson);
  } catch (err) {
    console.log(err);
    return inputText;
  }
}

function fixQoutesAndParse(jsonString) {
  if (typeof jsonString !== "string") {
    throw new Error("Input must be a string");
  }

  // replace smart double & single quotes
  const cleaned = jsonString
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'");

  return JSON.parse(cleaned);
}

function validateAICode(code) {

  if (code.length > 5000) {
    sendAndLogError(logger.ai, "AI generated code too large", 400);
  }

  const forbidden = [
    "localStorage",
    "sessionStorage",
    "cookie",
    "fetch",
    "XMLHttpRequest",
    "WebSocket",
    "eval",
    "Function",
    "child_process",
    "constructor",
    "__proto__",
    "setTimeout",
    "setInterval"
  ];

  const loopPatterns = [
    /while\s*\(\s*true\s*\)/i,
    /for\s*\(\s*;\s*;\s*\)/i
  ];

  for (const keyword of forbidden) {
    if (code.toLowerCase().includes(keyword.toLowerCase())) {
      sendAndLogError(
        logger.ai,
        `AI generated unsafe code, contains "${keyword}"`,
        400
      );
    }
  }

  for (const pattern of loopPatterns) {
    if (pattern.test(code)) {
      sendAndLogError(
        logger.ai,
        "AI generated infinite loop",
        400
      );
    }
  }

  return code;
}


module.exports = {
  cleanJson,
  getText,
  getCallTool,
  getTextCode,
  changeDN,
  getTextFromList,
  isValidJson,
  extractJson,
  replaceWithLocalTime,
  fixQoutesAndParse,
  replaceWithRestrictedMsg,
  validateAICode
};
