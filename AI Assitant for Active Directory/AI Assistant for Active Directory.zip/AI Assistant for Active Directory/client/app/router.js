import EmberRouter from '@ember/routing/router';
import config from 'community-base-tool/config/environment';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';
export default class Router extends EmberRouter {
  location = config.locationType;
  rootURL = config.rootURL;
}

Router.map(function () {
  this.route('settings', function () {
    this.route('general', { path: '/' });
    this.route('provider');
    this.route('about');
  });

  this.route('index', { path: '/' }, function () {
    this.mount(`${TOOL_INFORMATIONS.MODULE_AD.id}`);
  });

  this.route('testing')

  this.route('not-found', { path: '/*wildcard' });
});
