import Application from '@ember/application';
import Resolver from 'ember-resolver';
import loadInitializers from 'ember-load-initializers';
import 'ember-power-select/styles';
import { TOOL_INFORMATIONS } from '@admindroid/shared-components/utils/tool-informations';
import config from 'community-base-tool/config/environment';

export default class App extends Application {
  modulePrefix = config.modulePrefix;
  podModulePrefix = config.podModulePrefix;
  Resolver = Resolver;

  engines = {
    [TOOL_INFORMATIONS.MODULE_AD.id]: {
      dependencies: {
        services: [
          'router',
          'engine-registry',
          { 'authentication-ad': 'authentication-active-directory' },
          'settings-data',
          'ai-providers',
          'user',
          { 'tool-information': 'tool-info' },
          'flashMessages',
        ],
        externalRoutes: {
          'settings': 'settings',
          'settingsProvider': 'settings.provider'
        }
      },
    }
  };
}

loadInitializers(App, config.modulePrefix);
