import Component from '@glimmer/component';
import { action } from '@ember/object';
import { tracked } from '@glimmer/tracking';
import { service } from '@ember/service';
import { AUTH_TYPES } from '@admindroid/shared-components/utils/tool-informations';

export default class InitialPromptComponent extends Component {
  get chatStorageService() {
    return this.args.chatStorageService;
  }

  get selectedAdditionalChatDataPopup() {
    return this.chatStorageService.selectedAdditionalChatDataPopup;
  }

  isString = (variable) => {
    return typeof variable === 'string' || variable instanceof String;
  };
  isArray(variable) {
    return Array.isArray(variable);
  }
  isObject(variable) {
    return typeof variable === 'object' && !Array.isArray(variable);
  }

  decrement(value) {
    return value - 1;
  }
  @action
  printJSON(obj) {
    // console.log('printJSON called');
    return JSON.stringify(obj, null, 4);
  }
  @action
  handleKeyDown(event) {
    if (event.target.name === 'currentPrompt' && event.key === 'Enter') {
      if (event.shiftKey) {
        this.args.updateData(event);
      } else {
        // if (!this.authenticationM365.currentActiveUser) {
        //   console.log(this.flashMessages);
        //   this.flashMessages.info('Login to continue!', {
        //     sticky: true,
        //   });
        //   event.preventDefault();
        //   return;
        // }

        if (!this.args.providerChat.apiKeys.length) {
          this.args.checkAndShowAPIKeyWarning();
          event.preventDefault();
          return;
        }

        if (!this.args.handleSubmitChatForm.isRunning) {
          this.args.handleSubmitChatForm.perform(event);
        } else {
          event.preventDefault();
        }
      }
    }
  }

  isScrolledToBottom(containerID) {
    const chatContainer = document.getElementById(containerID);
    return (
      chatContainer.scrollHeight - chatContainer.scrollTop <=
      chatContainer.clientHeight + 5
    );
  }

  @action
  checkScroll(containerID, scrollButtonID) {
    const scrollButton = document.getElementById(scrollButtonID);
    if (this.isScrolledToBottom(containerID)) {
      scrollButton.style.display = 'none';
    } else {
      scrollButton.style.display = 'flex';
    }
  }

  @action
  getSuccessMsg(chatStorage, index) {
    let data = chatStorage[index - 1];
    if (data.role == 'user') {
      data = chatStorage[index - 2];
    }

    let result = null;
    if (data.role != 'user') {
      for (const [key, val] of Object.entries(data)) {
        if (key != 'role') {
          result = val[0].text.successMessage;
        }
      }
    }

    return result;
  }

  patternsWithType = [
    {
      type: 'mail',
      regex: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,
    },
    {
      type: 'id',
      regex:
        /\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b/g,
    },
    { type: 'phone', regex: /\b(?=(?:\D*\d){10,})(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{2,4}\)?[\s-]?)?\d{3,4}[\s-]?\d{4}\b/g },
    { type: 'url', regex: /\bhttps?:\/\/[^\s/$.?#].[^\s]*\b/g },
    // {
    //   type: 'date',
    //   regex:
    //     /\b(?:\d{1,2}[-\/]\d{1,2}[-\/]\d{4}|\d{4}[-\/]\d{1,2}[-\/]\d{1,2})\b/g,
    // },
    { type: 'ip', regex: /\b(?:\d{1,3}\.){3}\d{1,3}\b/g },
    { type: 'postal', regex: /\b\d{5,6}\b/g },
    { type: 'card', regex: /\b(?:\d[ -]*?){13,19}\b/g },
    { type: 'username', regex: /(?:^|\s)@[A-Za-z0-9_]{3,20}\b/g },
    { type: 'dn', regex: /(?:(?:CN|OU|DC|L|ST|O|C|UID|SN|GN)=(?:(?!(?:CN|OU|DC|L|ST|O|C|UID|SN|GN)=)[^,\n])+,)+(?:CN|OU|DC|L|ST|O|C|UID|SN|GN)=(?:[^\s,\n]+)/gi },
  ];

  @action
  getMaskedDatas(str) {
    if (typeof str !== 'string') return [];

    const results = [
      // quoted matches
      ...(str.match(/"([^"]+)"/g) || []).map((m) => m.slice(1, -1)),

      // pattern matches
      ...this.patternsWithType.flatMap(({ regex }) => str.match(regex) || []),
    ].map((m) => m.trim());

    // dedupe
    return [...new Set(results)].reverse();
  }

  @action
  getAIFomatedText(input) {
    if (typeof input !== 'string') return input;
    let output = input;
    output = output.replace(/(\b\w+)\s+"[^"]+"/g, (_, prevWord) => {
      return `${prevWord} {{${prevWord}}}`;
    });
    this.patternsWithType.forEach(({ type, regex }) => {
      output = output.replace(regex, `{{${type}}}`);
    });
    return output;
  }

  @action
  handleMaskAndSuggestDataPopup(
    title,
    dataTitle,
    datas,
    formatTextTitle,
    formatText,
    chat,
    event,
  ) {
    if (
      this.chatStorageService.selectedAdditionalChatDataPopup &&
      event.currentTarget ==
      this.chatStorageService.selectedAdditionalChatDataPopup.parentElement
    ) {
      this.chatStorageService.set('selectedAdditionalChatDataPopup', null);
      return;
    }
    event.stopPropagation();
    const data = {
      title,
      dataTitle,
      datas:[...new Set(datas)],
      formatTextTitle,
      formatText,
      parentElement: event.currentTarget,
      type: title,
      selectedChat: chat,
    };
    this.chatStorageService.set('selectedAdditionalChatDataPopup', data);
  }

  @action
  handleOnClickOutside() {
    this.chatStorageService.selectedMaskedDataPopup = null;
    this.chatStorageService.selectedSuggestedDataPopup = null;
  }

  @tracked canScrollLeft = false;
  @tracked canScrollRight = false;

  @action
  setupHorizontalScroll(element) {
    element.addEventListener(
      'wheel',
      function (event) {
        if (Math.abs(event.deltaX) > Math.abs(event.deltaY)) {
          return;
        }
        event.preventDefault();
        element.scrollLeft += event.deltaY * 3;
      },
      { passive: false },
    );
    this.updateScrollButtons(element);

    element.addEventListener('scroll', () => {
      this.updateScrollButtons(element);
    });
  }

  updateScrollButtons(parent) {
    const epsilon = 1; // tolerance for rounding errors

    this.canScrollLeft = parent.scrollLeft > epsilon;
    this.canScrollRight =
      parent.scrollLeft < parent.scrollWidth - parent.clientWidth - epsilon;
  }

  @action
  scrollRight() {
    const parent = document.getElementById('suggestions-parent');
    if (!parent) return;

    parent.scrollBy({
      left: 200, // scroll 200px to the right
      behavior: 'smooth', // smooth scrolling
    });
  }

  @action
  scrollLeft() {
    const parent = document.getElementById('suggestions-parent');
    if (!parent) return;

    parent.scrollBy({
      left: -200, // scroll 200px to the left
      behavior: 'smooth',
    });
  }

  @action
  async handleExploreData(index) {
    // this.chatStorageService.setData('selectedLHSTableIndex', index)
    if (this.chatStorageService.selectedLHSTableIndex != index) {
      this.chatStorageService.set('selectedLHSTableIndex', index);
    }
  }

  @action
  moveToSettings() {
    this.hostRouter.transitionTo('settings.provider', {
      queryParams: {
        providerName: this.args.providerChat.name, // or whatever value you want
      },
    });
  }
}
