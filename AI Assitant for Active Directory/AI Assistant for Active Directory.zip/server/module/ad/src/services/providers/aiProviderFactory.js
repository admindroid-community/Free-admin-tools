const GeminiProvider = require("../../../../../core/providers/geminiProvider.js");
const GroqProvider = require("../../../../../core/providers/groqProvider.js");
const CohereProvider = require("../../../../../core/providers/cohereProvider.js");
const OpenAiProvider = require("../../../../../core/providers/openaiProvider.js");
const ClaudeProvider = require("../../../../../core/providers/claudeProvider.js");
const ModuleAIContext = require("./aiProvider.js");
const { sendAndLogError } = require("../../../../../util/errorResponse.js");
const { logger } = require("../../../../../util/logger.js");
const providerService = require("../../../../../core/src/services/providerService.js");

class AIProviderFactory {
  static providers = {};

  static async createProvider(providerType, currentPrompt = null) {
    let { keyName, apiKey } = await providerService.getApiKey(providerType);

    if (!apiKey) {
      sendAndLogError(
        logger.ai,
        "Missing API key",
        400,
        "API key is required for authentication.",
      );
    }

    const providerKey = `${providerType.toLowerCase()}_${keyName}`;
    const ctx = new ModuleAIContext();
    if (!this.providers[providerKey]) {
      switch (providerType.toLowerCase()) {
        case "gemini":
          this.providers[providerKey] = new GeminiProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        case "groq":
          this.providers[providerKey] = new GroqProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        case "cohere":
          this.providers[providerKey] = new CohereProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        case "openai":
          this.providers[providerKey] = new OpenAiProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        case "claude":
          this.providers[providerKey] = new ClaudeProvider(
            apiKey,
            ctx,
            currentPrompt,
          );
          break;
        default:
          logger.ai.error(`Unsupported provider type: ${providerType}`);
          return sendAndLogError(
            logger.ai,
            "The specified AI provider is not supported.",
            400,
            `Unsupported provider type: ${providerType}`,
          );
      }
    }

    return this.providers[providerKey];
  }
}

module.exports = AIProviderFactory;
