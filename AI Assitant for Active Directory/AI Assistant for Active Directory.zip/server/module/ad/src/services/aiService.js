const { logger } = require("../../../../util/logger.js");
const { fixQoutesAndParse } = require("../../../../util/parse.js");
const LDAPQueryGenerator = require("./ldapQueryGenerator.js");
const AIProviderFactory = require("./providers/aiProviderFactory.js");

class AiService {

  async getResponse(
    aiProvider,
    model,
    prompt,
    currentTimeStamp,
    historyList,
    { bindData, maskingHistory }
  ) {
    try {
      logger.ai.debug(
        `getResponse called with provider: ${aiProvider}, model: ${model}, prompt: ${prompt}, Current Time: ${currentTimeStamp},`
      );
      const provider = await AIProviderFactory.createProvider(
        aiProvider,
        prompt
      );
      const promptStructure = {
        "UserQuery": prompt,
        "CurrentReferenceTime": currentTimeStamp
      }
      // const promptText = `This is the current user query: ${prompt}. The current reference times are: ${currentTimeStamp}.`;
      const promptText = JSON.stringify(promptStructure)
      var aiResponse = await provider.getResponse(model, promptText, historyList);
      if (aiResponse?.text && aiResponse?.text?.json) {
        logger.testing.ai.debug("ai response 1 : " + JSON.stringify(aiResponse));
        aiResponse.text = this.validateSuggestedQuery(prompt,aiResponse.text);
        const { query, unmaskedQuery, appliedFilterActions } = await LDAPQueryGenerator.generate(aiResponse?.text?.json, { bindData: bindData, maskingHistory: maskingHistory });
        aiResponse.text.json = query;
        logger.testing.ai.debug("ai response 2 : " + JSON.stringify(aiResponse));

        var unmaskedText = structuredClone(aiResponse);
        unmaskedText.text.json = structuredClone(unmaskedQuery);

      }
      return { text: aiResponse, unmaskedText };
    } catch (error) {

      logger.ai.error(`Error getting response from ${aiProvider} : ${error.message}`);

      throw error

    }
  }

  async generateCode(aiProvider, model, query, allKeys) {
    try {
      const provider = await AIProviderFactory.createProvider(
        aiProvider
      );
      const prompt = `Made changes in the above function, the example function given in the previous message, check the history. Made chagnes for this query"${query}". And this is my input schema ${allKeys}.`;
      logger.ai.debug(`getCode called with provider: ${aiProvider}, model: ${model}, prompt: ${prompt}`)
      return await provider.getCode(model, prompt);
    } catch (error) {
      logger.ai.error(
        `Error generating code with ${aiProvider} : ${error.message}`
      );
      throw error
    }
  }

  async priorityContext(
    aiProvider,
    model,
    headers,
    query
  ) {
    try {
      const provider = await AIProviderFactory.createProvider(
        aiProvider
      );
      const prompt = `This is the user query: ${query}. This is the keyfields: ${JSON.stringify(headers)}.`;
      logger.ai.debug(`getPriority called with provider: ${aiProvider}, model: ${model}, prompt: ${prompt}`);
      return await provider.getPriorityContext(model, prompt);
    } catch (error) {
      logger.ai.error(
        `Error getting priority context from ${aiProvider} : ${error.message}`
      );
      throw error
    }
  }

  async handleCallTool(
    aiProvider,
    model,
    prompt,
    summary
  ) {
    try {
      const provider = await AIProviderFactory.createProvider(
        aiProvider,
        null,
        summary
      );
      logger.ai.debug(`handleCallTool called with provider: ${aiProvider}, model: ${model}, prompt: ${prompt}`)
      return await provider.handleCallTool(model, prompt);
    } catch (error) {
      logger.ai.error(
        `Error handling call tool from ${aiProvider}  ${error.message}`
      );
      throw error
    }
  }

validateSuggestedQuery(userQuery, text) {
  if (!userQuery || !text || !text.suggestedQuery) return text;

  const suggestedQuery = text.suggestedQuery;

  const quotedValues = [...suggestedQuery.matchAll(/"([^"]+)"/g)]
    .map(m => m[1])
    .filter(v => v !== "...");

  let updatedQuery = userQuery;

  for (const value of quotedValues) {
    const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    const regex = new RegExp(`\\b${escaped}\\b`, "gi");

    if (regex.test(updatedQuery)) {
      updatedQuery = updatedQuery.replace(regex, `"${value}"`);
    }
  }

  text.suggestedQuery = updatedQuery;
  return text;
}

}
const aiService = new AiService();
module.exports = aiService;
