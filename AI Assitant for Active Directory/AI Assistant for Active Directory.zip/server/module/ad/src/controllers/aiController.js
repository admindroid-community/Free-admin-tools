const aiService = require("../services/aiService.js");
const { regexMasking } = require("../../../../util/mask.js");
const {
  changeDN,
  getText,
  getTextCode,
  getCallTool,
  replaceWithLocalTime,
  replaceWithRestrictedMsg,
  validateAICode,
} = require("../../../../util/parse.js");
const { unMaskMacro } = require("../../../../util/unmask.js");
const {
  getLdapFormatedTime,
  getCurrentTimeFormatted,
} = require("../../../../core/src/utils/ldapDataFormat.js");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const providerService = require("../../../../core/src/services/providerService.js");
const { logger } = require("../../../../util/logger.js");
const encryptService = require("../../../../util/encryptService.js");
const LDAPQueryGenerator = require("../services/ldapQueryGenerator.js");

class AiController {
  async generateCode(req, res, next) {
    try {
      const { prompt, provider, model, allKeys } = req.body;

      logger.ai.debug("provider : ", provider, " |prompt : " + prompt);

      let response = await aiService.generateCode(
        provider,
        model,
        prompt,
        allKeys,
      );
      response = getTextCode(response);
      await providerService.updateApiUsage(
        provider,
        response.inputToken,
        response.outputToken,
      );

      let code;
      logger.development.ai.info(`code: ${JSON.stringify(response)}`);

      if (response.text.type === "table") {
        const headers = response.text.code.headers;
        const tableDataFnCode = response.text.code.tableDataFn;

        validateAICode(tableDataFnCode);

        code = `function renderData(data) {
      const container = document.getElementById('responsive-chart-table');
      container.innerHTML = '';

      const rawData = data;

      ${tableDataFnCode};

      if (!sortedData || sortedData.length === 0) {
        const msg = document.createElement('div');
        msg.className = "not-found-msg";   
        msg.textContent = "No record found!";

        container.appendChild(msg);
        return;
      }

      const tableDiv = document.createElement('div');
      tableDiv.className = 'graphical-table';

      const table = document.createElement('table');
      const thead = document.createElement('thead');
      const tbody = document.createElement('tbody');

      const headers = ${JSON.stringify(headers)};
      const headerRow = document.createElement('tr');
      headers.forEach(headerText => {
        const th = document.createElement('th');
        th.textContent = headerText;
        headerRow.appendChild(th);
      });
      thead.appendChild(headerRow);

      sortedData.forEach(item => {
        const row = document.createElement('tr');
        headers.forEach(header => {
          const td = document.createElement('td');
          const rawValue = item?.[header];
          const dataValue = (rawValue === null || rawValue === undefined || rawValue === '')
            ? '-'
            : rawValue.toString();

         if (header === "thumbnailPhoto") {
            if (dataValue && dataValue !== "-") {
              const img = document.createElement("img");
              img.className = "thumbnailPhoto";
              img.setAttribute("src", dataValue);
              td.appendChild(img);
            } else {
              const div = document.createElement("div");
              div.className = "thumbnailPhoto";

              const icon = document.createElement("span");
              icon.className =
                "droid-custom-icon-profile-photo-fill user-not-found";

              div.appendChild(icon);
              td.appendChild(div);
            }
          } else {
            td.textContent = dataValue;
          }
          row.appendChild(td);
        });
        tbody.appendChild(row);
      });

      table.appendChild(thead);
      table.appendChild(tbody);
      tableDiv.appendChild(table);
      container.appendChild(tableDiv);
    }`;
      } else {
        const chartsData = response.text.code.chartsData ?? [];
        const summaryText = response.text.code.summaryText ?? [];

        // const displayNextChart = chartsData.length > 1 ? "inline" : "none";
        const displayNextChart = "none";

        code = `function renderData(data) {
  const chartsData = ${JSON.stringify(chartsData)};
  const summaryText = ${JSON.stringify(summaryText)};
  const container = document.getElementById("responsive-chart-table");
  container.innerHTML = "";

  const chartsWrapper = document.createElement("div");
  chartsWrapper.style.display = "flex";
  chartsWrapper.style.overflowX = "hidden";
  chartsWrapper.style.scrollBehavior = "smooth";
  chartsWrapper.style.width = "100%";
  chartsWrapper.style.flexDirection = "column-reverse";

  const summary = document.createElement("p");
  summary.textContent = summaryText || "";
  summary.style.fontSize = "12px";
  summary.style.borderBottom = "1px solid black";
  summary.style.width = "fit-content";
  summary.style.margin = "auto";
  summary.style.textAlign = "center";
  // chartsWrapper.appendChild(summary);
  container.appendChild(chartsWrapper);

  const canvases = [];
  const colorPalette = [
    "#f72585", "#b5179e", "#7209b7", "#560bad", "#480ca8",
    "#3a0ca3", "#3f37c9", "#4361ee", "#4895ef", "#4cc9f0"
  ];

  chartsData.forEach((item, index) => {
    const chartWrapper = document.createElement("div");
    chartWrapper.style.position = "relative";
    chartWrapper.style.minWidth = "100%";
    chartWrapper.style.flexShrink = 0;
    chartWrapper.style.padding = "10px";
    chartWrapper.style.borderRadius = "8px";

    const serial = document.createElement("div");
    serial.textContent = index + 1;
    serial.style.position = "absolute";
    serial.style.top = "5px";
    serial.style.left = "10px";
    serial.style.backgroundColor = "#ffecb3";
    serial.style.color = "#000";
    serial.style.fontWeight = "bold";
    serial.style.padding = "2px 6px";
    serial.style.borderRadius = "4px";

    if("${displayNextChart}" !== "none"){
      chartWrapper.appendChild(serial);
    }

    const canvas = document.createElement("canvas");
    chartWrapper.appendChild(canvas);
    canvases.push(canvas);

    chartsWrapper.appendChild(chartWrapper);

    const ctx = canvas.getContext("2d");
    const counts = {};

  data.forEach(u => {
  const val = u?.[item.field]?.[0];
  const key = val ? String(val) :\`Without \${item.field}\`;
  counts[key] = (counts[key] || 0) + 1;
  });


    const labels = Object.keys(counts);
    const values = Object.values(counts);
    const chartType = item.type || "bar";

    const dataset = {
      label: item.label,
      data: values
    };

    if (chartType === "bar" || chartType === "doughnut" || chartType === "pie") {
      dataset.backgroundColor = colorPalette;
      dataset.borderColor = "rgba(255,255,255,0.3)";
      dataset.borderWidth = 1;
    }
    if (chartType === "line") {
      dataset.fill = false;
      dataset.borderColor = colorPalette[0];
      dataset.tension = 0.3;
    }

    new Chart(ctx, {
      type: chartType,
      data: {
        labels: labels,
        datasets: [dataset]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true },
          title: {
            display: true,
            text: item.label,
            color: "black",
            font: { size: 16, weight: "bold" },
            padding: { top: 10, bottom: 10 }
          }
        }
      }
    });

  });

  const prevBtn = document.createElement("button");
  prevBtn.textContent = "Previous";
  prevBtn.style.marginRight = "10px";
  prevBtn.style.padding = "6px 12px";
  prevBtn.style.border = "none";
  prevBtn.style.borderRadius = "4px";
  prevBtn.style.backgroundColor = "#3a0ca3";
  prevBtn.style.color = "#fff";
  prevBtn.style.cursor = "pointer";

  const nextBtn = document.createElement("button");
  nextBtn.textContent = "Next";
  nextBtn.style.padding = "6px 12px";
  nextBtn.style.border = "none";
  nextBtn.style.borderRadius = "4px";
  nextBtn.style.backgroundColor = "#4361ee";
  nextBtn.style.color = "#fff";
  nextBtn.style.cursor = "pointer"; 

  if("${displayNextChart}" !== "none"){
    container.appendChild(prevBtn);
    container.appendChild(nextBtn);
  }

  let current = 0;

  function showChart(i) {
    const offset = i * chartsWrapper.clientWidth;
    chartsWrapper.scrollLeft = offset;
  }

  prevBtn.onclick = () => {
    current = (current - 1 + canvases.length) % canvases.length;
    showChart(current);
  };

  nextBtn.onclick = () => {
    current = (current + 1) % canvases.length;
    showChart(current);
  };
}
`;
      }
      return res.json({
        code: code,
        type: response.text.type,
        tokenCount: response.inputToken + response.outputToken,
      });

      // return res.json({
      //   code: response.text.code,
      //   type: response.text.type,
      //   tokenCount: response.inputToken + response.outputToken,
      // });
    } catch (error) {
      await this.handleError(error, this.generateCode, req, res, next);
    }
  }

  async getResponse(req, res, next) {
    try {
      // const ldapForamtedTimeStamp = getLdapFormatedTime();
      // const currentTimeStamp = `ldapGeneralizedTime = ${ldapForamtedTimeStamp.ldapGeneralizedTime} and ldapFileTime = ${ldapForamtedTimeStamp.ldapFileTime}`;
      const currentTimeStamp = getCurrentTimeFormatted();

      if (!req.session.ad_user) {
        sendAndLogError(
          logger.ldap,
          "Missing Bind DN.",
          401,
          "Session Closed, Please Login again.",
        );
      }

      const {
        prompt,
        provider,
        model,
        isMasked,
        isSmarterRetry,
        history,
        historyMaskValues,
      } = req.body;

      const userBindID = req.params.userBindID;
      const selectedProfile = (req.session.ad_user ?? []).find(profile => profile.userBindID === userBindID);

      if (!selectedProfile) {
        sendAndLogError(logger.ldap, "Missing Selected Domain", 400, "Kindly select the domain you want to perform actions");
      }

      const data = {
        ldapURL: selectedProfile.ldapURL,
        bindDN: selectedProfile.bindDN,
        bindPassword: encryptService.decrypt(selectedProfile.bindPassword),
        domainName: selectedProfile.domainName
      };

      const domainName = (req.session.ad_user ?? []).find(
        (profile) => profile.userBindID === userBindID,
      )?.domainName;

      let maskedQuery, maskingHistory, maskingSuggestion;

      if (isMasked && !isSmarterRetry) {
        const maskedResult = regexMasking(prompt, historyMaskValues);
        maskingHistory = maskedResult.history;
        maskedQuery = maskedResult.current;
      } else {
        maskingHistory = historyMaskValues;
        maskedQuery = { template: prompt, values: {} };
      }

      logger.testing.ldap.debug("maskingHistory : " + JSON.stringify(maskingHistory));
      logger.testing.ldap.debug("maskedQuery : " + JSON.stringify(maskedQuery));


      if (history?.length === 0) LDAPQueryGenerator.clearUPNCache();

      var { text, unmaskedText } = await aiService.getResponse(
        provider,
        model,
        maskedQuery.template,
        currentTimeStamp,
        history,
        { bindData: data, maskingHistory: maskingHistory.values }
      );

      logger.testing.ai.debug("outside text: " + JSON.stringify(text));
      logger.testing.ai.debug("outside unmaskedText: " + JSON.stringify(unmaskedText));

      await providerService.updateApiUsage(
        provider,
        text.inputToken,
        text.outputToken,
      );

      if (text.error) {
        sendAndLogError(
          logger.ai,
          "Search Unsuccessful",
          422,
          "Request understood but could not retrieve meaningful data",
        );
      } else {
        // unmaskedText = await unMaskMacro(
        //   JSON.stringify(unmaskedText),
        //   maskingHistory.values,
        // );
        // unmaskedText = JSON.parse(unmaskedText);


        let attempts = 0;
        const maxAttempts = 2;

        while (attempts < maxAttempts) {
          try {
            unmaskedText = await unMaskMacro(
              JSON.stringify(unmaskedText),
              maskingHistory.values
            );

            unmaskedText = JSON.parse(unmaskedText);

            break;

          } catch (err) {

            if (
              attempts === 0 &&
              err.message &&
              err.message.includes("Unclosed")
            ) {
              logger.ai.debug("Fixing unclosed macro and retrying...");

              if (typeof unmaskedText === "string") {
                unmaskedText = unmaskedText
                  .replace(/\{\{\{([^}]+)\}\]/g, "{{$1}}}")
                  .replace(/\{\{\{([^}]*)$/g, "{{$1}}}");
              }

              attempts++;
              continue;
            }

            sendAndLogError(
              logger.ai,
              "Search Unsuccessful",
              422,
              "Request understood but could not retrieve meaningful data",
            );

          }
        }


        if (!isSmarterRetry) {
          const suggestionMaskResult = regexMasking(
            getText(text).suggestedQuery,
            {}
          );
          const suggestedMaskedQueryValues =
            suggestionMaskResult.current.values;
          const suggestedNewMaskedQueryValues = Object.fromEntries(
            Object.entries(suggestedMaskedQueryValues).filter(([k, v]) => {
              return !(
                typeof v === "string" &&
                ((v.includes("{{{") &&
                  v.includes("}}}")) ||
                  (v.includes("{{") &&
                    v.includes("}}"))
                )
              );
            }),
          );
          maskingSuggestion = {
            text: unmaskedText.text.suggestedQuery,
            values: suggestedNewMaskedQueryValues,
          };
        }
        unmaskedText = changeDN(domainName, unmaskedText);
        unmaskedText = replaceWithLocalTime(unmaskedText);
        // unmaskedText = replaceWithRestrictedMsg(unmaskedText);
        res.json({
          text: getText(text),
          unmaskedText: getText(unmaskedText),
          maskedQuery,
          tokenCount: text.inputToken + text.outputToken,
          maskingHistory: maskingHistory || {},
          maskingSuggestion: maskingSuggestion || {},
          history: text.history,
        });
      }
    } catch (error) {
      return next(error);
      // await this.handleError(error, this.getResponse, req, res, next);
    }
  }

  async priorityContext(req, res, next) {
    try {
      const { provider, model, headers, query } = req.body;

      const response = await aiService.priorityContext(
        provider,
        model,
        headers,
        query,
      );
      await providerService.updateApiUsage(
        provider,
        response.inputToken,
        response.outputToken,
      );

      return res.json({
        priorityKeys: response.text,
        tokenCount: response.inputToken + response.outputToken,
      });
    } catch (error) {
      return next(error);
      // await this.handleError(error, this.priorityContext, req, res, next);
    }
  }

  async handleCallTool(req, res, next) {
    try {
      const { provider, model, prompt, summary } = req.body;

      const response = await aiService.handleCallTool(
        provider,
        model,
        prompt,
        summary,
      );
      await providerService.updateApiUsage(
        provider,
        response.inputToken,
        response.outputToken,
      );

      return res.json({
        callTool: getCallTool(response),
        tokenCount: response.inputToken + response.outputToken,
      });
    } catch (error) {
      return next(error);
      // await this.handleError(error, this.handleCallTool, req, res, next);
    }
  }

  async handleError(error, fn, req, res, next) {
    if (error.statusCode === 429) {
      const { provider } = req.body;
      const keySwitchResult = await providerService.switchApiKey(provider);
      if (keySwitchResult) {
        logger.apikey.info(provider + " api key switched");
        return fn(req, res, next);
      } else {
        return next(error);
      }
    } else {
      return next(error);
    }
  }
}

module.exports = new AiController();
