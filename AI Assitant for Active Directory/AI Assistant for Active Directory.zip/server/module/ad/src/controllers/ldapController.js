const encryptService = require("../../../../util/encryptService.js");
const ldapService = require("../services/ldapService.js");
const { sendAndLogError } = require("../../../../util/errorResponse.js");
const { logger } = require("../../../../util/logger.js");

class LDAPController {

  async executeLDAPRequest(req, res, next) {
    try {
      if (!req.session.ad_user) {
        sendAndLogError(logger.ldap, "Missing Bind DN.", 401, "Session Closed, Please Loggin again.");
      }

      const userBindID = req.params.userBindID;
      const paginationId = Number(req.query.paginationId ?? 0);
      var pageSize = Number(req.query.pageSize ?? 20);
      var sortLimit = Number(req.query.sortLimit ?? 2000);
      const selectedProfile = (req.session.ad_user ?? []).find(profile => profile.userBindID === userBindID);

      pageSize = Math.min(pageSize, 10000);
      sortLimit = Math.min(sortLimit, 2000);

      if (!selectedProfile) {
        sendAndLogError(logger.ldap, "Missing Selected Domain", 400, "Kindly select the domain you want to perform actions");
      }

      const params = {
        action: req.body,
        paginationId: paginationId,
        pageSize: pageSize,
        sortLimit: sortLimit,
        credentials: {
          ldapURL: selectedProfile.ldapURL,
          bindDN: selectedProfile.bindDN,
          bindPassword: encryptService.decrypt(selectedProfile.bindPassword)
        },
      };
      // const response = await ldapService.processLdapQuery(params, false, []);
      const response = await ldapService.recursiveSearch(params, false, []);
      res.json(response);
    } catch (error) {
      next(error);
    }
  }

  async getThumbnailPhoto(req, res, next) {
    try {
      const { username } = req.body;
      if (!req.session.ad_user) {
        sendAndLogError(logger.ldap, "Missing Bind DN.", 401, "Session Closed, Please Loggin again.");
      }

      const userBindID = req.params.userBindID;
      const selectedProfile = (req.session.ad_user ?? []).find(profile => profile.userBindID === userBindID);

      if (!selectedProfile) {
        sendAndLogError(logger.ldap, "Missing Selected Domain", 400, "Kindly select the domain you want to perform actions");
      }

      const data = {
        ldapURL: selectedProfile.ldapURL,
        bindDN: selectedProfile.bindDN,
        bindPassword: encryptService.decrypt(selectedProfile.bindPassword),
        domainName: selectedProfile.domainName
      };
      const response = await ldapService.getThumbnailPhoto(data, username);
      res.json(response);
    } catch (error) {
      next(error);
    }
  }

}

module.exports = new LDAPController();
